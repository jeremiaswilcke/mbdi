# Isidor Suite

**Isidor OS — Umfassende Pfarr-Management-Suite für WordPress**

Entwickelt von [Wilcke Worte & Visionen](https://wilcke-wuv.at) für katholische Pfarrgemeinden in Österreich.

## Module

| Modul | Beschreibung |
|-------|-------------|
| **Liturgus** | Diensteplanung für Gottesdienste (Lektor, Kommunionhelfer, Technik, etc.) |
| **Cantus** | Liedverwaltung und Liedplan-Erstellung |
| **Consilium** | Sitzungsmanagement für PGR/VVR mit RSVP, Abstimmungen und Protokoll |
| **Cellerar** | Finanzverwaltung (Einnahmen, Ausgaben, Berichte) |
| **Agenda** | Raum- und Terminbuchung |
| **Liturgia** | Liturgische Planung und Gottesdienstgestaltung |
| **Sakristan** | Sakristei-Verwaltung |
| **Tagesplan** | Tagesübersicht für die Pfarre |

## Systemanforderungen

- WordPress 6.0+
- PHP 8.0+
- MySQL 5.7+ / MariaDB 10.3+

## Installation

1. ZIP-Datei herunterladen (GitHub Release)
2. WordPress Admin → Plugins → Installieren → Plugin hochladen
3. Plugin aktivieren
4. Unter **Isidor OS → Einstellungen** Module aktivieren

## Auto-Updates

Das Plugin unterstützt automatische Updates über GitHub Releases. Dafür in `wp-config.php` eintragen:

```php
define('ISIDOR_GITHUB_USER', 'dein-github-username');
define('ISIDOR_GITHUB_REPO', 'isidor-suite');
define('ISIDOR_GITHUB_TOKEN', 'ghp_dein_token'); // Nur für private Repos
```

Updates erscheinen dann automatisch im WordPress Dashboard.

## Neues Release erstellen

1. Version in `isidor-suite.php` (Header: `Version:`) anpassen
2. Commit & Push
3. Auf GitHub: Releases → New Release
4. Tag: Versionsnummer (z.B. `12.0.0`)
5. ZIP als Asset anhängen
6. Release veröffentlichen

## Lizenz

Proprietär — © 2026 Wilcke Worte & Visionen. Alle Rechte vorbehalten.
