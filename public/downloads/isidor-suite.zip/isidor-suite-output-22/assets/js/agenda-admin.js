function agendaApproveSlot(id) {
    if (!confirm('Wirklich genehmigen?')) return;
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_approve_slot',
        nonce: agendaData.nonce,
        slot_id: id
    }, function(r) {
        alert(r.data.message);
        location.reload();
    });
}
function agendaRejectSlot(id) {
    if (!confirm('Wirklich ablehnen?')) return;
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_reject_slot',
        nonce: agendaData.nonce,
        slot_id: id
    }, function(r) {
        alert(r.data.message);
        location.reload();
    });
}

// Series Management
function agendaOpenSeriesForm() {
    document.getElementById('agenda-series-modal').style.display = 'block';
    document.getElementById('agenda-series-overlay').style.display = 'block';
}

function agendaCloseSeriesForm() {
    document.getElementById('agenda-series-modal').style.display = 'none';
    document.getElementById('agenda-series-overlay').style.display = 'none';
}

function agendaSubmitSeries(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    formData.append('action', 'agenda_create_series');
    
    jQuery.post(agendaData.ajaxUrl, Object.fromEntries(formData), function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}

function agendaToggleAnnouncement(seriesId, ready) {
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_toggle_announcement',
        nonce: agendaData.nonce,
        series_id: seriesId,
        ready: ready
    }, function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}

function agendaToggleInstance(instanceId, cancelled) {
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_toggle_instance',
        nonce: agendaData.nonce,
        instance_id: instanceId,
        cancelled: cancelled
    }, function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}

function agendaCancelInstance(instanceId) {
    const reason = prompt('Grund für Absage:');
    if (!reason) return;
    
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_toggle_instance',
        nonce: agendaData.nonce,
        instance_id: instanceId,
        cancelled: true,
        reason: reason
    }, function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}

// Events Management
function agendaOpenEventForm() {
    document.getElementById('agenda-event-modal').style.display = 'block';
    document.getElementById('agenda-event-overlay').style.display = 'block';
}

function agendaCloseEventForm() {
    document.getElementById('agenda-event-modal').style.display = 'none';
    document.getElementById('agenda-event-overlay').style.display = 'none';
}

function agendaSubmitEvent(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    formData.append('action', 'agenda_create_event');
    
    jQuery.post(agendaData.ajaxUrl, Object.fromEntries(formData), function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}

function agendaToggleEventAnnouncement(eventId, ready) {
    jQuery.post(agendaData.ajaxUrl, {
        action: 'agenda_toggle_event_announcement',
        nonce: agendaData.nonce,
        event_id: eventId,
        ready: ready
    }, function(r) {
        if (r.success) {
            alert(r.data.message);
            location.reload();
        } else {
            alert('Fehler: ' + r.data.message);
        }
    });
}
