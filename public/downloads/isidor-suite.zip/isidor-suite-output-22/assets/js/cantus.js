/**
 * Cantus Frontend JS — Liedplanung
 */

let currentCatalogSlot = null;

/* ================================================================
   Toast Notification System
   ================================================================ */
function cantusToast(message, type) {
    type = type || 'success';
    const container = document.getElementById('cantus-toast');
    if (!container) return;
    
    const msg = document.createElement('div');
    msg.className = 'cantus-toast-msg cantus-toast-' + type;
    msg.textContent = message;
    container.appendChild(msg);
    
    // Entfernen nach Animation
    setTimeout(function() { msg.remove(); }, 2600);
}

/* ================================================================
   Init
   ================================================================ */
jQuery(document).ready(function($) {
    
    // Typ-Pill Click
    $(document).on('change', 'input[name^="type_"]', function() {
        var slot = $(this).closest('.cantus-slot');
        var type = $(this).val();
        var inputs = slot.find('.cantus-inputs');
        
        inputs.attr('data-type', type);
        
        // Pill-Active umschalten
        slot.find('.cantus-pill').removeClass('cantus-pill-active');
        $(this).closest('.cantus-pill').addClass('cantus-pill-active');
        
        // Title-Hint leeren bei Typ-Wechsel
        var slotKey = slot.attr('data-slot');
        var hint = document.getElementById('hint_' + slotKey);
        if (hint && type === 'free') hint.textContent = '';
    });
    
    // Live Title Lookup — debounced
    var lookupTimers = {};
    $(document).on('input', '.cantus-number', function() {
        var slot = $(this).closest('.cantus-slot');
        var slotKey = slot.attr('data-slot');
        var number = $(this).val().trim();
        var typeEl = slot.find('input[name="type_' + slotKey + '"]:checked');
        var type = typeEl.length ? typeEl.val() : 'gl';
        var hint = document.getElementById('hint_' + slotKey);
        
        if (!hint) return;
        
        // Debounce: 400ms warten
        if (lookupTimers[slotKey]) clearTimeout(lookupTimers[slotKey]);
        
        if (!number) {
            hint.textContent = '';
            return;
        }
        
        lookupTimers[slotKey] = setTimeout(function() {
            var data = new FormData();
            data.append('action', 'cantus_lookup_title');
            data.append('nonce', cantusData.nonce);
            data.append('type', type);
            data.append('number', number);
            
            fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
            .then(function(r) { return r.json(); })
            .then(function(result) {
                if (result.success && result.data.short) {
                    hint.textContent = result.data.short;
                    hint.style.color = '#16a34a';
                    setTimeout(function() { hint.style.color = ''; }, 1500);
                } else {
                    hint.textContent = number ? '(nicht im Katalog)' : '';
                    hint.style.color = '#94a3b8';
                }
            });
        }, 400);
    });
    
    // Free Song Select
    $(document).on('change', '.cantus-free-select', function() {
        var slot = $(this).closest('.cantus-slot');
        var value = $(this).val();
        
        if (value === '__custom__') {
            slot.find('.cantus-free-title').show().focus();
        } else if (value) {
            slot.find('.cantus-free-title').val(value).hide();
        } else {
            slot.find('.cantus-free-title').val('').show();
        }
    });
    
    // Initial State: Free-Selects
    $('.cantus-slot').each(function() {
        var inputs = $(this).find('.cantus-inputs');
        var type = inputs.attr('data-type');
        
        if (type === 'free') {
            var select = $(this).find('.cantus-free-select');
            var title = $(this).find('.cantus-free-title');
            
            if (select.length && select.val() && select.val() !== '__custom__') {
                title.hide();
            }
        }
    });
    
    // Enter im Suchfeld → suchen
    $(document).on('keypress', '#catalog-search', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            searchCatalog();
        }
    });
    
    // Keyboard: Escape schließt Modal
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            closeCatalogModal();
        }
    });
});

/* ================================================================
   Save / Delete
   ================================================================ */
function cantusSave(messeId, slotKey) {
    var slot = document.querySelector('.cantus-slot[data-slot="' + slotKey + '"]');
    if (!slot) return;
    
    var typeEl = slot.querySelector('input[name="type_' + slotKey + '"]:checked');
    var type = typeEl ? typeEl.value : 'gl';
    var number = slot.querySelector('input[name="number_' + slotKey + '"]').value;
    var strophes = slot.querySelector('input[name="strophes_' + slotKey + '"]').value;
    var freeTitle = slot.querySelector('input[name="free_title_' + slotKey + '"]').value;
    
    // Validation
    if (type !== 'free' && !number) {
        cantusToast('Bitte eine Nummer eingeben', 'error');
        slot.querySelector('input[name="number_' + slotKey + '"]').focus();
        return;
    }
    if (type === 'free' && !freeTitle) {
        cantusToast('Bitte einen Liedtitel eingeben', 'error');
        slot.querySelector('input[name="free_title_' + slotKey + '"]').focus();
        return;
    }
    
    // Save-Button disabled
    var btn = slot.querySelector('.cantus-btn-slot-save');
    if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
    
    var data = new FormData();
    data.append('action', 'cantus_save_song');
    data.append('nonce', cantusData.nonce);
    data.append('messe_id', messeId);
    data.append('slot_key', slotKey);
    data.append('type', type);
    data.append('number', number);
    data.append('strophes', strophes);
    data.append('free_title', freeTitle);
    
    fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
    .then(function(r) { return r.json(); })
    .then(function(result) {
        if (btn) { btn.disabled = false; btn.textContent = '💾 Speichern'; }
        
        if (result.success) {
            var label = result.data.label || ('Slot ' + slotKey);
            cantusToast('✓ ' + label + ' gespeichert');
            
            // Titel-Hint aktualisieren
            var hint = document.getElementById('hint_' + slotKey);
            if (hint && result.data.song_short) {
                hint.textContent = result.data.song_short;
            }
            
            // Visuell als befüllt markieren
            slot.classList.remove('cantus-slot-empty');
            slot.classList.add('cantus-slot-filled');
            
            // Checkmark setzen
            var header = slot.querySelector('.cantus-slot-header');
            if (!header.querySelector('.cantus-slot-check')) {
                var check = document.createElement('span');
                check.className = 'cantus-slot-check';
                check.textContent = '✓';
                header.appendChild(check);
            }
            
            // Löschen-Button einblenden wenn noch nicht da
            var actions = slot.querySelector('.cantus-slot-actions');
            if (!actions.querySelector('.cantus-btn-slot-delete')) {
                var delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'cantus-btn-slot-delete';
                delBtn.textContent = '🗑';
                delBtn.onclick = function() { cantusDelete(messeId, slotKey); };
                actions.appendChild(delBtn);
            }
            
            updateFillCounter();
        } else {
            cantusToast('Fehler: ' + (result.data.message || 'Unbekannt'), 'error');
        }
    })
    .catch(function(err) {
        if (btn) { btn.disabled = false; btn.textContent = '💾 Speichern'; }
        cantusToast('Netzwerkfehler', 'error');
    });
}

function cantusSaveAll() {
    var slots = document.querySelectorAll('.cantus-slot');
    var toSave = [];
    
    slots.forEach(function(slot) {
        var slotKey = slot.getAttribute('data-slot');
        var messeId = slot.getAttribute('data-messe');
        var typeEl = slot.querySelector('input[name="type_' + slotKey + '"]:checked');
        var type = typeEl ? typeEl.value : 'gl';
        var number = slot.querySelector('input[name="number_' + slotKey + '"]').value;
        var freeTitle = slot.querySelector('input[name="free_title_' + slotKey + '"]').value;
        
        // Nur nicht-leere Slots
        if ((type !== 'free' && number) || (type === 'free' && freeTitle)) {
            toSave.push({ messeId: messeId, slotKey: slotKey });
        }
    });
    
    if (toSave.length === 0) {
        cantusToast('Keine Daten zum Speichern', 'info');
        return;
    }
    
    var saved = 0;
    var total = toSave.length;
    
    cantusToast('Speichere ' + total + ' Lieder…', 'info');
    
    toSave.forEach(function(item) {
        var slot = document.querySelector('.cantus-slot[data-slot="' + item.slotKey + '"]');
        var slotKey = item.slotKey;
        
        var typeEl = slot.querySelector('input[name="type_' + slotKey + '"]:checked');
        var data = new FormData();
        data.append('action', 'cantus_save_song');
        data.append('nonce', cantusData.nonce);
        data.append('messe_id', item.messeId);
        data.append('slot_key', slotKey);
        data.append('type', typeEl ? typeEl.value : 'gl');
        data.append('number', slot.querySelector('input[name="number_' + slotKey + '"]').value);
        data.append('strophes', slot.querySelector('input[name="strophes_' + slotKey + '"]').value);
        data.append('free_title', slot.querySelector('input[name="free_title_' + slotKey + '"]').value);
        
        fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
        .then(function(r) { return r.json(); })
        .then(function(result) {
            saved++;
            if (result.success) {
                slot.classList.remove('cantus-slot-empty');
                slot.classList.add('cantus-slot-filled');
            }
            if (saved === total) {
                cantusToast('✓ Alle ' + total + ' Lieder gespeichert');
                updateFillCounter();
            }
        });
    });
}

function cantusDelete(messeId, slotKey) {
    if (!confirm('Lied für diesen Slot löschen?')) return;
    
    var slot = document.querySelector('.cantus-slot[data-slot="' + slotKey + '"]');
    
    var data = new FormData();
    data.append('action', 'cantus_delete_song');
    data.append('nonce', cantusData.nonce);
    data.append('messe_id', messeId);
    data.append('slot_key', slotKey);
    
    fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
    .then(function(r) { return r.json(); })
    .then(function(result) {
        if (result.success) {
            var label = result.data.label || ('Slot ' + slotKey);
            cantusToast(label + ' gelöscht', 'info');
            
            // Felder leeren
            if (slot) {
                slot.querySelector('input[name="number_' + slotKey + '"]').value = '';
                slot.querySelector('input[name="strophes_' + slotKey + '"]').value = '';
                slot.querySelector('input[name="free_title_' + slotKey + '"]').value = '';
                
                // Visuell leer markieren
                slot.classList.remove('cantus-slot-filled');
                slot.classList.add('cantus-slot-empty');
                
                var check = slot.querySelector('.cantus-slot-check');
                if (check) check.remove();
                
                var delBtn = slot.querySelector('.cantus-btn-slot-delete');
                if (delBtn) delBtn.remove();
            }
            
            updateFillCounter();
        } else {
            cantusToast('Fehler beim Löschen', 'error');
        }
    });
}

/* ================================================================
   Fill Counter aktualisieren
   ================================================================ */
function updateFillCounter() {
    var filled = document.querySelectorAll('.cantus-slot-filled').length;
    var counter = document.querySelector('.cantus-fill-status');
    if (counter) {
        counter.textContent = filled + '/11';
    }
}

/* ================================================================
   Katalog-Modal
   ================================================================ */
function openCatalogModal(slotKey, slotName) {
    currentCatalogSlot = slotKey;
    
    var modal = document.getElementById('cantus-catalog-modal');
    var title = document.getElementById('catalog-modal-title');
    
    title.textContent = 'Lied wählen: ' + slotKey + '. ' + slotName;
    
    resetCatalogFilters();
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    // Focus auf Suchfeld
    setTimeout(function() {
        var search = document.getElementById('catalog-search');
        if (search) search.focus();
    }, 100);
}

function closeCatalogModal() {
    var modal = document.getElementById('cantus-catalog-modal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
    currentCatalogSlot = null;
}

function resetCatalogFilters() {
    var s = document.getElementById('catalog-search');
    if (s) s.value = '';
    var m = document.getElementById('catalog-filter-mass');
    if (m) m.value = '';
    var g = document.getElementById('catalog-filter-genre');
    if (g) g.value = '';
    var t = document.getElementById('catalog-filter-tag');
    if (t) t.value = '';
    
    var results = document.getElementById('catalog-results');
    if (results) results.innerHTML = '<p class="cantus-catalog-placeholder">Filter setzen und „Suchen" klicken</p>';
    
    var info = document.getElementById('catalog-results-info');
    if (info) info.textContent = '';
}

function searchCatalog() {
    var query = document.getElementById('catalog-search').value.trim();
    var mass = document.getElementById('catalog-filter-mass').value;
    var genre = document.getElementById('catalog-filter-genre').value;
    var tag = document.getElementById('catalog-filter-tag').value;
    
    var slot = document.querySelector('.cantus-slot[data-slot="' + currentCatalogSlot + '"]');
    var typeEl = slot ? slot.querySelector('input[name^="type_"]:checked') : null;
    var type = typeEl ? typeEl.value : 'gl';
    
    var data = new FormData();
    data.append('action', 'cantus_catalog_search');
    data.append('nonce', cantusData.nonce);
    data.append('q', query);
    data.append('mass', mass);
    data.append('genre', genre);
    data.append('tag', tag);
    data.append('type', type);
    
    var resultsDiv = document.getElementById('catalog-results');
    var infoDiv = document.getElementById('catalog-results-info');
    
    resultsDiv.innerHTML = '<p class="cantus-catalog-loading">🔍 Suche läuft…</p>';
    infoDiv.textContent = '';
    
    fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
    .then(function(r) { return r.json(); })
    .then(function(result) {
        if (result.success) {
            displayCatalogResults(result.data.results);
        } else {
            resultsDiv.innerHTML = '<p class="cantus-catalog-error">Fehler bei der Suche</p>';
        }
    })
    .catch(function() {
        resultsDiv.innerHTML = '<p class="cantus-catalog-error">Netzwerkfehler</p>';
    });
}

function displayCatalogResults(results) {
    var resultsDiv = document.getElementById('catalog-results');
    var infoDiv = document.getElementById('catalog-results-info');
    
    if (!results || results.length === 0) {
        resultsDiv.innerHTML = '<p class="cantus-catalog-empty">Keine Treffer</p>';
        infoDiv.textContent = '0 Treffer';
        return;
    }
    
    infoDiv.textContent = results.length + ' Treffer' + (results.length >= 50 ? ' (max. 50)' : '');
    
    var html = '<div class="cantus-catalog-list">';
    results.forEach(function(item) {
        var nr = item.nr_raw || '?';
        var title = item.title || '(ohne Titel)';
        var tags = item.tags ? '<span class="cantus-result-tags">' + escapeHtml(item.tags) + '</span>' : '';
        
        html += '<div class="cantus-catalog-item" onclick="selectCatalogItem(\'' + escapeHtml(nr) + '\')">'
            + '<div class="cantus-result-number">' + escapeHtml(nr) + '</div>'
            + '<div class="cantus-result-info">'
            + '<div class="cantus-result-title">' + escapeHtml(title) + '</div>'
            + tags
            + '</div></div>';
    });
    html += '</div>';
    resultsDiv.innerHTML = html;
}

function selectCatalogItem(nrRaw) {
    if (!currentCatalogSlot) return;
    
    var numberInput = document.querySelector('input[name="number_' + currentCatalogSlot + '"]');
    if (numberInput) {
        numberInput.value = nrRaw;
        numberInput.focus();
        
        // Visuelles Feedback
        numberInput.style.borderColor = '#16a34a';
        setTimeout(function() { numberInput.style.borderColor = ''; }, 1500);
        
        // Live-Lookup triggern für Titel-Hint
        numberInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    cantusToast('📖 ' + nrRaw + ' übernommen');
    closeCatalogModal();
}

function escapeHtml(text) {
    var map = { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":"&#039;" };
    return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}

/* ================================================================
   Liedsuche — [cantus_search] Frontend
   Live-Suche nach Titel mit debounced AJAX
   ================================================================ */
(function() {
    var searchTimer = null;

    document.addEventListener('DOMContentLoaded', function() {
        var input = document.getElementById('cantus-search-input');
        if (!input) return;

        input.addEventListener('input', function() {
            var q = this.value.trim();
            if (searchTimer) clearTimeout(searchTimer);

            if (q.length < 2) {
                renderSearchResults([]);
                return;
            }

            showSearchSpinner(true);

            searchTimer = setTimeout(function() {
                var data = new FormData();
                data.append('action', 'cantus_title_search');
                data.append('nonce', cantusData.nonce);
                data.append('q', q);

                fetch(cantusData.ajaxUrl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(result) {
                    showSearchSpinner(false);
                    if (result.success) {
                        renderSearchResults(result.data.results, q);
                    }
                })
                .catch(function() {
                    showSearchSpinner(false);
                });
            }, 300);
        });

        // Enter unterdrücken
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') e.preventDefault();
        });
    });

    function showSearchSpinner(show) {
        var el = document.getElementById('cantus-search-spinner');
        if (el) el.style.display = show ? 'inline' : 'none';
    }

    function renderSearchResults(results, query) {
        var container = document.getElementById('cantus-search-results');
        if (!container) return;

        if (!results || results.length === 0) {
            if (query && query.length >= 2) {
                container.innerHTML = '<div class="cantus-search-empty">Keine Treffer für „' + escapeHtml(query) + '"</div>';
            } else {
                container.innerHTML = '';
            }
            return;
        }

        var html = '<div class="cantus-search-count">' + results.length + ' Treffer' + (results.length >= 25 ? ' (max.)' : '') + '</div>';
        html += '<div class="cantus-search-list">';

        results.forEach(function(item) {
            var nr = item.nr_raw || '?';
            var type = (item.type || 'gl').toUpperCase();
            var title = item.title || '(ohne Titel)';
            var genre = item.genre ? '<span class="cantus-search-genre">' + escapeHtml(item.genre) + '</span>' : '';
            var composer = item.composer ? '<span class="cantus-search-composer">' + escapeHtml(item.composer) + '</span>' : '';

            // Suchbegriff im Titel hervorheben
            var highlighted = highlightMatch(title, query);

            html += '<div class="cantus-search-item">'
                + '<div class="cantus-search-nr">'
                + '<span class="cantus-search-type">' + escapeHtml(type) + '</span>'
                + '<span class="cantus-search-number">' + escapeHtml(nr) + '</span>'
                + '</div>'
                + '<div class="cantus-search-info">'
                + '<div class="cantus-search-title">' + highlighted + '</div>'
                + '<div class="cantus-search-meta">' + genre + composer + '</div>'
                + '</div>'
                + '</div>';
        });

        html += '</div>';
        container.innerHTML = html;
    }

    function highlightMatch(text, query) {
        if (!query) return escapeHtml(text);
        var escaped = escapeHtml(text);
        var qEsc = escapeHtml(query).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var re = new RegExp('(' + qEsc + ')', 'gi');
        return escaped.replace(re, '<mark>$1</mark>');
    }
})();
