/**
 * Isidor Cellerar Frontend JavaScript
 */
(function($) {
    'use strict';

    const IC = {
        config: window.isidorCellerar || {},
        
        init: function() {
            this.bindEvents();
            this.initTabs();
        },

        bindEvents: function() {
            $(document).on('click', '.ic-tab', this.handleTabClick.bind(this));
            $(document).on('submit', '#ic-income-form', this.handleIncomeSubmit.bind(this));
            $(document).on('change', '#ic-income-subtype', this.handleSubtypeChange.bind(this));
            $(document).on('submit', '#ic-expense-form', this.handleExpenseSubmit.bind(this));
            $(document).on('change', '#ic-expense-file', this.handleFileSelect.bind(this));
            $(document).on('submit', '#ic-export-form', this.handleExport.bind(this));
            $(document).on('click', '#ic-income-filter-apply', this.loadIncomeList.bind(this));
            $(document).on('click', '#ic-stats-filter-apply', this.loadStats.bind(this));
            $(document).on('click', '.ic-action-delete', this.handleDelete.bind(this));
            $(document).on('click', '.ic-action-status', this.handleStatusChange.bind(this));
            $(document).on('click', '.ic-modal-overlay, .ic-modal-close', this.closeModal.bind(this));
        },

        initTabs: function() {
            const firstTab = $('.ic-tab.active').data('tab');
            if (firstTab) this.activateTab(firstTab);
        },

        handleTabClick: function(e) {
            this.activateTab($(e.currentTarget).data('tab'));
        },

        activateTab: function(tab) {
            $('.ic-tab').removeClass('active').attr('aria-selected', 'false');
            $('.ic-tab[data-tab="' + tab + '"]').addClass('active').attr('aria-selected', 'true');
            $('.ic-panel').removeClass('active');
            $('#ic-panel-' + tab).addClass('active');
            
            switch(tab) {
                case 'income': this.loadIncomeList(); this.loadMessen(); break;
                case 'expenses': this.loadMySubmissions(); if (this.config.currentUser.canApprove) this.loadPendingExpenses(); break;
                case 'stats': this.loadStats(); break;
            }
        },

        api: function(endpoint, method, data) {
            const opts = {
                url: this.config.restUrl + endpoint,
                method: method || 'GET',
                headers: { 'X-WP-Nonce': this.config.restNonce },
                dataType: 'json'
            };
            if (data) {
                if (data instanceof FormData) {
                    opts.data = data;
                    opts.processData = false;
                    opts.contentType = false;
                } else {
                    opts.data = JSON.stringify(data);
                    opts.contentType = 'application/json';
                }
            }
            return $.ajax(opts);
        },

        handleIncomeSubmit: function(e) {
            e.preventDefault();
            const $form = $(e.target);
            const $btn = $form.find('button[type="submit"]').prop('disabled', true);
            
            const data = {
                subtype: $form.find('[name="subtype"]').val(),
                entry_date: $form.find('[name="entry_date"]').val(),
                amount: $form.find('[name="amount"]').val(),
                messe_id: $form.find('[name="messe_id"]').val() || null,
                category: $form.find('[name="category"]').val() || null,
                note: $form.find('[name="note"]').val() || ''
            };

            this.api('income', 'POST', data)
                .done(res => {
                    if (res.success) {
                        this.toast('Einnahme gespeichert!', 'success');
                        $form[0].reset();
                        $form.find('[name="entry_date"]').val(new Date().toISOString().split('T')[0]);
                        this.handleSubtypeChange();
                        this.loadIncomeList();
                    } else {
                        this.toast(res.error || 'Fehler beim Speichern', 'error');
                    }
                })
                .fail(() => this.toast('Fehler beim Speichern', 'error'))
                .always(() => $btn.prop('disabled', false));
        },

        handleSubtypeChange: function() {
            const subtype = $('#ic-income-subtype').val();
            const isPfarrcafe = subtype === 'pfarrcafe';
            
            $('.ic-form-group-messe').toggle(isPfarrcafe || subtype === 'klingelbeutel');
            $('.ic-form-group-messe .ic-required-marker').toggle(isPfarrcafe);
            $('.ic-form-group-category').toggle(isPfarrcafe);
            
            if (isPfarrcafe) {
                $('#ic-income-messe').prop('required', true);
            } else {
                $('#ic-income-messe').prop('required', false);
            }
        },

        handleExpenseSubmit: function(e) {
            e.preventDefault();
            const $form = $(e.target);
            const $btn = $form.find('button[type="submit"]').prop('disabled', true);
            
            const data = {
                entry_date: $form.find('[name="entry_date"]').val(),
                amount: $form.find('[name="amount"]').val(),
                category: $form.find('[name="category"]').val(),
                method: $form.find('[name="method"]').val() || null,
                note: $form.find('[name="note"]').val()
            };

            this.api('expense', 'POST', data)
                .done(res => {
                    if (res.success) {
                        const entryId = res.data.id;
                        const fileInput = $form.find('[name="file"]')[0];
                        
                        if (fileInput && fileInput.files.length > 0) {
                            const formData = new FormData();
                            formData.append('file', fileInput.files[0]);
                            
                            this.api('entry/' + entryId + '/file', 'POST', formData)
                                .done(() => this.toast('Ausgabe mit Beleg eingereicht!', 'success'))
                                .fail(() => this.toast('Ausgabe gespeichert, aber Beleg-Upload fehlgeschlagen', 'error'));
                        } else {
                            this.toast('Ausgabe eingereicht!', 'success');
                        }
                        
                        $form[0].reset();
                        $form.find('[name="entry_date"]').val(new Date().toISOString().split('T')[0]);
                        $('.ic-file-preview').hide().empty();
                        this.loadMySubmissions();
                    } else {
                        this.toast(res.error || 'Fehler beim Einreichen', 'error');
                    }
                })
                .fail(() => this.toast('Fehler beim Einreichen', 'error'))
                .always(() => $btn.prop('disabled', false));
        },

        handleFileSelect: function(e) {
            const file = e.target.files[0];
            const $preview = $('.ic-file-preview');
            
            if (file) {
                if (file.size > 5 * 1024 * 1024) {
                    this.toast('Datei zu groß (max. 5 MB)', 'error');
                    e.target.value = '';
                    $preview.hide();
                    return;
                }
                $preview.html('<strong>' + this.escapeHtml(file.name) + '</strong> (' + this.formatFileSize(file.size) + ')').show();
            } else {
                $preview.hide();
            }
        },

        handleExport: function(e) {
            e.preventDefault();
            const $form = $(e.target);
            const format = $form.find('[name="format"]').val();
            const params = new URLSearchParams({
                type: $form.find('[name="type"]').val(),
                date_from: $form.find('[name="date_from"]').val(),
                date_to: $form.find('[name="date_to"]').val()
            });
            
            window.location.href = this.config.restUrl + 'export/' + format + '?' + params.toString() + '&_wpnonce=' + this.config.restNonce;
        },

        loadIncomeList: function() {
            const $list = $('#ic-income-list').html('<div class="ic-loading">' + this.config.i18n.loading + '</div>');
            
            const filters = {
                type: 'income',
                date_from: $('#ic-income-filter-from').val(),
                date_to: $('#ic-income-filter-to').val()
            };

            this.api('finances?' + $.param(filters))
                .done(res => {
                    if (res.success && res.data.items.length > 0) {
                        let html = '';
                        res.data.items.forEach(item => {
                            html += this.renderIncomeItem(item);
                        });
                        $list.html(html);
                    } else {
                        $list.html('<div class="ic-list-empty">' + this.config.i18n.noData + '</div>');
                    }
                })
                .fail(() => $list.html('<div class="ic-list-empty">' + this.config.i18n.error + '</div>'));
        },

        renderIncomeItem: function(item) {
            return '<div class="ic-list-item" data-id="' + item.id + '">' +
                '<div class="ic-list-item-main">' +
                    '<span class="ic-list-item-title">' + this.escapeHtml(item.subtype_label) + '</span>' +
                    '<span class="ic-list-item-meta">' +
                        '<span>📅 ' + this.formatDate(item.entry_date) + '</span>' +
                        (item.note ? '<span>📝 ' + this.escapeHtml(item.note.substring(0, 50)) + '</span>' : '') +
                    '</span>' +
                '</div>' +
                '<div class="ic-list-item-amount income">+' + item.amount_formatted + '</div>' +
            '</div>';
        },

        loadMessen: function() {
            if (!this.config.messeExists) return;
            
            this.api('messen')
                .done(res => {
                    if (res.success) {
                        let html = '<option value="">' + this.config.i18n.selectMesse + '</option>';
                        res.data.forEach(m => {
                            html += '<option value="' + m.id + '">' + this.escapeHtml(m.title) + ' (' + this.formatDate(m.date) + ' ' + m.time + ')</option>';
                        });
                        $('#ic-income-messe').html(html);
                    }
                });
        },

        loadPendingExpenses: function() {
            const $list = $('#ic-pending-expenses').html('<div class="ic-loading">' + this.config.i18n.loading + '</div>');
            
            this.api('expenses/pending')
                .done(res => {
                    if (res.success && res.data.items.length > 0) {
                        let html = '';
                        res.data.items.forEach(item => {
                            html += this.renderExpenseItem(item, true);
                        });
                        $list.html(html);
                    } else {
                        $list.html('<div class="ic-list-empty">Keine offenen Ausgaben</div>');
                    }
                })
                .fail(() => $list.html('<div class="ic-list-empty">' + this.config.i18n.error + '</div>'));
        },

        loadMySubmissions: function() {
            const $list = $('#ic-my-submissions, #ic-submissions-list').html('<div class="ic-loading">' + this.config.i18n.loading + '</div>');
            
            this.api('my-submissions')
                .done(res => {
                    if (res.success && res.data.items.length > 0) {
                        let html = '';
                        res.data.items.forEach(item => {
                            html += this.renderExpenseItem(item, false);
                        });
                        $list.html(html);
                    } else {
                        $list.html('<div class="ic-list-empty">Keine Einreichungen</div>');
                    }
                })
                .fail(() => $list.html('<div class="ic-list-empty">' + this.config.i18n.error + '</div>'));
        },

        renderExpenseItem: function(item, showActions) {
            const statusLabels = {
                'submitted': 'Eingereicht', 'reviewed': 'Geprüft', 
                'approved': 'Genehmigt', 'reimbursed': 'Erstattet', 'rejected': 'Abgelehnt'
            };
            const statusColors = {
                'submitted': 'status-pending', 'reviewed': 'status-info',
                'approved': 'status-success', 'reimbursed': 'status-complete', 'rejected': 'status-error'
            };
            
            let actions = '';
            if (showActions && this.config.currentUser.canApprove) {
                if (item.status === 'submitted') {
                    actions = '<button class="ic-btn ic-btn-secondary ic-btn-sm ic-action-status" data-id="' + item.id + '" data-status="reviewed">Prüfen</button>';
                } else if (item.status === 'reviewed') {
                    actions = '<button class="ic-btn ic-btn-success ic-btn-sm ic-action-status" data-id="' + item.id + '" data-status="approved">Genehmigen</button>' +
                              '<button class="ic-btn ic-btn-danger ic-btn-sm ic-action-status" data-id="' + item.id + '" data-status="rejected">Ablehnen</button>';
                } else if (item.status === 'approved') {
                    actions = '<button class="ic-btn ic-btn-primary ic-btn-sm ic-action-status" data-id="' + item.id + '" data-status="reimbursed">Erstattet</button>';
                }
            }

            return '<div class="ic-list-item" data-id="' + item.entry_id + '">' +
                '<div class="ic-list-item-main">' +
                    '<span class="ic-list-item-title">' + this.escapeHtml(item.category || 'Ausgabe') + '</span>' +
                    '<span class="ic-list-item-meta">' +
                        '<span>📅 ' + this.formatDate(item.entry_date) + '</span>' +
                        '<span>👤 ' + this.escapeHtml(item.submitter_name) + '</span>' +
                        '<span class="ic-status ' + statusColors[item.status] + '">' + statusLabels[item.status] + '</span>' +
                    '</span>' +
                    (item.note ? '<span class="ic-list-item-meta">📝 ' + this.escapeHtml(item.note.substring(0, 80)) + '</span>' : '') +
                '</div>' +
                '<div class="ic-list-item-amount expense">-' + this.formatAmount(item.amount_cents) + '</div>' +
                (actions ? '<div class="ic-list-item-actions">' + actions + '</div>' : '') +
            '</div>';
        },

        handleStatusChange: function(e) {
            const $btn = $(e.currentTarget);
            const expenseId = $btn.data('id');
            const newStatus = $btn.data('status');
            
            if (newStatus === 'rejected') {
                const reason = prompt('Bitte geben Sie einen Ablehnungsgrund an:');
                if (!reason) return;
                this.updateStatus(expenseId, newStatus, reason);
            } else {
                this.updateStatus(expenseId, newStatus);
            }
        },

        updateStatus: function(expenseId, status, reason) {
            this.api('expense/' + expenseId + '/status', 'PUT', { status: status, reason: reason || null })
                .done(res => {
                    if (res.success) {
                        this.toast('Status aktualisiert!', 'success');
                        this.loadPendingExpenses();
                        this.loadMySubmissions();
                    } else {
                        this.toast(res.error || 'Fehler', 'error');
                    }
                })
                .fail(() => this.toast('Fehler beim Aktualisieren', 'error'));
        },

        handleDelete: function(e) {
            const id = $(e.currentTarget).closest('.ic-list-item').data('id');
            if (!confirm(this.config.i18n.confirmDelete)) return;
            
            this.api('entry/' + id, 'DELETE')
                .done(res => {
                    if (res.success) {
                        this.toast('Gelöscht!', 'success');
                        this.loadIncomeList();
                    } else {
                        this.toast(res.error || 'Fehler', 'error');
                    }
                })
                .fail(() => this.toast('Fehler beim Löschen', 'error'));
        },

        loadStats: function() {
            const filters = {
                date_from: $('#ic-stats-filter-from').val(),
                date_to: $('#ic-stats-filter-to').val()
            };

            this.api('finances/stats?' + $.param(filters))
                .done(res => {
                    if (res.success) {
                        const d = res.data;
                        $('#ic-stat-income').text(d.summary.income_formatted);
                        $('#ic-stat-expense').text(d.summary.expense_formatted);
                        $('#ic-stat-balance').text(d.summary.balance_formatted)
                            .css('color', d.summary.balance >= 0 ? 'var(--ic-success)' : 'var(--ic-error)');
                        
                        let breakdownHtml = '';
                        d.income_breakdown.forEach(item => {
                            breakdownHtml += '<div class="ic-breakdown-item"><span class="ic-breakdown-label">' + 
                                this.escapeHtml(item.label) + '</span><span class="ic-breakdown-value">' + 
                                item.formatted + '</span></div>';
                        });
                        $('#ic-income-breakdown').html(breakdownHtml || '<div class="ic-list-empty">Keine Daten</div>');
                        
                        let expenseHtml = '';
                        d.top_expense_categories.forEach(item => {
                            expenseHtml += '<div class="ic-breakdown-item"><span class="ic-breakdown-label">' + 
                                this.escapeHtml(item.category) + '</span><span class="ic-breakdown-value">' + 
                                item.formatted + '</span></div>';
                        });
                        $('#ic-expense-breakdown').html(expenseHtml || '<div class="ic-list-empty">Keine Daten</div>');

                        let openHtml = '';
                        ['submitted', 'reviewed', 'approved'].forEach(status => {
                            const s = d.open_expenses[status];
                            if (s.count > 0) {
                                openHtml += '<div class="ic-stat-card"><div class="ic-stat-content">' +
                                    '<span class="ic-stat-label">' + status.charAt(0).toUpperCase() + status.slice(1) + '</span>' +
                                    '<span class="ic-stat-value">' + s.count + ' (' + s.formatted + ')</span>' +
                                '</div></div>';
                            }
                        });
                        $('#ic-open-expenses-stats').html(openHtml || '<div class="ic-list-empty">Keine offenen Ausgaben</div>');
                    }
                });

            this.loadMonthlyChart();
        },

        loadMonthlyChart: function() {
            this.api('stats/monthly')
                .done(res => {
                    if (res.success && typeof Chart !== 'undefined') {
                        const ctx = document.getElementById('ic-monthly-chart');
                        if (!ctx) return;
                        
                        if (this.monthlyChart) this.monthlyChart.destroy();
                        
                        this.monthlyChart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: res.data.labels,
                                datasets: res.data.datasets.map(ds => ({
                                    label: ds.label,
                                    data: ds.data,
                                    backgroundColor: ds.color + '40',
                                    borderColor: ds.color,
                                    borderWidth: 2
                                }))
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                scales: {
                                    y: { beginAtZero: true }
                                }
                            }
                        });
                    }
                });
        },

        // Modal
        openModal: function(title, content, footer) {
            $('#ic-modal .ic-modal-title').text(title);
            $('#ic-modal .ic-modal-body').html(content);
            $('#ic-modal .ic-modal-footer').html(footer || '');
            $('#ic-modal').attr('aria-hidden', 'false');
        },

        closeModal: function() {
            $('#ic-modal').attr('aria-hidden', 'true');
        },

        // Toast notifications
        toast: function(message, type) {
            const $toast = $('<div class="ic-toast ic-toast-' + type + '">' + this.escapeHtml(message) + '</div>');
            $('#ic-toasts').append($toast);
            setTimeout(() => $toast.fadeOut(300, function() { $(this).remove(); }), 4000);
        },

        // Helpers
        escapeHtml: function(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        },

        formatDate: function(dateStr) {
            if (!dateStr) return '';
            const d = new Date(dateStr);
            return d.toLocaleDateString('de-AT', { day: '2-digit', month: '2-digit', year: 'numeric' });
        },

        formatAmount: function(cents) {
            return (cents / 100).toLocaleString('de-AT', { style: 'currency', currency: 'EUR' });
        },

        formatFileSize: function(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        }
    };

    // Initialize on ready
    $(document).ready(function() {
        if ($('#isidor-cellerar-app, #isidor-cellerar-submissions').length) {
            IC.init();
        }
    });

})(jQuery);
