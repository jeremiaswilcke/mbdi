/**
 * Isidor Communicator — Chat JavaScript
 */

let commCurrentRoom = null;
let commPollingTimer = null;
let commLastMessageTime = null;
let commUsers = [];

/* ================================================================
   Init
   ================================================================ */

jQuery(document).ready(function($) {
    loadRooms();
    loadUsers();
    
    // Icon Picker
    $(document).on('click', '.comm-icon-btn', function() {
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
    });
    
    // Polling starten
    startPolling();
});

/* ================================================================
   Rooms
   ================================================================ */

function loadRooms() {
    jQuery.ajax({
        url: isidorComm.restUrl + 'rooms',
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        success: function(data) {
            renderRoomList(data.rooms || []);
        },
        error: function() {
            jQuery('#comm-room-list').html('<div class="comm-loading">Fehler beim Laden</div>');
        }
    });
}

function renderRoomList(rooms) {
    var html = '';
    
    if (rooms.length === 0) {
        html = '<div class="comm-loading">Noch keine Chats vorhanden</div>';
    } else {
        rooms.forEach(function(room) {
            var avatar = room.avatar 
                ? '<img src="' + room.avatar + '" alt="">' 
                : room.icon || '💬';
            
            var preview = room.last_message || 'Noch keine Nachrichten';
            if (preview.length > 40) preview = preview.substring(0, 40) + '...';
            
            var time = room.last_message_at ? formatTime(room.last_message_at) : '';
            var badge = room.unread > 0 ? '<span class="comm-room-badge">' + room.unread + '</span>' : '';
            var activeClass = commCurrentRoom == room.id ? ' active' : '';
            
            html += '<div class="comm-room-item' + activeClass + '" onclick="openRoom(' + room.id + ')" data-room="' + room.id + '">';
            html += '<div class="comm-room-avatar">' + avatar + '</div>';
            html += '<div class="comm-room-info">';
            html += '<div class="comm-room-name">' + escapeHtml(room.name) + '</div>';
            html += '<div class="comm-room-preview">' + escapeHtml(preview) + '</div>';
            html += '</div>';
            html += '<div class="comm-room-meta">';
            html += '<span class="comm-room-time">' + time + '</span>';
            html += badge;
            html += '</div>';
            html += '</div>';
        });
    }
    
    jQuery('#comm-room-list').html(html);
}

function openRoom(roomId) {
    commCurrentRoom = roomId;
    commLastMessageTime = null;
    
    // UI Update
    jQuery('.comm-room-item').removeClass('active');
    jQuery('.comm-room-item[data-room="' + roomId + '"]').addClass('active');
    jQuery('#comm-placeholder').hide();
    jQuery('#comm-chat').show();
    jQuery('#comm-app').addClass('chat-open');
    
    // Room-Info laden
    var roomItem = jQuery('.comm-room-item[data-room="' + roomId + '"]');
    var roomName = roomItem.find('.comm-room-name').text();
    var roomIcon = roomItem.find('.comm-room-avatar').html();
    
    jQuery('#comm-chat-name').text(roomName);
    jQuery('#comm-chat-icon').html(roomIcon);
    
    // Nachrichten laden
    loadMessages(roomId);
    
    // Als gelesen markieren
    markAsRead(roomId);
}

function commCloseChat() {
    commCurrentRoom = null;
    jQuery('#comm-app').removeClass('chat-open');
    jQuery('#comm-chat').hide();
    jQuery('#comm-placeholder').show();
    jQuery('.comm-room-item').removeClass('active');
}

/* ================================================================
   Messages
   ================================================================ */

function loadMessages(roomId, since) {
    var url = isidorComm.restUrl + 'rooms/' + roomId + '/messages';
    if (since) url += '?since=' + encodeURIComponent(since);
    
    jQuery.ajax({
        url: url,
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        success: function(data) {
            var messages = data.messages || [];
            
            if (since && messages.length > 0) {
                // Neue Nachrichten anhängen
                appendMessages(messages);
            } else if (!since) {
                // Alle Nachrichten neu rendern
                renderMessages(messages);
            }
            
            if (messages.length > 0) {
                commLastMessageTime = messages[messages.length - 1].created_at;
            }
        }
    });
}

function renderMessages(messages) {
    var html = '';
    var lastDate = '';
    
    messages.forEach(function(msg) {
        var msgDate = msg.created_at.substring(0, 10);
        
        // Datumstrenner
        if (msgDate !== lastDate) {
            lastDate = msgDate;
            html += '<div class="comm-date-separator"><span>' + formatDate(msgDate) + '</span></div>';
        }
        
        html += renderMessage(msg);
    });
    
    var container = jQuery('#comm-messages');
    container.html(html);
    container.scrollTop(container[0].scrollHeight);
}

function appendMessages(messages) {
    var html = '';
    messages.forEach(function(msg) {
        html += renderMessage(msg);
    });
    
    var container = jQuery('#comm-messages');
    container.append(html);
    container.scrollTop(container[0].scrollHeight);
}

function renderMessage(msg) {
    var mineClass = msg.is_mine ? ' mine' : '';
    var html = '<div class="comm-message' + mineClass + '" data-id="' + msg.id + '">';
    
    if (!msg.is_mine) {
        html += '<div class="comm-message-avatar"><img src="' + msg.avatar + '" alt=""></div>';
    }
    
    html += '<div class="comm-message-content">';
    
    if (!msg.is_mine) {
        html += '<div class="comm-message-sender">' + escapeHtml(msg.user_name) + '</div>';
    }
    
    html += '<div class="comm-message-text">' + formatMessageText(msg.message) + '</div>';
    
    if (msg.attachment_url) {
        html += '<div class="comm-message-attachment">';
        if (msg.attachment_type && msg.attachment_type.startsWith('image')) {
            html += '<img src="' + msg.attachment_url + '" alt="Bild">';
        } else {
            html += '<a href="' + msg.attachment_url + '" target="_blank">📎 Datei</a>';
        }
        html += '</div>';
    }
    
    html += '<div class="comm-message-time">' + formatTime(msg.created_at) + '</div>';
    html += '</div></div>';
    
    return html;
}

function commSendMessage() {
    var input = jQuery('#comm-message-input');
    var message = input.val().trim();
    
    if (!message || !commCurrentRoom) return;
    
    input.val('').focus();
    
    jQuery.ajax({
        url: isidorComm.restUrl + 'rooms/' + commCurrentRoom + '/messages',
        method: 'POST',
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        data: { message: message },
        success: function(data) {
            // Neue Nachricht direkt laden
            loadMessages(commCurrentRoom, commLastMessageTime);
            loadRooms(); // Raumliste aktualisieren
        },
        error: function() {
            commToast('Fehler beim Senden', 'error');
        }
    });
}

function markAsRead(roomId) {
    jQuery.ajax({
        url: isidorComm.restUrl + 'rooms/' + roomId + '/read',
        method: 'POST',
        headers: { 'X-WP-Nonce': isidorComm.nonce }
    });
    
    // Badge entfernen
    jQuery('.comm-room-item[data-room="' + roomId + '"] .comm-room-badge').remove();
}

/* ================================================================
   Create Group
   ================================================================ */

function commShowCreateGroup() {
    renderUserSelect('group-members');
    jQuery('#comm-modal-group').show();
}

function commCreateGroup() {
    var name = jQuery('#group-name').val().trim();
    var description = jQuery('#group-description').val().trim();
    var icon = jQuery('#group-icon-picker .comm-icon-btn.active').data('icon') || '💬';
    var members = [];
    
    jQuery('#group-members input:checked').each(function() {
        members.push(parseInt(jQuery(this).val()));
    });
    
    if (!name) {
        commToast('Bitte Gruppennamen eingeben', 'error');
        return;
    }
    
    jQuery.ajax({
        url: isidorComm.restUrl + 'rooms',
        method: 'POST',
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        data: {
            name: name,
            description: description,
            icon: icon,
            members: members
        },
        success: function(data) {
            commCloseModal('group');
            jQuery('#group-name').val('');
            jQuery('#group-description').val('');
            loadRooms();
            commToast('Gruppe erstellt!');
            
            if (data.room_id) {
                setTimeout(function() {
                    openRoom(data.room_id);
                }, 500);
            }
        },
        error: function() {
            commToast('Fehler beim Erstellen', 'error');
        }
    });
}

/* ================================================================
   Direct Messages
   ================================================================ */

function commStartDM() {
    renderUserList('dm-user-list');
    jQuery('#comm-modal-dm').show();
}

function startDMWith(userId) {
    jQuery.ajax({
        url: isidorComm.restUrl + 'dm/' + userId,
        method: 'POST',
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        success: function(data) {
            commCloseModal('dm');
            loadRooms();
            
            if (data.room_id) {
                setTimeout(function() {
                    openRoom(data.room_id);
                }, 500);
            }
        },
        error: function() {
            commToast('Fehler beim Starten', 'error');
        }
    });
}

/* ================================================================
   Users
   ================================================================ */

function loadUsers() {
    jQuery.ajax({
        url: isidorComm.restUrl + 'users',
        headers: { 'X-WP-Nonce': isidorComm.nonce },
        success: function(data) {
            commUsers = data.users || [];
        }
    });
}

function renderUserSelect(containerId) {
    var html = '';
    commUsers.forEach(function(user) {
        if (user.id == isidorComm.userId) return; // Eigenen User ausblenden
        
        html += '<label class="comm-user-item">';
        html += '<input type="checkbox" value="' + user.id + '">';
        html += '<div class="comm-user-avatar"><img src="' + user.avatar + '" alt=""></div>';
        html += '<span class="comm-user-name">' + escapeHtml(user.name) + '</span>';
        html += '</label>';
    });
    
    jQuery('#' + containerId).html(html || '<div class="comm-loading">Keine User gefunden</div>');
}

function renderUserList(containerId) {
    var html = '';
    commUsers.forEach(function(user) {
        if (user.id == isidorComm.userId) return;
        
        html += '<div class="comm-user-item" onclick="startDMWith(' + user.id + ')">';
        html += '<div class="comm-user-avatar"><img src="' + user.avatar + '" alt=""></div>';
        html += '<span class="comm-user-name">' + escapeHtml(user.name) + '</span>';
        html += '</div>';
    });
    
    jQuery('#' + containerId).html(html || '<div class="comm-loading">Keine User gefunden</div>');
}

/* ================================================================
   File Attachment
   ================================================================ */

function commAttachFile() {
    if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
        commToast('Mediathek nicht verfügbar', 'error');
        return;
    }
    
    var frame = wp.media({
        title: 'Datei auswählen',
        button: { text: 'Anhängen' },
        multiple: false
    });
    
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        
        jQuery.ajax({
            url: isidorComm.restUrl + 'rooms/' + commCurrentRoom + '/messages',
            method: 'POST',
            headers: { 'X-WP-Nonce': isidorComm.nonce },
            data: {
                message: '',
                attachment_url: attachment.url,
                attachment_type: attachment.mime
            },
            success: function() {
                loadMessages(commCurrentRoom, commLastMessageTime);
                loadRooms();
            },
            error: function() {
                commToast('Fehler beim Hochladen', 'error');
            }
        });
    });
    
    frame.open();
}

/* ================================================================
   Polling
   ================================================================ */

function startPolling() {
    if (commPollingTimer) clearInterval(commPollingTimer);
    
    commPollingTimer = setInterval(function() {
        // Raumliste aktualisieren
        loadRooms();
        
        // Aktiven Chat aktualisieren
        if (commCurrentRoom && commLastMessageTime) {
            loadMessages(commCurrentRoom, commLastMessageTime);
        }
    }, isidorComm.pollInterval);
}

/* ================================================================
   Modal
   ================================================================ */

function commCloseModal(type) {
    jQuery('#comm-modal-' + type).hide();
}

function commShowRoomInfo() {
    commToast('Room-Info (noch nicht implementiert)');
}

/* ================================================================
   Helpers
   ================================================================ */

function formatTime(datetime) {
    if (!datetime) return '';
    var d = new Date(datetime.replace(' ', 'T'));
    var now = new Date();
    
    if (d.toDateString() === now.toDateString()) {
        return d.getHours().toString().padStart(2, '0') + ':' + 
               d.getMinutes().toString().padStart(2, '0');
    }
    
    return d.getDate() + '.' + (d.getMonth() + 1) + '.';
}

function formatDate(dateStr) {
    var d = new Date(dateStr);
    var today = new Date();
    var yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (d.toDateString() === today.toDateString()) return 'Heute';
    if (d.toDateString() === yesterday.toDateString()) return 'Gestern';
    
    var days = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
    return days[d.getDay()] + ', ' + d.getDate() + '.' + (d.getMonth() + 1) + '.' + d.getFullYear();
}

function formatMessageText(text) {
    if (!text) return '';
    // Links erkennen
    text = escapeHtml(text);
    text = text.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
    // Zeilenumbrüche
    text = text.replace(/\n/g, '<br>');
    return text;
}

function escapeHtml(text) {
    if (!text) return '';
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function commToast(message, type) {
    type = type || 'success';
    var toast = jQuery('#comm-toast');
    var msg = jQuery('<div class="comm-toast-msg ' + type + '">' + escapeHtml(message) + '</div>');
    toast.append(msg);
    setTimeout(function() { msg.remove(); }, 2600);
}
