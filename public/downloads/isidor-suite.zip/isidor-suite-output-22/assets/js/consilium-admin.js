/**
 * Isidor Consilium - Admin JavaScript
 */
(function($) {
    'use strict';

    var API = consiliumAdmin.restUrl;
    var NONCE = consiliumAdmin.restNonce;
    var i18n = consiliumAdmin.i18n;

    function apiRequest(method, endpoint, data) {
        var opts = {
            url: API + endpoint,
            method: method,
            headers: { 'X-WP-Nonce': NONCE },
            dataType: 'json'
        };
        if (data && (method === 'POST' || method === 'PUT')) {
            opts.contentType = 'application/json';
            opts.data = JSON.stringify(data);
        } else if (data && method === 'GET') {
            opts.data = data;
        }
        return $.ajax(opts);
    }

    function showStatus(selector, msg, isError) {
        var $el = $(selector);
        var color = isError ? '#dc2626' : '#10b981';
        $el.html('<span style="color:' + color + '">' + msg + '</span>');
        setTimeout(function() { $el.html(''); }, 4000);
    }

    // =========================================================================
    // SESSION EDITOR
    // =========================================================================

    var Editor = {
        sessionId: 0,

        init: function() {
            var $editor = $('#consilium-editor');
            if (!$editor.length) return;
            this.sessionId = parseInt($editor.data('session-id')) || 0;

            $('#consilium-save-session').on('click', this.saveSession.bind(this));
            $('#consilium-delete-session').on('click', this.deleteSession.bind(this));
            $('#consilium-start-session').on('click', this.startSession.bind(this));
            $('#consilium-send-invitations').on('click', this.sendInvitations.bind(this));
            $('#consilium-send-reminder').on('click', this.sendReminder.bind(this));
            $('#consilium-send-protocol').on('click', this.sendProtocol.bind(this));
            $('#consilium-save-protocol-draft').on('click', this.saveProtocolDraft.bind(this));
            $('#consilium-finalize-protocol').on('click', this.finalizeProtocol.bind(this));

            $('#consilium-gremium').on('change', function() {
                if ($(this).val() === 'sonstige') {
                    $('#consilium-custom-gremium-wrap').show();
                } else {
                    $('#consilium-custom-gremium-wrap').hide();
                }
            });

            if (this.sessionId > 0) {
                this.loadTopics();
                this.loadParticipants();
                this.initTopicAdd();
                this.initUserSearch();
            }
        },

        saveSession: function() {
            var data = {
                title: $('#consilium-title').val(),
                gremium: $('#consilium-gremium').val(),
                session_date: $('#consilium-date').val(),
                time_start: $('#consilium-time-start').val() || null,
                time_end: $('#consilium-time-end').val() || null,
                location: $('#consilium-location').val() || null,
                topic_deadline: $('#consilium-topic-deadline').val() || null,
                reminder_days: parseInt($('#consilium-reminder-days').val()) || 0
            };
            if (data.gremium === 'sonstige') {
                data.custom_gremium_label = $('#consilium-custom-gremium').val() || null;
            }
            if (!data.title || !data.session_date) {
                alert('Titel und Datum sind Pflichtfelder.');
                return;
            }
            var self = this;
            var method = this.sessionId > 0 ? 'PUT' : 'POST';
            var endpoint = this.sessionId > 0 ? 'sessions/' + this.sessionId : 'sessions';
            apiRequest(method, endpoint, data).done(function(res) {
                if (res.success) {
                    showStatus('#consilium-save-status', i18n.saved);
                    if (!self.sessionId && res.data && res.data.id) {
                        window.location.href = consiliumAdmin.adminUrl + '?page=isidor-consilium-edit&id=' + res.data.id;
                    }
                } else {
                    showStatus('#consilium-save-status', res.message || i18n.error, true);
                }
            }).fail(function(xhr) {
                var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : i18n.error;
                showStatus('#consilium-save-status', msg, true);
            });
        },

        deleteSession: function() {
            if (!confirm(i18n.confirmDelete)) return;
            apiRequest('DELETE', 'sessions/' + this.sessionId).done(function(res) {
                if (res.success) window.location.href = consiliumAdmin.adminUrl + '?page=isidor-consilium';
            });
        },

        startSession: function() {
            if (!confirm(i18n.confirmStart)) return;
            apiRequest('POST', 'sessions/' + this.sessionId + '/start').done(function(res) {
                if (res.success) window.location.reload();
            });
        },

        sendInvitations: function() {
            var $btn = $('#consilium-send-invitations').prop('disabled', true).text('Wird gesendet…');
            apiRequest('POST', 'sessions/' + this.sessionId + '/send-invitations').done(function(res) {
                if (res.success) {
                    alert(i18n.invitationsSent + ' (' + res.data.sent + ' gesendet, ' + res.data.failed + ' fehlgeschlagen)');
                    window.location.reload();
                }
            }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('Einladungen senden'); });
        },

        sendReminder: function() {
            var $btn = $('#consilium-send-reminder').prop('disabled', true).text('Wird gesendet…');
            apiRequest('POST', 'sessions/' + this.sessionId + '/send-reminder').done(function(res) {
                if (res.success && res.result) {
                    alert('Erinnerungen gesendet (' + res.result.sent + ' gesendet, ' + res.result.failed + ' fehlgeschlagen)');
                } else {
                    alert(res.result && res.result.info ? res.result.info : 'Erinnerung gesendet.');
                }
                $btn.prop('disabled', false).text('⏰ Erinnerung senden');
            }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('⏰ Erinnerung senden'); });
        },

        sendProtocol: function() {
            if (!confirm('Protokoll an alle Teilnehmer versenden?')) return;
            var $btn = $('#consilium-send-protocol').prop('disabled', true).text('Wird gesendet…');
            apiRequest('POST', 'sessions/' + this.sessionId + '/send-protocol').done(function(res) {
                if (res.success && res.result) {
                    alert('Protokoll versendet (' + res.result.sent + ' gesendet, ' + res.result.failed + ' fehlgeschlagen)');
                } else { alert(res.message || i18n.error); }
                $btn.prop('disabled', false).text('📧 Protokoll versenden');
            }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('📧 Protokoll versenden'); });
        },

        saveProtocolDraft: function() {
            apiRequest('POST', 'sessions/' + this.sessionId + '/protocol-draft').done(function(res) {
                if (res.success) { alert(i18n.protocolDraftSaved); window.location.reload(); }
                else { alert(res.message || i18n.error); }
            }).fail(function() { alert(i18n.error); });
        },

        finalizeProtocol: function() {
            if (!confirm(i18n.confirmFinalize)) return;
            var $btn = $('#consilium-finalize-protocol');
            $btn.prop('disabled', true).text('Wird abgelegt...');
            apiRequest('POST', 'sessions/' + this.sessionId + '/protocol-finalize').done(function(res) {
                if (res.success) { alert(i18n.protocolFinalized); window.location.reload(); }
                else { alert(res.message || i18n.error); $btn.prop('disabled', false).text('Endgültig ablegen & versenden'); }
            }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('Endgültig ablegen & versenden'); });
        },

        loadTopics: function() {
            var self = this;
            apiRequest('GET', 'sessions/' + this.sessionId + '/topics').done(function(res) {
                if (res.success) self.renderTopics(res.data);
            });
        },

        renderTopics: function(topics) {
            var $list = $('#consilium-topics-list');
            $list.empty();
            if (!topics.length) { $list.html('<p class="consilium-loading">' + i18n.noTopics + '</p>'); return; }
            topics.forEach(function(topic, i) {
                var $item = $('<div class="consilium-topic-item" data-topic-id="' + topic.id + '">'
                    + '<span class="consilium-topic-item__handle">&#9776;</span>'
                    + '<span class="consilium-topic-item__number">' + (i + 1) + '</span>'
                    + '<span class="consilium-topic-item__title">' + $('<span>').text(topic.title).html() + '</span>'
                    + '<span class="consilium-topic-item__actions">'
                    + '<button type="button" class="button button-small consilium-edit-topic" data-id="' + topic.id + '" data-title="' + $('<span>').text(topic.title).html() + '">&#9998;</button>'
                    + '<button type="button" class="button button-small consilium-delete-topic" data-id="' + topic.id + '">&times;</button>'
                    + '</span></div>');
                $list.append($item);
            });
            $list.sortable({ handle: '.consilium-topic-item__handle', placeholder: 'ui-sortable-placeholder',
                update: function() {
                    var order = [];
                    $list.find('.consilium-topic-item').each(function() { order.push($(this).data('topic-id')); });
                    apiRequest('PUT', 'topics/reorder', { order: order });
                    $list.find('.consilium-topic-item__number').each(function(i) { $(this).text(i + 1); });
                }
            });
            $list.off('click', '.consilium-edit-topic').on('click', '.consilium-edit-topic', function() {
                var id = $(this).data('id'), currentTitle = $(this).data('title');
                var newTitle = prompt('TOP-Titel bearbeiten:', currentTitle);
                if (newTitle && newTitle !== currentTitle) {
                    apiRequest('PUT', 'topics/' + id, { title: newTitle }).done(function() { Editor.loadTopics(); });
                }
            });
            $list.off('click', '.consilium-delete-topic').on('click', '.consilium-delete-topic', function() {
                if (!confirm(i18n.confirmDelete)) return;
                apiRequest('DELETE', 'topics/' + $(this).data('id')).done(function() { Editor.loadTopics(); });
            });
        },

        initTopicAdd: function() {
            var self = this;
            $('#consilium-add-topic').on('click', function() {
                var title = $('#consilium-new-topic-title').val().trim();
                if (!title) return;
                apiRequest('POST', 'sessions/' + self.sessionId + '/topics', { title: title }).done(function(res) {
                    if (res.success) { $('#consilium-new-topic-title').val(''); self.loadTopics(); }
                });
            });
            $('#consilium-new-topic-title').on('keypress', function(e) {
                if (e.which === 13) { e.preventDefault(); $('#consilium-add-topic').click(); }
            });
        },

        loadParticipants: function() {
            var self = this;
            apiRequest('GET', 'sessions/' + this.sessionId + '/participants').done(function(res) {
                if (res.success) self.renderParticipants(res.data);
            });
        },

        renderParticipants: function(participants) {
            var $list = $('#consilium-participants-list');
            $list.empty();
            if (!participants.length) { $list.html('<p class="consilium-loading"><em>Noch keine Teilnehmer.</em></p>'); return; }
            var self = this;
            participants.forEach(function(p) {
                var $item = $('<div class="consilium-participant-item"><div class="consilium-participant-item__info"><span class="consilium-participant-item__name">' + $('<span>').text(p.name).html() + '</span><span class="consilium-participant-item__email">' + $('<span>').text(p.email).html() + '</span></div><button type="button" class="button button-small" data-user-id="' + p.user_id + '">&times;</button></div>');
                $item.find('button').on('click', function() {
                    apiRequest('DELETE', 'sessions/' + self.sessionId + '/participants/' + $(this).data('user-id')).done(function() { self.loadParticipants(); });
                });
                $list.append($item);
            });
        },

        initUserSearch: function() {
            var self = this;
            var $input = $('#consilium-user-search'), $suggestions = $('#consilium-user-suggestions'), debounceTimer = null;
            $input.on('input', function() {
                var query = $(this).val().trim();
                clearTimeout(debounceTimer);
                if (query.length < 2) { $suggestions.hide().empty(); return; }
                debounceTimer = setTimeout(function() {
                    apiRequest('GET', 'users/search', { search: query }).done(function(res) {
                        $suggestions.empty();
                        if (res.success && res.data.length) {
                            res.data.forEach(function(user) {
                                var $item = $('<div class="consilium-suggestion-item">' + $('<span>').text(user.name).html() + ' <small>(' + $('<span>').text(user.email).html() + ')</small></div>');
                                $item.on('click', function() {
                                    apiRequest('POST', 'sessions/' + self.sessionId + '/participants', { user_id: user.id }).done(function() {
                                        self.loadParticipants(); $input.val(''); $suggestions.hide();
                                    }).fail(function(xhr) { alert(xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : i18n.error); });
                                });
                                $suggestions.append($item);
                            });
                            $suggestions.show();
                        } else { $suggestions.hide(); }
                    });
                }, 300);
            });
            $(document).on('click', function(e) { if (!$(e.target).closest('.consilium-add-participant').length) $suggestions.hide(); });
        }
    };

    // =========================================================================
    // LIVE SESSION
    // =========================================================================

    var Live = {
        sessionId: 0, activeTopicId: 0, autosaveTimer: null, pollTimers: {}, lastContent: '',

        init: function() {
            var $layout = $('.consilium-live-layout');
            if (!$layout.length) return;
            this.sessionId = parseInt($layout.data('session-id'));
            this.activeTopicId = parseInt($('#consilium-active-topic-id').val()) || 0;

            $(document).on('click', '.consilium-live-topic', this.onTopicClick.bind(this));
            $(document).on('change', '.consilium-attendance__check', this.onAttendanceChange.bind(this));
            $('#consilium-complete-session').on('click', this.completeSession.bind(this));
            $('#consilium-save-protocol-draft').on('click', this.saveProtocolDraft.bind(this));
            $('#consilium-finalize-protocol').on('click', this.finalizeProtocol.bind(this));
            $('#consilium-create-vote').on('click', this.createVote.bind(this));
            $(document).on('click', '.consilium-start-vote', this.startVote.bind(this));
            $(document).on('click', '.consilium-stop-vote', this.stopVote.bind(this));

            this.initAutosave();
            this.loadClosedVoteResults();
            this.startActiveVotePolling();
        },

        onTopicClick: function(e) {
            var $topic = $(e.currentTarget), topicId = parseInt($topic.data('topic-id'));
            if (topicId === this.activeTopicId) return;
            this.saveProtocol(true);
            $('.consilium-live-topic').removeClass('consilium-live-topic--active');
            $topic.addClass('consilium-live-topic--active');
            var index = $topic.index(), title = $topic.find('.consilium-live-topic__title').text();
            $('#consilium-active-topic-title').text('TOP ' + (index + 1) + ': ' + title);
            this.activeTopicId = topicId;
            $('#consilium-active-topic-id').val(topicId);
            this.loadProtocol(topicId);
        },

        loadProtocol: function(topicId) {
            var self = this;
            apiRequest('GET', 'protocols/' + topicId).done(function(res) {
                if (res.success && res.data) { self.setEditorContent(res.data.content || ''); self.lastContent = res.data.content || ''; }
            });
        },

        setEditorContent: function(content) {
            if (typeof tinymce !== 'undefined' && tinymce.get('consilium_protocol')) tinymce.get('consilium_protocol').setContent(content);
            else $('#consilium_protocol').val(content);
        },

        getEditorContent: function() {
            if (typeof tinymce !== 'undefined' && tinymce.get('consilium_protocol')) return tinymce.get('consilium_protocol').getContent();
            return $('#consilium_protocol').val();
        },

        initAutosave: function() {
            var self = this;
            this.autosaveTimer = setInterval(function() { self.saveProtocol(false); }, consiliumAdmin.autosaveInterval);
        },

        saveProtocol: function(force) {
            if (!this.activeTopicId) return;
            var content = this.getEditorContent();
            if (!force && content === this.lastContent) return;
            this.lastContent = content;
            var $status = $('#consilium-autosave-status');
            $status.text('Speichert...').attr('class', 'consilium-autosave-status consilium-autosave-status--saving');
            apiRequest('PUT', 'protocols/' + this.activeTopicId, { content: content }).done(function() {
                $status.text('Gespeichert').attr('class', 'consilium-autosave-status consilium-autosave-status--saved');
                setTimeout(function() { $status.text(''); }, 3000);
            }).fail(function() { $status.text('Fehler!').attr('class', 'consilium-autosave-status consilium-autosave-status--saving'); });
        },

        onAttendanceChange: function() {
            var attendance = {};
            $('.consilium-attendance__check').each(function() { attendance[$(this).data('user-id')] = $(this).is(':checked') ? 1 : 0; });
            apiRequest('PUT', 'sessions/' + this.sessionId + '/attendance', { attendance: attendance });
        },

        completeSession: function() {
            if (!confirm(i18n.confirmComplete)) return;
            var $btn = $('#consilium-complete-session');
            $btn.prop('disabled', true).text('Wird abgeschlossen...');
            this.saveProtocol(true);
            var self = this;
            setTimeout(function() {
                apiRequest('POST', 'sessions/' + self.sessionId + '/complete').done(function(res) {
                    if (res.success) { alert(i18n.sessionCompleted); window.location.reload(); }
                    else { alert(res.message || i18n.error); $btn.prop('disabled', false).text('Sitzung abschließen'); }
                }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('Sitzung abschließen'); });
            }, 1500);
        },

        saveProtocolDraft: function() {
            this.saveProtocol(true);
            var self = this;
            setTimeout(function() {
                apiRequest('POST', 'sessions/' + self.sessionId + '/protocol-draft').done(function(res) {
                    if (res.success) alert(i18n.protocolDraftSaved);
                    else alert(res.message || i18n.error);
                }).fail(function() { alert(i18n.error); });
            }, 1000);
        },

        finalizeProtocol: function() {
            if (!confirm(i18n.confirmFinalize)) return;
            this.saveProtocol(true);
            var $btn = $('#consilium-finalize-protocol');
            $btn.prop('disabled', true).text('Wird abgelegt...');
            var self = this;
            setTimeout(function() {
                apiRequest('POST', 'sessions/' + self.sessionId + '/protocol-finalize').done(function(res) {
                    if (res.success) { alert(i18n.protocolFinalized); window.location.href = consiliumAdmin.adminUrl + '?page=isidor-consilium'; }
                    else { alert(res.message || i18n.error); $btn.prop('disabled', false).text('Endgültig ablegen & versenden'); }
                }).fail(function() { alert(i18n.error); $btn.prop('disabled', false).text('Endgültig ablegen & versenden'); });
            }, 1500);
        },

        createVote: function() {
            var title = $('#consilium-vote-title').val().trim(), mode = $('#consilium-vote-mode').val();
            var options = $('#consilium-vote-options').val().trim().split(',').map(function(s) { return s.trim(); }).filter(Boolean);
            if (!title) { alert('Bitte Titel eingeben.'); return; }
            if (options.length < 2) { alert('Mindestens 2 Optionen erforderlich.'); return; }
            apiRequest('POST', 'votes', { session_id: this.sessionId, topic_id: this.activeTopicId, title: title, mode: mode, options: options }).done(function(res) {
                if (res.success) { $('#consilium-vote-title').val(''); window.location.reload(); }
                else alert(res.message || i18n.error);
            });
        },

        startVote: function(e) {
            apiRequest('PUT', 'votes/' + $(e.currentTarget).data('vote-id') + '/start').done(function(res) {
                if (res.success) window.location.reload(); else alert(res.message || i18n.error);
            });
        },

        stopVote: function(e) {
            var voteId = $(e.currentTarget).data('vote-id'), self = this;
            apiRequest('PUT', 'votes/' + voteId + '/stop').done(function(res) {
                if (res.success && res.data && res.data.protocol_html) {
                    self.setEditorContent(self.getEditorContent() + '\n' + res.data.protocol_html);
                    self.saveProtocol(true);
                }
                window.location.reload();
            });
        },

        startActiveVotePolling: function() {
            var self = this;
            $('.consilium-vote-live').each(function() { self.pollVote($(this).data('vote-id')); });
        },

        pollVote: function(voteId) {
            var self = this, $card = $('.consilium-vote-live[data-vote-id="' + voteId + '"]');
            this.pollTimers[voteId] = setInterval(function() {
                apiRequest('GET', 'votes/' + voteId + '/status').done(function(res) {
                    if (!res.success || !res.data) return;
                    var d = res.data;
                    if (d.status !== 'active') { clearInterval(self.pollTimers[voteId]); window.location.reload(); return; }
                    var pct = d.total_eligible > 0 ? Math.round((d.votes_cast / d.total_eligible) * 100) : 0;
                    $card.find('.consilium-vote-progress').html('<span class="consilium-vote-progress__text">' + d.votes_cast + ' von ' + d.total_eligible + ' (' + pct + '%)</span><div class="consilium-vote-progress__bar"><div class="consilium-vote-progress__fill" style="width:' + pct + '%"></div></div>');
                });
            }, consiliumAdmin.pollInterval);
        },

        loadClosedVoteResults: function() {
            $('.consilium-vote-results').each(function() {
                var voteId = $(this).data('vote-id'), $container = $(this);
                apiRequest('GET', 'votes/' + voteId + '/results').done(function(res) {
                    if (!res.success || !res.data) return;
                    var html = '<table><thead><tr><th>Option</th><th>Stimmen</th><th>%</th></tr></thead><tbody>';
                    res.data.results.forEach(function(r) { html += '<tr><td>' + $('<span>').text(r.option).html() + '</td><td>' + r.count + '</td><td>' + r.percent + '%</td></tr>'; });
                    html += '</tbody></table><p style="margin:4px 0 0;font-size:0.85em;color:#6b7280;">Gesamt: ' + res.data.total + ' Stimmen</p>';
                    $container.html(html);
                });
            });
        }
    };

    $(document).ready(function() { Editor.init(); Live.init(); });

})(jQuery);
