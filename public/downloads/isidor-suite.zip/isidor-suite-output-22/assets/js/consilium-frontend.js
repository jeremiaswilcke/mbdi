/**
 * Isidor Consilium - Frontend JavaScript v2
 * @package IsidorSuite
 * @since 12.0.0
 */
(function($) {
    'use strict';
    var API=isidorConsilium.restUrl+'consilium/',NONCE=isidorConsilium.restNonce,i18n=isidorConsilium.i18n,canManage,canAdmin,canVote,userId;
    function api(m,ep,d){var o={url:API+ep,method:m,headers:{'X-WP-Nonce':NONCE},dataType:'json'};if(d&&(m==='POST'||m==='PUT')){o.contentType='application/json';o.data=JSON.stringify(d);}else if(d&&m==='GET'){o.data=d;}return $.ajax(o);}
    function esc(s){return $('<span>').text(s||'').html();}
    function fmtDate(d){if(!d)return'';return new Date(d+'T00:00:00').toLocaleDateString('de-AT',{day:'2-digit',month:'2-digit',year:'numeric'});}
    function fmtDateLong(d){if(!d)return'';return new Date(d+'T00:00:00').toLocaleDateString('de-AT',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});}
    function fmtTime(t){return t?t.substring(0,5):'';}
    function strip(h){var d=document.createElement('div');d.innerHTML=h||'';return d.textContent||d.innerText||'';}
    var GL={pgr:'Pfarrgemeinderat',vvr:'Vermögensverwaltungsrat',liturgieausschuss:'Liturgieausschuss',sonstige:'Sonstige'};
    function grem(s){return s.gremium_label||s.custom_gremium_label||GL[s.gremium]||s.gremium||'';}
    var RSL={pending:'⏳ Ausstehend',accepted:'✅ Zugesagt',declined:'❌ Abgesagt',maybe:'❓ Vielleicht'};
    var TSL={planned:'',submitted:'📥 Eingereicht',accepted:'✅ Angenommen',rejected:'❌ Abgelehnt'};

    var App={sid:null,
        init:function(){if(!$('#isidor-consilium-app').length)return;var $a=$('#isidor-consilium-app');canManage=$a.data('can-manage')=='1';canAdmin=$a.data('can-admin')=='1';userId=parseInt($a.data('user-id'));
            $('#consilium-filter-gremium,#consilium-filter-status').on('change',this.loadList.bind(this));$('#consilium-back-to-list').on('click',this.showList.bind(this));
            if(canManage)$('#consilium-create-session').on('click',function(){App.showEditor(null);});
            if(window.location.hash==='#submit-topic'){var sid=new URLSearchParams(window.location.search).get('session_id');if(sid){this.showDetail(parseInt(sid));return;}}
            this.loadList();},
        loadList:function(){var self=this,p={},g=$('#consilium-filter-gremium').val(),s=$('#consilium-filter-status').val();if(g)p.gremium=g;if(s)p.status=s;
            var $l=$('#consilium-sessions-list').html('<p class="consilium-loading">'+i18n.loading+'</p>');
            api('GET','sessions',p).done(function(r){r.success?self.renderList(r.data):$l.html('<p class="consilium-error">'+i18n.error+'</p>');}).fail(function(){$l.html('<p class="consilium-error">'+i18n.error+'</p>');});},
        renderList:function(list){var $l=$('#consilium-sessions-list').empty(),self=this;if(!list.length){$l.html('<div class="consilium-empty"><p>Keine Sitzungen.</p></div>');return;}
            list.forEach(function(s){var time=fmtTime(s.time_start);if(s.time_end)time+=' – '+fmtTime(s.time_end);var ps=s.protocol_status||'none';
                var psH=ps!=='none'?' <span class="consilium-protocol-status consilium-protocol-status--'+esc(ps)+'">'+esc(s.protocol_status_label||ps)+'</span>':'';
                var $c=$('<div class="consilium-session-card"><div class="consilium-session-card__header"><h3>'+esc(s.title)+'</h3><div><span class="consilium-badge consilium-badge--'+esc(s.gremium)+'">'+esc(grem(s))+'</span> <span class="consilium-status consilium-status--'+esc(s.status)+'">'+esc(s.status_label)+'</span>'+psH+'</div></div>'
                    +'<div class="consilium-session-card__meta">📅 '+esc(fmtDate(s.session_date))+(time?' | 🕐 '+esc(time):'')+(s.location?' | 📍 '+esc(s.location):'')+' | 👥 '+(s.participant_count||0)+'</div></div>');
                $c.on('click',function(){self.showDetail(s.id);});$l.append($c);});},
        showList:function(){this.sid=null;$('#consilium-session-detail').hide();$('#consilium-session-editor').remove();$('.consilium-app__filters').show();$('#consilium-sessions-list').show();this.loadList();},
        showEditor:function(session){var isE=!!(session&&session.id);if(isE)this.sid=session.id;
            $('.consilium-app__filters').hide();$('#consilium-sessions-list').hide();$('#consilium-session-detail').hide();$('#consilium-session-editor').remove();
            var s=isE?session:{title:'',gremium:'pgr',custom_gremium_label:'',session_date:'',time_start:'19:00',time_end:'21:00',location:'',topic_deadline:'',reminder_days:3};
            var h='<div id="consilium-session-editor" class="consilium-editor"><button type="button" class="consilium-btn consilium-btn--back" id="ce-back">← Zurück</button><h2>'+(isE?'Sitzung bearbeiten':'Neue Sitzung')+'</h2><div class="consilium-form">';
            h+='<div class="consilium-field"><label>Titel *</label><input type="text" id="ce-title" value="'+esc(s.title)+'" class="consilium-input"></div>';
            h+='<div class="consilium-field"><label>Gremium</label><select id="ce-gremium" class="consilium-select">';['pgr','vvr','liturgieausschuss','sonstige'].forEach(function(g){h+='<option value="'+g+'"'+(s.gremium===g?' selected':'')+'>'+esc(GL[g])+'</option>';});h+='</select></div>';
            h+='<div class="consilium-field consilium-field--custom" style="'+(s.gremium==='sonstige'?'':'display:none;')+'"><label>Bezeichnung</label><input type="text" id="ce-custom" value="'+esc(s.custom_gremium_label||'')+'" class="consilium-input"></div>';
            h+='<div class="consilium-field-row"><div class="consilium-field"><label>Datum *</label><input type="date" id="ce-date" value="'+esc(s.session_date||'')+'" class="consilium-input"></div>';
            h+='<div class="consilium-field"><label>Von</label><input type="time" id="ce-start" value="'+esc(s.time_start||'19:00')+'" class="consilium-input"></div>';
            h+='<div class="consilium-field"><label>Bis</label><input type="time" id="ce-end" value="'+esc(s.time_end||'21:00')+'" class="consilium-input"></div></div>';
            h+='<div class="consilium-field"><label>Ort</label><input type="text" id="ce-location" value="'+esc(s.location||'')+'" class="consilium-input"></div>';
            h+='<div class="consilium-field-row"><div class="consilium-field"><label>TOP-Deadline</label><input type="date" id="ce-deadline" value="'+esc(s.topic_deadline||'')+'" class="consilium-input"></div>';
            h+='<div class="consilium-field"><label>Erinnerung (Tage)</label><input type="number" id="ce-reminder" value="'+(s.reminder_days||3)+'" min="0" max="30" class="consilium-input" style="width:80px;"></div></div>';
            h+='<button type="button" class="consilium-btn consilium-btn--primary" id="ce-save">'+(isE?'Speichern':'Erstellen')+'</button></div></div>';
            $('#isidor-consilium-app').append(h);
            $('#ce-back').on('click',function(){isE&&App.sid?App.showDetail(App.sid):App.showList();});
            $('#ce-gremium').on('change',function(){$(this).val()==='sonstige'?$('.consilium-field--custom').show():$('.consilium-field--custom').hide();});
            var self=this;$('#ce-save').on('click',function(){
                var d={title:$('#ce-title').val().trim(),gremium:$('#ce-gremium').val(),custom_gremium_label:$('#ce-custom').val().trim(),session_date:$('#ce-date').val(),time_start:$('#ce-start').val(),time_end:$('#ce-end').val(),location:$('#ce-location').val().trim(),topic_deadline:$('#ce-deadline').val()||null,reminder_days:parseInt($('#ce-reminder').val())||0};
                if(!d.title||!d.session_date){alert('Titel und Datum sind Pflicht.');return;}$(this).prop('disabled',true);
                if(isE)api('PUT','sessions/'+session.id,d).done(function(r){r.success?self.showDetail(session.id):alert(r.message||i18n.error);});
                else api('POST','sessions',d).done(function(r){r.success&&r.data?self.showDetail(r.data.id):alert(r.message||i18n.error);});
            });},
        showDetail:function(id){var self=this;this.sid=id;$('.consilium-app__filters').hide();$('#consilium-sessions-list').hide();$('#consilium-session-editor').remove();$('#consilium-session-detail').show();$('#consilium-detail-content').html('<p class="consilium-loading">'+i18n.loading+'</p>');api('GET','sessions/'+id).done(function(r){if(r.success)self.renderDetail(r.data);});},
        renderDetail:function(s){var $c=$('#consilium-detail-content'),ps=s.protocol_status||'none',editable=canManage&&s.status!=='archived'&&ps!=='finalized',h='';
            // Header
            h+='<div class="consilium-detail-header"><h2>'+esc(s.title)+'</h2><div class="consilium-detail-header__badges"><span class="consilium-badge consilium-badge--'+esc(s.gremium)+'">'+esc(grem(s))+'</span> <span class="consilium-status consilium-status--'+esc(s.status)+'">'+esc(s.status_label)+'</span>';
            if(ps!=='none')h+=' <span class="consilium-protocol-status consilium-protocol-status--'+esc(ps)+'">'+esc(s.protocol_status_label||ps)+'</span>';
            h+='</div>';if(canManage&&s.status!=='archived'){h+='<div class="consilium-detail-header__actions"><button class="consilium-btn consilium-btn--small" id="cd-edit">✏️</button>';if(s.status==='draft')h+=' <button class="consilium-btn consilium-btn--small consilium-btn--danger-text" id="cd-delete">🗑️</button>';h+='</div>';}h+='</div>';
            // Info
            h+='<div class="consilium-detail-info"><div class="consilium-detail-info__item"><label>Datum</label><span>'+esc(fmtDateLong(s.session_date))+'</span></div>';
            var tm=fmtTime(s.time_start);if(s.time_end)tm+=' – '+fmtTime(s.time_end);if(tm)h+='<div class="consilium-detail-info__item"><label>Uhrzeit</label><span>'+esc(tm)+' Uhr</span></div>';
            if(s.location)h+='<div class="consilium-detail-info__item"><label>Ort</label><span>'+esc(s.location)+'</span></div>';h+='</div>';
            // RSVP
            var myRsvp=null;if(s.participants)s.participants.forEach(function(p){if(p.user_id===userId)myRsvp=p.rsvp;});
            if(myRsvp!==null&&s.status!=='completed'&&s.status!=='archived'){
                h+='<div class="consilium-rsvp-bar"><span>Ihre Rückmeldung: <strong>'+esc(RSL[myRsvp])+'</strong></span><div class="consilium-rsvp-bar__actions">';
                ['accepted','declined','maybe'].forEach(function(r){h+='<button class="consilium-rsvp-btn'+(r===myRsvp?' consilium-rsvp-btn--active':'')+'" data-rsvp="'+r+'">'+esc(RSL[r])+'</button>';});h+='</div></div>';}
            if(canManage&&s.rsvp_summary){var rs=s.rsvp_summary;h+='<div class="consilium-rsvp-summary">✅ '+rs.accepted+' | ❌ '+rs.declined+' | ❓ '+rs.maybe+' | ⏳ '+rs.pending+'</div>';}
            // Actions
            if(canManage){h+='<div class="consilium-status-actions">';
                if(s.status==='draft')h+='<button class="consilium-btn consilium-btn--primary" id="cd-invite">📧 Einladungen</button> <button class="consilium-btn consilium-btn--success" id="cd-start">🔴 Starten</button>';
                if(s.status==='invited')h+='<button class="consilium-btn consilium-btn--secondary" id="cd-invite">📧 Erneut</button> <button class="consilium-btn consilium-btn--warning" id="cd-reminder">⏰ Erinnerung</button> <button class="consilium-btn consilium-btn--success" id="cd-start">🔴 Starten</button>';
                if(s.status==='active')h+='<button class="consilium-btn consilium-btn--primary" id="cd-complete">✅ Abschließen</button>';
                if(s.status==='completed'&&ps!=='finalized')h+='<button class="consilium-btn consilium-btn--success" id="cd-pfinalize">🔒 Protokoll ablegen</button>';
                if(s.status==='completed'&&ps==='finalized')h+='<button class="consilium-btn consilium-btn--primary" id="cd-send-protocol">📧 Protokoll versenden</button>';
                h+='</div>';}
            // Participants
            h+='<div class="consilium-detail-section"><h3>👥 Teilnehmer ('+(s.participants?s.participants.length:0)+')</h3>';
            if(s.participants&&s.participants.length){h+='<div class="consilium-participants">';s.participants.forEach(function(p){var ri=({accepted:'✅',declined:'❌',maybe:'❓',pending:'⏳'})[p.rsvp||'pending']||'⏳';
                h+='<div class="consilium-participant"><span>'+ri+' '+esc(p.name)+'</span>';if(editable)h+='<button class="consilium-participant__rm" data-uid="'+p.user_id+'">&times;</button>';h+='</div>';});h+='</div>';}
            if(editable)h+='<div class="consilium-add-participant"><input type="text" id="cd-psearch" placeholder="Suchen…" class="consilium-input"><div id="cd-presults" class="consilium-search-results"></div></div>';h+='</div>';
            // Topics
            h+='<div class="consilium-detail-section"><h3>📋 Tagesordnung</h3><div id="cd-topics">';
            var showProtocol=s.status==='active'||s.status==='completed';
            if(s.topics&&s.topics.length){s.topics.forEach(function(t,i){var ts=t.status||'planned',badge=TSL[ts]?' <span class="consilium-topic-badge consilium-topic-badge--'+ts+'">'+TSL[ts]+'</span>':'';
                var reporter=t.reporter_name?' <small class="consilium-topic-reporter">👤 '+esc(t.reporter_name)+'</small>':'';
                h+='<div class="consilium-topic"><div class="consilium-topic__header"><span class="consilium-topic__num">'+(i+1)+'</span> <span class="consilium-topic__title">'+esc(t.title)+badge+reporter+'</span>';
                if(editable){h+='<div class="consilium-topic__actions"><button class="ct-edit" data-tid="'+t.id+'">✏️</button><button class="ct-reporter" data-tid="'+t.id+'" data-rid="'+(t.reporter_user_id||0)+'" title="Berichterstatter/in">👤</button><button class="ct-del" data-tid="'+t.id+'">🗑️</button>';
                    if(ts==='submitted')h+='<button class="ct-accept" data-tid="'+t.id+'">👍</button><button class="ct-reject" data-tid="'+t.id+'">👎</button>';h+='</div>';}
                h+='</div>';
                if(showProtocol){h+='<div class="consilium-topic__protocol">';
                    if(editable)h+='<textarea class="consilium-ptextarea" data-tid="'+t.id+'" placeholder="Protokoll…"></textarea><button class="consilium-btn consilium-btn--small ct-psave" data-tid="'+t.id+'">Speichern</button>';
                    else h+='<div class="consilium-topic__pcontent" data-tid="'+t.id+'"><em class="consilium-loading">…</em></div>';
                    h+='</div>';}
                h+='</div>';});}else h+='<p class="consilium-muted">Keine TOPs.</p>';h+='</div>';
            if(editable){h+='<div class="consilium-add-topic"><div class="consilium-add-topic__row"><input type="text" id="cd-newtop" placeholder="Neuer TOP…" class="consilium-input">';
                h+='<select id="cd-newtop-reporter" class="consilium-select consilium-select--small"><option value="">Berichterstatter/in</option>';
                if(s.participants)s.participants.forEach(function(p){h+='<option value="'+p.user_id+'">'+esc(p.name)+'</option>';});
                h+='</select><button class="consilium-btn consilium-btn--primary consilium-btn--small" id="cd-addtop">+</button></div></div>';}
            // Topic submit
            if(!canManage&&myRsvp!==null&&s.topic_deadline&&s.topic_deadline>=new Date().toISOString().substring(0,10)){
                h+='<div class="consilium-submit-topic" id="cd-submit-topic"><h4>📝 Thema einreichen</h4><p class="consilium-help">Frist: '+esc(fmtDate(s.topic_deadline))+'</p>';
                h+='<input type="text" id="cd-submit-title" placeholder="Titel" class="consilium-input"><textarea id="cd-submit-desc" placeholder="Beschreibung (optional)" class="consilium-input" rows="2"></textarea>';
                h+='<button class="consilium-btn consilium-btn--primary" id="cd-submit-btn">Einreichen</button></div>';}
            h+='</div>';
            // Votes
            if(s.votes&&s.votes.length){h+='<div class="consilium-detail-section"><h3>🗳️ Abstimmungen</h3>';
                s.votes.forEach(function(v){var vs=v.status==='active'?'active':(v.status==='closed'?'completed':'draft');
                    h+='<div class="consilium-vote-item"><strong>'+esc(v.title)+(v.timing==='advance'?' <small>(Vorab)</small>':'')+'</strong> <span class="consilium-status consilium-status--'+vs+'">'+esc(v.status)+'</span>';
                    if(v.status==='closed')h+='<div class="consilium-vr" data-vid="'+v.id+'"><em>…</em></div>';
                    if(canManage&&s.status==='active'){if(v.status==='pending')h+='<button class="consilium-btn consilium-btn--small cd-vstart" data-vid="'+v.id+'">▶</button>';if(v.status==='active')h+='<button class="consilium-btn consilium-btn--small consilium-btn--danger cd-vstop" data-vid="'+v.id+'">⏹</button>';}
                    h+='</div>';});h+='</div>';}
            // New vote
            if(canManage&&(s.status==='active'||s.status==='draft'||s.status==='invited')){
                h+='<div class="consilium-detail-section"><h3>➕ Neue Abstimmung</h3><div class="consilium-form consilium-form--compact">';
                h+='<input type="text" id="cd-vtitle" placeholder="Titel" class="consilium-input">';
                h+='<div class="consilium-field-row"><select id="cd-vmode" class="consilium-select"><option value="open">Offen</option><option value="secret">Geheim</option></select><select id="cd-vtiming" class="consilium-select"><option value="live">Live</option><option value="advance">Vorab</option></select></div>';
                h+='<input type="text" id="cd-voptions" placeholder="Optionen (kommagetrennt, leer=Ja/Nein/Enthaltung)" class="consilium-input">';
                h+='<button class="consilium-btn consilium-btn--primary consilium-btn--small" id="cd-cvote">Erstellen</button></div></div>';}
            $c.html(h);this.bindDetail(s);},
        bindDetail:function(s){var self=this,sid=s.id;
            $('#cd-edit').on('click',function(){self.showEditor(s);});
            $('#cd-delete').on('click',function(){if(!confirm('Löschen?'))return;api('DELETE','sessions/'+sid).done(function(r){r.success?self.showList():alert(r.message||i18n.error);});});
            $('#cd-invite').on('click',function(){$(this).prop('disabled',true).text('…');api('POST','sessions/'+sid+'/send-invitations').done(function(r){alert(r.success?'Gesendet ('+r.data.sent+').':(r.message||i18n.error));self.showDetail(sid);});});
            $('#cd-start').on('click',function(){if(!confirm('Sitzung starten?'))return;$(this).prop('disabled',true);api('POST','sessions/'+sid+'/start').done(function(){self.showDetail(sid);});});
            $('#cd-complete').on('click',function(){if(!confirm('Abschließen?'))return;$(this).prop('disabled',true);api('POST','sessions/'+sid+'/complete').done(function(){self.showDetail(sid);});});
            $('#cd-reminder').on('click',function(){$(this).prop('disabled',true);api('POST','sessions/'+sid+'/send-reminder').done(function(){alert('Gesendet.');self.showDetail(sid);});});
            $('#cd-pfinalize').on('click',function(){if(!confirm('Protokoll ablegen?'))return;$(this).prop('disabled',true);api('POST','sessions/'+sid+'/protocol-finalize').done(function(r){alert(r.success?'Abgelegt.':(r.message||i18n.error));self.showDetail(sid);});});
            $('#cd-send-protocol').on('click',function(){if(!confirm('Protokoll versenden?'))return;$(this).prop('disabled',true);api('POST','sessions/'+sid+'/send-protocol').done(function(r){alert(r.success?'Versendet.':(r.message||i18n.error));self.showDetail(sid);});});
            // RSVP
            $('.consilium-rsvp-btn').on('click',function(){var rsvp=$(this).data('rsvp');$('.consilium-rsvp-btn').removeClass('consilium-rsvp-btn--active');$(this).addClass('consilium-rsvp-btn--active');api('POST','sessions/'+sid+'/rsvp',{rsvp:rsvp});});
            // Topic submit
            $('#cd-submit-btn').on('click',function(){var t=$('#cd-submit-title').val().trim();if(!t){alert('Titel!');return;}$(this).prop('disabled',true);api('POST','sessions/'+sid+'/submit-topic',{title:t,description:$('#cd-submit-desc').val().trim()}).done(function(r){alert(r.success?'Eingereicht!':(r.message||i18n.error));self.showDetail(sid);});});
            // Participants
            $('.consilium-participant__rm').on('click',function(e){e.stopPropagation();if(!confirm('Entfernen?'))return;api('DELETE','sessions/'+sid+'/participants/'+$(this).data('uid')).done(function(){self.showDetail(sid);});});
            var st;$('#cd-psearch').on('input',function(){var q=$(this).val().trim();clearTimeout(st);if(q.length<2){$('#cd-presults').empty();return;}
                st=setTimeout(function(){api('GET','users/search',{search:q}).done(function(r){if(!r.success)return;var $r=$('#cd-presults').empty();r.data.forEach(function(u){$('<div class="consilium-search-result">'+esc(u.name)+' <small>('+esc(u.email)+')</small></div>').on('click',function(){api('POST','sessions/'+sid+'/participants',{user_id:u.id}).done(function(){self.showDetail(sid);});}).appendTo($r);});});},300);});
            // Topics CRUD
            $('#cd-addtop').on('click',function(){var t=$('#cd-newtop').val().trim();if(!t)return;var rid=$('#cd-newtop-reporter').val()||null;api('POST','sessions/'+sid+'/topics',{title:t,reporter_user_id:rid}).done(function(){self.showDetail(sid);});});
            $('#cd-newtop').on('keypress',function(e){if(e.which===13)$('#cd-addtop').click();});
            $('.ct-edit').on('click',function(e){e.stopPropagation();var tid=$(this).data('tid'),nw=prompt('Umbenennen:');if(nw&&nw.trim())api('PUT','topics/'+tid,{title:nw.trim()}).done(function(){self.showDetail(sid);});});
            $('.ct-reporter').on('click',function(e){e.stopPropagation();var tid=$(this).data('tid'),curRid=$(this).data('rid')||0;
                var names={0:'– Keine/r –'};if(s.participants)s.participants.forEach(function(p){names[p.user_id]=p.name;});
                var msg='Berichterstatter/in wählen:\n';Object.keys(names).forEach(function(k){msg+=k+' = '+names[k]+'\n';});
                var chosen=prompt(msg,curRid);if(chosen===null)return;api('PUT','topics/'+tid,{reporter_user_id:parseInt(chosen)||0}).done(function(){self.showDetail(sid);});});
            $('.ct-del').on('click',function(e){e.stopPropagation();if(!confirm('Löschen?'))return;api('DELETE','topics/'+$(this).data('tid')).done(function(){self.showDetail(sid);});});
            $('.ct-accept').on('click',function(e){e.stopPropagation();api('PUT','topics/'+$(this).data('tid')+'/accept').done(function(){self.showDetail(sid);});});
            $('.ct-reject').on('click',function(e){e.stopPropagation();api('PUT','topics/'+$(this).data('tid')+'/reject').done(function(){self.showDetail(sid);});});
            // Protocols (only load when session is active or completed)
            if((s.status==='active'||s.status==='completed')&&s.topics)s.topics.forEach(function(t){api('GET','protocols/'+t.id).done(function(r){if(r.success&&r.data&&r.data.content){$('.consilium-ptextarea[data-tid="'+t.id+'"]').val(strip(r.data.content));$('.consilium-topic__pcontent[data-tid="'+t.id+'"]').html(r.data.content);}else{$('.consilium-topic__pcontent[data-tid="'+t.id+'"]').html('<em class="consilium-muted">–</em>');}});});
            $('.ct-psave').on('click',function(){var tid=$(this).data('tid'),txt=$('.consilium-ptextarea[data-tid="'+tid+'"]').val(),$b=$(this).prop('disabled',true).text('…');api('PUT','protocols/'+tid,{content:'<p>'+txt.replace(/\n/g,'</p><p>')+'</p>'}).done(function(r){$b.prop('disabled',false).text(r.success?'✓':'!');setTimeout(function(){$b.text('Speichern');},2000);});});
            // Votes
            $('.cd-vstart').on('click',function(){$(this).prop('disabled',true);api('PUT','votes/'+$(this).data('vid')+'/start').done(function(){self.showDetail(sid);});});
            $('.cd-vstop').on('click',function(){if(!confirm('Beenden?'))return;$(this).prop('disabled',true);api('PUT','votes/'+$(this).data('vid')+'/stop').done(function(){self.showDetail(sid);});});
            $('#cd-cvote').on('click',function(){var t=$('#cd-vtitle').val().trim();if(!t){alert('Titel!');return;}$(this).prop('disabled',true);
                var optsRaw=$('#cd-voptions').val().trim(),opts=optsRaw?optsRaw.split(',').map(function(x){return x.trim();}).filter(Boolean):null,timing=$('#cd-vtiming').val()||'live';
                api('POST','votes',{session_id:sid,title:t,mode:$('#cd-vmode').val(),timing:timing,options:opts}).done(function(r){if(r.success&&timing==='live'&&r.data&&r.data.id)api('PUT','votes/'+r.data.id+'/start').always(function(){self.showDetail(sid);});else self.showDetail(sid);});});
            $('.consilium-vr').each(function(){var vid=$(this).data('vid'),$co=$(this);api('GET','votes/'+vid+'/results').done(function(r){if(r.success&&r.data&&r.data.results){var rh='<table class="consilium-vote-table"><thead><tr><th>Option</th><th>#</th><th>%</th></tr></thead><tbody>';r.data.results.forEach(function(x){rh+='<tr><td>'+esc(x.option)+'</td><td>'+x.count+'</td><td>'+x.percent+'%</td></tr>';});rh+='</tbody></table>';$co.html(rh);}else $co.html('<em>–</em>');});});
            if(window.location.hash==='#submit-topic')setTimeout(function(){var el=document.getElementById('cd-submit-topic');if(el)el.scrollIntoView({behavior:'smooth'});},300);}
    };

    // VOTE PAGE
    var Vote={timer:null,sessionId:0,
        init:function(){var $v=$('#isidor-consilium-vote');if(!$v.length)return;this.sessionId=parseInt($v.data('session-id'))||0;userId=parseInt($v.data('user-id'));if(this.sessionId){this.poll();this.timer=setInterval(this.poll.bind(this),5000);}else this.loadSessions();},
        loadSessions:function(){api('GET','sessions',{}).done(function(r){var all=(r.success?r.data:[]).filter(function(s){return s.status==='active'||s.status==='invited';});var $c=$('#consilium-vote-session-list').empty();if(!all.length){$c.html('<p class="consilium-muted">Keine aktiven Sitzungen.</p>');return;}
            all.forEach(function(s){$('<div class="consilium-session-card consilium-session-card--compact"><h3>'+esc(s.title)+'</h3><span>📅 '+esc(fmtDate(s.session_date))+'</span></div>').on('click',function(){window.location.href=window.location.pathname+'?session_id='+s.id;}).appendTo($c);});});},
        poll:function(){var self=this;api('GET','sessions/'+this.sessionId+'/live-state').done(function(r){if(!r.success)return;var active=null;(r.votes||[]).forEach(function(v){if(v.status==='active')active=v;});if(active)self.showVote(active);else self.showOverview(r.votes||[],r.session);});},
        showVote:function(v){var self=this,$c=$('#consilium-vote-content');api('GET','votes/'+v.id+'/status').done(function(r){if(!r.success)return;if(r.data.user_voted){$c.html('<div class="consilium-vote-voted"><div class="consilium-vote-voted__icon">✓</div><h3>Abgestimmt</h3><p class="consilium-muted">Ergebnis nach Schließung.</p></div>');return;}
            var opts=v.options||['Ja','Nein','Enthaltung'],ml=v.mode==='secret'?'🔒 Geheim':'👁 Offen',h='<div class="consilium-vote-active"><div class="consilium-vote-active__title">'+esc(v.title)+'</div><div class="consilium-vote-active__mode">'+ml+'</div><div class="consilium-vote-active__options">';
            opts.forEach(function(o){h+='<button class="consilium-vote-option-btn" data-vid="'+v.id+'" data-c="'+esc(o)+'">'+esc(o)+'</button>';});h+='</div></div>';$c.html(h);
            $c.find('.consilium-vote-option-btn').on('click',function(){var ch=$(this).data('c'),vid=$(this).data('vid');if(!confirm('"'+ch+'"?'))return;$(this).addClass('consilium-vote-option-btn--selected');$c.find('.consilium-vote-option-btn').prop('disabled',true);
                api('POST','votes/'+vid+'/cast',{choice:ch}).done(function(r){r.success?$c.html('<div class="consilium-vote-voted"><div class="consilium-vote-voted__icon">✓</div><h3>Erfasst!</h3></div>'):(alert(r.message||i18n.error),$c.find('.consilium-vote-option-btn').prop('disabled',false).removeClass('consilium-vote-option-btn--selected'));});});});},
        showOverview:function(votes,session){var h='<div class="consilium-vote-overview"><h3>'+esc(session.title)+'</h3><p class="consilium-muted">'+esc(fmtDateLong(session.session_date))+'</p>';
            if(!votes.length)h+='<div class="consilium-vote-waiting"><div class="consilium-spinner"></div><p>Warten auf Abstimmung…</p></div>';
            else votes.forEach(function(v){h+='<div class="consilium-vote-overview__item"><strong>'+esc(v.title)+'</strong>';
                if(v.status==='closed'&&v.results&&v.results.results){h+=' ✅<div class="consilium-vote-mini-results">';v.results.results.forEach(function(x){h+='<div class="consilium-vote-result-row"><span class="consilium-vote-result-label">'+esc(x.option)+'</span><div class="consilium-vote-result-bar"><div class="consilium-vote-result-fill" style="width:'+x.percent+'%"></div></div><span class="consilium-vote-result-count">'+x.count+'</span></div>';});h+='</div>';}
                else if(v.status==='pending')h+=' <span class="consilium-status consilium-status--draft">Geplant</span>';h+='</div>';});
            h+='</div>';$('#consilium-vote-content').html(h);}
    };

    // LIVE DASHBOARD
    var Live={timer:null,sessionId:0,
        init:function(){var $l=$('#isidor-consilium-live');if(!$l.length)return;this.sessionId=parseInt($l.data('session-id'));userId=parseInt($l.data('user-id'));this.load();this.timer=setInterval(this.load.bind(this),5000);
            $('#consilium-live-end').on('click',this.endSession.bind(this));$('#consilium-live-new-vote').on('click',this.newVote.bind(this));},
        load:function(){var self=this;api('GET','sessions/'+this.sessionId+'/live-state').done(function(r){if(r.success)self.render(r);});},
        render:function(d){var s=d.session,topics=d.topics||[],parts=d.participants||[],votes=d.votes||[],protos=d.protocols||{},rsvp=d.rsvp_summary||{};
            var tm=fmtTime(s.time_start);if(s.time_end)tm+=' – '+fmtTime(s.time_end);
            $('#consilium-live-info').html('<strong>'+esc(s.title)+'</strong> | 📅 '+esc(fmtDateLong(s.session_date))+(tm?' | 🕐 '+esc(tm):'')+(s.location?' | 📍 '+esc(s.location):'')+' <span class="consilium-status consilium-status--'+esc(s.status)+'">'+(s.status==='active'?'🔴 LIVE':esc(s.status))+'</span>');
            // Topics
            var th='';topics.forEach(function(t,i){th+='<div class="consilium-live-topic"><span class="consilium-live-topic__num">'+(i+1)+'</span> <strong>'+esc(t.title)+'</strong></div>';});
            $('#consilium-live-topics').html(th||'<p class="consilium-muted">–</p>');
            // Protocol
            var ph='';topics.forEach(function(t,i){var c=strip(protos[t.id]||'');ph+='<div class="consilium-live-protocol-item"><label><strong>TOP '+(i+1)+'</strong></label><textarea class="consilium-live-ptextarea" data-tid="'+t.id+'" rows="3">'+esc(c)+'</textarea><button class="consilium-btn consilium-btn--small cl-psave" data-tid="'+t.id+'">💾</button></div>';});
            $('#consilium-live-protocol').html(ph);var self=this;$('.cl-psave').off('click').on('click',function(){var tid=$(this).data('tid'),txt=$('.consilium-live-ptextarea[data-tid="'+tid+'"]').val(),$b=$(this).text('…');api('PUT','protocols/'+tid,{content:'<p>'+txt.replace(/\n/g,'</p><p>')+'</p>'}).done(function(r){$b.text(r.success?'✓':'!');setTimeout(function(){$b.text('💾');},2000);});});
            // Attendance
            var ah='';parts.forEach(function(p){var ck=parseInt(p.attended)?'checked':'',ri=({accepted:'✅',declined:'❌',maybe:'❓',pending:'⏳'})[p.rsvp||'pending']||'⏳';ah+='<div class="consilium-live-attendee"><label><input type="checkbox" class="cl-attend" data-uid="'+p.user_id+'" '+ck+'> '+esc(p.display_name)+'</label> <small>'+ri+'</small></div>';});
            $('#consilium-live-attendance').html(ah||'<p class="consilium-muted">–</p>');
            $('.cl-attend').off('change').on('change',function(){var atts={};$('.cl-attend').each(function(){atts[$(this).data('uid')]=$(this).is(':checked')?1:0;});api('PUT','sessions/'+self.sessionId+'/attendance',{attendance:atts});});
            // Votes
            var vh='';votes.forEach(function(v){var sc=v.status==='active'?'active':(v.status==='closed'?'completed':'draft');
                vh+='<div class="consilium-live-vote"><strong>'+esc(v.title)+'</strong> <span class="consilium-status consilium-status--'+sc+'">'+esc(v.status)+'</span>';
                if(v.status==='active')vh+=' <small>('+v.ballot_count+')</small>';
                if(v.status==='pending')vh+=' <button class="consilium-btn consilium-btn--small cl-vstart" data-vid="'+v.id+'">▶</button>';
                if(v.status==='active')vh+=' <button class="consilium-btn consilium-btn--small consilium-btn--danger cl-vstop" data-vid="'+v.id+'">⏹</button>';
                if(v.status==='closed'&&v.results&&v.results.results){vh+='<div class="consilium-live-vote__results">';v.results.results.forEach(function(x){vh+='<div class="consilium-vote-result-row"><span class="consilium-vote-result-label">'+esc(x.option)+'</span><div class="consilium-vote-result-bar"><div class="consilium-vote-result-fill" style="width:'+x.percent+'%"></div></div><span class="consilium-vote-result-count">'+x.count+'</span></div>';});vh+='</div>';}
                vh+='</div>';});
            $('#consilium-live-votes').html(vh||'<p class="consilium-muted">–</p>');
            $('.cl-vstart').off('click').on('click',function(){$(this).prop('disabled',true);api('PUT','votes/'+$(this).data('vid')+'/start').done(function(){self.load();});});
            $('.cl-vstop').off('click').on('click',function(){if(!confirm('Beenden?'))return;$(this).prop('disabled',true);api('PUT','votes/'+$(this).data('vid')+'/stop').done(function(){self.load();});});
            // RSVP
            $('#consilium-live-rsvp').html('✅ '+rsvp.accepted+' | ❌ '+rsvp.declined+' | ❓ '+rsvp.maybe+' | ⏳ '+rsvp.pending);},
        newVote:function(){var self=this,title=prompt('Abstimmungstitel:');if(!title||!title.trim())return;
            var mode=confirm('Geheim? (OK=Geheim)')?'secret':'open';
            var optsRaw=prompt('Optionen (kommagetrennt, leer=Ja/Nein/Enthaltung):','');
            var opts=optsRaw?optsRaw.split(',').map(function(x){return x.trim();}).filter(Boolean):null;
            api('POST','votes',{session_id:self.sessionId,title:title.trim(),mode:mode,timing:'live',options:opts}).done(function(r){if(r.success&&r.data&&r.data.id)api('PUT','votes/'+r.data.id+'/start').done(function(){self.load();});else alert(r.message||i18n.error);});},
        endSession:function(){if(!confirm('Sitzung beenden?'))return;var self=this;api('POST','sessions/'+this.sessionId+'/complete').done(function(r){if(r.success){clearInterval(self.timer);alert('Abgeschlossen.');window.location.reload();}});}
    };

    $(document).ready(function(){if(typeof isidorConsilium!=='undefined'){canVote=isidorConsilium.currentUser&&isidorConsilium.currentUser.canVote;App.init();Vote.init();Live.init();}});
})(jQuery);
