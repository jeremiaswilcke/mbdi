/**
 * Isidor Shell – App Interaction Layer
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', init);

    function init() {
        setupMenuToggle();
        setupNavOverlay();
        setupActiveStates();
        setupScrollHeader();
    }

    /* -------- Hamburger / Sidebar Toggle -------- */
    function setupMenuToggle() {
        var btn = document.getElementById('isidor-menu-toggle');
        var nav = document.getElementById('isidor-shell-nav');
        if (!btn || !nav) return;

        btn.addEventListener('click', function () {
            var isOpen = nav.classList.toggle('open');
            btn.classList.toggle('open', isOpen);
            document.body.style.overflow = isOpen ? 'hidden' : '';
        });
    }

    /* -------- Overlay click closes nav -------- */
    function setupNavOverlay() {
        var overlay = document.getElementById('isidor-nav-overlay');
        var nav = document.getElementById('isidor-shell-nav');
        var btn = document.getElementById('isidor-menu-toggle');
        if (!overlay) return;

        overlay.addEventListener('click', function () {
            if (nav) nav.classList.remove('open');
            if (btn) btn.classList.remove('open');
            document.body.style.overflow = '';
        });
    }

    /* -------- Mark active nav based on URL -------- */
    function setupActiveStates() {
        var current = window.location.pathname.replace(/\/+$/, '');
        var items = document.querySelectorAll('.isidor-nav-item, .isidor-bottom-item');

        items.forEach(function (item) {
            var href = item.getAttribute('href');
            if (!href) return;

            var link = href.replace(/\/+$/, '');
            // Extract pathname if full URL
            try {
                var u = new URL(href, window.location.origin);
                link = u.pathname.replace(/\/+$/, '');
            } catch (e) {}

            if (link === current) {
                item.classList.add('active');
            }
        });
    }

    /* -------- Subtle header shadow on scroll -------- */
    function setupScrollHeader() {
        var header = document.querySelector('.isidor-shell-header');
        if (!header) return;

        var scrolled = false;

        window.addEventListener('scroll', function () {
            var isScrolled = window.scrollY > 8;
            if (isScrolled !== scrolled) {
                scrolled = isScrolled;
                header.style.boxShadow = scrolled
                    ? '0 2px 12px rgba(0,0,0,0.15)'
                    : 'none';
            }
        }, { passive: true });
    }

})();
