/**
 * Liturgia Admin JavaScript
 *
 * Drag&Drop Sortierung, AJAX CRUD, wp_editor Handling, Modals.
 *
 * @package IsidorSuite\Liturgia
 */

(function($) {
    'use strict';

    // ========================================================================
    // GLOBALS
    // ========================================================================

    var data = window.liturgiaData || {};

    // ========================================================================
    // INIT
    // ========================================================================

    $(document).ready(function() {
        // Übersicht: Events laden
        if ($('#liturgia-events-body').length) {
            liturgiaLoadEvents();
        }

        // Detail: Sortable initialisieren
        if ($('#liturgia-elements-list').length) {
            initSortable();
            initWPEditors();
        }

        // Event-Bindings
        bindOverviewEvents();
        bindDetailEvents();
        bindModalEvents();
    });

    // ========================================================================
    // ÜBERSICHT
    // ========================================================================

    function liturgiaLoadEvents() {
        var period = $('#liturgia-filter-period').val();
        var status = $('#liturgia-filter-status').val();
        var type = $('#liturgia-filter-type').val();

        $('#liturgia-events-body').html('<tr><td colspan="6" style="text-align:center;padding:30px;">Wird geladen...</td></tr>');

        $.post(data.ajaxUrl, {
            action: 'liturgia_list_events',
            _wpnonce: data.nonce,
            period: period,
            status: status,
            event_type: type
        }, function(response) {
            if (response.success) {
                renderEventsTable(response.data.events);
            } else {
                $('#liturgia-events-body').html('<tr><td colspan="6" style="text-align:center;color:red;">Fehler beim Laden</td></tr>');
            }
        });
    }

    function renderEventsTable(events) {
        var $body = $('#liturgia-events-body');

        if (!events || events.length === 0) {
            $body.html('<tr><td colspan="6" style="text-align:center;padding:40px;color:#666;">Keine Gottesdienste gefunden.</td></tr>');
            return;
        }

        var statuses = data.statuses;
        var eventTypes = data.eventTypes;
        var html = '';

        events.forEach(function(ev) {
            var st = statuses[ev.status] || statuses['entwurf'];
            var typeLabel = eventTypes[ev.event_type] || ev.event_type;
            var dateStr = formatDate(ev.event_date);

            html += '<tr>';
            html += '<td><strong>' + dateStr + '</strong></td>';
            html += '<td><a href="' + data.editUrl + ev.id + '" class="liturgia-event-title-link">' + escHtml(ev.event_title) + '</a>';
            if (ev.location_default) {
                html += '<br><small style="color:#888;">📍 ' + escHtml(ev.location_default) + '</small>';
            }
            html += '</td>';
            html += '<td>' + escHtml(typeLabel) + '</td>';
            html += '<td><span class="liturgia-badge" style="background:' + st.bg + ';color:' + st.color + '">' + st.label + '</span></td>';
            html += '<td style="text-align:center;">' + (ev.element_count || 0) + '</td>';
            html += '<td>';
            html += '<a href="' + data.editUrl + ev.id + '" class="button button-small">Bearbeiten</a> ';
            html += '<button type="button" class="button button-small liturgia-delete-event-btn" data-id="' + ev.id + '" data-title="' + escHtml(ev.event_title) + '" style="color:#d63638;">Löschen</button>';
            html += '</td>';
            html += '</tr>';
        });

        $body.html(html);

        // Auch Kalender aktualisieren
        renderCalendar(events);
    }

    function renderCalendar(events) {
        var $cal = $('#liturgia-calendar-grid');
        if (!$cal.length) return;

        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth();

        // Map events nach Datum
        var eventMap = {};
        events.forEach(function(ev) {
            if (!eventMap[ev.event_date]) eventMap[ev.event_date] = [];
            eventMap[ev.event_date].push(ev);
        });

        var days = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
        var html = '';

        // Header
        days.forEach(function(d) {
            html += '<div class="liturgia-calendar-header">' + d + '</div>';
        });

        // Erster Tag des Monats
        var first = new Date(year, month, 1);
        var startDay = (first.getDay() + 6) % 7; // Mo=0
        var daysInMonth = new Date(year, month + 1, 0).getDate();

        // Leere Zellen
        for (var i = 0; i < startDay; i++) {
            html += '<div class="liturgia-calendar-day other-month"></div>';
        }

        var todayStr = formatDateISO(today);
        var statusColors = {
            'entwurf': '#6b7280',
            'in_abstimmung': '#d97706',
            'freigegeben': '#059669',
            'abgeschlossen': '#2563eb'
        };

        for (var d = 1; d <= daysInMonth; d++) {
            var dateStr = year + '-' + pad(month + 1) + '-' + pad(d);
            var isToday = dateStr === todayStr;

            html += '<div class="liturgia-calendar-day' + (isToday ? ' today' : '') + '">';
            html += '<div class="liturgia-calendar-date">' + d + '</div>';

            if (eventMap[dateStr]) {
                eventMap[dateStr].forEach(function(ev) {
                    var color = statusColors[ev.status] || '#6b7280';
                    html += '<a href="' + data.editUrl + ev.id + '" class="liturgia-calendar-event" style="background:' + color + ';" title="' + escHtml(ev.event_title) + '">';
                    html += escHtml(ev.event_title);
                    html += '</a>';
                });
            }

            html += '</div>';
        }

        $cal.html(html);
    }

    function bindOverviewEvents() {
        // Filter
        $(document).on('change', '#liturgia-filter-period, #liturgia-filter-status, #liturgia-filter-type', liturgiaLoadEvents);

        // Ansicht umschalten
        $(document).on('click', '.liturgia-view-toggle .button', function() {
            var view = $(this).data('view');
            $('.liturgia-view-toggle .button').removeClass('active');
            $(this).addClass('active');

            if (view === 'calendar') {
                $('#liturgia-list-view').hide();
                $('#liturgia-calendar-view').show();
            } else {
                $('#liturgia-list-view').show();
                $('#liturgia-calendar-view').hide();
            }
        });

        // Neues Event erstellen
        $(document).on('click', '#liturgia-create-event', function() {
            $('#liturgia-new-title').val('');
            $('#liturgia-new-date').val('');
            $('#liturgia-new-type').val('hochamt');
            $('#liturgia-new-location').val('');
            $('#liturgia-new-template').val('');
            $('#liturgia-create-modal').show();
            $('#liturgia-new-title').focus();
        });

        // Event erstellen ausführen
        $(document).on('click', '#liturgia-do-create', function() {
            var title = $('#liturgia-new-title').val().trim();
            var date = $('#liturgia-new-date').val();

            if (!title) {
                alert('Bitte einen Titel eingeben.');
                return;
            }
            if (!date) {
                alert('Bitte ein Datum auswählen.');
                return;
            }

            var $btn = $(this);
            $btn.prop('disabled', true).text('Wird erstellt...');

            $.post(data.ajaxUrl, {
                action: 'liturgia_save_event',
                _wpnonce: data.nonce,
                event_title: title,
                event_date: date,
                event_type: $('#liturgia-new-type').val(),
                location_default: $('#liturgia-new-location').val(),
                template_id: $('#liturgia-new-template').val()
            }, function(response) {
                $btn.prop('disabled', false).text('Erstellen & Bearbeiten');
                if (response.success) {
                    window.location.href = data.editUrl + response.data.id;
                } else {
                    alert(response.data.message || 'Fehler beim Erstellen');
                }
            });
        });

        // Event löschen (Übersicht)
        $(document).on('click', '.liturgia-delete-event-btn', function() {
            var id = $(this).data('id');
            var title = $(this).data('title');

            if (!confirm('Event "' + title + '" wirklich löschen? Dies kann nicht rückgängig gemacht werden.')) {
                return;
            }

            $.post(data.ajaxUrl, {
                action: 'liturgia_delete_event',
                _wpnonce: data.nonce,
                id: id
            }, function(response) {
                if (response.success) {
                    liturgiaLoadEvents();
                } else {
                    alert(response.data.message || 'Fehler');
                }
            });
        });
    }

    // ========================================================================
    // DETAIL
    // ========================================================================

    function bindDetailEvents() {
        var $eventId = $('#liturgia-event-id');
        if (!$eventId.length) return;

        var eventId = parseInt($eventId.val());

        // Status ändern
        $(document).on('change', '#liturgia-status-select', function() {
            var status = $(this).val();

            $.post(data.ajaxUrl, {
                action: 'liturgia_update_status',
                _wpnonce: data.nonce,
                id: eventId,
                status: status
            }, function(response) {
                if (response.success) {
                    var st = data.statuses[status];
                    $('.liturgia-detail-header .liturgia-badge')
                        .css({ background: st.bg, color: st.color })
                        .text(st.label);
                    $('#liturgia-summary-status').text(st.label);
                }
            });
        });

        // Grunddaten speichern
        $(document).on('click', '#liturgia-save-meta', function() {
            var $btn = $(this);
            $btn.prop('disabled', true).text('Speichern...');

            // TinyMCE triggerSave
            if (typeof tinyMCE !== 'undefined') {
                tinyMCE.triggerSave();
            }

            $.post(data.ajaxUrl, {
                action: 'liturgia_save_event',
                _wpnonce: data.nonce,
                id: eventId,
                event_title: $('#liturgia-edit-title').val(),
                event_date: $('#liturgia-edit-date').val(),
                event_type: $('#liturgia-edit-type').val(),
                location_default: $('#liturgia-edit-location').val(),
                post_id: $('#liturgia-edit-post-id').val(),
                notes: $('#liturgia_event_notes').val()
            }, function(response) {
                $btn.prop('disabled', false).text('Grunddaten speichern');
                if (response.success) {
                    // Header aktualisieren
                    $('#liturgia-event-title-display').text($('#liturgia-edit-title').val());
                    showNotice('Grunddaten gespeichert!', 'success');
                } else {
                    showNotice(response.data.message || 'Fehler', 'error');
                }
            });
        });

        // Element speichern
        $(document).on('click', '.liturgia-el-save', function() {
            var $card = $(this).closest('.liturgia-element-card');
            saveElement($card);
        });

        // Element löschen
        $(document).on('click', '.liturgia-el-delete', function() {
            if (!confirm('Element wirklich löschen?')) return;

            var $card = $(this).closest('.liturgia-element-card');
            var elId = $card.data('id');

            if (elId) {
                $.post(data.ajaxUrl, {
                    action: 'liturgia_delete_element',
                    _wpnonce: data.nonce,
                    element_id: elId
                }, function(response) {
                    if (response.success) {
                        $card.slideUp(200, function() { $(this).remove(); updateCounts(); });
                    }
                });
            } else {
                $card.slideUp(200, function() { $(this).remove(); updateCounts(); });
            }
        });

        // Neues Element hinzufügen
        $(document).on('click', '#liturgia-add-element', function() {
            addNewElement(eventId);
        });

        // Element-Typ ändern → bedingte Felder (v2: erweiterte Lied-Typen)
        $(document).on('change', '.liturgia-el-type', function() {
            var type = $(this).val();
            var $card = $(this).closest('.liturgia-element-card');

            // Lied-Typen (alles was einen Cantus-Slot hat)
            var liedTypes = ['lied', 'einzug', 'kyrie', 'gloria', 'sanctus', 'agnus_dei',
                             'kommunion', 'antwortpsalm', 'ruf_vor_evangelium', 'gabenbereitung', 'auszug'];
            var lesungTypes = ['lesung', 'evangelium', 'fuerbitten'];

            $card.find('.liturgia-cond-lied').toggle(liedTypes.indexOf(type) >= 0);
            $card.find('.liturgia-cond-lesung').toggle(lesungTypes.indexOf(type) >= 0);

            // Typ-Badge im Header aktualisieren
            var typeLabel = data.elementTypes[type] || type;
            $card.find('.liturgia-element-type-badge').text(typeLabel);
        });

        // Drucken
        $(document).on('click', '#liturgia-print-btn', function() {
            window.open(data.printUrl + eventId, '_blank');
        });

        // PDF
        $(document).on('click', '#liturgia-pdf-btn', function() {
            window.location.href = data.pdfUrl + eventId + '&_wpnonce=' + data.nonce;
        });

        // E-Mail Modal öffnen
        $(document).on('click', '#liturgia-email-btn', function() {
            openEmailModal(eventId);
        });

        // Vorlage laden Modal
        $(document).on('click', '#liturgia-load-template', function() {
            $('#liturgia-template-modal').show();
        });

        // Vorlage anwenden
        $(document).on('click', '#liturgia-do-apply-template', function() {
            var templateId = $('#liturgia-template-select').val();
            if (!templateId) {
                alert('Bitte eine Vorlage wählen.');
                return;
            }

            if (!confirm('Bestehende Elemente werden durch die Vorlage ersetzt. Fortfahren?')) return;

            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(data.ajaxUrl, {
                action: 'liturgia_apply_template',
                _wpnonce: data.nonce,
                event_id: eventId,
                template_id: templateId
            }, function(response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    closeAllModals();
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Fehler');
                }
            });
        });

        // Als Vorlage speichern
        $(document).on('click', '#liturgia-save-as-template', function() {
            $('#liturgia-template-name').val('');
            $('#liturgia-save-template-modal').show();
            $('#liturgia-template-name').focus();
        });

        $(document).on('click', '#liturgia-do-save-template', function() {
            var name = $('#liturgia-template-name').val().trim();
            if (!name) {
                alert('Bitte einen Namen eingeben.');
                return;
            }

            $.post(data.ajaxUrl, {
                action: 'liturgia_save_template',
                _wpnonce: data.nonce,
                event_id: eventId,
                title: name
            }, function(response) {
                if (response.success) {
                    closeAllModals();
                    showNotice('Vorlage gespeichert!', 'success');
                } else {
                    alert(response.data.message || 'Fehler');
                }
            });
        });

        // Vorlage löschen
        $(document).on('click', '.liturgia-btn-delete-template', function() {
            var id = $(this).data('id');
            if (!confirm('Vorlage löschen?')) return;

            $.post(data.ajaxUrl, {
                action: 'liturgia_delete_template',
                _wpnonce: data.nonce,
                template_id: id
            }, function(response) {
                if (response.success) {
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Fehler');
                }
            });
        });

        // Event löschen (Detail)
        $(document).on('click', '#liturgia-delete-event', function() {
            if (!confirm('Dieses Event und alle zugehörigen Elemente wirklich löschen?')) return;

            $.post(data.ajaxUrl, {
                action: 'liturgia_delete_event',
                _wpnonce: data.nonce,
                id: eventId
            }, function(response) {
                if (response.success) {
                    window.location.href = data.overviewUrl;
                }
            });
        });
    }

    // ========================================================================
    // ELEMENT CRUD
    // ========================================================================

    function saveElement($card) {
        var elId = $card.data('id') || 0;
        var eventId = parseInt($('#liturgia-event-id').val());

        // TinyMCE triggerSave
        if (typeof tinyMCE !== 'undefined') {
            tinyMCE.triggerSave();
        }

        // v2: Personen aus Tags sammeln
        var persons = collectPersons($card);

        var postData = {
            action: 'liturgia_save_element',
            _wpnonce: data.nonce,
            element_id: elId,
            event_id: eventId,
            element_type: $card.find('.liturgia-el-type').val(),
            title: $card.find('.liturgia-el-title').val(),
            duration_minutes: $card.find('.liturgia-el-duration').val() || null,
            responsible_role: $card.find('.liturgia-el-role').val(),
            responsible_person: '', // v2: backward compat, wird durch persons ersetzt
            location: $card.find('.liturgia-el-location').val(),
            description: $card.find('.liturgia-el-description').val(),
            hymnal_number: $card.find('.liturgia-el-hymnal').val() || '',
            cantus_song_id: $card.find('.liturgia-el-cantus-id').val() || null,
            cantus_song_type: $card.find('.liturgia-el-cantus-type').val() || 'gl',
            cantus_song_strophes: $card.find('.liturgia-el-cantus-strophes').val() || '',
            cantus_override: $card.find('.liturgia-el-cantus-override').is(':checked') ? 1 : 0,
            reading_reference: $card.find('.liturgia-el-reading-ref').val() || '',
            reading_override: $card.find('.liturgia-el-reading-override').is(':checked') ? 1 : 0,
            reading_text: $card.find('.liturgia-el-reading-text').val() || '',
            media_notes: $card.find('.liturgia-el-media').val() || '',
            persons: JSON.stringify(persons)
        };

        var $btn = $card.find('.liturgia-el-save');
        $btn.prop('disabled', true).text('Speichern...');

        $.post(data.ajaxUrl, postData, function(response) {
            $btn.prop('disabled', false).html('&#x1F4BE; Speichern');

            if (response.success) {
                // ID setzen falls neu
                if (!elId && response.data.id) {
                    $card.data('id', response.data.id);
                    $card.attr('data-id', response.data.id);
                    // Person-Picker Element-ID nachsetzen
                    $card.find('.liturgia-person-picker').attr('data-element-id', response.data.id);
                }

                // Header aktualisieren
                var title = $card.find('.liturgia-el-title').val();
                var hymnal = $card.find('.liturgia-el-hymnal').val();

                $card.find('.liturgia-element-title').text(title);

                // Personen-Anzeige im Header
                var personNames = [];
                $card.find('.liturgia-person-tag').each(function() {
                    personNames.push($(this).data('name'));
                });
                if (personNames.length > 0) {
                    var display = personNames.slice(0, 2).join(', ');
                    if (personNames.length > 2) display += ' +' + (personNames.length - 2);
                    $card.find('.liturgia-element-person').text(display).show();
                    $card.find('.liturgia-element-role').hide();
                } else {
                    $card.find('.liturgia-element-person').text('').hide();
                    $card.find('.liturgia-element-role').show();
                }

                if (hymnal) {
                    if ($card.find('.liturgia-element-gl').length) {
                        $card.find('.liturgia-element-gl').text(hymnal);
                    } else {
                        $card.find('.liturgia-element-header-right').prepend('<span class="liturgia-element-gl">' + escHtml(hymnal) + '</span>');
                    }
                }

                // Sync-Badges aktualisieren
                updateSyncBadges($card);

                showNotice('Element gespeichert!', 'success');
                updateCounts();
            } else {
                showNotice(response.data.message || 'Fehler beim Speichern', 'error');
            }
        });
    }

    /**
     * Personen aus Person-Tags einer Karte sammeln
     */
    function collectPersons($card) {
        var persons = [];
        $card.find('.liturgia-person-tag').each(function() {
            var $tag = $(this);
            persons.push({
                user_id: parseInt($tag.data('user-id')) || 0,
                person_name: $tag.data('name') || '',
                role: $tag.data('role') || $card.find('.liturgia-el-role').val() || 'sonstige'
            });
        });
        return persons;
    }

    /**
     * Sync-Badges im Header aktualisieren
     */
    function updateSyncBadges($card) {
        var $right = $card.find('.liturgia-element-header-right');

        // Cantus-Badge
        $right.find('.liturgia-element-sync-badge-cantus').remove();
        if ($card.find('.liturgia-el-cantus-override').is(':checked')) {
            $right.find('.liturgia-element-toggle').before(
                '<span class="liturgia-element-sync-badge liturgia-element-sync-badge-cantus" title="Wird zu Cantus synchronisiert">&#x1F3B5;</span>'
            );
        }

        // Tagesplan-Badge
        $right.find('.liturgia-element-sync-badge-reading').remove();
        if ($card.find('.liturgia-el-reading-override').is(':checked')) {
            $right.find('.liturgia-element-toggle').before(
                '<span class="liturgia-element-sync-badge liturgia-element-sync-badge-reading" title="Wird zu Tagesplan synchronisiert">&#x1F4D6;</span>'
            );
        }
    }

    function addNewElement(eventId) {
        var nextNum = $('#liturgia-elements-list .liturgia-element-card').length + 1;

        // Leere-Meldung entfernen
        $('#liturgia-empty-state').remove();

        var html = '<div class="liturgia-element-card open" data-id="" data-type="sonstiges">';
        html += '<div class="liturgia-element-handle" title="Ziehen zum Sortieren">&#x2630;</div>';
        html += '<div class="liturgia-element-header" onclick="liturgiaToggleElement(this)">';
        html += '<div class="liturgia-element-header-left">';
        html += '<span class="liturgia-element-number">' + nextNum + '</span>';
        html += '<span class="liturgia-element-type-badge">Sonstiges</span>';
        html += '<strong class="liturgia-element-title">Neues Element</strong>';
        html += '</div>';
        html += '<div class="liturgia-element-header-right">';
        html += '<span class="liturgia-element-person" style="display:none;"></span>';
        html += '<span class="liturgia-element-role">Sonstige</span>';
        html += '<span class="liturgia-element-toggle">&#x25BE;</span>';
        html += '</div>';
        html += '</div>';

        // Body
        html += '<div class="liturgia-element-body">';

        // Zeile 1: Typ, Titel, Dauer
        html += '<div class="liturgia-form-row liturgia-form-row-3col">';
        html += '<label>Was? <select class="liturgia-el-type">';
        $.each(data.elementTypes, function(key, label) {
            html += '<option value="' + key + '">' + escHtml(label) + '</option>';
        });
        html += '</select></label>';
        html += '<label>Titel <input type="text" class="liturgia-el-title regular-text" value="" placeholder="Titel des Elements"></label>';
        html += '<label>Dauer (Min.) <input type="number" class="liturgia-el-duration" min="0" style="width:80px;"></label>';
        html += '</div>';

        // Zeile 2: Rolle, Ort
        html += '<div class="liturgia-form-row liturgia-form-row-2col">';
        html += '<label>Rolle <select class="liturgia-el-role">';
        $.each(data.roles, function(key, label) {
            html += '<option value="' + key + '">' + escHtml(label) + '</option>';
        });
        html += '</select></label>';
        html += '<label>Wo? <input type="text" class="liturgia-el-location regular-text" list="liturgia-locations-datalist" placeholder="z.B. Ambo"></label>';
        html += '</div>';

        // v2: User-Picker (Multi-Person)
        html += '<div class="liturgia-form-row">';
        html += '<label><strong>Personen zuweisen</strong></label>';
        html += '<div class="liturgia-person-picker" data-element-id="">';
        html += '<div class="liturgia-person-tags"></div>';
        html += '<div class="liturgia-person-search-wrap">';
        html += '<input type="text" class="liturgia-person-search regular-text" placeholder="Person suchen (Name eingeben)..." autocomplete="off">';
        html += '<div class="liturgia-person-results" style="display:none;"></div>';
        html += '</div>';
        html += '<div class="liturgia-person-guest-wrap" style="margin-top:4px;">';
        html += '<input type="text" class="liturgia-person-guest-name" placeholder="Gast-Name (ohne WP-Konto)" style="width:200px;">';
        html += '<button type="button" class="button liturgia-person-add-guest" style="margin-left:4px;">+ Gast</button>';
        html += '</div>';
        html += '</div>';
        html += '</div>';

        // Beschreibung
        html += '<div class="liturgia-form-row"><label>Details / Anweisungen</label>';
        html += '<textarea class="liturgia-el-description" rows="4" placeholder="Anweisungen, Details..."></textarea></div>';

        // Lied / Cantus (versteckt)
        html += '<div class="liturgia-conditional liturgia-cond-lied" style="display:none;">';
        html += '<div class="liturgia-form-row liturgia-form-row-3col">';
        html += '<label>GL/Lied-Nr. <div class="liturgia-cantus-search-wrap"><input type="text" class="liturgia-el-hymnal regular-text" placeholder="z.B. GL 175" autocomplete="off"><div class="liturgia-cantus-results" style="display:none;"></div></div></label>';
        html += '<label>Lied-Typ <select class="liturgia-el-cantus-type"><option value="gl">Gotteslob (GL)</option><option value="jd">Jodeldicke (JD)</option><option value="free">Freitext</option></select></label>';
        html += '<label>Strophen <input type="text" class="liturgia-el-cantus-strophes regular-text" placeholder="z.B. 1,3,5"></label>';
        html += '</div>';
        html += '<div class="liturgia-form-row"><label><input type="checkbox" class="liturgia-el-cantus-override" value="1"> <strong>In Cantus &uuml;bernehmen</strong></label></div>';
        html += '</div>';

        // Lesung / Evangelium / Fürbitten (versteckt)
        html += '<div class="liturgia-conditional liturgia-cond-lesung" style="display:none;">';
        html += '<div class="liturgia-form-row liturgia-form-row-2col">';
        html += '<label>Schriftstelle <input type="text" class="liturgia-el-reading-ref regular-text" placeholder="z.B. Jes 52,13-53,12"></label>';
        html += '<label><input type="checkbox" class="liturgia-el-reading-override" value="1"> <strong>Im Tagesplan &uuml;bernehmen</strong></label>';
        html += '</div>';
        html += '<div class="liturgia-form-row"><label>Lesungstext / F&uuml;rbitten-Text</label>';
        html += '<textarea class="liturgia-el-reading-text" rows="6"></textarea></div>';
        html += '</div>';

        // Media
        html += '<div class="liturgia-form-row liturgia-media-section">';
        html += '<label>&#x1F3A5; Media/Technik-Hinweise</label>';
        html += '<textarea class="liturgia-el-media" rows="3"></textarea></div>';

        // Actions
        html += '<div class="liturgia-element-actions">';
        html += '<button type="button" class="button button-primary liturgia-el-save">&#x1F4BE; Speichern</button>';
        html += '<button type="button" class="button liturgia-el-delete liturgia-btn-danger">&#x1F5D1; L&ouml;schen</button>';
        html += '</div>';

        html += '</div>'; // body
        html += '</div>'; // card

        var $el = $(html);
        $('#liturgia-elements-list').append($el);

        // Scroll to new element
        $('html, body').animate({
            scrollTop: $el.offset().top - 100
        }, 300);

        updateCounts();
    }

    // ========================================================================
    // SORTABLE
    // ========================================================================

    function initSortable() {
        $('#liturgia-elements-list').sortable({
            handle: '.liturgia-element-handle',
            placeholder: 'liturgia-element-card ui-sortable-placeholder',
            tolerance: 'pointer',
            update: function() {
                var eventId = parseInt($('#liturgia-event-id').val());
                var order = [];

                $('#liturgia-elements-list .liturgia-element-card').each(function(i) {
                    var id = $(this).data('id');
                    if (id) {
                        order.push(id);
                    }
                    $(this).find('.liturgia-element-number').text(i + 1);
                });

                if (order.length > 0) {
                    $.post(data.ajaxUrl, {
                        action: 'liturgia_reorder_elements',
                        _wpnonce: data.nonce,
                        event_id: eventId,
                        order: order
                    });
                }
            }
        });
    }

    // ========================================================================
    // WP_EDITOR
    // ========================================================================

    function initWPEditors() {
        // Bestehende wp_editor Instanzen werden von WordPress automatisch initialisiert.
        // Für dynamisch hinzugefügte Elemente nutzen wir einfache Textareas.
        // Bei Bedarf kann hier wp.editor.initialize() aufgerufen werden.
    }

    // ========================================================================
    // v2: USER-PICKER (Personen suchen + Tags)
    // ========================================================================

    var personSearchTimer = null;

    $(document).on('input', '.liturgia-person-search', function() {
        var $input = $(this);
        var $wrap = $input.closest('.liturgia-person-search-wrap');
        var $results = $wrap.find('.liturgia-person-results');
        var query = $input.val().trim();

        clearTimeout(personSearchTimer);

        if (query.length < 2) {
            $results.hide().empty();
            return;
        }

        personSearchTimer = setTimeout(function() {
            $.post(data.ajaxUrl, {
                action: 'liturgia_search_users',
                _wpnonce: data.nonce,
                q: query
            }, function(response) {
                if (!response.success || !response.data.users.length) {
                    $results.html('<div class="liturgia-person-result-empty">Keine Benutzer gefunden</div>').show();
                    return;
                }

                var html = '';
                response.data.users.forEach(function(user) {
                    // Prüfen ob User bereits hinzugefügt
                    var $picker = $input.closest('.liturgia-person-picker');
                    var already = false;
                    $picker.find('.liturgia-person-tag').each(function() {
                        if (parseInt($(this).data('user-id')) === user.id) already = true;
                    });
                    if (already) return;

                    html += '<div class="liturgia-person-result" data-user-id="' + user.id + '" data-name="' + escHtml(user.display_name) + '" data-email="' + escHtml(user.email) + '">';
                    html += '<strong>' + escHtml(user.display_name) + '</strong>';
                    html += '<small>' + escHtml(user.email) + '</small>';
                    html += '</div>';
                });

                if (!html) {
                    html = '<div class="liturgia-person-result-empty">Alle Benutzer bereits zugewiesen</div>';
                }

                $results.html(html).show();
            });
        }, 300);
    });

    // Ergebnis anklicken → Person hinzufügen
    $(document).on('click', '.liturgia-person-result', function() {
        var $result = $(this);
        var userId = $result.data('user-id');
        var name = $result.data('name');
        var $picker = $result.closest('.liturgia-person-picker');
        var role = $picker.closest('.liturgia-element-card').find('.liturgia-el-role').val() || 'sonstige';

        addPersonTag($picker, userId, name, role);

        // Suche zurücksetzen
        $picker.find('.liturgia-person-search').val('');
        $picker.find('.liturgia-person-results').hide().empty();
    });

    // Gast hinzufügen
    $(document).on('click', '.liturgia-person-add-guest', function() {
        var $wrap = $(this).closest('.liturgia-person-guest-wrap');
        var $input = $wrap.find('.liturgia-person-guest-name');
        var name = $input.val().trim();

        if (!name) {
            $input.focus();
            return;
        }

        var $picker = $(this).closest('.liturgia-person-picker');
        var role = $picker.closest('.liturgia-element-card').find('.liturgia-el-role').val() || 'sonstige';

        addPersonTag($picker, 0, name, role);
        $input.val('');
    });

    // Person entfernen
    $(document).on('click', '.liturgia-person-remove', function(e) {
        e.stopPropagation();
        $(this).closest('.liturgia-person-tag').fadeOut(150, function() { $(this).remove(); });
    });

    // Suchergebnisse schließen bei Klick außerhalb
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.liturgia-person-search-wrap').length) {
            $('.liturgia-person-results').hide();
        }
    });

    function addPersonTag($picker, userId, name, role) {
        var tag = '<span class="liturgia-person-tag" data-user-id="' + userId + '" data-name="' + escHtml(name) + '" data-role="' + escHtml(role) + '">';
        tag += escHtml(name);
        if (userId === 0) tag += ' <small>(Gast)</small>';
        tag += ' <button type="button" class="liturgia-person-remove" title="Entfernen">&times;</button>';
        tag += '</span>';

        $picker.find('.liturgia-person-tags').append(tag);
    }

    // ========================================================================
    // v2: CANTUS-KATALOG AUTOCOMPLETE
    // ========================================================================

    var cantusSearchTimer = null;

    $(document).on('input', '.liturgia-el-hymnal', function() {
        var $input = $(this);
        var $wrap = $input.closest('.liturgia-cantus-search-wrap');
        var $results = $wrap.find('.liturgia-cantus-results');
        var query = $input.val().trim();

        clearTimeout(cantusSearchTimer);

        if (!data.hasCantus || query.length < 2) {
            $results.hide().empty();
            return;
        }

        cantusSearchTimer = setTimeout(function() {
            $.post(data.ajaxUrl, {
                action: 'liturgia_search_cantus_catalog',
                _wpnonce: data.nonce,
                q: query
            }, function(response) {
                if (!response.success || !response.data.songs || !response.data.songs.length) {
                    $results.hide().empty();
                    return;
                }

                var html = '';
                response.data.songs.forEach(function(song) {
                    html += '<div class="liturgia-cantus-result" data-id="' + song.id + '" data-type="' + escHtml(song.type) + '" data-number="' + escHtml(song.number) + '" data-title="' + escHtml(song.title) + '">';
                    html += '<strong>' + escHtml(song.number) + '</strong> ';
                    html += escHtml(song.title);
                    if (song.genre) html += ' <small>(' + escHtml(song.genre) + ')</small>';
                    html += '</div>';
                });

                $results.html(html).show();
            });
        }, 300);
    });

    // Cantus-Ergebnis anklicken
    $(document).on('click', '.liturgia-cantus-result', function() {
        var $result = $(this);
        var $card = $result.closest('.liturgia-element-card');

        $card.find('.liturgia-el-hymnal').val($result.data('number'));
        $card.find('.liturgia-el-cantus-id').val($result.data('id'));
        $card.find('.liturgia-el-cantus-type').val($result.data('type'));
        $card.find('.liturgia-el-title').val($result.data('title'));

        // Titel im Header aktualisieren
        $card.find('.liturgia-element-title').text($result.data('title'));

        $result.closest('.liturgia-cantus-results').hide().empty();
    });

    // Cantus-Ergebnisse schließen bei Klick außerhalb
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.liturgia-cantus-search-wrap').length) {
            $('.liturgia-cantus-results').hide();
        }
    });

    // ========================================================================
    // v2: SYNC-BUTTON
    // ========================================================================

    $(document).on('click', '#liturgia-sync-btn, #liturgia-manual-sync', function() {
        var eventId = parseInt($('#liturgia-event-id').val());
        if (!eventId) return;

        var $btn = $(this);
        $btn.prop('disabled', true);

        var $result = $('#liturgia-sync-result');
        $result.html('<span style="color:#666;">Synchronisation l&auml;uft...</span>');

        $.post(data.ajaxUrl, {
            action: 'liturgia_sync_to_modules',
            _wpnonce: data.nonce,
            event_id: eventId
        }, function(response) {
            $btn.prop('disabled', false);

            if (response.success) {
                var msg = response.data.message || 'Sync abgeschlossen';
                $result.html('<span style="color:#059669;">&#x2714; ' + escHtml(msg) + '</span>');
                showNotice('Synchronisation abgeschlossen', 'success');
            } else {
                $result.html('<span style="color:#d63638;">&#x2718; ' + escHtml(response.data.message || 'Fehler') + '</span>');
                showNotice('Sync fehlgeschlagen', 'error');
            }

            // Ergebnis nach 6 Sekunden ausblenden
            setTimeout(function() {
                $result.fadeOut(400, function() { $(this).html('').show(); });
            }, 6000);
        }).fail(function() {
            $btn.prop('disabled', false);
            $result.html('<span style="color:#d63638;">Verbindungsfehler</span>');
        });
    });

    // ========================================================================
    // E-MAIL
    // ========================================================================

    function openEmailModal(eventId) {
        $('#liturgia-email-modal').show();
        $('#liturgia-email-extra').val('');
        $('#liturgia-email-status').text('');

        // Benutzer laden
        $.post(data.ajaxUrl, {
            action: 'liturgia_get_email_users',
            _wpnonce: data.nonce,
            event_id: eventId
        }, function(response) {
            if (response.success) {
                var html = '';
                response.data.users.forEach(function(user) {
                    var checked = '';
                    html += '<label><input type="checkbox" class="liturgia-email-user" value="' + user.id + '" ' + checked + '> ';
                    html += escHtml(user.name) + ' <small>(' + escHtml(user.email) + ')</small></label>';
                });
                $('#liturgia-email-users').html(html);

                // Beteiligte markieren
                if (response.data.participants) {
                    response.data.participants.forEach(function(uid) {
                        $('.liturgia-email-user[value="' + uid + '"]').prop('checked', true);
                    });
                }
            }
        });

        // Schnellauswahl
        $(document).off('click', '.liturgia-email-quick').on('click', '.liturgia-email-quick', function() {
            var group = $(this).data('group');

            if (group === 'participants') {
                // Alle Beteiligten
                $.post(data.ajaxUrl, {
                    action: 'liturgia_get_email_users',
                    _wpnonce: data.nonce,
                    event_id: eventId
                }, function(response) {
                    if (response.success && response.data.participants) {
                        $('.liturgia-email-user').prop('checked', false);
                        response.data.participants.forEach(function(uid) {
                            $('.liturgia-email-user[value="' + uid + '"]').prop('checked', true);
                        });
                    }
                });
            } else if (group === 'liturgieausschuss') {
                // Alle auswählen (die Liturgieausschuss-IDs kommen aus den Settings)
                // Einfachste Lösung: alle auswählen und der Server filtert
                $('.liturgia-email-user').prop('checked', true);
            }
        });

        // Senden
        $(document).off('click', '#liturgia-do-send-email').on('click', '#liturgia-do-send-email', function() {
            var userIds = [];
            $('.liturgia-email-user:checked').each(function() {
                userIds.push($(this).val());
            });
            var extraEmails = $('#liturgia-email-extra').val();

            if (userIds.length === 0 && !extraEmails.trim()) {
                alert('Bitte mindestens einen Empfänger auswählen.');
                return;
            }

            var $btn = $(this);
            $btn.prop('disabled', true).text('Wird gesendet...');
            $('#liturgia-email-status').text('PDF wird erstellt und E-Mails werden versendet...');

            $.post(data.ajaxUrl, {
                action: 'liturgia_send_email',
                _wpnonce: data.nonce,
                event_id: eventId,
                user_ids: userIds,
                extra_emails: extraEmails
            }, function(response) {
                $btn.prop('disabled', false).html('📧 Senden (mit PDF)');

                if (response.success) {
                    $('#liturgia-email-status').html('<span style="color:green;">✓ ' + response.data.message + '</span>');
                    setTimeout(function() { closeAllModals(); }, 2000);
                } else {
                    $('#liturgia-email-status').html('<span style="color:red;">✗ ' + (response.data.message || 'Fehler') + '</span>');
                }
            });
        });
    }

    // ========================================================================
    // MODALS
    // ========================================================================

    function bindModalEvents() {
        // Schließen
        $(document).on('click', '.liturgia-modal-close, .liturgia-modal-cancel', function() {
            $(this).closest('.liturgia-modal').hide();
        });

        // Overlay-Klick
        $(document).on('click', '.liturgia-modal', function(e) {
            if (e.target === this) {
                $(this).hide();
            }
        });

        // ESC
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                closeAllModals();
            }
        });
    }

    function closeAllModals() {
        $('.liturgia-modal').hide();
    }

    // ========================================================================
    // HELPERS
    // ========================================================================

    function updateCounts() {
        var count = $('#liturgia-elements-list .liturgia-element-card').length;
        $('#liturgia-count-elements').text(count);

        // Nummern aktualisieren
        $('#liturgia-elements-list .liturgia-element-card').each(function(i) {
            $(this).find('.liturgia-element-number').text(i + 1);
        });
    }

    function showNotice(message, type) {
        var color = type === 'error' ? '#d63638' : '#00a32a';
        var $notice = $('<div class="notice notice-' + (type === 'error' ? 'error' : 'success') + ' is-dismissible" style="position:fixed;top:40px;right:20px;z-index:100200;padding:10px 20px;border-left:4px solid ' + color + ';background:#fff;box-shadow:0 4px 12px rgba(0,0,0,0.15);"><p>' + message + '</p></div>');
        $('body').append($notice);
        setTimeout(function() { $notice.fadeOut(300, function() { $(this).remove(); }); }, 3000);
    }

    function escHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        var parts = dateStr.split('-');
        if (parts.length !== 3) return dateStr;
        var days = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
        var d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        return days[d.getDay()] + ', ' + parts[2] + '.' + parts[1] + '.' + parts[0];
    }

    function formatDateISO(date) {
        return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
    }

    function pad(n) {
        return n < 10 ? '0' + n : String(n);
    }

    // Toggle Element expand/collapse
    window.liturgiaToggleElement = function(headerEl) {
        var $card = $(headerEl).closest('.liturgia-element-card');
        $card.toggleClass('open');
        $card.find('.liturgia-element-body').slideToggle(200);
    };

})(jQuery);
