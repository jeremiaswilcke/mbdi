/**
 * Liturgia Frontend JavaScript
 *
 * Handles AJAX loading of events list and detail view,
 * filter changes, and back-button navigation.
 *
 * @package IsidorSuite\Liturgia
 * @since 2.0.0
 */

(function ($) {
    'use strict';

    var cfg = window.liturgiaFrontend || {};

    // ========================================================================
    // INIT
    // ========================================================================

    $(document).ready(function () {
        if (!$('#liturgia-frontend-app').length) return;

        loadEvents();
        bindEvents();
    });

    // ========================================================================
    // EVENT BINDINGS
    // ========================================================================

    function bindEvents() {
        // Filter changes
        $('#liturgia-fe-filter-period, #liturgia-fe-filter-status').on('change', function () {
            loadEvents();
        });

        // Click on event card
        $(document).on('click', '.liturgia-fe-event-card', function () {
            var id = $(this).data('event-id');
            if (id) {
                loadEventDetail(id);
            }
        });

        // Back button
        $('#liturgia-fe-back').on('click', function () {
            showListView();
        });
    }

    // ========================================================================
    // VIEW SWITCHING
    // ========================================================================

    function showListView() {
        $('#liturgia-fe-detail').hide();
        $('#liturgia-fe-list').show();
    }

    function showDetailView() {
        $('#liturgia-fe-list').hide();
        $('#liturgia-fe-detail').show();

        // Scroll to top of app
        $('html, body').animate({
            scrollTop: $('#liturgia-frontend-app').offset().top - 20
        }, 200);
    }

    // ========================================================================
    // LOAD EVENTS LIST
    // ========================================================================

    function loadEvents() {
        var $container = $('#liturgia-fe-events');
        $container.html('<div class="liturgia-fe-loading">Wird geladen...</div>');

        $.post(cfg.ajaxUrl, {
            action: 'liturgia_frontend_get_events',
            _wpnonce: cfg.nonce,
            period: $('#liturgia-fe-filter-period').val(),
            status: $('#liturgia-fe-filter-status').val()
        }, function (response) {
            if (response.success) {
                renderEventsList(response.data.events);
            } else {
                $container.html('<div class="liturgia-fe-empty">Fehler beim Laden der Events.</div>');
            }
        }).fail(function () {
            $container.html('<div class="liturgia-fe-empty">Verbindungsfehler. Bitte erneut versuchen.</div>');
        });
    }

    // ========================================================================
    // RENDER EVENTS LIST
    // ========================================================================

    function renderEventsList(events) {
        var $container = $('#liturgia-fe-events');

        if (!events || events.length === 0) {
            $container.html(
                '<div class="liturgia-fe-empty">' +
                    '<div class="liturgia-fe-empty-icon">&#128467;</div>' +
                    '<p>Keine Gottesdienste gefunden.</p>' +
                '</div>'
            );
            return;
        }

        var html = '';

        events.forEach(function (ev) {
            html += '<div class="liturgia-fe-event-card" data-event-id="' + ev.id + '">';

            // Date strip
            html += '<div class="liturgia-fe-card-date">';
            html += '<span class="liturgia-fe-card-day">' + formatDay(ev.event_date) + '</span>';
            html += '<span class="liturgia-fe-card-month">' + formatMonth(ev.event_date) + '</span>';
            html += '</div>';

            // Card body
            html += '<div class="liturgia-fe-card-body">';
            html += '<div class="liturgia-fe-card-title">' + esc(ev.event_title) + '</div>';
            html += '<div class="liturgia-fe-card-meta">';
            html += '<span class="liturgia-fe-card-date-long">' + esc(ev.date_formatted) + '</span>';
            if (ev.location_default) {
                html += '<span class="liturgia-fe-card-location">' + esc(ev.location_default) + '</span>';
            }
            html += '</div>';
            html += '<div class="liturgia-fe-card-footer">';
            html += '<span class="liturgia-fe-badge" style="color:' + ev.status_color + ';background:' + ev.status_bg + ';">' + esc(ev.status_label) + '</span>';
            html += '<span class="liturgia-fe-card-type">' + esc(ev.type_label) + '</span>';
            html += '<span class="liturgia-fe-card-elements">' + (ev.element_count || 0) + ' Elemente</span>';
            html += '</div>';
            html += '</div>'; // card-body

            html += '</div>'; // event-card
        });

        $container.html(html);
    }

    // ========================================================================
    // LOAD EVENT DETAIL
    // ========================================================================

    function loadEventDetail(eventId) {
        var $content = $('#liturgia-fe-detail-content');
        $content.html('<div class="liturgia-fe-loading">Wird geladen...</div>');
        showDetailView();

        $.post(cfg.ajaxUrl, {
            action: 'liturgia_frontend_get_event_detail',
            _wpnonce: cfg.nonce,
            event_id: eventId
        }, function (response) {
            if (response.success) {
                renderEventDetail(response.data);
            } else {
                $content.html('<div class="liturgia-fe-empty">Event konnte nicht geladen werden.</div>');
            }
        }).fail(function () {
            $content.html('<div class="liturgia-fe-empty">Verbindungsfehler. Bitte erneut versuchen.</div>');
        });
    }

    // ========================================================================
    // RENDER EVENT DETAIL
    // ========================================================================

    function renderEventDetail(data) {
        var ev       = data.event;
        var elements = data.elements || [];
        var parts    = data.participants || [];
        var duration = data.total_duration || 0;

        var html = '';

        // ---- Header ----
        html += '<div class="liturgia-fe-detail-header">';
        html += '<div class="liturgia-fe-detail-header-main">';
        html += '<h2 class="liturgia-fe-detail-title">' + esc(ev.event_title) + '</h2>';
        html += '<div class="liturgia-fe-detail-meta">';
        html += '<span>' + esc(ev.date_formatted) + '</span>';
        html += '<span class="liturgia-fe-badge" style="color:' + ev.status_color + ';background:' + ev.status_bg + ';">' + esc(ev.status_label) + '</span>';
        html += '<span>' + esc(ev.type_label) + '</span>';
        if (ev.location_default) {
            html += '<span>' + esc(ev.location_default) + '</span>';
        }
        html += '</div>'; // meta
        if (duration > 0) {
            html += '<div class="liturgia-fe-detail-duration">Gesch&auml;tzte Dauer: ca. ' + duration + ' Min.</div>';
        }
        html += '</div>'; // header-main
        html += '</div>'; // header

        // ---- Layout: elements + sidebar ----
        html += '<div class="liturgia-fe-detail-layout">';

        // ---- Elements ----
        html += '<div class="liturgia-fe-detail-elements">';
        html += '<h3>Ablauf</h3>';

        if (elements.length === 0) {
            html += '<div class="liturgia-fe-empty"><p>Noch keine Elemente geplant.</p></div>';
        } else {
            html += '<div class="liturgia-fe-elements-list">';
            elements.forEach(function (el, i) {
                html += renderElement(el, i + 1);
            });
            html += '</div>';
        }

        html += '</div>'; // detail-elements

        // ---- Participants sidebar ----
        html += '<div class="liturgia-fe-detail-sidebar">';
        html += '<div class="liturgia-fe-sidebar-box">';
        html += '<h4>Beteiligte</h4>';

        if (parts.length === 0) {
            html += '<p class="liturgia-fe-muted">Noch keine Beteiligten zugewiesen.</p>';
        } else {
            html += '<ul class="liturgia-fe-participants-list">';
            parts.forEach(function (group) {
                html += '<li class="liturgia-fe-participant-group">';
                html += '<strong>' + esc(group.role) + '</strong>';
                html += '<span>' + group.names.map(esc).join(', ') + '</span>';
                html += '</li>';
            });
            html += '</ul>';
        }

        html += '</div>'; // sidebar-box

        // Summary box
        html += '<div class="liturgia-fe-sidebar-box">';
        html += '<h4>&Uuml;bersicht</h4>';
        html += '<ul class="liturgia-fe-summary-list">';
        html += '<li><span>Elemente</span><strong>' + elements.length + '</strong></li>';
        html += '<li><span>Dauer</span><strong>' + (duration > 0 ? 'ca. ' + duration + ' Min.' : '&ndash;') + '</strong></li>';
        html += '<li><span>Status</span><strong>' + esc(ev.status_label) + '</strong></li>';
        html += '<li><span>Typ</span><strong>' + esc(ev.type_label) + '</strong></li>';
        html += '</ul>';
        html += '</div>'; // sidebar-box

        // Notes
        if (ev.notes) {
            html += '<div class="liturgia-fe-sidebar-box">';
            html += '<h4>Notizen</h4>';
            html += '<div class="liturgia-fe-notes">' + ev.notes + '</div>';
            html += '</div>';
        }

        html += '</div>'; // sidebar
        html += '</div>'; // layout

        $('#liturgia-fe-detail-content').html(html);
    }

    // ========================================================================
    // RENDER SINGLE ELEMENT
    // ========================================================================

    function renderElement(el, num) {
        var html = '';

        html += '<div class="liturgia-fe-element">';

        // Number
        html += '<div class="liturgia-fe-element-num">' + num + '</div>';

        // Content
        html += '<div class="liturgia-fe-element-content">';

        // Top line: type badge + title
        html += '<div class="liturgia-fe-element-top">';
        html += '<span class="liturgia-fe-element-type">' + esc(el.type_label) + '</span>';
        html += '<span class="liturgia-fe-element-title">' + esc(el.title) + '</span>';
        if (el.duration_minutes && parseInt(el.duration_minutes) > 0) {
            html += '<span class="liturgia-fe-element-duration">' + el.duration_minutes + ' Min.</span>';
        }
        html += '</div>';

        // Persons
        if (el.persons && el.persons.length > 0) {
            var names = el.persons.map(function (p) { return p.display_name; });
            html += '<div class="liturgia-fe-element-persons">' + names.map(esc).join(', ') + '</div>';
        }

        // Details: hymnal number, location, reading reference
        var details = [];
        if (el.hymnal_number) {
            details.push(esc(el.hymnal_number));
        }
        if (el.reading_reference) {
            details.push(esc(el.reading_reference));
        }
        if (el.location) {
            details.push(esc(el.location));
        }
        if (details.length > 0) {
            html += '<div class="liturgia-fe-element-details">' + details.join(' &middot; ') + '</div>';
        }

        // Description (if not empty)
        if (el.description && el.description.trim()) {
            html += '<div class="liturgia-fe-element-desc">' + el.description + '</div>';
        }

        html += '</div>'; // element-content
        html += '</div>'; // element

        return html;
    }

    // ========================================================================
    // HELPERS
    // ========================================================================

    function esc(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function formatDay(dateStr) {
        if (!dateStr) return '';
        var parts = dateStr.split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : '';
    }

    function formatMonth(dateStr) {
        if (!dateStr) return '';
        var months = ['Jan', 'Feb', 'M\u00e4r', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
        var parts = dateStr.split('-');
        if (parts.length !== 3) return '';
        var idx = parseInt(parts[1], 10) - 1;
        return months[idx] || '';
    }

})(jQuery);
