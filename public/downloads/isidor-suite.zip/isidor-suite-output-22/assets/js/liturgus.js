/**
 * Liturgus Frontend JS
 */

function liturgusSignup(messeId, slotKey, isBackup) {
    if (!confirm('Möchten Sie sich wirklich eintragen?')) {
        return;
    }
    
    const data = new FormData();
    data.append('action', 'liturgus_signup');
    data.append('nonce', liturgusData.nonce);
    data.append('messe_id', messeId);
    data.append('slot_key', slotKey);
    if (isBackup) {
        data.append('is_backup', '1');
    }
    
    fetch(liturgusData.ajaxUrl, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            alert(result.data.message);
            location.reload();
        } else {
            alert(result.data.message || 'Fehler beim Eintragen');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Fehler beim Eintragen');
    });
}

function liturgusCancel(assignmentId) {
    if (!confirm('Wirklich austragen?')) {
        return;
    }
    
    const data = new FormData();
    data.append('action', 'liturgus_cancel');
    data.append('nonce', liturgusData.nonce);
    data.append('assignment_id', assignmentId);
    
    fetch(liturgusData.ajaxUrl, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            alert(result.data.message);
            location.reload();
        } else {
            alert(result.data.message || 'Fehler beim Austragen');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Fehler beim Austragen');
    });
}

function liturgusOpenSwap(assignmentId, slotLabel, datetime, messTitle) {
    document.getElementById('liturgus-swap-my-assignment-id').value = assignmentId;
    document.getElementById('liturgus-swap-my-service').innerHTML = 
        '<strong>' + slotLabel + '</strong><br>' + 
        datetime + '<br>' + 
        messTitle;
    document.getElementById('liturgus-swap-modal').style.display = 'flex';
}

function liturgusCloseSwap() {
    document.getElementById('liturgus-swap-modal').style.display = 'none';
    document.getElementById('liturgus-swap-target').value = '';
    document.getElementById('liturgus-swap-message').value = '';
}

function liturgusSubmitSwap() {
    const myAssignmentId = document.getElementById('liturgus-swap-my-assignment-id').value;
    const theirAssignmentId = document.getElementById('liturgus-swap-target').value;
    const message = document.getElementById('liturgus-swap-message').value;
    
    if (!theirAssignmentId) {
        alert('Bitte Dienst auswählen');
        return;
    }
    
    if (!confirm('Wirklich tauschen? Beide Dienste werden getauscht!')) {
        return;
    }
    
    const data = new FormData();
    data.append('action', 'liturgus_swap_request');
    data.append('nonce', liturgusData.nonce);
    data.append('my_assignment_id', myAssignmentId);
    data.append('their_assignment_id', theirAssignmentId);
    data.append('message', message);
    
    fetch(liturgusData.ajaxUrl, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            alert(result.data.message);
            liturgusCloseSwap();
            location.reload();
        } else {
            alert(result.data.message || 'Fehler beim Senden');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Fehler beim Senden');
    });
}

// Tauschanfrage annehmen
function liturgusAcceptSwap(swapId) {
    if (!confirm('Tauschanfrage annehmen?')) return;
    
    const data = new FormData();
    data.append('action', 'liturgus_accept_swap');
    data.append('nonce', liturgusData.nonce);
    data.append('swap_id', swapId);
    
    fetch(liturgusData.ajaxUrl, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            alert(result.data.message || 'Tausch angenommen!');
            location.reload();
        } else {
            alert(result.data.message || 'Fehler');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Fehler');
    });
}

// Tauschanfrage ablehnen
function liturgusRejectSwap(swapId) {
    if (!confirm('Tauschanfrage ablehnen?')) return;
    
    const data = new FormData();
    data.append('action', 'liturgus_reject_swap');
    data.append('nonce', liturgusData.nonce);
    data.append('swap_id', swapId);
    
    fetch(liturgusData.ajaxUrl, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            alert(result.data.message || 'Tausch abgelehnt');
            location.reload();
        } else {
            alert(result.data.message || 'Fehler');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Fehler');
    });
}

// ESC zum Schließen
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        var modal = document.getElementById('liturgus-swap-modal');
        if (modal && modal.style.display === 'flex') {
            liturgusCloseSwap();
        }
        var slotCfg = document.getElementById('liturgus-slot-config-overlay');
        if (slotCfg && slotCfg.style.display === 'flex') {
            liturgusCloseSlotConfig();
        }
    }
});

// =========================================================================
// SLOT CONFIG (pro Messe)
// =========================================================================
var _slotConfigMesseId = null;

function liturgusOpenSlotConfig(messeId, messeTitle) {
    if (typeof liturgusData === 'undefined') { alert('Fehler: liturgusData nicht geladen.'); return; }
    _slotConfigMesseId = messeId;
    var overlay = document.getElementById('liturgus-slot-config-overlay');
    if (!overlay) return;
    // Move to body to escape overflow:hidden containers
    if (overlay.parentNode !== document.body) document.body.appendChild(overlay);
    document.getElementById('liturgus-slot-config-title').textContent = messeTitle;
    overlay.style.display = 'flex';

    var list = document.getElementById('liturgus-slot-config-list');
    list.innerHTML = '<p style="color:#9ca3af;text-align:center;">Lade…</p>';

    var fd = new FormData();
    fd.append('action', 'liturgus_get_messe_slots');
    fd.append('nonce', liturgusData.nonce);
    fd.append('messe_id', messeId);

    fetch(liturgusData.ajaxUrl, {method:'POST', body:fd})
        .then(function(r){return r.json();})
        .then(function(resp){
            if(!resp.success){list.innerHTML='<p>Fehler</p>';return;}
            _renderSlotConfig(resp.data);
        });
}

function _renderSlotConfig(data) {
    var list = document.getElementById('liturgus-slot-config-list');
    var global = data.global || [];
    var messeOverrides = {};
    (data.messe||[]).forEach(function(m){ messeOverrides[m.slot_key]=m; });

    var h = '';
    global.forEach(function(g){
        var mo = messeOverrides[g.slot_key];
        var pos = mo ? parseInt(mo.positions) : parseInt(g.positions);
        var bpos = mo ? parseInt(mo.backup_positions) : parseInt(g.backup_positions);
        var disabled = mo ? parseInt(mo.is_disabled) : 0;
        var badge = mo ? ' <small style="color:#16a34a;">(angepasst)</small>' : '';

        h += '<div class="liturgus-slotcfg-row" data-key="'+g.slot_key+'">';
        h += '<label class="liturgus-slotcfg-enable"><input type="checkbox" class="lsc-enable" '+(disabled?'':'checked')+'></label>';
        h += '<div class="liturgus-slotcfg-label'+(disabled?' liturgus-slotcfg-disabled':'')+'">'+_lscEsc(g.label)+badge+'</div>';
        h += '<div class="liturgus-slotcfg-inputs">';
        h += '<label title="Positionen"><input type="number" class="lsc-pos consilium-input" value="'+pos+'" min="0" max="20" style="width:55px;"> Pos</label>';
        h += '<label title="Backup"><input type="number" class="lsc-bpos consilium-input" value="'+bpos+'" min="0" max="10" style="width:55px;"> Bkp</label>';
        h += '</div>';
        h += '</div>';
    });

    list.innerHTML = h;

    list.querySelectorAll('.lsc-enable').forEach(function(cb){
        cb.addEventListener('change', function(){
            var label = this.closest('.liturgus-slotcfg-row').querySelector('.liturgus-slotcfg-label');
            label.classList.toggle('liturgus-slotcfg-disabled', !this.checked);
        });
    });
}

function _lscEsc(s){var d=document.createElement('span');d.textContent=s;return d.innerHTML;}

function liturgusSaveSlotConfig(){
    var rows = document.querySelectorAll('.liturgus-slotcfg-row');
    var slots = [];
    rows.forEach(function(row, i){
        slots.push({
            slot_key: row.dataset.key,
            positions: parseInt(row.querySelector('.lsc-pos').value)||0,
            backup_positions: parseInt(row.querySelector('.lsc-bpos').value)||0,
            is_disabled: row.querySelector('.lsc-enable').checked ? 0 : 1,
            sort_order: i
        });
    });

    var fd = new FormData();
    fd.append('action', 'liturgus_save_messe_slots');
    fd.append('nonce', liturgusData.nonce);
    fd.append('messe_id', _slotConfigMesseId);
    fd.append('slots', JSON.stringify(slots));

    var btn = document.querySelector('#liturgus-slot-config-overlay .liturgus-modal-footer .liturgus-btn:last-child');
    btn.disabled = true; btn.textContent = '…';

    fetch(liturgusData.ajaxUrl, {method:'POST', body:fd})
        .then(function(r){return r.json();})
        .then(function(resp){
            btn.disabled = false; btn.textContent = '💾 Speichern';
            if(resp.success){
                liturgusCloseSlotConfig();
                location.reload();
            } else {
                alert(resp.data?.message||'Fehler');
            }
        });
}

function liturgusResetSlotConfig(){
    if(!confirm('Auf Standard zurücksetzen? Alle Anpassungen für diese Messe werden entfernt.')) return;
    var fd = new FormData();
    fd.append('action', 'liturgus_save_messe_slots');
    fd.append('nonce', liturgusData.nonce);
    fd.append('messe_id', _slotConfigMesseId);
    fd.append('reset', '1');

    fetch(liturgusData.ajaxUrl, {method:'POST', body:fd})
        .then(function(r){return r.json();})
        .then(function(resp){
            if(resp.success){ liturgusCloseSlotConfig(); location.reload(); }
        });
}

function liturgusCloseSlotConfig(){
    var o = document.getElementById('liturgus-slot-config-overlay');
    if(o) o.style.display = 'none';
}
