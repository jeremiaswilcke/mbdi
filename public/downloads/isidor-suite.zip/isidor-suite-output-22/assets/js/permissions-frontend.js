/**
 * Isidor Permissions Frontend
 * Template management + User permission editing
 * @since 12.0.0
 */
(function($){
'use strict';

var API = isidorPerms.restUrl;
var NONCE = isidorPerms.restNonce;
var ICONS_URL = isidorPerms.iconsUrl || '';
var modules = null;
var services = null;
var templates = null;

function api(m,ep,data){
    var o={url:API+ep,method:m,headers:{'X-WP-Nonce':NONCE},dataType:'json'};
    if(data&&(m==='POST'||m==='PUT')){o.contentType='application/json';o.data=JSON.stringify(data);}
    else if(data&&m==='GET'){o.data=data;}
    return $.ajax(o);
}
function esc(s){return $('<span>').text(s||'').html();}

// Known SVG icons for templates (slug → filename)
var ICON_MAP = {
    'diakon':'diakon','wortgottesdienstleiter':'wortgottesdienstleiter','kantor':'kantor',
    'organist':'organist','mesner':'mesner','ministrant':'ministrant','lektor':'lektor',
    'kommunionhelfer':'kommunionhelfer','technik':'technik','kiwogo-leiter':'kiwogo_leiter',
    'kiwogo_leiter':'kiwogo_leiter','pgr-mitglied':'pgr_mitglied','pgr_mitglied':'pgr_mitglied',
    'vvr-mitglied':'vvr_mitglied','vvr_mitglied':'vvr_mitglied','ag-leiter':'ag_leiter',
    'ag_leiter':'ag_leiter','mitarbeiter':'mitarbeiter'
};
function tplIcon(tpl, size) {
    size = size || 40;
    var slug = (tpl.slug || tpl.name || '').toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9_-]/g,'');
    var file = ICON_MAP[slug];
    if (file && ICONS_URL) {
        return '<img src="'+ICONS_URL+file+'.svg" alt="" style="width:'+size+'px;height:'+size+'px;object-fit:contain;">';
    }
    return '<span style="font-size:'+Math.round(size*0.7)+'px;">'+(tpl.icon||'\uD83D\uDCCB')+'</span>';
}

// =========================================================================
// TEMPLATE LIST
// =========================================================================
var TplList = {
    init: function(){
        if(!$('#isidor-perm-templates').length) return;
        this.load();
    },
    load: function(){
        var self=this, $c=$('#isidor-perm-templates');
        $c.html('<p class="isidor-perm-loading">Lade Templates…</p>');

        $.when(
            api('GET','permissions/templates'),
            modules ? $.Deferred().resolve() : api('GET','permissions/modules'),
            services ? $.Deferred().resolve() : api('GET','permissions/services')
        ).done(function(tRes, mRes, sRes){
            if(mRes && mRes[0]) modules = mRes[0].data;
            if(sRes && sRes[0]) services = sRes[0].data;
            var tData = Array.isArray(tRes) ? tRes[0] : tRes;
            templates = tData.data || [];
            self.render(templates);
        });
    },
    render: function(list){
        var $c=$('#isidor-perm-templates').empty(), self=this;

        var h='<div class="isidor-perm-header">';
        h+='<h2>Berechtigungs-Templates</h2>';
        h+='<button class="consilium-btn consilium-btn--primary" id="ipt-create">+ Neues Template</button>';
        h+='</div>';

        if(!list.length){
            h+='<div class="isidor-perm-empty">';
            h+='<p>Noch keine Templates angelegt.</p>';
            h+='<button class="consilium-btn consilium-btn--secondary" id="ipt-import">📦 Starter-Pack importieren</button>';
            h+='</div>';
        } else {
            h+='<div class="isidor-perm-grid">';
            list.forEach(function(t){
                h+='<div class="isidor-perm-card" data-id="'+t.id+'">';
                h+='<div class="isidor-perm-card__icon">'+tplIcon(t, 44)+'</div>';
                h+='<div class="isidor-perm-card__body">';
                h+='<strong>'+esc(t.name)+'</strong>';
                if(t.description) h+='<p>'+esc(t.description)+'</p>';
                h+='<span class="isidor-perm-card__count">👥 '+esc(t.user_count||0)+' Benutzer</span>';
                h+='</div></div>';
            });
            h+='</div>';
            h+='<div style="margin-top:16px;"><button class="consilium-btn consilium-btn--secondary consilium-btn--small" id="ipt-import">📦 Starter-Pack importieren</button></div>';
        }

        $c.html(h);
        $('.isidor-perm-card').on('click', function(){ TplEditor.open($(this).data('id')); });
        $('#ipt-create').on('click', function(){ TplEditor.open(null); });
        $('#ipt-import').on('click', function(){
            if(!confirm('Starter-Pack importieren? Bestehende Templates werden nicht überschrieben.')) return;
            $(this).prop('disabled',true).text('Importiere…');
            api('POST','permissions/starter-pack').done(function(r){
                alert(r.created && r.created.length ? r.created.length+' Templates importiert:\n'+r.created.join(', ') : 'Alle Templates existieren bereits.');
                self.load();
            });
        });
    }
};

// =========================================================================
// TEMPLATE EDITOR
// =========================================================================
var TplEditor = {
    current: null,
    open: function(id){
        var self=this;
        if(id){
            api('GET','permissions/templates/'+id).done(function(r){
                if(r.success){ self.current=r.data; self.render(); }
            });
        } else {
            this.current = null;
            this.render();
        }
    },
    render: function(){
        var t=this.current;
        var isEdit=!!(t&&t.id);
        var $c=$('#isidor-perm-templates');

        var h='<div class="isidor-perm-editor">';
        h+='<button class="consilium-btn consilium-btn--back" id="ipe-back">&larr; Zurück</button>';
        h+='<h2>'+(isEdit?'Template bearbeiten: '+esc(t.name):'Neues Template')+'</h2>';

        // Name + Meta
        h+='<div class="consilium-form">';
        h+='<div class="consilium-field-row">';
        h+='<div class="consilium-field" style="flex:2"><label>Name *</label><input type="text" id="ipe-name" value="'+esc(t?t.name:'')+'" class="consilium-input" placeholder="z.B. Lektor"></div>';
        h+='<div class="consilium-field" style="flex:0 0 80px"><label>Icon</label><input type="text" id="ipe-icon" value="'+esc(t?t.icon:'')+'" class="consilium-input" placeholder="📋"></div>';
        h+='</div>';
        h+='<div class="consilium-field"><label>Beschreibung</label><input type="text" id="ipe-desc" value="'+esc(t?t.description:'')+'" class="consilium-input" placeholder="Kurze Beschreibung"></div>';

        // Permission matrix
        h+='<h3 style="margin-top:20px;">Modul-Berechtigungen</h3>';
        h+='<div class="isidor-perm-matrix">';

        var existingPerms = {};
        if(t && t.permissions) {
            t.permissions.forEach(function(p){ existingPerms[p.module+'_'+p.permission]=true; });
        }

        if(modules){
            Object.keys(modules).forEach(function(mod){
                var m=modules[mod];
                h+='<div class="isidor-perm-matrix__module">';
                h+='<div class="isidor-perm-matrix__header">'+esc(m.icon||'')+' '+esc(m.name)+'</div>';
                Object.keys(m.permissions).forEach(function(perm){
                    var checked = existingPerms[mod+'_'+perm] ? ' checked' : '';
                    h+='<label class="isidor-perm-matrix__item"><input type="checkbox" class="ipe-perm" data-mod="'+mod+'" data-perm="'+perm+'"'+checked+'> '+esc(m.permissions[perm])+'</label>';
                });
                h+='</div>';
            });
        }
        h+='</div>';

        // Service assignments
        h+='<h3 style="margin-top:20px;">Dienst-Zuordnungen (Liturgus)</h3>';
        h+='<p class="consilium-muted" style="margin-bottom:8px;">Welche Dienste werden automatisch zugewiesen, wenn dieses Template vergeben wird?</p>';
        h+='<div class="isidor-perm-services">';

        var existingSvcs = {};
        if(t && t.services) { t.services.forEach(function(s){ existingSvcs[s]=true; }); }

        if(services){
            var lastCat='';
            services.forEach(function(s){
                if(s.category!==lastCat){ if(lastCat) h+='</div>'; h+='<div class="isidor-perm-svc-group"><strong>'+esc(s.category)+'</strong>'; lastCat=s.category; }
                var checked = existingSvcs[s.slug] ? ' checked' : '';
                h+='<label class="isidor-perm-matrix__item"><input type="checkbox" class="ipe-svc" data-slug="'+esc(s.slug)+'"'+checked+'> '+esc(s.name)+'</label>';
            });
            if(lastCat) h+='</div>';
        }
        h+='</div>';

        // Action buttons
        h+='<div class="consilium-form-actions" style="margin-top:20px;">';
        h+='<button class="consilium-btn consilium-btn--primary" id="ipe-save">'+(isEdit?'Speichern':'Template erstellen')+'</button>';
        if(isEdit) h+='<button class="consilium-btn consilium-btn--danger-text" id="ipe-delete">🗑️ Löschen</button>';
        h+='</div>';
        h+='</div></div>';

        $c.html(h);

        // Bindings
        var self=this;
        $('#ipe-back').on('click', function(){ TplList.load(); });
        $('#ipe-save').on('click', function(){ self.save(); });
        $('#ipe-delete').on('click', function(){
            if(!confirm('Template "'+t.name+'" löschen?\n'+t.user_count+' Benutzer sind betroffen und verlieren diese Berechtigungen.')) return;
            api('DELETE','permissions/templates/'+t.id).done(function(r){
                alert(r.success ? 'Gelöscht.' : (r.message||'Fehler'));
                TplList.load();
            });
        });
    },
    save: function(){
        var t=this.current, isEdit=!!(t&&t.id);
        var name=$('#ipe-name').val().trim();
        if(!name){alert('Name erforderlich.');return;}

        var perms=[], svcs=[];
        $('.ipe-perm:checked').each(function(){ perms.push({module:$(this).data('mod'),permission:$(this).data('perm')}); });
        $('.ipe-svc:checked').each(function(){ svcs.push($(this).data('slug')); });

        var data={
            name: name,
            icon: $('#ipe-icon').val().trim(),
            description: $('#ipe-desc').val().trim(),
            permissions: perms,
            services: svcs
        };

        var $btn=$('#ipe-save').prop('disabled',true).text('Wird gespeichert…');
        var method = isEdit ? 'PUT' : 'POST';
        var url = isEdit ? 'permissions/templates/'+t.id : 'permissions/templates';

        api(method, url, data).done(function(r){
            if(r.success){
                alert(isEdit?'Gespeichert.':'Template erstellt.');
                TplList.load();
            } else {
                alert(r.message||'Fehler');
                $btn.prop('disabled',false).text(isEdit?'Speichern':'Template erstellen');
            }
        }).fail(function(){
            $btn.prop('disabled',false).text(isEdit?'Speichern':'Template erstellen');
        });
    }
};

// =========================================================================
// USER PERMISSIONS EDITOR
// =========================================================================
var UserPerms = {
    userId: null,
    profile: null,

    open: function(uid){
        var self=this;
        this.userId = uid;

        // Load data
        $.when(
            api('GET','permissions/users/'+uid),
            api('GET','permissions/templates'),
            modules ? $.Deferred().resolve() : api('GET','permissions/modules'),
            services ? $.Deferred().resolve() : api('GET','permissions/services')
        ).done(function(pRes, tRes, mRes, sRes){
            var pData = Array.isArray(pRes) ? pRes[0] : pRes;
            var tData = Array.isArray(tRes) ? tRes[0] : tRes;
            if(mRes && mRes[0]) modules = mRes[0].data;
            if(sRes && sRes[0]) services = sRes[0].data;
            self.profile = pData.data;
            templates = tData.data || [];
            self.render();
        });
    },

    render: function(){
        var p=this.profile, $c=$('#isidor-perm-user-editor');
        if(!$c.length){ $c=$('<div id="isidor-perm-user-editor"></div>'); $('#isidor-perm-templates').after($c); }

        var h='<div class="isidor-perm-editor">';
        h+='<button class="consilium-btn consilium-btn--back" id="upe-back">&larr; Zurück</button>';
        h+='<h2>Berechtigungen: '+esc(p.display_name)+'</h2>';

        // Role
        h+='<div class="consilium-field" style="max-width:300px;">';
        h+='<label>Master-Rolle</label>';
        h+='<select id="upe-role" class="consilium-select">';
        h+='<option value="isidor_mitglied"'+(p.role==='isidor_mitglied'?' selected':'')+'>Mitglied</option>';
        h+='<option value="isidor_sekretaer"'+(p.role==='isidor_sekretaer'?' selected':'')+'>Sekretär(in)</option>';
        h+='<option value="isidor_pfarrer"'+(p.role==='isidor_pfarrer'?' selected':'')+'>Pfarrer</option>';
        h+='</select>';
        h+='</div>';

        // Templates
        h+='<h3 style="margin-top:20px;">Templates</h3>';
        h+='<div class="isidor-perm-tpl-list">';
        var assignedIds = {};
        if(p.templates) p.templates.forEach(function(t){ assignedIds[t.template_id]=true; });

        if(templates && templates.length){
            templates.forEach(function(t){
                var checked = assignedIds[t.id] ? ' checked' : '';
                h+='<label class="isidor-perm-tpl-item"><input type="checkbox" class="upe-tpl" data-tid="'+t.id+'"'+checked+'> '+tplIcon(t,20)+' '+esc(t.name);
                if(t.user_count!==undefined) h+=' <small class="consilium-muted">('+t.user_count+')</small>';
                h+='</label>';
            });
        } else {
            h+='<p class="consilium-muted">Keine Templates vorhanden. <a href="#" id="upe-goto-templates">Templates erstellen</a></p>';
        }
        h+='</div>';

        // Effective permissions (read-only display)
        h+='<h3 style="margin-top:20px;">Effektive Berechtigungen</h3>';
        h+='<p class="consilium-muted" style="margin-bottom:8px;">Zusammengerechnet aus Templates + individuelle Anpassungen. Klick auf [+] oder [–] für Overrides.</p>';
        h+='<div id="upe-effective"></div>';

        // Effective services
        h+='<h3 style="margin-top:20px;">Effektive Dienste</h3>';
        h+='<div id="upe-services"></div>';

        // Delegate capability
        h+='<h3 style="margin-top:20px;">Sonderrechte</h3>';
        var hasAssign = p.role==='isidor_pfarrer'||p.role==='isidor_sekretaer';
        // Check if user has assign cap beyond their role
        h+='<label class="isidor-perm-matrix__item"><input type="checkbox" id="upe-can-assign"'+(hasAssign?' checked disabled':'')+((p.overrides||[]).some(function(o){return o.module==='_system'&&o.permission==='assign_templates'&&o.action==='grant';})?' checked':'')+'> Darf Templates an andere Benutzer zuweisen</label>';

        // Save
        h+='<div class="consilium-form-actions" style="margin-top:20px;">';
        h+='<button class="consilium-btn consilium-btn--primary" id="upe-save">💾 Speichern</button>';
        h+='</div>';
        h+='</div>';

        $c.html(h).show();
        $('#isidor-perm-templates').hide();

        this.renderEffective();
        this.renderServices();
        this.bind();
    },

    renderEffective: function(){
        var p=this.profile, h='';
        if(!modules) return;

        Object.keys(modules).forEach(function(mod){
            var m=modules[mod];
            var eff = p.effective_permissions[mod] || [];
            var hasAny = false;
            var items='';

            Object.keys(m.permissions).forEach(function(perm){
                var active = eff.indexOf(perm) !== -1;
                // Check if it's from override
                var isOverride = (p.overrides||[]).some(function(o){ return o.module===mod && o.permission===perm; });
                var overrideAction = '';
                (p.overrides||[]).forEach(function(o){ if(o.module===mod&&o.permission===perm) overrideAction=o.action; });

                var source = '';
                if(isOverride && overrideAction==='grant') source = ' <small class="isidor-perm-src isidor-perm-src--override">(individuell)</small>';
                else if(isOverride && overrideAction==='revoke') source = ' <small class="isidor-perm-src isidor-perm-src--revoked">(entzogen)</small>';
                else if(active) source = ' <small class="isidor-perm-src">(aus Template)</small>';

                var icon = active ? '✅' : '⬜';
                var btn = '';
                if(!active) btn = ' <button class="isidor-perm-override-btn" data-mod="'+mod+'" data-perm="'+perm+'" data-action="grant" title="Hinzufügen">+</button>';
                else if(!isOverride || overrideAction!=='revoke') btn = ' <button class="isidor-perm-override-btn" data-mod="'+mod+'" data-perm="'+perm+'" data-action="revoke" title="Entziehen">–</button>';
                if(isOverride) btn += ' <button class="isidor-perm-override-btn isidor-perm-override-btn--rm" data-mod="'+mod+'" data-perm="'+perm+'" data-action="remove" title="Override entfernen">✕</button>';

                items += '<div class="isidor-perm-eff-item">'+icon+' '+esc(m.permissions[perm])+source+btn+'</div>';
                if(active) hasAny=true;
            });

            if(hasAny || true) { // Always show all modules
                h+='<div class="isidor-perm-eff-module'+(hasAny?'':' isidor-perm-eff-module--empty')+'">';
                h+='<div class="isidor-perm-eff-module__header">'+(m.icon||'')+' '+esc(m.name)+'</div>';
                h+=items;
                h+='</div>';
            }
        });

        $('#upe-effective').html(h);

        // Override button handlers
        var self=this;
        $('.isidor-perm-override-btn').off('click').on('click', function(){
            var mod=$(this).data('mod'), perm=$(this).data('perm'), action=$(this).data('action');
            if(action==='remove'){
                // Remove override from profile
                self.profile.overrides = (self.profile.overrides||[]).filter(function(o){ return !(o.module===mod && o.permission===perm); });
            } else {
                // Add/replace override
                self.profile.overrides = (self.profile.overrides||[]).filter(function(o){ return !(o.module===mod && o.permission===perm); });
                self.profile.overrides.push({module:mod, permission:perm, action:action});
            }
            // Recalculate effective (approximate client-side)
            self.recalcEffective();
            self.renderEffective();
        });
    },

    renderServices: function(){
        var p=this.profile, h='';
        if(!services) return;

        var effSvcs = p.effective_services || [];
        var svcOverrides = {};
        (p.service_overrides||[]).forEach(function(o){ svcOverrides[o.service_slug]=o.action; });

        services.forEach(function(s){
            var active = effSvcs.indexOf(s.slug) !== -1;
            var isOverride = svcOverrides[s.slug] !== undefined;
            var icon = active ? '✅' : '⬜';
            var source = '';
            if(isOverride && svcOverrides[s.slug]==='grant') source=' <small class="isidor-perm-src isidor-perm-src--override">(individuell)</small>';
            else if(isOverride && svcOverrides[s.slug]==='revoke') source=' <small class="isidor-perm-src isidor-perm-src--revoked">(entzogen)</small>';
            else if(active) source=' <small class="isidor-perm-src">(aus Template)</small>';

            var btn='';
            if(!active) btn=' <button class="isidor-svc-override-btn" data-slug="'+s.slug+'" data-action="grant">+</button>';
            else if(!isOverride || svcOverrides[s.slug]!=='revoke') btn=' <button class="isidor-svc-override-btn" data-slug="'+s.slug+'" data-action="revoke">–</button>';
            if(isOverride) btn+=' <button class="isidor-svc-override-btn isidor-perm-override-btn--rm" data-slug="'+s.slug+'" data-action="remove">✕</button>';

            h+='<div class="isidor-perm-eff-item">'+icon+' '+esc(s.name)+source+btn+'</div>';
        });

        $('#upe-services').html(h);

        var self=this;
        $('.isidor-svc-override-btn').off('click').on('click', function(){
            var slug=$(this).data('slug'), action=$(this).data('action');
            if(action==='remove'){
                self.profile.service_overrides = (self.profile.service_overrides||[]).filter(function(o){ return o.service_slug!==slug; });
            } else {
                self.profile.service_overrides = (self.profile.service_overrides||[]).filter(function(o){ return o.service_slug!==slug; });
                self.profile.service_overrides.push({service_slug:slug, action:action});
            }
            self.recalcServices();
            self.renderServices();
        });
    },

    recalcEffective: function(){
        // Client-side recalc based on selected templates + overrides
        var p=this.profile;
        var eff={};

        // From selected templates
        var selectedTplIds = {};
        $('.upe-tpl:checked').each(function(){ selectedTplIds[$(this).data('tid')]=true; });

        if(templates) templates.forEach(function(t){
            if(!selectedTplIds[t.id]) return;
            // We need template perms — fetch or use cached
            // For now approximate: we'll just keep what server sent since full recalc needs template details
        });

        // Keep server-side effective as base, apply overrides
        eff = JSON.parse(JSON.stringify(p.effective_permissions || {}));

        (p.overrides||[]).forEach(function(o){
            if(o.action==='grant'){
                if(!eff[o.module]) eff[o.module]=[];
                if(eff[o.module].indexOf(o.permission)===-1) eff[o.module].push(o.permission);
            } else if(o.action==='revoke'){
                if(eff[o.module]) eff[o.module]=eff[o.module].filter(function(x){return x!==o.permission;});
            }
        });

        p.effective_permissions = eff;
    },

    recalcServices: function(){
        var p=this.profile;
        // Keep base from server, apply overrides
        // (full recalc would need template service data)
        var base = p._base_services || (p._base_services = (p.effective_services||[]).slice());
        var eff = base.slice();

        (p.service_overrides||[]).forEach(function(o){
            if(o.action==='grant' && eff.indexOf(o.service_slug)===-1) eff.push(o.service_slug);
            else if(o.action==='revoke') eff=eff.filter(function(x){return x!==o.service_slug;});
        });

        p.effective_services = eff;
    },

    bind: function(){
        var self=this;
        $('#upe-back').on('click', function(){
            $('#isidor-perm-user-editor').hide();
            $('#isidor-perm-templates').show();
            // Trigger user list reload if exists
            if(window.isidorUserListReload) window.isidorUserListReload();
        });

        $('#upe-save').on('click', function(){
            var $btn=$(this).prop('disabled',true).text('Wird gespeichert…');
            var tplIds=[];
            $('.upe-tpl:checked').each(function(){ tplIds.push(parseInt($(this).data('tid'))); });

            var data = {
                role: $('#upe-role').val(),
                template_ids: tplIds,
                overrides: self.profile.overrides || [],
                service_overrides: self.profile.service_overrides || [],
                can_assign_templates: $('#upe-can-assign').is(':checked') && !$('#upe-can-assign').prop('disabled'),
            };

            api('PUT','permissions/users/'+self.userId, data).done(function(r){
                if(r.success){
                    self.profile = r.data;
                    alert('Gespeichert.');
                    self.render();
                } else {
                    alert(r.message||'Fehler');
                }
                $btn.prop('disabled',false).text('💾 Speichern');
            }).fail(function(){
                $btn.prop('disabled',false).text('💾 Speichern');
            });
        });

        // Template checkboxes trigger recalc
        $('.upe-tpl').on('change', function(){
            // Would need to re-fetch effective — for now just mark as changed
            // Full recalc happens on save
        });
    }
};

// Make UserPerms accessible globally for user manager integration
window.IsidorUserPerms = UserPerms;

// =========================================================================
// SERVICE TYPES MANAGEMENT
// =========================================================================
var SvcMgr = {
    init: function(){
        if(!$('#isidor-perm-services').length) return;
        this.load();
    },
    load: function(){
        var self=this;
        api('GET','permissions/services').done(function(r){
            services = r.data || [];
            self.render();
        });
    },
    render: function(){
        var $c=$('#isidor-perm-services').empty();
        var h='<div class="isidor-perm-header">';
        h+='<h2>Dienst-Typen</h2>';
        h+='</div>';
        h+='<p class="consilium-muted" style="margin-bottom:16px;">Diese Dienste stehen in der Template-Matrix und bei der Benutzerverwaltung zur Auswahl. Gelöschte Dienste werden deaktiviert, bestehende Zuordnungen bleiben erhalten.</p>';

        // Category groups
        var cats = {};
        services.forEach(function(s){
            var cat = s.category || 'sonstige';
            if(!cats[cat]) cats[cat]=[];
            cats[cat].push(s);
        });

        var catLabels = {liturgisch:'⛪ Liturgisch',musikalisch:'🎵 Musikalisch',technisch:'🎛️ Technisch',sonstige:'📋 Sonstige'};

        Object.keys(catLabels).forEach(function(cat){
            var items = cats[cat] || [];
            h+='<div class="isidor-perm-svc-mgr-group">';
            h+='<h3>'+(catLabels[cat]||cat)+'</h3>';
            h+='<div class="isidor-perm-svc-list">';
            items.forEach(function(s){
                h+='<div class="isidor-perm-svc-row" data-id="'+s.id+'">';
                h+='<span class="isidor-perm-svc-name">'+esc(s.name)+'</span>';
                h+='<span class="isidor-perm-svc-slug consilium-muted">'+esc(s.slug)+'</span>';
                h+='<button class="isidor-perm-override-btn isidor-perm-svc-edit" title="Umbenennen">✏️</button>';
                h+='<button class="isidor-perm-override-btn isidor-perm-override-btn--rm isidor-perm-svc-del" title="Deaktivieren">✕</button>';
                h+='</div>';
            });
            h+='</div>';

            // Add new in this category
            h+='<div class="isidor-perm-svc-add">';
            h+='<input type="text" class="consilium-input isidor-perm-svc-new-name" placeholder="Neuer Dienst…" data-cat="'+cat+'" style="flex:1;max-width:250px;">';
            h+='<button class="consilium-btn consilium-btn--small consilium-btn--secondary isidor-perm-svc-add-btn" data-cat="'+cat+'">+ Hinzufügen</button>';
            h+='</div>';
            h+='</div>';
        });

        $c.html(h);
        this.bind();
    },
    bind: function(){
        var self=this;

        // Add
        $('.isidor-perm-svc-add-btn').on('click', function(){
            var cat=$(this).data('cat');
            var $input=$(this).siblings('.isidor-perm-svc-new-name');
            var name=$input.val().trim();
            if(!name){$input.focus();return;}
            var $btn=$(this).prop('disabled',true).text('…');
            api('POST','permissions/services',{name:name,category:cat}).done(function(r){
                if(r.success){
                    $input.val('');
                    self.load();
                } else {
                    alert(r.message||'Fehler');
                }
                $btn.prop('disabled',false).text('+ Hinzufügen');
            });
        });

        // Enter key in input
        $('.isidor-perm-svc-new-name').on('keydown', function(e){
            if(e.key==='Enter'){e.preventDefault(); $(this).siblings('.isidor-perm-svc-add-btn').click();}
        });

        // Edit (rename)
        $('.isidor-perm-svc-edit').on('click', function(){
            var $row=$(this).closest('.isidor-perm-svc-row');
            var id=$row.data('id');
            var current=$row.find('.isidor-perm-svc-name').text();
            var newName=prompt('Dienst umbenennen:',current);
            if(!newName||newName===current) return;
            api('PUT','permissions/services/'+id,{name:newName}).done(function(r){
                if(r.success) self.load();
            });
        });

        // Delete (deactivate)
        $('.isidor-perm-svc-del').on('click', function(){
            var $row=$(this).closest('.isidor-perm-svc-row');
            var id=$row.data('id');
            var name=$row.find('.isidor-perm-svc-name').text();
            if(!confirm('Dienst "'+name+'" deaktivieren?')) return;
            api('DELETE','permissions/services/'+id).done(function(r){
                if(r.success) self.load();
            });
        });
    }
};

// =========================================================================
// INIT
// =========================================================================
$(document).ready(function(){
    TplList.init();
    SvcMgr.init();
});

})(jQuery);
