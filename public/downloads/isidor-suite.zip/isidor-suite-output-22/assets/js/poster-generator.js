/**
 * Isidor Plakat-Generator
 * Mit Templates und E-Mail-Versand
 */
document.addEventListener('DOMContentLoaded', function() {
    if (!document.getElementById('poster-canvas')) return;

    // --- CONFIG ---
    const formats = {
        'a4_p': { w: 210, h: 297 }, 'a4_l': { w: 297, h: 210 },
        'a3_p': { w: 297, h: 420 }, 'a3_l': { w: 420, h: 297 }
    };
    
    // Farbpalette (Pfarre-CI)
    const colorPalette = [
        { name: 'Hellblau', hex: '#6DC0D2' },
        { name: 'Grün', hex: '#90AD50' },
        { name: 'Dunkelblau', hex: '#155277' },
        { name: 'Beere', hex: '#AF3F6C' },
        { name: 'Altrosa', hex: '#BC8080' },
        { name: 'Weiß', hex: '#FFFFFF' },
        { name: 'Schwarz', hex: '#000000' },
    ];
    
    // Fonts
    const fonts = {
        'FormaDJRBanner-Black': { label: 'Forma DJR Black', weight: '900' },
        'FormaDJRBanner-Light': { label: 'Forma DJR Light', weight: '300' },
        'Arial': { label: 'Arial', weight: 'normal' },
    };
    
    // Templates mit exakten Maßen (mm)
    const templates = {
        'veranstaltung': {
            name: '🎪 Veranstaltung',
            elements: [
                { id: 'type', x: 11.15, y: 9.95, font: 'FormaDJRBanner-Black', size: 50.3, color: '#90AD50', text: 'VERANSTALTUNGSFORM' },
                { id: 'title', x: 11.15, y: 45, font: 'FormaDJRBanner-Black', size: 99, color: '#155277', text: 'Titel der\nVeranstaltung', lineHeight: 0.95 },
                { id: 'date', x: 41, y: 205, font: 'FormaDJRBanner-Black', size: 60, color: '#155277', text: 'Datum' },
                { id: 'time', x: 41, y: 240, font: 'FormaDJRBanner-Black', size: 60, color: '#155277', text: 'Uhrzeit' },
                { id: 'speaker', x: 115.8, y: 230, font: 'FormaDJRBanner-Black', size: 36, color: '#90AD50', text: 'Referent' },
                { id: 'subtitle', x: 115.8, y: 250, font: 'FormaDJRBanner-Light', size: 30, color: '#6DC0D2', text: 'Untertitel' },
            ]
        },
        'messe': {
            name: '⛪ Hl. Messe',
            elements: [
                { id: 'type', x: 11.15, y: 9.95, font: 'FormaDJRBanner-Black', size: 50.3, color: '#90AD50', text: 'HL. MESSE' },
                { id: 'title', x: 11.15, y: 45, font: 'FormaDJRBanner-Black', size: 99, color: '#155277', text: 'Titel der\nVeranstaltung', lineHeight: 0.95 },
                { id: 'date', x: 41, y: 205, font: 'FormaDJRBanner-Black', size: 60, color: '#155277', text: 'Datum' },
                { id: 'time', x: 41, y: 240, font: 'FormaDJRBanner-Black', size: 60, color: '#155277', text: 'Uhrzeit' },
                { id: 'info1', x: 115.8, y: 230, font: 'FormaDJRBanner-Black', size: 36, color: '#90AD50', text: 'Spezial' },
                { id: 'info2', x: 115.8, y: 250, font: 'FormaDJRBanner-Light', size: 30, color: '#6DC0D2', text: 'Information2' },
            ]
        },
        'leer': {
            name: '📄 Leeres Plakat',
            elements: []
        }
    };
    
    const screenScale = 2.5; // 1mm = 2.5px
    let currentFormat = formats['a4_p'];
    let currentTemplate = 'veranstaltung';
    let headerObj = null, footerObj = null;
    const data = window.isidorData || {};

    // --- FABRIC INIT ---
    const canvas = new fabric.Canvas('poster-canvas', {
        width: currentFormat.w * screenScale,
        height: currentFormat.h * screenScale,
        backgroundColor: '#ffffff',
        preserveObjectStacking: true
    });

    // --- FONT PRELOAD ---
    // Ensure FormaDJR fonts are fully loaded before rendering any text
    function preloadFonts() {
        if (!document.fonts) return Promise.resolve();
        
        // Load all custom fonts
        const loads = [
            document.fonts.load('900 48px "FormaDJRBanner-Black"').catch(() => {}),
            document.fonts.load('300 48px "FormaDJRBanner-Light"').catch(() => {}),
        ];
        
        return Promise.all(loads).then(() => {
            // Wait for all fonts to be ready
            return document.fonts.ready;
        });
    }

    // --- INIT ---
    function init() {
        preloadFonts().then(() => {
            populateDropdowns();
            buildColorPalette();
            buildTemplateButtons();
            setupEvents();
            applyTemplate('veranstaltung');
        });
    }

    function populateDropdowns() {
        const hSelect = document.getElementById('ipa-header-select');
        const fSelect = document.getElementById('ipa-footer-select');
        const fontSelect = document.getElementById('ipa-font');
        const eventSelect = document.getElementById('ipa-event-select');
        
        if (data.headers) {
            data.headers.forEach(img => hSelect.add(new Option(img.name, img.url)));
        }
        if (data.footers) {
            data.footers.forEach(img => fSelect.add(new Option(img.name, img.url)));
        }
        if (fontSelect) {
            Object.keys(fonts).forEach(key => {
                fontSelect.add(new Option(fonts[key].label, key));
            });
        }
        // Events + Sondermessen
        if (eventSelect && data.events && data.events.length > 0) {
            data.events.forEach(evt => {
                const dateStr = formatDateShort(evt.date);
                const label = `${evt.type_icon || '📅'} ${evt.title} (${dateStr})`;
                const opt = new Option(label, evt.id);
                opt.dataset.event = JSON.stringify(evt);
                eventSelect.add(opt);
            });
        }
        // Sondermessen hinzufügen
        if (eventSelect && data.special_masses && data.special_masses.length > 0) {
            const optgroup = document.createElement('optgroup');
            optgroup.label = '⛪ Sondermessen';
            data.special_masses.forEach(m => {
                const dateStr = formatDateShort(m.date);
                const opt = new Option(`⛪ ${m.title} (${dateStr})`, 'messe_' + m.id);
                opt.dataset.messe = JSON.stringify(m);
                optgroup.appendChild(opt);
            });
            eventSelect.appendChild(optgroup);
        }
    }
    
    function buildColorPalette() {
        const container = document.getElementById('ipa-color-palette');
        if (!container) return;
        
        colorPalette.forEach(c => {
            const swatch = document.createElement('button');
            swatch.type = 'button';
            swatch.className = 'color-swatch';
            swatch.style.backgroundColor = c.hex;
            swatch.title = c.name;
            swatch.dataset.color = c.hex;
            if (c.hex === '#FFFFFF') swatch.style.border = '2px solid #ccc';
            
            swatch.addEventListener('click', () => {
                document.getElementById('ipa-color').value = c.hex;
                updateSelectedText('fill', c.hex);
                container.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
                swatch.classList.add('active');
            });
            container.appendChild(swatch);
        });
    }
    
    function buildTemplateButtons() {
        const container = document.getElementById('ipa-template-buttons');
        if (!container) return;
        
        Object.keys(templates).forEach(key => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'button' + (key === currentTemplate ? ' button-primary' : '');
            btn.textContent = templates[key].name;
            btn.addEventListener('click', () => {
                applyTemplate(key);
                container.querySelectorAll('button').forEach(b => b.classList.remove('button-primary'));
                btn.classList.add('button-primary');
            });
            container.appendChild(btn);
        });
    }

    // --- TEMPLATES ---
    function applyTemplate(templateKey) {
        currentTemplate = templateKey;
        canvas.clear();
        canvas.setBackgroundColor('#ffffff', canvas.renderAll.bind(canvas));
        headerObj = null;
        footerObj = null;
        
        const tpl = templates[templateKey];
        if (!tpl || !tpl.elements) return;
        
        tpl.elements.forEach(el => {
            const textObj = new fabric.IText(el.text, {
                left: el.x * screenScale,
                top: el.y * screenScale,
                fontFamily: el.font,
                fontSize: el.size * screenScale / 2.83, // pt to px at scale
                fill: el.color,
                lineHeight: el.lineHeight || 1.0,
                id: el.id
            });
            canvas.add(textObj);
        });
        
        // Force Fabric to re-measure text with loaded fonts
        canvas.getObjects().forEach(obj => {
            if (obj.type === 'i-text' || obj.type === 'text') {
                obj.dirty = true;
                obj.initDimensions();
                obj.setCoords();
            }
        });
        
        canvas.requestRenderAll();
    }
    
    function loadEventData(evt) {
        // Template wählen basierend auf Typ
        const tplKey = (evt.type === 'messe' || evt.meta1 === 'messe') ? 'messe' : 'veranstaltung';
        applyTemplate(tplKey);
        
        // Texte füllen
        canvas.getObjects().forEach(obj => {
            if (!obj.id) return;
            
            switch(obj.id) {
                case 'type':
                    // Bei Sonstiges: custom_type verwenden wenn vorhanden
                    let typeText = evt.type_label || evt.type || 'VERANSTALTUNG';
                    if ((evt.meta1 === 'sonstiges' || evt.type === 'sonstiges') && evt.custom_type) {
                        typeText = evt.custom_type;
                    }
                    obj.set('text', typeText.toUpperCase());
                    break;
                case 'title':
                    obj.set('text', evt.title || 'Titel');
                    break;
                case 'date':
                    obj.set('text', formatDateLong(evt.date));
                    break;
                case 'time':
                    if (evt.start_time && evt.start_time !== '00:00:00') {
                        obj.set('text', evt.start_time.substring(0, 5) + ' Uhr');
                    } else {
                        obj.set('text', '');
                    }
                    break;
                case 'speaker':
                case 'info1':
                    obj.set('text', evt.speaker || '');
                    break;
                case 'subtitle':
                case 'info2':
                    obj.set('text', evt.subtitle || evt.meta2 || '');
                    break;
            }
        });
        
        canvas.renderAll();
    }
    
    function loadMesseData(messe) {
        applyTemplate('messe');
        
        canvas.getObjects().forEach(obj => {
            if (!obj.id) return;
            
            switch(obj.id) {
                case 'type':
                    obj.set('text', 'HL. MESSE');
                    break;
                case 'title':
                    obj.set('text', messe.title || messe.liturgical || 'Sondermesse');
                    break;
                case 'date':
                    obj.set('text', formatDateLong(messe.date));
                    break;
                case 'time':
                    obj.set('text', messe.time ? messe.time.substring(0, 5) + ' Uhr' : '');
                    break;
                case 'info1':
                    obj.set('text', messe.liturgical || '');
                    break;
                case 'info2':
                    obj.set('text', data.parish?.name || '');
                    break;
            }
        });
        
        canvas.renderAll();
    }

    // --- EVENTS ---
    function setupEvents() {
        // Format
        document.getElementById('ipa-format')?.addEventListener('change', (e) => {
            currentFormat = formats[e.target.value];
            resizeCanvas();
        });

        // Header/Footer
        document.getElementById('ipa-header-select')?.addEventListener('change', (e) => loadDeco(e.target.value, 'header'));
        document.getElementById('ipa-footer-select')?.addEventListener('change', (e) => loadDeco(e.target.value, 'footer'));

        // Text Properties
        document.getElementById('ipa-font-size')?.addEventListener('input', (e) => updateSelectedText('fontSize', parseInt(e.target.value)));
        document.getElementById('ipa-color')?.addEventListener('input', (e) => updateSelectedText('fill', e.target.value));
        document.getElementById('ipa-text-content')?.addEventListener('input', (e) => updateSelectedText('text', e.target.value));
        document.getElementById('ipa-font')?.addEventListener('change', (e) => updateSelectedText('fontFamily', e.target.value));
        document.getElementById('ipa-shadow')?.addEventListener('change', (e) => {
            const shadow = e.target.checked ? new fabric.Shadow({ color: 'rgba(0,0,0,0.5)', blur: 5, offsetX: 3, offsetY: 3 }) : null;
            updateSelectedText('shadow', shadow);
        });

        // Canvas Selection
        canvas.on('selection:created', syncUI);
        canvas.on('selection:updated', syncUI);

        // Buttons
        document.getElementById('ipa-add-text')?.addEventListener('click', addNewText);
        document.getElementById('ipa-delete')?.addEventListener('click', deleteSelected);
        document.getElementById('ipa-bg-color')?.addEventListener('input', (e) => {
            canvas.setBackgroundColor(e.target.value, canvas.renderAll.bind(canvas));
        });

        // Upload & Export
        document.getElementById('ipa-bg-upload')?.addEventListener('change', handleBgUpload);
        document.getElementById('ipa-fit-bg')?.addEventListener('click', fitBackground);
        document.getElementById('ipa-download-pdf')?.addEventListener('click', generatePDF);
        document.getElementById('ipa-send-email')?.addEventListener('click', sendEmail);
        
        // Event Dropdown
        document.getElementById('ipa-event-select')?.addEventListener('change', function() {
            const opt = this.options[this.selectedIndex];
            if (opt.dataset.event) {
                loadEventData(JSON.parse(opt.dataset.event));
            } else if (opt.dataset.messe) {
                loadMesseData(JSON.parse(opt.dataset.messe));
            }
        });
    }
    
    function updateSelectedText(prop, val) {
        const obj = canvas.getActiveObject();
        if (obj && (obj.type === 'text' || obj.type === 'i-text')) {
            obj.set(prop, val);
            canvas.requestRenderAll();
        }
    }
    
    function addNewText() {
        const t = new fabric.IText('Neuer Text', {
            fontFamily: document.getElementById('ipa-font')?.value || 'FormaDJRBanner-Black',
            left: 100,
            top: 300,
            fontSize: 32,
            fill: document.getElementById('ipa-color')?.value || '#000000'
        });
        canvas.add(t);
        canvas.setActiveObject(t);
    }
    
    function deleteSelected() {
        const obj = canvas.getActiveObject();
        if (obj && obj !== headerObj && obj !== footerObj) {
            canvas.remove(obj);
            canvas.discardActiveObject();
            canvas.requestRenderAll();
        }
    }

    function syncUI() {
        const obj = canvas.getActiveObject();
        if (!obj) return;
        
        // For text objects, sync text controls
        if (obj.type === 'text' || obj.type === 'i-text') {
            const content = document.getElementById('ipa-text-content');
            const size = document.getElementById('ipa-font-size');
            const color = document.getElementById('ipa-color');
            const shadow = document.getElementById('ipa-shadow');
            const font = document.getElementById('ipa-font');
            
            if (content) content.value = obj.text || '';
            if (size) size.value = Math.round(obj.fontSize) || 40;
            if (color) color.value = obj.fill || '#000000';
            if (shadow) shadow.checked = !!obj.shadow;
            if (font && obj.fontFamily) font.value = obj.fontFamily;
        }
    }

    function resizeCanvas() {
        canvas.setWidth(currentFormat.w * screenScale);
        canvas.setHeight(currentFormat.h * screenScale);
        canvas.renderAll();
    }

    /**
     * Reorder canvas layers: uploaded images at bottom, header/footer above, text on top.
     */
    function reorderLayers() {
        const objects = canvas.getObjects().slice(); // copy
        // Sort: user images (bottom) → header/footer (middle) → text (top)
        objects.sort((a, b) => {
            const order = (obj) => {
                if (obj === headerObj || obj === footerObj) return 1;
                if (obj.type === 'i-text' || obj.type === 'text' || obj.type === 'textbox') return 2;
                return 0; // uploaded images
            };
            return order(a) - order(b);
        });
        objects.forEach((obj, i) => canvas.moveTo(obj, i));
        canvas.renderAll();
    }

    function loadDeco(url, type) {
        if (!url) {
            if (type === 'header' && headerObj) { canvas.remove(headerObj); headerObj = null; }
            if (type === 'footer' && footerObj) { canvas.remove(footerObj); footerObj = null; }
            return;
        }
        fabric.Image.fromURL(url, function(img) {
            img.scaleToWidth(canvas.width);
            img.set({ selectable: false, evented: false });
            
            if (type === 'header') {
                if (headerObj) canvas.remove(headerObj);
                img.set({ top: 0, left: 0 });
                headerObj = img;
            } else {
                if (footerObj) canvas.remove(footerObj);
                img.set({ top: canvas.height - img.getScaledHeight(), left: 0 });
                footerObj = img;
            }
            canvas.add(img);
            reorderLayers();
        }, { crossOrigin: 'anonymous' });
    }

    function handleBgUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function(evt) {
            fabric.Image.fromURL(evt.target.result, function(img) {
                // Scale to fit canvas width but keep aspect ratio
                const scale = canvas.width / img.width;
                img.set({
                    originX: 'left',
                    originY: 'top',
                    left: 0,
                    top: 0,
                    scaleX: scale,
                    scaleY: scale,
                    selectable: true,       // Allow selection
                    hasControls: true,      // Show resize handles
                    hasBorders: true,       // Show selection border
                    lockRotation: false,    // Allow rotation
                    cornerSize: 12,         // Bigger corners for easier grabbing
                    cornerColor: '#16a34a',
                    cornerStrokeColor: '#fff',
                    borderColor: '#16a34a',
                    transparentCorners: false,
                });
                canvas.add(img);
                canvas.setActiveObject(img);
                reorderLayers();
            });
        };
        reader.readAsDataURL(file);
    }

    function fitBackground() {
        const obj = canvas.getActiveObject();
        if (obj && obj.type === 'image') {
            const scale = canvas.width / obj.width;
            obj.set({ left: 0, top: 0, scaleX: scale, scaleY: scale });
            canvas.discardActiveObject();
            reorderLayers();
        }
    }

    function generatePDF() {
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
            orientation: currentFormat.w > currentFormat.h ? 'l' : 'p',
            unit: 'mm',
            format: [currentFormat.w, currentFormat.h]
        });
        
        const imgData = canvas.toDataURL({ format: 'png', multiplier: 3 });
        pdf.addImage(imgData, 'PNG', 0, 0, currentFormat.w, currentFormat.h);
        pdf.save('plakat.pdf');
    }
    
    function sendEmail() {
        const emailSelect = document.getElementById('ipa-email-select');
        const email = emailSelect?.value;
        
        if (!email) {
            alert('Bitte E-Mail-Adresse auswählen');
            return;
        }
        
        // PDF als Base64
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
            orientation: currentFormat.w > currentFormat.h ? 'l' : 'p',
            unit: 'mm',
            format: [currentFormat.w, currentFormat.h]
        });
        
        const imgData = canvas.toDataURL({ format: 'png', multiplier: 3 });
        pdf.addImage(imgData, 'PNG', 0, 0, currentFormat.w, currentFormat.h);
        const pdfBase64 = pdf.output('datauristring');
        
        // An Server senden
        const btn = document.getElementById('ipa-send-email');
        btn.disabled = true;
        btn.textContent = '📤 Wird gesendet...';
        
        fetch(data.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'isidor_poster_send_email',
                nonce: data.nonce,
                email: email,
                pdf: pdfBase64
            })
        })
        .then(r => r.json())
        .then(res => {
            btn.disabled = false;
            btn.textContent = '📧 Per E-Mail senden';
            if (res.success) {
                alert('✓ E-Mail gesendet an: ' + email);
            } else {
                alert('Fehler: ' + (res.data?.message || 'Unbekannter Fehler'));
            }
        })
        .catch(err => {
            btn.disabled = false;
            btn.textContent = '📧 Per E-Mail senden';
            alert('Fehler beim Senden: ' + err);
        });
    }

    // --- HELPERS ---
    function formatDateShort(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.getDate() + '.' + (d.getMonth() + 1) + '.' + d.getFullYear();
    }
    
    function formatDateLong(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        const days = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
        const months = ['Jänner', 'Februar', 'März', 'April', 'Mai', 'Juni', 
                        'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
        return days[d.getDay()] + ', ' + d.getDate() + '. ' + months[d.getMonth()];
    }

    // --- START ---
    init();
});
