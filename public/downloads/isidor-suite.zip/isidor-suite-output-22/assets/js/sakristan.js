/**
 * Isidor Sakristan – Frontend JavaScript
 */
(function($) {
    'use strict';

    var D = window.sakristanData || {};
    
    /* ================================================================
       TOAST
       ================================================================ */
    function toast(msg) {
        var $t = $('#sakr-toast');
        if (!$t.length) {
            $t = $('<div id="sakr-toast" class="sakr-toast"></div>').appendTo('body');
        }
        $t.text(msg).addClass('show');
        clearTimeout($t.data('timer'));
        $t.data('timer', setTimeout(function(){ $t.removeClass('show'); }, 2500));
    }

    /* ================================================================
       STANDARD-CHECKLISTE (Template-basiert, post_meta)
       ================================================================ */
    $(document).on('change', '.sakr-checklist-cb', function() {
        var $cb = $(this);
        var key = $cb.data('key');
        var messe = $cb.data('messe');
        var checked = $cb.is(':checked');
        
        // Visuelles Feedback
        $cb.closest('.sakr-check-item').toggleClass('checked', checked);
        
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_toggle_checklist',
            nonce: D.nonce,
            messe_id: messe,
            key: key,
            checked: checked ? 1 : 0
        }).fail(function() {
            // Rollback
            $cb.prop('checked', !checked);
            $cb.closest('.sakr-check-item').toggleClass('checked', !checked);
            toast('Fehler beim Speichern');
        });
    });

    /* ================================================================
       DYNAMISCHE TODOS
       ================================================================ */
    
    // Toggle erledigt/offen
    $(document).on('change', '.sakr-todo-cb', function() {
        var $cb = $(this);
        var id = $cb.data('id');
        var $item = $cb.closest('.sakr-todo-item');
        
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_toggle_todo',
            nonce: D.nonce,
            todo_id: id
        }, function(r) {
            if (r.success) {
                var done = r.data.status === 'erledigt';
                $item.toggleClass('sakr-done', done);
                toast(done ? 'Erledigt ✓' : 'Wieder geöffnet');
            }
        }).fail(function() {
            $cb.prop('checked', !$cb.is(':checked'));
            toast('Fehler');
        });
    });

    // Neues ToDo (Messe-gebunden)
    $(document).on('click', '#sakr-add-todo-btn', function() {
        var $btn = $(this);
        var title = $('#sakr-new-todo-title').val().trim();
        var priority = $('#sakr-new-todo-priority').val();
        var messe = $btn.data('messe');
        
        if (!title) { $('#sakr-new-todo-title').focus(); return; }
        
        $btn.prop('disabled', true);
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_create_todo',
            nonce: D.nonce,
            title: title,
            priority: priority,
            messe_id: messe
        }, function(r) {
            if (r.success) {
                var $list = $('#sakr-messe-todos');
                $list.find('.sakr-no-todos').remove();
                $list.append(r.data.html);
                $('#sakr-new-todo-title').val('');
                toast('Aufgabe angelegt');
            } else {
                toast(r.data || 'Fehler');
            }
        }).always(function() {
            $btn.prop('disabled', false);
        });
    });

    // Enter-Taste im Titel-Feld
    $(document).on('keydown', '#sakr-new-todo-title', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); $('#sakr-add-todo-btn').click(); }
    });

    // Neues ToDo (Allgemein – aus dem Todos-Tab)
    $(document).on('click', '#sakr-gen-add-btn', function() {
        var $btn = $(this);
        var title = $('#sakr-gen-todo-title').val().trim();
        var priority = $('#sakr-gen-todo-priority').val();
        var dueDate = $('#sakr-gen-todo-date').val();
        
        if (!title) { $('#sakr-gen-todo-title').focus(); return; }
        
        $btn.prop('disabled', true);
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_create_todo',
            nonce: D.nonce,
            title: title,
            priority: priority,
            due_date: dueDate,
            messe_id: 0
        }, function(r) {
            if (r.success) {
                var $list = $('#sakr-global-todos');
                $list.find('.sakr-empty').remove();
                $list.prepend(r.data.html);
                $('#sakr-gen-todo-title').val('');
                toast('Aufgabe angelegt');
            } else {
                toast(r.data || 'Fehler');
            }
        }).always(function() {
            $btn.prop('disabled', false);
        });
    });

    $(document).on('keydown', '#sakr-gen-todo-title', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); $('#sakr-gen-add-btn').click(); }
    });

    // ToDo löschen
    $(document).on('click', '.sakr-todo-delete', function() {
        var $btn = $(this);
        var id = $btn.data('id');
        if (!confirm('Aufgabe wirklich löschen?')) return;
        
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_delete_todo',
            nonce: D.nonce,
            todo_id: id
        }, function(r) {
            if (r.success) {
                $btn.closest('.sakr-todo-item').fadeOut(200, function(){ $(this).remove(); });
                toast('Gelöscht');
            }
        });
    });

    /* ================================================================
       MESSE ALS VORBEREITET MARKIEREN
       ================================================================ */
    $(document).on('click', '#sakr-complete-btn', function() {
        var $btn = $(this);
        var messe = $btn.data('messe');
        
        if (!confirm('Sakristei als vorbereitet markieren und Pfarrer informieren?')) return;
        
        $btn.prop('disabled', true).text('Wird gespeichert…');
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_complete',
            nonce: D.nonce,
            messe_id: messe
        }, function(r) {
            if (r.success) {
                toast('✅ Vorbereitet — Benachrichtigung gesendet');
                setTimeout(function() { location.reload(); }, 800);
            } else {
                toast(r.data || 'Fehler');
                $btn.prop('disabled', false).text('✅ Sakristei vorbereitet — Pfarrer informieren');
            }
        });
    });

    /* ================================================================
       DIENSTZEIT-ERFASSUNG
       ================================================================ */
    $(document).on('click', '#sakr-tl-save-btn', function() {
        var $btn = $(this);
        var data = {
            action: 'isidor_sakr_save_timelog',
            nonce: D.nonce,
            log_date: $('#sakr-tl-date').val(),
            start_time: $('#sakr-tl-start').val(),
            end_time: $('#sakr-tl-end').val(),
            category: $('#sakr-tl-category').val(),
            note: $('#sakr-tl-note').val()
        };
        
        if (!data.log_date || !data.start_time || !data.end_time) {
            toast('Bitte Datum und Zeiten ausfüllen');
            return;
        }
        
        $btn.prop('disabled', true).text('Speichern…');
        $.post(D.ajaxUrl, data, function(r) {
            if (r.success) {
                toast(r.data.message);
                // Seite neu laden um die Tabelle zu aktualisieren
                setTimeout(function() { location.reload(); }, 600);
            } else {
                toast(r.data || 'Fehler');
            }
        }).always(function() {
            $btn.prop('disabled', false).text('Eintragen');
        });
    });

    // Dienstzeit löschen
    $(document).on('click', '.sakr-tl-delete', function() {
        var $btn = $(this);
        var id = $btn.data('id');
        if (!confirm('Eintrag wirklich löschen?')) return;
        
        $.post(D.ajaxUrl, {
            action: 'isidor_sakr_delete_timelog',
            nonce: D.nonce,
            tl_id: id
        }, function(r) {
            if (r.success) {
                $btn.closest('tr').fadeOut(200, function(){ $(this).remove(); });
                toast('Eintrag gelöscht');
            }
        });
    });

    // Auto-Berechnung der Stunden bei Von/Bis-Änderung
    $(document).on('change', '#sakr-tl-start, #sakr-tl-end', function() {
        var start = $('#sakr-tl-start').val();
        var end = $('#sakr-tl-end').val();
        if (start && end) {
            var s = start.split(':').map(Number);
            var e = end.split(':').map(Number);
            var diff = (e[0]*60 + e[1]) - (s[0]*60 + s[1]);
            if (diff > 0) {
                var h = (diff / 60).toFixed(1).replace('.', ',');
                $('#sakr-tl-save-btn').text('Eintragen (' + h + ' h)');
            }
        }
    });

})(jQuery);
