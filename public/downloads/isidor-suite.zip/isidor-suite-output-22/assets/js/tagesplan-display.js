/**
 * Isidor Tagesplan – Display Controller
 * Für die digitale Vollbild-Anzeige (Sakristei, Orgel, etc.)
 */
(function($) {
    'use strict';

    // Auto-reload bei Datum-Wechsel (Mitternacht)
    function scheduleNextDayReload() {
        var now = new Date();
        var tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 1, 0);
        var ms = tomorrow - now;

        setTimeout(function() {
            window.location.reload();
        }, ms);
    }

    $(function() {
        scheduleNextDayReload();
    });

})(jQuery);
