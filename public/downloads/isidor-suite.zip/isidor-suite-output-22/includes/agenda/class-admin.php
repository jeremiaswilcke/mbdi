<?php
class Isidor_Agenda_Admin {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }
    
    public function enqueue_scripts($hook) {
        // Nur auf Agenda-Admin-Seiten laden
        if (strpos($hook, 'isidor-agenda') === false && strpos($hook, 'agenda') === false) {
            return;
        }
        
        wp_enqueue_script(
            'isidor-agenda-admin',
            ISIDOR_SUITE_URL . 'assets/js/agenda-admin.js',
            ['jquery'],
            ISIDOR_SUITE_VERSION,
            true
        );
        
        wp_localize_script('isidor-agenda-admin', 'agendaData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('agenda_nonce'),
        ]);
        
        wp_enqueue_style(
            'isidor-agenda-admin',
            ISIDOR_SUITE_URL . 'assets/css/agenda-admin.css',
            [],
            ISIDOR_SUITE_VERSION
        );
    }
    
    public function add_menu() {
        add_menu_page(
            'Agenda',
            'Agenda',
            'agenda_request_room',
            'isidor-agenda',
            [$this, 'render_dashboard'],
            'dashicons-calendar-alt',
            26
        );
        
        add_submenu_page(
            'isidor-agenda',
            'Räume',
            'Räume',
            'agenda_manage_rooms',
            'isidor-agenda-rooms',
            [$this, 'render_rooms']
        );
    }
    
    public function render_dashboard() {
        $tab = $_GET['tab'] ?? 'calendar';
        include ISIDOR_SUITE_PATH . 'templates/agenda/admin-dashboard.php';
    }
    
    public function render_rooms() {
        $rooms = Isidor_Agenda_Rooms::get_all(false);
        include ISIDOR_SUITE_PATH . 'templates/agenda/admin-rooms.php';
    }
}
