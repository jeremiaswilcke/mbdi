<?php
class Isidor_Agenda_API {
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }
    
    public function register_routes() {
        register_rest_route('isidor/v1', '/agenda/slots', [
            'methods' => 'GET',
            'callback' => [$this, 'get_slots'],
            'permission_callback' => '__return_true'
        ]);
        
        register_rest_route('isidor/v1', '/agenda/rooms', [
            'methods' => 'GET',
            'callback' => [$this, 'get_rooms'],
            'permission_callback' => '__return_true'
        ]);
    }
    
    public function get_slots($request) {
        $from = $request['from'] ?? date('Y-m-d');
        $to = $request['to'] ?? date('Y-m-d', strtotime('+30 days'));
        
        return Isidor_Agenda_Slots::get_for_period($from, $to);
    }
    
    public function get_rooms() {
        return Isidor_Agenda_Rooms::get_all();
    }
}
