<?php
class Isidor_Agenda_Approvals {
    public function __construct() {
        add_action('wp_ajax_agenda_approve_slot', [$this, 'ajax_approve']);
        add_action('wp_ajax_agenda_reject_slot', [$this, 'ajax_reject']);
    }
    
    public function ajax_approve() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_approve_booking')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $slot_id = intval($_POST['slot_id']);
        
        if (Isidor_Agenda_Slots::approve($slot_id)) {
            wp_send_json_success(['message' => 'Genehmigt!']);
        } else {
            wp_send_json_error(['message' => 'Fehler']);
        }
    }
    
    public function ajax_reject() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_approve_booking')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_slots',
            ['status' => 'rejected', 'updated_at' => current_time('mysql')],
            ['id' => intval($_POST['slot_id'])]
        );
        
        wp_send_json_success(['message' => 'Abgelehnt!']);
    }
}
