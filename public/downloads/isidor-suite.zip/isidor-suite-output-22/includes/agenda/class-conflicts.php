<?php
class Isidor_Agenda_Conflicts {
    public function daily_check() {
        // Prüfe Konflikte für nächste 7 Tage
        // Sende Notifications
    }
    
    public static function detect($date, $room_id = null) {
        global $wpdb;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots 
                WHERE date = %s AND status IN ('pending', 'approved')";
        
        $params = [$date];
        
        if ($room_id) {
            $sql .= " AND room_id = %d";
            $params[] = $room_id;
        }
        
        $sql .= " ORDER BY room_id, start_time";
        
        $slots = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        $conflicts = [];
        $by_room = [];
        
        foreach ($slots as $slot) {
            $room = $slot['room_id'];
            if (!isset($by_room[$room])) {
                $by_room[$room] = [];
            }
            $by_room[$room][] = $slot;
        }
        
        foreach ($by_room as $room_id => $room_slots) {
            for ($i = 0; $i < count($room_slots) - 1; $i++) {
                for ($j = $i + 1; $j < count($room_slots); $j++) {
                    $a = $room_slots[$i];
                    $b = $room_slots[$j];
                    
                    if ($a['end_time'] > $b['start_time']) {
                        $conflicts[] = [$a['id'], $b['id']];
                    }
                }
            }
        }
        
        return $conflicts;
    }
}
