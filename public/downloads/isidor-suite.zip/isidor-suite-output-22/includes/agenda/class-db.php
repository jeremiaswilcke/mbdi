<?php
/**
 * Isidor Agenda - Database
 */
class Isidor_Agenda_DB {
    
    public static function activate() {
        try {
            // Check if WordPress is loaded
            if (!function_exists('add_option')) {
                error_log('Isidor Agenda: WordPress not fully loaded during activation');
                return;
            }
            
            global $wpdb;
            
            if (!$wpdb) {
                error_log('Isidor Agenda: $wpdb not available');
                return;
            }
            
            $charset = $wpdb->get_charset_collate();
            
            if (!file_exists(ABSPATH . 'wp-admin/includes/upgrade.php')) {
                error_log('Isidor Agenda: upgrade.php not found');
                return;
            }
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Räume
        $sql1 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_rooms (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            location VARCHAR(200),
            capacity INT UNSIGNED,
            requires_approval TINYINT(1) DEFAULT 1,
            allowed_roles TEXT,
            notes TEXT,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NOT NULL,
            KEY active (active)
        ) $charset;";
        
        // Buchungen/Slots (nur Raumbuchungen, KEIN Plakat-Flag)
        $sql2 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_slots (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED,
            date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            room_id INT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            requested_by BIGINT UNSIGNED NOT NULL,
            approved_by BIGINT UNSIGNED,
            conflict_group_id INT UNSIGNED,
            comment TEXT,
            created_at DATETIME NOT NULL,
            updated_at DATETIME,
            KEY messe_id (messe_id),
            KEY room_date (room_id, date),
            KEY status (status),
            KEY conflict_group (conflict_group_id)
        ) $charset;";
        
        // Veranstaltungen (normale Events MIT Plakat-Flag + Raum)
        $sql3 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_events (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(300) NOT NULL,
            description TEXT,
            date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            room_id INT UNSIGNED,
            slot_id INT UNSIGNED,
            is_announcement_ready TINYINT(1) DEFAULT 0,
            meta1 VARCHAR(200),
            meta2 VARCHAR(200),
            speaker VARCHAR(200),
            speaker_title VARCHAR(200),
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME,
            status VARCHAR(20) DEFAULT 'draft',
            KEY date (date),
            KEY room (room_id),
            KEY slot (slot_id),
            KEY announcement (is_announcement_ready),
            KEY status (status)
        ) $charset;";
        
        // Messen-Meta Templates
        $sql4 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_mass_meta_templates (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED NOT NULL UNIQUE,
            title_override VARCHAR(300),
            meta1 VARCHAR(200),
            meta2 VARCHAR(200),
            description TEXT,
            speaker VARCHAR(200),
            speaker_title VARCHAR(200),
            default_room_id INT UNSIGNED,
            created_at DATETIME NOT NULL,
            updated_at DATETIME,
            KEY messe_id (messe_id)
        ) $charset;";
        
        // Slot-Meta Overrides
        $sql5 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_mass_meta_overrides (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            slot_id INT UNSIGNED NOT NULL UNIQUE,
            title_override VARCHAR(300),
            meta1 VARCHAR(200),
            meta2 VARCHAR(200),
            description TEXT,
            speaker VARCHAR(200),
            speaker_title VARCHAR(200),
            KEY slot_id (slot_id)
        ) $charset;";
        
        // Core-Meta Changelog
        $sql6 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_core_meta_log (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            meta_key VARCHAR(50) NOT NULL,
            old_value TEXT,
            new_value TEXT,
            created_at DATETIME NOT NULL,
            KEY messe_id (messe_id),
            KEY meta_key (meta_key),
            KEY created_at (created_at)
        ) $charset;";
        
        // Serien-Veranstaltungen (MIT Plakat-Flag)
        $sql7 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_series (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(300) NOT NULL,
            description TEXT,
            recurrence_pattern VARCHAR(50) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            room_id INT UNSIGNED,
            is_announcement_ready TINYINT(1) DEFAULT 0,
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            active TINYINT(1) DEFAULT 1,
            KEY recurrence (recurrence_pattern),
            KEY dates (start_date, end_date),
            KEY announcement (is_announcement_ready)
        ) $charset;";
        
        // Serien-Instanzen
        $sql8 = "CREATE TABLE {$wpdb->prefix}isidor_agenda_series_instances (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            series_id INT UNSIGNED NOT NULL,
            date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            room_id INT UNSIGNED,
            status VARCHAR(20) DEFAULT 'active',
            is_cancelled TINYINT(1) DEFAULT 0,
            cancellation_reason TEXT,
            KEY series_id (series_id),
            KEY date (date),
            KEY status (status)
        ) $charset;";
        
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
        dbDelta($sql5);
        dbDelta($sql6);
        dbDelta($sql7);
        dbDelta($sql8);
        
        // Rollen & Capabilities
        self::add_roles_and_caps();
        
        // CPT registrieren
        self::register_cpt();
        
        // Flush rewrite rules (only if function exists)
        if (function_exists('flush_rewrite_rules')) {
            flush_rewrite_rules();
        }
        
        error_log('Isidor Agenda: Activation completed successfully');
        
        } catch (Exception $e) {
            error_log('Isidor Agenda Activation Error: ' . $e->getMessage());
            wp_die('Isidor Agenda Aktivierungsfehler: ' . $e->getMessage() . ' in ' . $e->getFile() . ' on line ' . $e->getLine());
        }
    }
    
    private static function add_roles_and_caps() {
        $admin = get_role('administrator');
        $caps = [
            'agenda_manage_rooms',
            'agenda_request_room',
            'agenda_approve_booking',
            'agenda_edit_meta',
            'agenda_write_core_meta',
            'agenda_export',
            'agenda_create_event'
        ];
        
        foreach ($caps as $cap) {
            if ($admin) {
                $admin->add_cap($cap);
            }
        }
        
        // Pfarrer
        $pfarrer = get_role('isidor_pfarrer');
        if ($pfarrer) {
            $pfarrer->add_cap('agenda_manage_rooms');
            $pfarrer->add_cap('agenda_approve_booking');
            $pfarrer->add_cap('agenda_edit_meta');
            $pfarrer->add_cap('agenda_write_core_meta');
            $pfarrer->add_cap('agenda_export');
            $pfarrer->add_cap('agenda_create_event');
        }
        
        // Sekretär
        $sek = get_role('isidor_sekretaer');
        if ($sek) {
            $sek->add_cap('agenda_manage_rooms');
            $sek->add_cap('agenda_request_room');
            $sek->add_cap('agenda_approve_booking');
            $sek->add_cap('agenda_edit_meta');
            $sek->add_cap('agenda_export');
            $sek->add_cap('agenda_create_event');
        }
        
        // Alle können Räume anfragen
        $roles = ['editor', 'isidor_diakon', 'isidor_lektor', 'isidor_kommunion', 
                  'isidor_ministrant', 'isidor_orgel', 'isidor_technik'];
        
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('agenda_request_room');
            }
        }
    }
    
    public static function register_cpt() {
        // Keine eigenen CPTs mehr - Events sind in DB-Tabelle
    }
    
    public static function deactivate() {
        // Cron entfernen
        wp_clear_scheduled_hook('agenda_daily_conflict_check');
    }
}
