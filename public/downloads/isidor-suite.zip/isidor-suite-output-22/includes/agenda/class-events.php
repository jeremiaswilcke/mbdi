<?php
/**
 * Isidor Agenda - Events (Veranstaltungen mit Plakat-Flag)
 */
class Isidor_Agenda_Events {
    
    /** Veranstaltungstypen */
    public const TYPES = [
        'fest' => ['label' => 'Fest', 'icon' => '🎉'],
        'vortrag' => ['label' => 'Vortrag', 'icon' => '🎤'],
        'messe' => ['label' => 'Hl. Messe', 'icon' => '⛪'],
        'ausflug' => ['label' => 'Ausflug', 'icon' => '🚌'],
        'sonstiges' => ['label' => 'Sonstiges', 'icon' => '📝'],
    ];
    
    public function __construct() {
        add_action('wp_ajax_agenda_create_event', [$this, 'ajax_create_event']);
        add_action('wp_ajax_agenda_toggle_event_announcement', [$this, 'ajax_toggle_announcement']);
    }
    
    /**
     * Event erstellen (mit automatischer Raumbuchung)
     */
    public static function create($data) {
        global $wpdb;
        
        // Zuerst Raum buchen (wenn angegeben)
        $slot_id = null;
        if (!empty($data['room_id'])) {
            $slot_data = [
                'messe_id' => $data['messe_id'] ?? null,
                'date' => $data['date'],
                'start_time' => $data['start_time'],
                'end_time' => $data['end_time'],
                'room_id' => $data['room_id'],
                'comment' => 'Automatisch für Event: ' . ($data['title'] ?? 'Veranstaltung')
            ];
            
            $slot_id = Isidor_Agenda_Slots::create($slot_data);
            
            if (is_wp_error($slot_id)) {
                return $slot_id; // Fehler: Raum nicht verfügbar
            }
        }
        
        // Event erstellen - Status abhängig von Raum-Genehmigung
        $event_status = 'pending'; // Warte auf Raum-Genehmigung
        
        $wpdb->insert($wpdb->prefix . 'isidor_agenda_events', [
            'title' => sanitize_text_field($data['title'] ?? ''),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'date' => $data['date'],
            'start_time' => $data['start_time'],
            'end_time' => $data['end_time'],
            'room_id' => $data['room_id'] ?? null,
            'slot_id' => $slot_id,
            'is_announcement_ready' => !empty($data['is_public']) ? 1 : 0,
            'meta1' => sanitize_text_field($data['event_type'] ?? ''), // Veranstaltungstyp
            'meta2' => sanitize_text_field($data['subtitle'] ?? ''),   // Untertitel
            'speaker' => sanitize_text_field($data['speaker'] ?? ''),
            'speaker_title' => sanitize_text_field($data['custom_type'] ?? ''), // Bei Sonstiges: Freitext-Typ
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
            'status' => $event_status
        ]);
        
        $event_id = $wpdb->insert_id;
        
        do_action('isidor_agenda_event_created', $event_id, $data);
        
        return $event_id;
    }
    
    /**
     * Event genehmigen (wenn Slot genehmigt wurde)
     */
    public static function approve($event_id) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_events',
            ['status' => 'approved'],
            ['id' => $event_id]
        );
    }
    
    /**
     * Plakat-Flag togglen
     */
    public static function toggle_announcement($event_id, $ready = true) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_events',
            ['is_announcement_ready' => $ready ? 1 : 0],
            ['id' => $event_id]
        );
    }
    
    /**
     * Events für Zeitraum
     */
    public static function get_for_period($from, $to, $announcement_ready_only = false) {
        global $wpdb;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_agenda_events 
                WHERE date BETWEEN %s AND %s";
        
        $params = [$from, $to];
        
        if ($announcement_ready_only) {
            $sql .= " AND is_announcement_ready = 1";
        }
        
        $sql .= " ORDER BY date, start_time";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    }
    
    /**
     * Öffentliche Events für Plakat-Generator
     * Holt alle Events mit is_announcement_ready = 1
     */
    public static function get_public_events($limit = 50) {
        global $wpdb;
        
        $sql = "SELECT e.*, r.name as room_name 
                FROM {$wpdb->prefix}isidor_agenda_events e
                LEFT JOIN {$wpdb->prefix}isidor_agenda_rooms r ON e.room_id = r.id
                WHERE e.is_announcement_ready = 1 
                AND e.date >= CURDATE()
                AND e.status != 'cancelled'
                ORDER BY e.date, e.start_time
                LIMIT %d";
        
        $events = $wpdb->get_results($wpdb->prepare($sql, $limit), ARRAY_A);
        
        // Typ-Labels hinzufügen
        foreach ($events as &$event) {
            $type_key = $event['meta1'] ?? 'sonstiges';
            $event['type_label'] = self::TYPES[$type_key]['label'] ?? 'Sonstiges';
            $event['type_icon'] = self::TYPES[$type_key]['icon'] ?? '📝';
            $event['subtitle'] = $event['meta2'] ?? '';
            $event['custom_type'] = $event['speaker_title'] ?? '';
        }
        
        return $events;
    }
    
    /**
     * Einzelnes Event abrufen
     */
    public static function get($event_id) {
        global $wpdb;
        
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT e.*, r.name as room_name 
             FROM {$wpdb->prefix}isidor_agenda_events e
             LEFT JOIN {$wpdb->prefix}isidor_agenda_rooms r ON e.room_id = r.id
             WHERE e.id = %d",
            $event_id
        ), ARRAY_A);
        
        if ($event) {
            $type_key = $event['meta1'] ?? 'sonstiges';
            $event['type_label'] = self::TYPES[$type_key]['label'] ?? 'Sonstiges';
            $event['type_icon'] = self::TYPES[$type_key]['icon'] ?? '📝';
            $event['subtitle'] = $event['meta2'] ?? '';
            $event['custom_type'] = $event['speaker_title'] ?? '';
        }
        
        return $event;
    }
    
    /**
     * AJAX: Event erstellen
     */
    public function ajax_create_event() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        $event_id = self::create($_POST);
        
        if (is_wp_error($event_id)) {
            wp_send_json_error(['message' => $event_id->get_error_message()]);
        }
        
        wp_send_json_success([
            'message' => 'Veranstaltung erstellt!',
            'event_id' => $event_id
        ]);
    }
    
    /**
     * AJAX: Plakat-Toggle
     */
    public function ajax_toggle_announcement() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_edit_meta')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $event_id = intval($_POST['event_id']);
        $ready = !empty($_POST['ready']);
        
        if (self::toggle_announcement($event_id, $ready)) {
            wp_send_json_success([
                'message' => $ready ? 'Plakat-Flag aktiviert' : 'Plakat-Flag deaktiviert'
            ]);
        } else {
            wp_send_json_error(['message' => 'Fehler']);
        }
    }
}
