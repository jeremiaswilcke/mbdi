<?php
class Isidor_Agenda_Exports {
    public function __construct() {
        add_action('init', [$this, 'handle_export']);
        
        // Admin-Post Handler
        add_action('admin_post_agenda_export_pdf', [$this, 'handle_pdf_export']);
        add_action('admin_post_agenda_export_csv', [$this, 'handle_csv_export']);
        add_action('admin_post_agenda_export_json', [$this, 'handle_json_export']);
        add_action('admin_post_agenda_export_ical', [$this, 'handle_ical_export']);
    }
    
    public function handle_pdf_export() {
        check_admin_referer('agenda_export', 'export_nonce');
        
        if (!current_user_can('agenda_export')) {
            wp_die('Keine Berechtigung');
        }
        
        $from = sanitize_text_field($_POST['from_date'] ?? date('Y-m-d'));
        $to = sanitize_text_field($_POST['to_date'] ?? date('Y-m-d', strtotime('+30 days')));
        $type = sanitize_text_field($_POST['export_type'] ?? 'all');
        
        $this->export_pdf($from, $to, $type);
    }
    
    public function handle_csv_export() {
        check_admin_referer('agenda_export', 'export_nonce');
        
        if (!current_user_can('agenda_export')) {
            wp_die('Keine Berechtigung');
        }
        
        $from = sanitize_text_field($_POST['from_date'] ?? date('Y-m-d'));
        $to = sanitize_text_field($_POST['to_date'] ?? date('Y-m-d', strtotime('+30 days')));
        $type = sanitize_text_field($_POST['export_type'] ?? 'all');
        $delimiter = $_POST['delimiter'] ?? ',';
        
        $this->export_csv($from, $to, $type, $delimiter);
    }
    
    public function handle_json_export() {
        check_admin_referer('agenda_export', 'export_nonce');
        
        if (!current_user_can('agenda_export')) {
            wp_die('Keine Berechtigung');
        }
        
        $from = sanitize_text_field($_POST['from_date'] ?? date('Y-m-d'));
        $to = sanitize_text_field($_POST['to_date'] ?? date('Y-m-d', strtotime('+30 days')));
        $type = sanitize_text_field($_POST['export_type'] ?? 'all');
        $pretty = !empty($_POST['pretty']);
        
        $this->export_json($from, $to, $type, $pretty);
    }
    
    public function handle_ical_export() {
        check_admin_referer('agenda_export', 'export_nonce');
        
        if (!current_user_can('agenda_export')) {
            wp_die('Keine Berechtigung');
        }
        
        $from = sanitize_text_field($_POST['from_date'] ?? date('Y-m-d'));
        $to = sanitize_text_field($_POST['to_date'] ?? date('Y-m-d', strtotime('+90 days')));
        $type = sanitize_text_field($_POST['export_type'] ?? 'all');
        
        $this->export_ical($from, $to, $type);
    }
    
    public function handle_export() {
        if (!isset($_GET['agenda_export'])) return;
        
        if (!current_user_can('agenda_export')) {
            wp_die('Keine Berechtigung');
        }
        
        $type = $_GET['agenda_export'];
        $from = $_GET['from'] ?? date('Y-m-d');
        $to = $_GET['to'] ?? date('Y-m-d', strtotime('+30 days'));
        
        if ($type === 'pdf') {
            $this->export_pdf($from, $to);
        } elseif ($type === 'csv') {
            $this->export_csv($from, $to);
        } elseif ($type === 'json') {
            $this->export_json($from, $to);
        }
    }
    
    private function export_csv($from, $to, $type = 'all', $delimiter = ',') {
        $slots = Isidor_Agenda_Slots::get_for_period($from, $to);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="agenda_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Datum', 'Start', 'Ende', 'Raum', 'Status', 'Angefragt von'], $delimiter);
        
        foreach ($slots as $slot) {
            $room = Isidor_Agenda_Rooms::get($slot['room_id']);
            $user = get_userdata($slot['requested_by']);
            
            fputcsv($output, [
                $slot['date'],
                $slot['start_time'],
                $slot['end_time'],
                $room['name'] ?? '',
                $slot['status'],
                $user->display_name ?? ''
            ], $delimiter);
        }
        
        fclose($output);
        exit;
    }
    
    private function export_json($from, $to, $type = 'all', $pretty = true) {
        $slots = Isidor_Agenda_Slots::get_for_period($from, $to);
        
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="agenda_' . date('Y-m-d') . '.json"');
        
        $flags = JSON_UNESCAPED_UNICODE;
        if ($pretty) {
            $flags |= JSON_PRETTY_PRINT;
        }
        
        echo json_encode($slots, $flags);
        exit;
    }
    
    private function export_pdf($from, $to, $type = 'all') {
        // Check if FPDF exists
        if (!file_exists(ISIDOR_AGENDA_PATH . 'lib/fpdf/fpdf.php')) {
            wp_die('FPDF fehlt! Bitte von https://www.fpdf.org herunterladen und in /lib/fpdf/ ablegen.');
        }
        
        require_once ISIDOR_AGENDA_PATH . 'lib/fpdf/fpdf.php';
        
        $slots = Isidor_Agenda_Slots::get_for_period($from, $to);
        $instances = Isidor_Agenda_Series::get_instances($from, $to);
        
        $pdf = new FPDF('L', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        
        $pdf->Cell(0, 10, 'Agenda: ' . date('d.m.Y', strtotime($from)) . ' - ' . date('d.m.Y', strtotime($to)), 0, 1, 'C');
        $pdf->Ln(5);
        
        // Einzelbuchungen
        if (!empty($slots)) {
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, 'Einzelbuchungen', 0, 1);
            $pdf->SetFont('Arial', 'B', 9);
            
            $pdf->Cell(30, 7, 'Datum', 1);
            $pdf->Cell(25, 7, 'Zeit', 1);
            $pdf->Cell(50, 7, 'Raum', 1);
            $pdf->Cell(40, 7, 'Status', 1);
            $pdf->Cell(60, 7, 'Angefragt von', 1);
            $pdf->Ln();
            
            $pdf->SetFont('Arial', '', 8);
            
            foreach ($slots as $slot) {
                $room = Isidor_Agenda_Rooms::get($slot['room_id']);
                $user = get_userdata($slot['requested_by']);
                
                $pdf->Cell(30, 6, date('d.m.Y', strtotime($slot['date'])), 1);
                $pdf->Cell(25, 6, substr($slot['start_time'], 0, 5) . '-' . substr($slot['end_time'], 0, 5), 1);
                $pdf->Cell(50, 6, substr($room['name'] ?? '', 0, 30), 1);
                $pdf->Cell(40, 6, $slot['status'], 1);
                $pdf->Cell(60, 6, substr($user->display_name ?? '', 0, 40), 1);
                $pdf->Ln();
            }
            
            $pdf->Ln(5);
        }
        
        // Serienveranstaltungen
        if (!empty($instances)) {
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, 'Serienveranstaltungen', 0, 1);
            $pdf->SetFont('Arial', 'B', 9);
            
            $pdf->Cell(30, 7, 'Datum', 1);
            $pdf->Cell(25, 7, 'Zeit', 1);
            $pdf->Cell(70, 7, 'Serie', 1);
            $pdf->Cell(50, 7, 'Raum', 1);
            $pdf->Cell(20, 7, 'Plakat', 1);
            $pdf->Ln();
            
            $pdf->SetFont('Arial', '', 8);
            
            foreach ($instances as $inst) {
                $room = $inst['room_id'] ? Isidor_Agenda_Rooms::get($inst['room_id']) : null;
                
                $pdf->Cell(30, 6, date('d.m.Y', strtotime($inst['date'])), 1);
                $pdf->Cell(25, 6, substr($inst['start_time'], 0, 5) . '-' . substr($inst['end_time'], 0, 5), 1);
                $pdf->Cell(70, 6, substr($inst['series_title'], 0, 40), 1);
                $pdf->Cell(50, 6, substr($room['name'] ?? '-', 0, 30), 1);
                $pdf->Cell(20, 6, $inst['is_announcement_ready'] ? 'JA' : 'NEIN', 1, 0, 'C');
                $pdf->Ln();
            }
        }
        
        $pdf->Output('D', 'agenda_' . date('Y-m-d') . '.pdf');
        exit;
    }
    
    private function export_ical($from, $to, $type = 'all') {
        // Get events
        $events = [];
        
        if ($type === 'all' || $type === 'events') {
            $agenda_events = Isidor_Agenda_Events::get_for_period($from, $to);
            foreach ($agenda_events as $event) {
                $events[] = [
                    'title' => $event['title'],
                    'description' => $event['description'] ?? '',
                    'date' => $event['date'],
                    'start' => $event['start_time'],
                    'end' => $event['end_time'],
                ];
            }
        }
        
        if ($type === 'all' || $type === 'series') {
            $series_instances = Isidor_Agenda_Series::get_instances($from, $to);
            foreach ($series_instances as $inst) {
                $events[] = [
                    'title' => $inst['series_title'],
                    'description' => $inst['series_description'] ?? '',
                    'date' => $inst['date'],
                    'start' => $inst['start_time'],
                    'end' => $inst['end_time'],
                ];
            }
        }
        
        // Generate iCal
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="agenda_' . date('Y-m-d') . '.ics"');
        
        echo "BEGIN:VCALENDAR\r\n";
        echo "VERSION:2.0\r\n";
        echo "PRODID:-//Isidor Agenda//NONSGML v1.0//DE\r\n";
        echo "CALSCALE:GREGORIAN\r\n";
        echo "METHOD:PUBLISH\r\n";
        echo "X-WR-CALNAME:Isidor Agenda\r\n";
        echo "X-WR-TIMEZONE:Europe/Vienna\r\n";
        
        foreach ($events as $event) {
            $uid = md5($event['title'] . $event['date'] . $event['start']);
            $dtstart = date('Ymd\THis', strtotime($event['date'] . ' ' . $event['start']));
            $dtend = date('Ymd\THis', strtotime($event['date'] . ' ' . $event['end']));
            $dtstamp = date('Ymd\THis');
            
            echo "BEGIN:VEVENT\r\n";
            echo "UID:" . $uid . "@isidor-agenda\r\n";
            echo "DTSTAMP:" . $dtstamp . "\r\n";
            echo "DTSTART:" . $dtstart . "\r\n";
            echo "DTEND:" . $dtend . "\r\n";
            echo "SUMMARY:" . $this->escape_ical($event['title']) . "\r\n";
            
            if (!empty($event['description'])) {
                echo "DESCRIPTION:" . $this->escape_ical($event['description']) . "\r\n";
            }
            
            echo "STATUS:CONFIRMED\r\n";
            echo "END:VEVENT\r\n";
        }
        
        echo "END:VCALENDAR\r\n";
        exit;
    }
    
    private function escape_ical($string) {
        $string = str_replace(["\r\n", "\n", "\r"], '\n', $string);
        $string = str_replace(',', '\,', $string);
        $string = str_replace(';', '\;', $string);
        return $string;
    }
}
