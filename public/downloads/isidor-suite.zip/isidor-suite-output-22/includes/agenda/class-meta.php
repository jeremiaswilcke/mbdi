<?php
class Isidor_Agenda_Meta {
    
    public static function save_override($slot_id, $data) {
        global $wpdb;
        
        $wpdb->replace($wpdb->prefix . 'isidor_agenda_mass_meta_overrides', [
            'slot_id' => $slot_id,
            'title_override' => $data['title_override'] ?? null,
            'meta1' => $data['meta1'] ?? null,
            'meta2' => $data['meta2'] ?? null,
            'description' => $data['description'] ?? null,
            'speaker' => $data['speaker'] ?? null,
            'speaker_title' => $data['speaker_title'] ?? null
        ]);
    }
    
    public static function write_to_core($messe_id, $data) {
        if (!current_user_can('agenda_write_core_meta')) {
            return false;
        }
        
        $allowed_keys = ['_is_meta1', '_is_meta2', '_is_description', '_is_speaker', '_is_speaker_title', '_is_location_text'];
        
        foreach ($data as $key => $value) {
            if (!in_array($key, $allowed_keys)) continue;
            
            $old_value = get_post_meta($messe_id, $key, true);
            
            update_post_meta($messe_id, $key, $value);
            
            // Log
            global $wpdb;
            $wpdb->insert($wpdb->prefix . 'isidor_agenda_core_meta_log', [
                'messe_id' => $messe_id,
                'user_id' => get_current_user_id(),
                'meta_key' => $key,
                'old_value' => $old_value,
                'new_value' => $value,
                'created_at' => current_time('mysql')
            ]);
        }
        
        do_action('isidor_agenda_core_meta_written', $messe_id, $data);
        
        return true;
    }
}
