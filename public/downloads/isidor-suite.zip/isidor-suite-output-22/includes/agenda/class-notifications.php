<?php
class Isidor_Agenda_Notifications {
    public static function send_new_request($slot_id) {
        $admins = get_users(['role__in' => ['administrator', 'isidor_pfarrer', 'isidor_sekretaer']]);
        
        foreach ($admins as $admin) {
            wp_mail(
                $admin->user_email,
                'Neue Raumbuchungsanfrage',
                "Eine neue Raumbuchung wartet auf Genehmigung.\n\nBitte prüfen: " . admin_url('admin.php?page=isidor-agenda&tab=requests')
            );
        }
    }
    
    public static function send_approval($slot_id) {
        global $wpdb;
        $slot = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE id = %d",
            $slot_id
        ), ARRAY_A);
        
        $user = get_userdata($slot['requested_by']);
        
        wp_mail(
            $user->user_email,
            'Raumbuchung genehmigt',
            "Ihre Raumbuchung wurde genehmigt."
        );
    }
}
