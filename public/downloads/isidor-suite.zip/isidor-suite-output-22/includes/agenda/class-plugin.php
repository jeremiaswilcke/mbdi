<?php
/**
 * Isidor Agenda - Main Plugin Class
 */
class Isidor_Agenda_Plugin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
        $this->init_components();
    }
    
    private function load_dependencies() {
        require_once ISIDOR_AGENDA_PATH . 'class-db.php';
        require_once ISIDOR_AGENDA_PATH . 'class-rooms.php';
        require_once ISIDOR_AGENDA_PATH . 'class-slots.php';
        require_once ISIDOR_AGENDA_PATH . 'class-events.php';
        require_once ISIDOR_AGENDA_PATH . 'class-series.php';
        require_once ISIDOR_AGENDA_PATH . 'class-meta.php';
        require_once ISIDOR_AGENDA_PATH . 'class-conflicts.php';
        require_once ISIDOR_AGENDA_PATH . 'class-approvals.php';
        require_once ISIDOR_AGENDA_PATH . 'class-notifications.php';
        require_once ISIDOR_AGENDA_PATH . 'class-exports.php';
        require_once ISIDOR_AGENDA_PATH . 'class-admin.php';
        require_once ISIDOR_AGENDA_PATH . 'class-shortcodes.php';
        require_once ISIDOR_AGENDA_PATH . 'class-api.php';
    }
    
    private function init_hooks() {
        add_action('init', [$this, 'register_cpt']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        
        // Query-Vars für Kalender-Navigation registrieren
        add_filter('query_vars', [$this, 'register_query_vars']);
        
        // Core Integration
        add_action('save_post_isidor_messe', [$this, 'on_messe_save'], 10, 2);
        add_action('before_delete_post', [$this, 'on_messe_delete']);
        
        // Cron
        if (!wp_next_scheduled('agenda_daily_conflict_check')) {
            wp_schedule_event(strtotime('today 08:00'), 'daily', 'agenda_daily_conflict_check');
        }
        add_action('agenda_daily_conflict_check', [new Isidor_Agenda_Conflicts(), 'daily_check']);
    }
    
    /**
     * Kalender-Query-Vars bei WordPress registrieren
     */
    public function register_query_vars(array $vars): array {
        $vars[] = 'cal_month';
        $vars[] = 'cal_day';
        return $vars;
    }
    
    private function init_components() {
        if (is_admin()) {
            new Isidor_Agenda_Admin();
        }
        
        new Isidor_Agenda_Rooms();
        new Isidor_Agenda_Slots();
        new Isidor_Agenda_Events();
        new Isidor_Agenda_Series();
        new Isidor_Agenda_Approvals();
        new Isidor_Agenda_Shortcodes();
        new Isidor_Agenda_API();
        new Isidor_Agenda_Exports();
    }
    
    public function register_cpt() {
        Isidor_Agenda_DB::register_cpt();
    }
    
    public function admin_assets($hook) {
        if (strpos($hook, 'isidor-agenda') === false) {
            return;
        }
        
        wp_enqueue_style('agenda-admin', ISIDOR_SUITE_URL . 'assets/css/agenda-admin.css', [], ISIDOR_AGENDA_VERSION);
        wp_enqueue_script('agenda-admin', ISIDOR_SUITE_URL . 'assets/js/agenda-admin.js', ['jquery'], ISIDOR_AGENDA_VERSION, true);
        
        wp_localize_script('agenda-admin', 'agendaData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('agenda_nonce'),
            'restUrl' => rest_url('isidor/v1/')
        ]);
    }
    
    public function frontend_assets() {
        if (!is_singular() && !has_shortcode(get_post()->post_content ?? '', 'isidor_agenda')) {
            return;
        }
        
        wp_enqueue_style('agenda-frontend', ISIDOR_SUITE_URL . 'assets/css/agenda-frontend.css', [], ISIDOR_AGENDA_VERSION);
        wp_enqueue_script('agenda-frontend', ISIDOR_SUITE_URL . 'assets/js/agenda-frontend.js', ['jquery'], ISIDOR_AGENDA_VERSION, true);
        
        wp_localize_script('agenda-frontend', 'agendaData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('agenda_nonce')
        ]);
    }
    
    public function on_messe_save($post_id, $post) {
        // Hook für andere Module
        do_action('isidor_agenda_messe_updated', $post_id, $post);
    }
    
    public function on_messe_delete($post_id) {
        if (get_post_type($post_id) !== 'isidor_messe') {
            return;
        }
        
        global $wpdb;
        
        // Slots löschen
        $wpdb->delete($wpdb->prefix . 'isidor_agenda_slots', ['messe_id' => $post_id]);
        
        // Meta-Templates löschen
        $wpdb->delete($wpdb->prefix . 'isidor_agenda_mass_meta_templates', ['messe_id' => $post_id]);
        
        do_action('isidor_agenda_messe_deleted', $post_id);
    }
    
    public static function deactivate() {
        Isidor_Agenda_DB::deactivate();
    }
}
