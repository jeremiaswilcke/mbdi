<?php
/**
 * Class Isidor_Poster_Tool
 * Handles logic for the poster generation tool (Fabric.js integration).
 */
class Isidor_Poster_Tool {

    private static $instance;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        // 1. Shortcode registrieren [isidor_poster]
        add_shortcode( 'isidor_poster', array( $this, 'render_shortcode' ) );
        
        // 2. Meta Box (Button) im Event-Editor registrieren
        add_action( 'add_meta_boxes', array( $this, 'add_poster_meta_box' ) );
        
        // 3. AJAX Handler für E-Mail-Versand
        add_action( 'wp_ajax_isidor_poster_send_email', array( $this, 'ajax_send_email' ) );
    }

    /**
     * --- META BOX LOGIK ---
     */
    public function add_poster_meta_box() {
        // Für Events (Agenda)
        add_meta_box(
            'isidor_poster_box',
            'Plakat Generator',
            array( $this, 'render_poster_meta_box_content' ),
            'isidor_event',
            'side',
            'default'
        );
        
        // Für Messen (Core)
        add_meta_box(
            'isidor_poster_box_messe',
            '🖼️ Plakat erstellen',
            array( $this, 'render_poster_meta_box_messe' ),
            'isidor_messe',
            'side',
            'default'
        );
    }

    public function render_poster_meta_box_content( $post ) {
        if ( $post->post_status === 'auto-draft' || empty($post->ID) ) {
            echo '<p style="color:#888;">Bitte speichere das Event zuerst, um ein Plakat zu erstellen.</p>';
            return;
        }

        // WICHTIG: Ersetze 'plakat-generator' durch den Slug deiner WP-Seite, auf der der Shortcode liegt!
        $generator_url = home_url( '/plakat-generator/?event_id=' . $post->ID );

        echo '<div style="text-align:center; padding: 10px 0;">';
        echo '<a href="' . esc_url($generator_url) . '" target="_blank" class="button button-primary" style="width:100%; text-align:center;">';
        echo '<span class="dashicons dashicons-art" style="margin-top:4px; margin-right:5px;"></span> Plakat erstellen';
        echo '</a>';
        echo '</div>';
    }

    public function render_poster_meta_box_messe( $post ) {
        if ( $post->post_status === 'auto-draft' || empty($post->ID) ) {
            echo '<p style="color:#888;">Bitte speichere die Messe zuerst.</p>';
            return;
        }

        // Suche die Plakat-Generator Seite
        global $wpdb;
        $page_id = $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' AND post_status = 'publish' 
             AND post_content LIKE '%[isidor_poster%' LIMIT 1"
        );
        
        if ( $page_id ) {
            $generator_url = add_query_arg( 'messe_id', $post->ID, get_permalink($page_id) );
        } else {
            $generator_url = home_url( '/plakat-generator/?messe_id=' . $post->ID );
        }

        echo '<div style="text-align:center; padding: 10px 0;">';
        echo '<a href="' . esc_url($generator_url) . '" target="_blank" class="button button-primary" style="width:100%; text-align:center;">';
        echo '🖼️ Plakat erstellen';
        echo '</a>';
        echo '</div>';
    }

    /**
     * --- DATEN LOGIK ---
     */
    private function get_media_assets( $pattern ) {
        $args = array(
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => 20,
            's'              => $pattern, 
            'orderby'        => 'title',
            'order'          => 'ASC',
        );

        $query = new WP_Query( $args );
        $assets = array();

        foreach ( $query->posts as $post ) {
            $assets[] = array(
                'name' => $post->post_title,
                'url'  => wp_get_attachment_url( $post->ID )
            );
        }
        return $assets;
    }

    private function get_event_data( $event_id, $messe_id = 0 ) {
        // Standard-Werte (Standalone Modus)
        $data = array(
            'headline' => 'Titel der Veranstaltung',
            'subline'  => 'Datum & Uhrzeit',
            'location' => class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : get_bloginfo('name'),
            'content'  => 'Hier Beschreibungstext eingeben...'
        );
        
        // Messe-Daten (isidor_messe CPT)
        if ( $messe_id ) {
            $post = get_post( $messe_id );
            if ( $post && $post->post_type === 'isidor_messe' ) {
                $data['headline'] = $post->post_title;
                $d = get_post_meta( $messe_id, '_is_date', true );
                $t = get_post_meta( $messe_id, '_is_time', true );
                if ( $d ) {
                    $data['subline'] = date_i18n( 'l, d. F Y', strtotime($d) );
                    if ( $t ) $data['subline'] .= ', ' . $t . ' Uhr';
                }
                $liturgical = get_post_meta( $messe_id, '_is_liturgical', true );
                if ( $liturgical ) {
                    $data['content'] = $liturgical;
                }
                return $data;
            }
        }

        // Event-Daten (Agenda)
        if ( $event_id ) {
            $post = get_post( $event_id );
            if ( $post ) {
                $data['headline'] = $post->post_title;
                $start_date = get_post_meta( $event_id, '_isidor_start_date', true ); 
                $room_id    = get_post_meta( $event_id, '_isidor_room_id', true );
                
                if( $start_date ) {
                    $data['subline'] = date_i18n( 'd. F Y, H:i', strtotime($start_date) ) . ' Uhr';
                }
                if( $room_id ) {
                    $data['location'] = get_the_title( $room_id );
                }
            }
        }
        return $data;
    }

    /**
     * --- FRONTEND / SHORTCODE ---
     */
    public function render_shortcode( $atts ) {
        // Libs laden
        wp_enqueue_script( 'fabric-js', 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js', array(), '5.3.1', true );
        wp_enqueue_script( 'jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true );
        
        // Plugin Scripts – verwende ISIDOR_SUITE_URL
        wp_enqueue_script( 'isidor-poster-js', ISIDOR_SUITE_URL . 'assets/js/poster-generator.js', array('jquery', 'fabric-js', 'jspdf'), ISIDOR_SUITE_VERSION, true );
        wp_enqueue_style( 'isidor-poster-css', ISIDOR_SUITE_URL . 'assets/css/poster-generator.css', array(), ISIDOR_SUITE_VERSION );

        $event_id = isset( $_GET['event_id'] ) ? intval( $_GET['event_id'] ) : 0;
        $messe_id = isset( $_GET['messe_id'] ) ? intval( $_GET['messe_id'] ) : 0;
        
        // Parish-Daten für Poster
        $parish_data = [];
        $poster_emails = [];
        if (class_exists('Isidor_Parish_Settings')) {
            $parish_data = [
                'name' => Isidor_Parish_Settings::name(),
                'address' => Isidor_Parish_Settings::address_oneline(),
                'phone' => Isidor_Parish_Settings::get('phone'),
                'website' => Isidor_Parish_Settings::get('website'),
                'logo' => Isidor_Parish_Settings::get('logo_url'),
            ];
            // E-Mail Schnellwahl
            $emails_raw = Isidor_Parish_Settings::get('poster_emails', '');
            if ($emails_raw) {
                $emails_raw = str_replace(["\r\n", "\r", "\n"], ',', $emails_raw);
                $poster_emails = array_filter(array_map('trim', explode(',', $emails_raw)));
            }
        }
        
        // Öffentliche Veranstaltungen für Dropdown
        $public_events = [];
        if (class_exists('Isidor_Agenda_Events')) {
            $public_events = Isidor_Agenda_Events::get_public_events(30);
        }
        
        // Sondermessen für Dropdown
        $special_masses = [];
        $special_messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => 30,
            'meta_query' => [
                ['key' => '_is_special', 'value' => '1'],
                ['key' => '_is_date', 'value' => date('Y-m-d'), 'compare' => '>=', 'type' => 'DATE']
            ],
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC'
        ]);
        foreach ($special_messen as $m) {
            $special_masses[] = [
                'id' => $m->ID,
                'title' => $m->post_title,
                'date' => get_post_meta($m->ID, '_is_date', true),
                'time' => get_post_meta($m->ID, '_is_time', true),
                'liturgical' => get_post_meta($m->ID, '_is_liturgical', true),
            ];
        }

        wp_localize_script( 'isidor-poster-js', 'isidorData', array(
            'initial' => $this->get_event_data( $event_id, $messe_id ),
            'headers' => $this->get_media_assets( 'header_' ),
            'footers' => $this->get_media_assets( 'footer_' ),
            'parish'  => $parish_data,
            'events'  => $public_events,
            'special_masses' => $special_masses,
            'poster_emails' => $poster_emails,
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('isidor_poster_nonce'),
        ));
        
        // Custom Fonts CSS einbinden + Preload
        $fonts_url = ISIDOR_SUITE_URL . 'assets/fonts/';
        $font_css = "
            @font-face {
                font-family: 'FormaDJRBanner-Black';
                src: url('{$fonts_url}FormaDJRBanner-Black-Testing.ttf') format('truetype');
                font-weight: 900;
                font-style: normal;
                font-display: block;
            }
            @font-face {
                font-family: 'FormaDJRBanner-Light';
                src: url('{$fonts_url}FormaDJRBanner-Light-Testing.ttf') format('truetype');
                font-weight: 300;
                font-style: normal;
                font-display: block;
            }
            /* Hidden font preloader — forces browser to load fonts immediately */
            .isidor-font-preload {
                position: absolute;
                left: -9999px;
                top: -9999px;
                visibility: hidden;
                pointer-events: none;
            }
        ";
        wp_add_inline_style('isidor-poster-css', $font_css);

        // Font preload link tags for faster loading
        echo '<link rel="preload" href="' . esc_url($fonts_url . 'FormaDJRBanner-Black-Testing.ttf') . '" as="font" type="font/ttf" crossorigin>';
        echo '<link rel="preload" href="' . esc_url($fonts_url . 'FormaDJRBanner-Light-Testing.ttf') . '" as="font" type="font/ttf" crossorigin>';

        ob_start();
        ?>
        <!-- Hidden preloader to trigger font loading in DOM -->
        <span class="isidor-font-preload" style="font-family:'FormaDJRBanner-Black';">.</span>
        <span class="isidor-font-preload" style="font-family:'FormaDJRBanner-Light';">.</span>
        <div id="isidor-poster-app">
            <div class="ipa-sidebar">
                <h3>📋 Vorlage</h3>
                <div id="ipa-template-buttons" class="ipa-template-buttons"></div>
                
                <hr>
                <h3>🎪 Veranstaltung wählen</h3>
                
                <div class="ipa-group">
                    <label>Veranstaltung laden</label>
                    <select id="ipa-event-select">
                        <option value="">-- Manuell eingeben --</option>
                    </select>
                    <small>Wähle eine Veranstaltung, um Daten zu übernehmen</small>
                </div>
                
                <hr>
                <h3>📐 Format & Layout</h3>
                
                <div class="ipa-group">
                    <label>Format</label>
                    <select id="ipa-format">
                        <option value="a4_p">DIN A4 Hochformat</option>
                        <option value="a4_l">DIN A4 Querformat</option>
                        <option value="a3_p">DIN A3 Hochformat</option>
                        <option value="a3_l">DIN A3 Querformat</option>
                    </select>
                </div>
                
                <div class="ipa-row">
                    <div class="ipa-group">
                        <label>Header</label>
                        <select id="ipa-header-select"><option value="">Kein Header</option></select>
                    </div>
                    <div class="ipa-group">
                        <label>Footer</label>
                        <select id="ipa-footer-select"><option value="">Kein Footer</option></select>
                    </div>
                </div>
                
                <div class="ipa-group">
                    <label>Hintergrundfarbe</label>
                    <input type="color" id="ipa-bg-color" value="#ffffff">
                </div>

                <hr>
                <h3>✏️ Text bearbeiten</h3>
                
                <div class="ipa-font-info">
                    <strong>💡 Tipp:</strong>
                    Klicke auf einen Text im Canvas, um ihn zu bearbeiten.
                </div>
                
                <div class="ipa-group">
                    <label>Schriftart</label>
                    <select id="ipa-font"></select>
                </div>
                
                <div class="ipa-group">
                    <label>Text</label>
                    <textarea id="ipa-text-content" rows="3" placeholder="Text eingeben..."></textarea>
                </div>
                
                <div class="ipa-row">
                    <div class="ipa-group">
                        <label>Größe</label>
                        <input type="number" id="ipa-font-size" value="40" min="8" max="200">
                    </div>
                    <div class="ipa-group">
                        <label>Farbe</label>
                        <input type="color" id="ipa-color" value="#155277">
                    </div>
                </div>
                
                <div class="ipa-group">
                    <label>Schnellauswahl Farben</label>
                    <div id="ipa-color-palette"></div>
                </div>

                <div class="ipa-group">
                    <label class="ipa-checkbox">
                        <input type="checkbox" id="ipa-shadow"> Schlagschatten
                    </label>
                </div>
                
                <div class="ipa-row">
                    <button id="ipa-add-text" class="button">+ Text hinzufügen</button>
                    <button id="ipa-delete" class="button">🗑️ Löschen</button>
                </div>

                <hr>
                <h3>🖼️ Hintergrundbild</h3>
                
                <div class="ipa-group">
                    <input type="file" id="ipa-bg-upload" accept="image/*">
                </div>
                <button id="ipa-fit-bg" class="button" style="width:100%;">Bild einpassen</button>

                <div class="ipa-actions">
                    <button id="ipa-download-pdf" class="button button-primary button-large">
                        📥 PDF herunterladen
                    </button>
                    
                    <?php if (!empty($poster_emails)): ?>
                    <hr style="margin: 15px 0;">
                    <div class="ipa-group">
                        <label>📧 Per E-Mail senden</label>
                        <select id="ipa-email-select">
                            <option value="">-- Empfänger wählen --</option>
                            <?php foreach ($poster_emails as $email): ?>
                                <option value="<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button id="ipa-send-email" class="button" style="width:100%;">
                        📧 Per E-Mail senden
                    </button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="ipa-canvas-wrapper">
                <canvas id="poster-canvas"></canvas>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * AJAX: E-Mail mit PDF senden
     */
    public function ajax_send_email() {
        check_ajax_referer('isidor_poster_nonce', 'nonce');
        
        $email = sanitize_email($_POST['email'] ?? '');
        $pdf_data = $_POST['pdf'] ?? '';
        
        if (!$email || !is_email($email)) {
            wp_send_json_error(['message' => 'Ungültige E-Mail-Adresse']);
        }
        
        if (!$pdf_data) {
            wp_send_json_error(['message' => 'Keine PDF-Daten']);
        }
        
        // Base64 dekodieren
        $pdf_data = str_replace('data:application/pdf;base64,', '', $pdf_data);
        $pdf_binary = base64_decode($pdf_data);
        
        if (!$pdf_binary) {
            wp_send_json_error(['message' => 'PDF konnte nicht dekodiert werden']);
        }
        
        // Temporäre Datei erstellen
        $upload_dir = wp_upload_dir();
        $filename = 'plakat_' . date('Y-m-d_His') . '.pdf';
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        file_put_contents($filepath, $pdf_binary);
        
        // E-Mail senden
        $parish_name = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : get_bloginfo('name');
        $subject = 'Plakat von ' . $parish_name;
        $message = "Anbei ein neues Plakat.\n\nErstellt am: " . date('d.m.Y H:i') . "\n\nMit freundlichen Grüßen,\n" . $parish_name;
        
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        $attachments = [$filepath];
        
        $sent = wp_mail($email, $subject, $message, $headers, $attachments);
        
        // Temp-Datei löschen
        @unlink($filepath);
        
        if ($sent) {
            wp_send_json_success(['message' => 'E-Mail gesendet']);
        } else {
            wp_send_json_error(['message' => 'E-Mail konnte nicht gesendet werden']);
        }
    }
}