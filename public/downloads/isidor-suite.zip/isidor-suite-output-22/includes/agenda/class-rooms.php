<?php
/**
 * Isidor Agenda - Rooms Management
 */
class Isidor_Agenda_Rooms {
    
    public function __construct() {
        add_action('wp_ajax_agenda_save_room', [$this, 'ajax_save_room']);
        add_action('wp_ajax_agenda_delete_room', [$this, 'ajax_delete_room']);
        add_action('wp_ajax_agenda_get_room', [$this, 'ajax_get_room']);
    }
    
    /**
     * Alle Räume holen
     */
    public static function get_all($active_only = true) {
        global $wpdb;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_agenda_rooms";
        
        if ($active_only) {
            $sql .= " WHERE active = 1";
        }
        
        $sql .= " ORDER BY name ASC";
        
        return $wpdb->get_results($sql); // Returns objects by default
    }
    
    /**
     * Raum holen
     */
    public static function get($room_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_agenda_rooms WHERE id = %d",
            $room_id
        ), ARRAY_A);
    }
    
    /**
     * Raum erstellen/updaten
     */
    public static function save($data) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'isidor_agenda_rooms';
        
        $room_data = [
            'name' => sanitize_text_field($data['name']),
            'location' => sanitize_text_field($data['location'] ?? ''),
            'capacity' => intval($data['capacity'] ?? 0),
            'requires_approval' => !empty($data['requires_approval']) ? 1 : 0,
            'allowed_roles' => is_array($data['allowed_roles'] ?? null) 
                ? implode(',', $data['allowed_roles']) 
                : '',
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'active' => !empty($data['active']) ? 1 : 0
        ];
        
        if (!empty($data['id'])) {
            // Update
            $room_data['updated_at'] = current_time('mysql');
            $wpdb->update($table, $room_data, ['id' => intval($data['id'])]);
            return intval($data['id']);
        } else {
            // Insert
            $room_data['created_at'] = current_time('mysql');
            $wpdb->insert($table, $room_data);
            return $wpdb->insert_id;
        }
    }
    
    /**
     * Raum löschen (soft delete)
     */
    public static function delete($room_id) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_rooms',
            ['active' => 0],
            ['id' => $room_id]
        );
    }
    
    /**
     * Prüfe ob Raum verfügbar
     */
    public static function is_available($room_id, $date, $start_time, $end_time, $exclude_slot_id = null) {
        global $wpdb;
        
        $sql = "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_agenda_slots 
                WHERE room_id = %d 
                AND date = %s 
                AND status IN ('pending', 'approved')
                AND (
                    (start_time < %s AND end_time > %s) OR
                    (start_time < %s AND end_time > %s) OR
                    (start_time >= %s AND end_time <= %s)
                )";
        
        $params = [$room_id, $date, $end_time, $start_time, $end_time, $end_time, $start_time, $end_time];
        
        if ($exclude_slot_id) {
            $sql .= " AND id != %d";
            $params[] = $exclude_slot_id;
        }
        
        $conflicts = $wpdb->get_var($wpdb->prepare($sql, $params));
        
        return $conflicts == 0;
    }
    
    /**
     * AJAX: Save Room
     */
    public function ajax_save_room() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_manage_rooms')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $room_id = self::save($_POST);
        
        if ($room_id) {
            wp_send_json_success([
                'message' => 'Raum gespeichert!',
                'room_id' => $room_id
            ]);
        } else {
            wp_send_json_error(['message' => 'Fehler beim Speichern']);
        }
    }
    
    /**
     * AJAX: Delete Room
     */
    public function ajax_delete_room() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_manage_rooms')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $room_id = intval($_POST['room_id']);
        
        if (self::delete($room_id)) {
            wp_send_json_success(['message' => 'Raum gelöscht!']);
        } else {
            wp_send_json_error(['message' => 'Fehler beim Löschen']);
        }
    }
    
    /**
     * AJAX: Get Room
     */
    public function ajax_get_room() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_manage_rooms')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $room_id = intval($_POST['room_id']);
        $room = self::get($room_id);
        
        if ($room) {
            wp_send_json_success(['room' => $room]);
        } else {
            wp_send_json_error(['message' => 'Raum nicht gefunden']);
        }
    }
}
