<?php
/**
 * Isidor Agenda - Serienveranstaltungen
 */
class Isidor_Agenda_Series {
    
    public function __construct() {
        add_action('wp_ajax_agenda_create_series', [$this, 'ajax_create_series']);
        add_action('wp_ajax_agenda_toggle_instance', [$this, 'ajax_toggle_instance']);
        add_action('wp_ajax_agenda_toggle_announcement', [$this, 'ajax_toggle_announcement']);
    }
    
    /**
     * Serie erstellen
     */
    public static function create($data) {
        global $wpdb;
        
        if (!current_user_can('agenda_manage_rooms')) {
            return new WP_Error('permission', 'Keine Berechtigung');
        }
        
        // Serie anlegen
        $wpdb->insert($wpdb->prefix . 'isidor_agenda_series', [
            'title' => sanitize_text_field($data['title']),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'recurrence_pattern' => sanitize_text_field($data['recurrence_pattern']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'] ?? null,
            'start_time' => $data['start_time'],
            'end_time' => $data['end_time'],
            'room_id' => intval($data['room_id'] ?? 0) ?: null,
            'is_announcement_ready' => !empty($data['is_announcement_ready']) ? 1 : 0,
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
            'active' => 1
        ]);
        
        $series_id = $wpdb->insert_id;
        
        // Termine generieren
        self::generate_instances($series_id);
        
        do_action('isidor_agenda_series_created', $series_id);
        
        return $series_id;
    }
    
    /**
     * Instanzen generieren
     */
    public static function generate_instances($series_id) {
        global $wpdb;
        
        $series = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_agenda_series WHERE id = %d",
            $series_id
        ), ARRAY_A);
        
        if (!$series) return false;
        
        $start = new DateTime($series['start_date']);
        $end = $series['end_date'] ? new DateTime($series['end_date']) : (clone $start)->modify('+1 year');
        
        $instances = [];
        
        switch ($series['recurrence_pattern']) {
            case 'weekly':
                $current = clone $start;
                while ($current <= $end) {
                    $instances[] = $current->format('Y-m-d');
                    $current->modify('+1 week');
                }
                break;
                
            case 'biweekly':
                $current = clone $start;
                while ($current <= $end) {
                    $instances[] = $current->format('Y-m-d');
                    $current->modify('+2 weeks');
                }
                break;
                
            case 'monthly':
                $current = clone $start;
                $day_of_month = $start->format('d');
                while ($current <= $end) {
                    $instances[] = $current->format('Y-m-d');
                    $current->modify('+1 month');
                    // Fix für 31. -> 30. etc
                    if ($current->format('d') != $day_of_month) {
                        $current->modify('last day of previous month');
                    }
                }
                break;
                
            case 'first_monday':
                $current = clone $start;
                $current->modify('first monday of this month');
                while ($current <= $end) {
                    if ($current >= $start) {
                        $instances[] = $current->format('Y-m-d');
                    }
                    $current->modify('first monday of next month');
                }
                break;
                
            case 'last_friday':
                $current = clone $start;
                $current->modify('last friday of this month');
                while ($current <= $end) {
                    if ($current >= $start) {
                        $instances[] = $current->format('Y-m-d');
                    }
                    $current->modify('last friday of next month');
                }
                break;
                
            case 'daily':
                $current = clone $start;
                while ($current <= $end) {
                    $instances[] = $current->format('Y-m-d');
                    $current->modify('+1 day');
                }
                break;
        }
        
        // In DB speichern
        foreach ($instances as $date) {
            $wpdb->insert($wpdb->prefix . 'isidor_agenda_series_instances', [
                'series_id' => $series_id,
                'date' => $date,
                'start_time' => $series['start_time'],
                'end_time' => $series['end_time'],
                'room_id' => $series['room_id'],
                'status' => 'active'
            ]);
        }
        
        return count($instances);
    }
    
    /**
     * Instanz deaktivieren/reaktivieren
     */
    public static function toggle_instance($instance_id, $cancelled = true, $reason = '') {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_series_instances',
            [
                'is_cancelled' => $cancelled ? 1 : 0,
                'cancellation_reason' => $reason
            ],
            ['id' => $instance_id]
        );
    }
    
    /**
     * Plakat-Flag togglen
     */
    public static function toggle_announcement($series_id, $ready = true) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_series',
            ['is_announcement_ready' => $ready ? 1 : 0],
            ['id' => $series_id]
        );
    }
    
    /**
     * Alle Serien holen
     */
    public static function get_all($active_only = true) {
        global $wpdb;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_agenda_series";
        
        if ($active_only) {
            $sql .= " WHERE active = 1";
        }
        
        $sql .= " ORDER BY start_date DESC, title ASC";
        
        return $wpdb->get_results($sql, ARRAY_A);
    }
    
    /**
     * Instanzen für Zeitraum
     */
    public static function get_instances($from, $to, $include_cancelled = false) {
        global $wpdb;
        
        $sql = "SELECT i.*, s.title as series_title, s.description, s.is_announcement_ready
                FROM {$wpdb->prefix}isidor_agenda_series_instances i
                JOIN {$wpdb->prefix}isidor_agenda_series s ON i.series_id = s.id
                WHERE i.date BETWEEN %s AND %s
                AND s.active = 1";
        
        if (!$include_cancelled) {
            $sql .= " AND i.is_cancelled = 0";
        }
        
        $sql .= " ORDER BY i.date, i.start_time";
        
        return $wpdb->get_results($wpdb->prepare($sql, $from, $to), ARRAY_A);
    }
    
    /**
     * Ankündigungsfähige Serien
     */
    public static function get_announcement_ready($from, $to) {
        return self::get_instances($from, $to, false);
    }
    
    /**
     * AJAX: Serie erstellen
     */
    public function ajax_create_series() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        $series_id = self::create($_POST);
        
        if (is_wp_error($series_id)) {
            wp_send_json_error(['message' => $series_id->get_error_message()]);
        }
        
        wp_send_json_success([
            'message' => 'Serie erstellt!',
            'series_id' => $series_id
        ]);
    }
    
    /**
     * AJAX: Instanz togglen
     */
    public function ajax_toggle_instance() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_manage_rooms')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $instance_id = intval($_POST['instance_id']);
        $cancelled = !empty($_POST['cancelled']);
        $reason = sanitize_textarea_field($_POST['reason'] ?? '');
        
        if (self::toggle_instance($instance_id, $cancelled, $reason)) {
            wp_send_json_success([
                'message' => $cancelled ? 'Termin abgesagt' : 'Termin reaktiviert'
            ]);
        } else {
            wp_send_json_error(['message' => 'Fehler']);
        }
    }
    
    /**
     * AJAX: Plakat-Toggle
     */
    public function ajax_toggle_announcement() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        if (!current_user_can('agenda_edit_meta')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $series_id = intval($_POST['series_id']);
        $ready = !empty($_POST['ready']);
        
        if (self::toggle_announcement($series_id, $ready)) {
            wp_send_json_success([
                'message' => $ready ? 'Plakat-Flag aktiviert' : 'Plakat-Flag deaktiviert'
            ]);
        } else {
            wp_send_json_error(['message' => 'Fehler']);
        }
    }
}
