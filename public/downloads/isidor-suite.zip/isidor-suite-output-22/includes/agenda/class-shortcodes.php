<?php
class Isidor_Agenda_Shortcodes {
    public function __construct() {
        add_shortcode('isidor_agenda_calendar', [$this, 'calendar']);
        add_shortcode('isidor_agenda_rooms', [$this, 'rooms']);
        add_shortcode('isidor_agenda_request_form', [$this, 'request_form']);
        add_shortcode('isidor_agenda_my_requests', [$this, 'my_requests']);
    }
    
    public function calendar($atts) {
        if (!is_user_logged_in()) {
            return '<p>Bitte melden Sie sich an.</p>';
        }
        $atts = shortcode_atts(['month' => ''], $atts);
        
        // Monat bestimmen (cal_month – 'month' ist reserviert in WordPress)
        $month = $atts['month'];
        if (!$month) {
            $month = get_query_var('cal_month', '');
            if (!$month && isset($_GET['cal_month'])) {
                $month = sanitize_text_field($_GET['cal_month']);
            }
        }
        if (!$month || !preg_match('/^\d{4}-\d{2}$/', $month)) {
            $month = date('Y-m');
        }
        $start = $month . '-01';
        $end = date('Y-m-t', strtotime($start));
        
        // === DATEN LADEN ===
        $events = [];
        if (class_exists('Isidor_Agenda_Events')) {
            $raw = Isidor_Agenda_Events::get_for_period($start, $end);
            if (is_array($raw)) $events = $raw;
        }
        
        $series = [];
        if (class_exists('Isidor_Agenda_Series') && method_exists('Isidor_Agenda_Series', 'get_instances')) {
            $raw = Isidor_Agenda_Series::get_instances($start, $end);
            if (is_array($raw)) $series = $raw;
        }
        
        $messen = [];
        if (post_type_exists('isidor_messe')) {
            $messen_query = new WP_Query([
                'post_type' => 'isidor_messe',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'meta_query' => [['key' => '_is_date', 'value' => [$start, $end], 'compare' => 'BETWEEN', 'type' => 'DATE']],
                'meta_key' => '_is_date',
                'orderby' => 'meta_value',
                'order' => 'ASC',
            ]);
            $messen = $messen_query->posts;
        }
        
        // === NACH DATUM GRUPPIEREN ===
        $items_by_date = [];
        
        foreach ($messen as $messe) {
            $d = get_post_meta($messe->ID, '_is_date', true);
            $t = get_post_meta($messe->ID, '_is_time', true) ?: '00:00';
            if ($d) {
                $items_by_date[$d][] = [
                    'type' => 'messe',
                    'title' => $messe->post_title,
                    'time' => $t,
                    'liturgical' => get_post_meta($messe->ID, '_is_liturgical', true) ?: '',
                ];
            }
        }
        
        foreach ($events as $ev) {
            $d = $ev['date'] ?? '';
            if (!$d) continue;
            $room_name = '';
            if (!empty($ev['room_id']) && class_exists('Isidor_Agenda_Rooms')) {
                $room = Isidor_Agenda_Rooms::get($ev['room_id']);
                $room_name = $room['name'] ?? '';
            }
            $items_by_date[$d][] = [
                'type' => 'event',
                'title' => $ev['title'] ?? 'Veranstaltung',
                'time' => substr($ev['start_time'] ?? '00:00', 0, 5),
                'end_time' => substr($ev['end_time'] ?? '', 0, 5),
                'room' => $room_name,
                'description' => wp_trim_words($ev['description'] ?? '', 20),
                'status' => $ev['status'] ?? '',
            ];
        }
        
        foreach ($series as $s) {
            $d = $s['date'] ?? '';
            if (!$d) continue;
            $items_by_date[$d][] = [
                'type' => 'series',
                'title' => $s['title'] ?? 'Termin (Serie)',
                'time' => substr($s['start_time'] ?? '00:00', 0, 5),
                'end_time' => substr($s['end_time'] ?? '', 0, 5),
                'room' => $s['room_name'] ?? '',
            ];
        }
        
        // Pro Tag nach Uhrzeit sortieren
        foreach ($items_by_date as &$day_items) {
            usort($day_items, function($a, $b) { return strcmp($a['time'], $b['time']); });
        }
        unset($day_items);
        
        // Liturgische Namen pro Tag (für das Detail-Panel)
        $liturgical_by_date = [];
        if (class_exists('Isidor_Liturgical_Calendar')) {
            for ($d = 1; $d <= (int)(new DateTime($end))->format('j'); $d++) {
                $date_str = sprintf('%s-%02d', $month, $d);
                $info = Isidor_Liturgical_Calendar::get_name($date_str);
                if ($info && !empty($info['name'])) {
                    $liturgical_by_date[$date_str] = $info['name'];
                }
            }
        }
        
        // === KALENDER RENDERN ===
        $dt = new DateTime($start);
        $month_name = $this->german_month_name((int)$dt->format('n')) . ' ' . $dt->format('Y');
        $days_in_month = (int) $dt->format('t');
        $first_dow = (int) (new DateTime($start))->format('N');
        
        $prev_month = date('Y-m', strtotime($start . ' -1 month'));
        $next_month = date('Y-m', strtotime($start . ' +1 month'));
        $base_url = get_permalink();
        
        $today = date('Y-m-d');
        
        // JSON-Daten für JS (alle Tages-Einträge + liturgische Namen)
        $js_data = wp_json_encode([
            'items' => $items_by_date,
            'liturgical' => $liturgical_by_date,
            'weekdays' => [1=>'Montag',2=>'Dienstag',3=>'Mittwoch',4=>'Donnerstag',5=>'Freitag',6=>'Samstag',7=>'Sonntag'],
        ], JSON_UNESCAPED_UNICODE);
        
        $html = '<div class="isidor-agenda-calendar" id="isidor-cal" data-cal=\'' . esc_attr($js_data) . '\'>';
        
        // Header
        $html .= '<div class="agenda-cal-header">';
        $html .= '<a href="' . esc_url(add_query_arg('cal_month', $prev_month, $base_url)) . '" class="agenda-cal-nav" title="Voriger Monat">◀</a>';
        $html .= '<h2>' . esc_html($month_name) . '</h2>';
        $html .= '<a href="' . esc_url(add_query_arg('cal_month', $next_month, $base_url)) . '" class="agenda-cal-nav" title="Nächster Monat">▶</a>';
        $html .= '</div>';
        
        // Grid
        $html .= '<div class="agenda-cal-grid">';
        $day_names = ['MO', 'DI', 'MI', 'DO', 'FR', 'SA', 'SO'];
        foreach ($day_names as $dn) {
            $html .= '<div class="agenda-cal-dayname">' . $dn . '</div>';
        }
        
        for ($i = 1; $i < $first_dow; $i++) {
            $html .= '<div class="agenda-cal-day empty"></div>';
        }
        
        for ($d = 1; $d <= $days_in_month; $d++) {
            $date_str = sprintf('%s-%02d', $month, $d);
            $is_today = ($date_str === $today);
            $has_events = isset($items_by_date[$date_str]);
            $event_count = $has_events ? count($items_by_date[$date_str]) : 0;
            
            $classes = 'agenda-cal-day';
            if ($is_today) $classes .= ' today';
            if ($has_events) $classes .= ' has-events';
            $dow = (int)(new DateTime($date_str))->format('N');
            if ($dow >= 6) $classes .= ' weekend';
            
            // Klickbarer Div statt Link
            $html .= '<div class="' . $classes . '" data-date="' . $date_str . '" data-dow="' . $dow . '" role="button" tabindex="0">';
            $html .= '<span class="agenda-cal-num">' . $d . '</span>';
            if ($has_events) {
                $html .= '<span class="agenda-cal-badge">' . $event_count . '</span>';
            }
            $html .= '</div>';
        }
        
        $html .= '</div>'; // .agenda-cal-grid
        
        // Detail-Panel (wird von JS befüllt)
        $html .= '<div class="agenda-day-detail" id="agenda-day-detail" style="display:none;"></div>';
        
        $html .= '</div>'; // .isidor-agenda-calendar
        
        // Inline-Script für Kalender-Interaktion
        $html .= $this->render_calendar_script();
        
        return $html;
    }
    
    /**
     * JavaScript für den Kalender: Klick auf Tag → Detail-Panel inline
     */
    private function render_calendar_script(): string {
        return '<script>
(function() {
    var cal = document.getElementById("isidor-cal");
    if (!cal) return;
    
    var data = JSON.parse(cal.getAttribute("data-cal"));
    var panel = document.getElementById("agenda-day-detail");
    var days = cal.querySelectorAll(".agenda-cal-day[data-date]");
    var selected = null;
    
    var badges = {messe: "⛪", event: "📅", series: "🔁"};
    var statusLabels = {pending: "⏳ Ausstehend", draft: "📝 Entwurf", rejected: "❌ Abgelehnt"};
    
    function selectDay(el) {
        var date = el.getAttribute("data-date");
        var dow = parseInt(el.getAttribute("data-dow"));
        
        // Toggle: gleicher Tag nochmal → schließen
        if (selected === date) {
            panel.style.display = "none";
            el.classList.remove("selected");
            selected = null;
            return;
        }
        
        // Vorherige Auswahl entfernen
        days.forEach(function(d) { d.classList.remove("selected"); });
        el.classList.add("selected");
        selected = date;
        
        // Datum formatieren
        var parts = date.split("-");
        var dayNum = parseInt(parts[2]);
        var monthNum = parseInt(parts[1]);
        var months = ["","Jänner","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
        var dayName = data.weekdays[dow] || "";
        var formatted = dayName + ", " + dayNum + ". " + months[monthNum] + " " + parts[0];
        
        var liturgical = data.liturgical[date] || "";
        var items = data.items[date] || [];
        
        // Panel bauen
        var h = "<div class=\"agenda-day-detail-header\">";
        h += "<div class=\"agenda-day-detail-date\">";
        h += "<strong>" + formatted + "</strong>";
        if (liturgical) {
            h += "<span class=\"agenda-day-liturgical\">" + liturgical + "</span>";
        }
        h += "</div></div>";
        
        if (items.length === 0) {
            h += "<div class=\"agenda-day-empty\">";
            h += "<span class=\"agenda-day-empty-icon\">📭</span>";
            h += "<p>Keine Einträge an diesem Tag.</p>";
            h += "</div>";
        } else {
            h += "<div class=\"agenda-day-items\">";
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                var badge = badges[it.type] || "📅";
                var cls = "type-" + (it.type || "event");
                var timeStr = (it.time && it.time !== "00:00") ? it.time : "–";
                
                h += "<div class=\"agenda-day-item " + cls + "\">";
                h += "<div class=\"agenda-day-item-time\">";
                h += "<span class=\"agenda-item-time-main\">" + timeStr + "</span>";
                if (it.end_time && it.end_time !== "00:00") {
                    h += "<span class=\"agenda-item-time-end\">bis " + it.end_time + "</span>";
                }
                h += "</div>";
                h += "<div class=\"agenda-day-item-content\">";
                h += "<div class=\"agenda-day-item-title\">" + badge + " " + (it.title || "") + "</div>";
                
                var meta = [];
                if (it.liturgical) meta.push("🕯️ " + it.liturgical);
                if (it.room) meta.push("📍 " + it.room);
                if (it.status && it.status !== "approved") {
                    meta.push(statusLabels[it.status] || it.status);
                }
                if (it.description) meta.push(it.description);
                
                if (meta.length) {
                    h += "<div class=\"agenda-day-item-meta\">";
                    for (var j = 0; j < meta.length; j++) {
                        h += "<span class=\"agenda-item-meta-tag\">" + meta[j] + "</span>";
                    }
                    h += "</div>";
                }
                
                h += "</div></div>";
            }
            h += "</div>";
        }
        
        panel.innerHTML = h;
        panel.style.display = "block";
        
        // Sanft zum Panel scrollen
        setTimeout(function() {
            panel.scrollIntoView({behavior: "smooth", block: "nearest"});
        }, 50);
    }
    
    // Click-Handler auf allen Tagen
    days.forEach(function(day) {
        day.addEventListener("click", function(e) {
            e.preventDefault();
            selectDay(this);
        });
        day.addEventListener("keydown", function(e) {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                selectDay(this);
            }
        });
    });
})();
</script>';
    }
    
    private function german_month_name(int $m): string {
        return ['', 'Jänner','Februar','März','April','Mai','Juni',
                'Juli','August','September','Oktober','November','Dezember'][$m] ?? '';
    }
    
    private function german_weekday_name(int $dow): string {
        return [1=>'Montag',2=>'Dienstag',3=>'Mittwoch',4=>'Donnerstag',
                5=>'Freitag',6=>'Samstag',7=>'Sonntag'][$dow] ?? '';
    }
    
    // ========================================================
    // Andere Shortcodes
    // ========================================================
    
    public function rooms($atts) {
        $atts = shortcode_atts(['booking_url' => ''], $atts);
        $rooms = Isidor_Agenda_Rooms::get_all();
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/agenda/shortcode-rooms.php';
        return ob_get_clean();
    }
    
    public function request_form($atts) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agenda_request'])) {
            check_admin_referer('agenda_request', 'agenda_nonce');
            
            // Raum-Slot erstellen
            $slot_data = [
                'room_id' => intval($_POST['room_id']),
                'date' => sanitize_text_field($_POST['date']),
                'start_time' => sanitize_text_field($_POST['start_time']),
                'end_time' => sanitize_text_field($_POST['end_time']),
                'comment' => sanitize_textarea_field($_POST['comment'] ?? ''),
            ];
            
            $slot_result = Isidor_Agenda_Slots::create($slot_data);
            
            if (is_wp_error($slot_result)) {
                echo '<div class="notice error"><p>' . $slot_result->get_error_message() . '</p></div>';
            } else {
                // Wenn Veranstaltung aktiviert, auch Event erstellen
                if (!empty($_POST['is_event']) && !empty($_POST['event_title'])) {
                    $event_data = [
                        'title' => sanitize_text_field($_POST['event_title']),
                        'description' => sanitize_textarea_field($_POST['event_description'] ?? ''),
                        'date' => $slot_data['date'],
                        'start_time' => $slot_data['start_time'],
                        'end_time' => $slot_data['end_time'],
                        'room_id' => $slot_data['room_id'],
                        'slot_id' => $slot_result, // Verknüpfung mit Slot
                        'event_type' => sanitize_text_field($_POST['event_type'] ?? 'sonstiges'),
                        'subtitle' => sanitize_text_field($_POST['event_subtitle'] ?? ''),
                        'speaker' => sanitize_text_field($_POST['event_speaker'] ?? ''),
                        'custom_type' => sanitize_text_field($_POST['event_custom_type'] ?? ''),
                        'is_public' => !empty($_POST['event_public']),
                    ];
                    
                    Isidor_Agenda_Events::create($event_data);
                }
                
                echo '<div class="notice success"><p>✓ Anfrage erfolgreich gesendet!</p></div>';
                Isidor_Agenda_Notifications::send_new_request($slot_result);
            }
        }
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/agenda/shortcode-request-form.php';
        return ob_get_clean();
    }
    
    public function my_requests($atts) {
        global $wpdb;
        $user_id = get_current_user_id();
        $requests = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE requested_by = %d ORDER BY date DESC, created_at DESC LIMIT 50",
            $user_id
        ), ARRAY_A);
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/agenda/shortcode-my-requests.php';
        return ob_get_clean();
    }
}
