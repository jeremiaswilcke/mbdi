<?php
/**
 * Slots Management (Reine Raumbuchungen, KEIN Plakat-Flag)
 */
class Isidor_Agenda_Slots {
    
    public function __construct() {
        add_action('wp_ajax_agenda_cancel_request', [$this, 'ajax_cancel_request']);
    }
    
    public function ajax_cancel_request() {
        check_ajax_referer('agenda_nonce', 'nonce');
        
        $request_id = intval($_POST['request_id']);
        $user_id = get_current_user_id();
        
        global $wpdb;
        
        // Check if user owns this request
        $request = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE id = %d",
            $request_id
        ), ARRAY_A);
        
        if (!$request || $request['requested_by'] != $user_id) {
            wp_send_json_error('Keine Berechtigung');
        }
        
        // Only pending requests can be cancelled
        if ($request['status'] !== 'pending') {
            wp_send_json_error('Nur ausstehende Anfragen können storniert werden');
        }
        
        // Update status to cancelled
        $updated = $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_slots',
            ['status' => 'cancelled'],
            ['id' => $request_id]
        );
        
        if ($updated) {
            wp_send_json_success('Anfrage wurde storniert');
        } else {
            wp_send_json_error('Fehler beim Stornieren');
        }
    }
    
    public static function create($data) {
        global $wpdb;
        
        if (!current_user_can('agenda_request_room')) {
            return new WP_Error('permission', 'Keine Berechtigung');
        }
        
        // Konfliktprüfung
        if (!Isidor_Agenda_Rooms::is_available(
            $data['room_id'], 
            $data['date'], 
            $data['start_time'], 
            $data['end_time']
        )) {
            return new WP_Error('conflict', 'Raum ist bereits gebucht');
        }
        
        $wpdb->insert($wpdb->prefix . 'isidor_agenda_slots', [
            'messe_id' => $data['messe_id'] ?? null,
            'date' => $data['date'],
            'start_time' => $data['start_time'],
            'end_time' => $data['end_time'],
            'room_id' => $data['room_id'],
            'status' => 'pending',
            'requested_by' => get_current_user_id(),
            'comment' => $data['comment'] ?? '',
            'created_at' => current_time('mysql')
        ]);
        
        $slot_id = $wpdb->insert_id;
        
        do_action('isidor_agenda_slot_created', $slot_id, $data);
        
        return $slot_id;
    }
    
    public static function approve($slot_id) {
        global $wpdb;
        
        $updated = $wpdb->update(
            $wpdb->prefix . 'isidor_agenda_slots',
            [
                'status' => 'approved',
                'approved_by' => get_current_user_id(),
                'updated_at' => current_time('mysql')
            ],
            ['id' => $slot_id]
        );
        
        if ($updated) {
            // Prüfe ob Event zu diesem Slot gehört
            $event = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}isidor_agenda_events WHERE slot_id = %d",
                $slot_id
            ), ARRAY_A);
            
            if ($event) {
                // Event auch genehmigen
                $wpdb->update(
                    $wpdb->prefix . 'isidor_agenda_events',
                    ['status' => 'approved'],
                    ['id' => $event['id']]
                );
            }
            
            do_action('isidor_agenda_slot_approved', $slot_id);
        }
        
        return $updated;
    }
    
    public static function get_for_period($from, $to, $status = null) {
        global $wpdb;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE date BETWEEN %s AND %s";
        $params = [$from, $to];
        
        if ($status) {
            $sql .= " AND status = %s";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY date, start_time";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    }
}
