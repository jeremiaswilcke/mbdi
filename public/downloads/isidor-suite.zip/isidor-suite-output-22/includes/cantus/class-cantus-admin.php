<?php
/**
 * Cantus Admin - Backend für freie Lieder
 */
class Cantus_Admin {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_post_cantus_save_free_songs', [$this, 'save_free_songs']);
        add_action('admin_post_cantus_submit_batch', [$this, 'submit_batch']);
        add_action('admin_post_cantus_import_catalog', [$this, 'import_catalog']);
    }
    
    public function add_menu() {
        add_menu_page(
            'Cantus Liedverwaltung',
            'Cantus',
            'isidor_cantus_edit',
            'isidor-cantus',
            [$this, 'render_page'],
            'dashicons-playlist-audio',
            30
        );

        add_submenu_page(
            'isidor-cantus',
            'Cantus Katalog Import',
            'Katalog Import',
            'isidor_cantus_edit',
            'isidor-cantus-import',
            [$this, 'render_import_page']
        );
        
        add_submenu_page(
            'isidor-cantus',
            'Freie Lieder',
            'Freie Lieder',
            'isidor_cantus_edit',
            'isidor-cantus-free-songs',
            [$this, 'render_free_songs']
        );
        
        add_submenu_page(
            'isidor-cantus',
            'Genehmigung',
            'Genehmigung',
            'isidor_cantus_edit',
            'isidor-cantus-batches',
            [$this, 'render_batches']
        );
    }
    
    public function render_page() {
        ?>
        <div class="wrap">
            <h1>Cantus Liedverwaltung</h1>
            <p>Verwalten Sie hier Ihre Liedplanung.</p>
            
            <div class="card">
                <h2>Shortcode für Frontend</h2>
                <p>Fügen Sie diesen Shortcode auf einer Seite ein:</p>
                <code>[isidor_cantus]</code>
            </div>
            
            <div class="card">
                <h2>Freie Lieder</h2>
                <p>Legen Sie eine Datenbank mit freien Liedern an (nicht GL/JD).</p>
                <p><a href="<?php echo admin_url('admin.php?page=isidor-cantus-free-songs'); ?>" class="button button-primary">Freie Lieder verwalten</a></p>
            </div>
        </div>
        <?php
    }
    
    public function render_free_songs() {
        // Hole aktuelle Liste
        $songs = get_option('isidor_cantus_free_songs', '[]');
        $songs = json_decode($songs, true) ?: [];
        
        // Neue ID generieren
        $next_id = 1;
        if (!empty($songs)) {
            $max_id = max(array_column($songs, 'id'));
            $next_id = $max_id + 1;
        }
        
        ?>
        <div class="wrap">
            <h1>Freie Lieder</h1>
            <p>Lieder die nicht im Gotteslob (GL) oder Jubilate Deo (JD) stehen.</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('cantus_free_songs', 'cantus_nonce'); ?>
                <input type="hidden" name="action" value="cantus_save_free_songs">
                
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="80">ID</th>
                            <th>Liedtitel</th>
                            <th width="100">Aktion</th>
                        </tr>
                    </thead>
                    <tbody id="free-songs-list">
                        <?php foreach ($songs as $song): ?>
                            <tr>
                                <td><?php echo esc_html($song['id']); ?></td>
                                <td>
                                    <input type="hidden" name="songs[<?php echo $song['id']; ?>][id]" value="<?php echo $song['id']; ?>">
                                    <input type="text" name="songs[<?php echo $song['id']; ?>][title]" value="<?php echo esc_attr($song['title']); ?>" class="regular-text" required>
                                </td>
                                <td>
                                    <button type="button" class="button" onclick="deleteSong(this)">Löschen</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <!-- Template für neue Zeilen -->
                        <tr id="new-song-template" style="display:none;">
                            <td><span class="new-id"></span></td>
                            <td>
                                <input type="hidden" name="songs[NEW][id]" value="NEW" class="song-id">
                                <input type="text" name="songs[NEW][title]" value="" class="regular-text" required>
                            </td>
                            <td>
                                <button type="button" class="button" onclick="deleteSong(this)">Löschen</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <p class="submit">
                    <button type="button" class="button" onclick="addNewSong()">+ Neues Lied</button>
                    <input type="submit" class="button button-primary" value="Speichern">
                </p>
            </form>
        </div>
        
        <script>
        let nextId = <?php echo $next_id; ?>;
        
        function addNewSong() {
            const template = document.getElementById('new-song-template');
            const clone = template.cloneNode(true);
            
            clone.id = '';
            clone.style.display = '';
            
            // ID setzen
            clone.querySelector('.new-id').textContent = nextId;
            clone.querySelector('.song-id').value = nextId;
            clone.querySelector('.song-id').name = 'songs[' + nextId + '][id]';
            clone.querySelector('input[type="text"]').name = 'songs[' + nextId + '][title]';
            
            document.getElementById('free-songs-list').appendChild(clone);
            nextId++;
        }
        
        function deleteSong(btn) {
            if (confirm('Wirklich löschen?')) {
                btn.closest('tr').remove();
            }
        }
        </script>
        
        <style>
        .wp-list-table input[type="text"] {
            width: 100%;
        }
        </style>
        <?php
    }
    
    public function save_free_songs() {
        check_admin_referer('cantus_free_songs', 'cantus_nonce');
        
        if (!current_user_can('isidor_cantus_edit')) {
            wp_die('Keine Berechtigung');
        }
        
        $songs = $_POST['songs'] ?? [];
        $cleaned = [];
        
        foreach ($songs as $id => $song) {
            if (!empty($song['title'])) {
                $cleaned[] = [
                    'id' => intval($song['id']),
                    'title' => sanitize_text_field($song['title'])
                ];
            }
        }
        
        // Sortieren nach ID
        usort($cleaned, function($a, $b) {
            return $a['id'] - $b['id'];
        });
        
        update_option('isidor_cantus_free_songs', json_encode($cleaned, JSON_UNESCAPED_UNICODE));
        
        wp_redirect(admin_url('admin.php?page=isidor-cantus-free-songs&saved=1'));
        exit;
    }
    
    public function render_batches() {
        $batches = Cantus_Batch::get_batches();
        
        ?>
        <div class="wrap">
            <h1>Liedplanung - Genehmigung</h1>
            <p>Senden Sie fertige Mess-Batches zur Genehmigung an Pfarrer und Diakone.</p>
            
            <?php foreach ($batches as $batch): ?>
                <div class="card" style="margin-bottom: 20px;">
                    <h2><?php echo esc_html($batch['label']); ?></h2>
                    
                    <p>
                        <strong>Status:</strong>
                        <?php echo $batch['stats']['total']; ?> Messen gesamt |
                        <?php echo $batch['stats']['bereit']; ?> bereit |
                        <?php echo $batch['stats']['zur_genehmigung']; ?> zur Genehmigung |
                        <?php echo $batch['stats']['genehmigt']; ?> genehmigt
                    </p>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                        <?php wp_nonce_field('cantus_submit_batch', 'cantus_nonce'); ?>
                        <input type="hidden" name="action" value="cantus_submit_batch">
                        <input type="hidden" name="batch_id" value="<?php echo esc_attr($batch['id']); ?>">
                        
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th width="50"><input type="checkbox" id="select-all-<?php echo $batch['id']; ?>" onclick="toggleAll(this, '<?php echo $batch['id']; ?>')"></th>
                                    <th>Datum</th>
                                    <th>Zeit</th>
                                    <th>Messe</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($batch['messen'] as $messe): 
                                    $status_labels = [
                                        'leer' => '⚪ Leer',
                                        'in_arbeit' => '🟡 In Arbeit',
                                        'bereit' => '🟢 Bereit',
                                        'zur_genehmigung' => '🔵 Zur Genehmigung',
                                        'genehmigt' => '✅ Genehmigt'
                                    ];
                                ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="messen[]" value="<?php echo $messe['id']; ?>" 
                                                   class="batch-<?php echo $batch['id']; ?>"
                                                   <?php echo ($messe['status'] === 'bereit') ? 'checked' : ''; ?>
                                                   <?php echo ($messe['status'] === 'leer') ? 'disabled' : ''; ?>>
                                        </td>
                                        <td><?php echo date('d.m.Y', strtotime($messe['date'])); ?></td>
                                        <td><?php echo $messe['time']; ?></td>
                                        <td><?php echo esc_html($messe['title']); ?></td>
                                        <td><?php echo $status_labels[$messe['status']]; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <p class="submit">
                            <input type="submit" class="button button-primary" value="Ausgewählte zur Genehmigung senden">
                        </p>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
        
        <script>
        function toggleAll(checkbox, batchId) {
            const checkboxes = document.querySelectorAll('.batch-' + batchId + ':not([disabled])');
            checkboxes.forEach(cb => cb.checked = checkbox.checked);
        }
        </script>
        <?php
    }
    
    public function submit_batch() {
        check_admin_referer('cantus_submit_batch', 'cantus_nonce');
        
        if (!current_user_can('isidor_cantus_edit')) {
            wp_die('Keine Berechtigung');
        }
        
        $batch_id = $_POST['batch_id'];
        $messe_ids = $_POST['messen'] ?? [];
        $user_id = get_current_user_id();
        
        if (empty($messe_ids)) {
            wp_redirect(admin_url('admin.php?page=isidor-cantus-batches&error=no_selection'));
            exit;
        }
        
        Cantus_Batch::submit_batch($batch_id, $messe_ids, $user_id);
        
        wp_redirect(admin_url('admin.php?page=isidor-cantus-batches&submitted=1'));
        exit;
    }

    public function render_import_page() {
        if (!current_user_can('isidor_cantus_edit')) {
            wp_die('Keine Berechtigung.');
        }
        ?>
        <div class="wrap">
            <h1>Cantus Katalog Import (CSV)</h1>
            <p>Importiert eine Gotteslob-CSV in die Cantus-Katalog-Datenbank. Bestehende Einträge werden aktualisiert.</p>

            <?php if (!empty($_GET['cantus_import_done'])): ?>
                <div class="notice notice-success">
                    <p><strong>Import abgeschlossen:</strong>
                        <?php echo intval($_GET['inserted'] ?? 0); ?> neu,
                        <?php echo intval($_GET['updated'] ?? 0); ?> aktualisiert,
                        <?php echo intval($_GET['skipped'] ?? 0); ?> übersprungen,
                        <?php echo intval($_GET['errors'] ?? 0); ?> Fehler.
                    </p>
                </div>
            <?php endif; ?>

            <?php
            // Aktuelle Katalog-Statistik
            global $wpdb;
            $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}isidor_cantus_catalog");
            if ($count > 0): ?>
                <div class="notice notice-info">
                    <p>📚 Aktuell <strong><?php echo number_format($count); ?> Lieder</strong> im Katalog.</p>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('cantus_import_catalog', 'cantus_import_nonce'); ?>
                <input type="hidden" name="action" value="cantus_import_catalog">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="cantus_csv">CSV-Datei</label></th>
                        <td>
                            <input type="file" name="cantus_csv" id="cantus_csv" accept=".csv,text/csv" required>
                            <p class="description">
                                Mindest-Format: <code>nr,titel</code> (z.B. <code>380,"Großer Gott, wir loben dich"</code>).<br>
                                Nummern mit Varianten wie <code>174,3</code> werden automatisch erkannt.<br>
                                Optionale Spalten: <code>genre, mass_setting, liturgy_slot, themes, tags, composer, lyricist, source</code>
                            </p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('CSV importieren'); ?>
            </form>
        </div>
        <?php
    }

    public function import_catalog() {
        if (!current_user_can('isidor_cantus_edit')) {
            wp_die('Keine Berechtigung.');
        }
        if (!isset($_POST['cantus_import_nonce']) || !wp_verify_nonce($_POST['cantus_import_nonce'], 'cantus_import_catalog')) {
            wp_die('Ungültiger Nonce.');
        }
        if (empty($_FILES['cantus_csv']['tmp_name'])) {
            wp_die('Keine CSV hochgeladen.');
        }

        $tmp = $_FILES['cantus_csv']['tmp_name'];
        $contents = file_get_contents($tmp);
        if ($contents === false) wp_die('CSV konnte nicht gelesen werden.');

        // delimiter tolerant: try semicolon, else comma
        $first_line = strtok($contents, "\n");
        $delimiter = (substr_count($first_line, ';') > substr_count($first_line, ',')) ? ';' : ',';

        $fh = fopen($tmp, 'r');
        if (!$fh) wp_die('CSV konnte nicht geöffnet werden.');

        $header = fgetcsv($fh, 0, $delimiter);
        if (!$header) wp_die('CSV Header fehlt.');

        $header = array_map(function($h){ return strtolower(trim($h)); }, $header);

        // Flexible Spaltennamen: nr/nr_raw + titel/title
        $nr_col    = in_array('nr', $header, true) ? 'nr' : (in_array('nr_raw', $header, true) ? 'nr_raw' : null);
        $title_col = in_array('titel', $header, true) ? 'titel' : (in_array('title', $header, true) ? 'title' : null);

        if (!$nr_col) wp_die('CSV muss Spalte "nr" oder "nr_raw" enthalten.');

        $idx = array_flip($header);
        $stats = ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0];

        while (($row = fgetcsv($fh, 0, $delimiter)) !== false) {
            if (count($row) === 1 && trim($row[0]) === '') continue;

            $nr_raw = isset($idx[$nr_col], $row[$idx[$nr_col]]) ? trim((string)$row[$idx[$nr_col]]) : '';
            if ($nr_raw === '') { $stats['skipped']++; continue; }

            // Titel aus CSV oder leer
            $title = ($title_col && isset($idx[$title_col], $row[$idx[$title_col]]))
                ? trim((string)$row[$idx[$title_col]])
                : '';

            // nr_base / nr_variant automatisch aus nr_raw ableiten (z.B. "174,3" → base=174, variant=3)
            $nr_base = null;
            $nr_variant = null;
            if (preg_match('/^(\d+)(?:[,.](\d+))?/', $nr_raw, $m)) {
                $nr_base = (int)$m[1];
                $nr_variant = isset($m[2]) ? (int)$m[2] : null;
            }

            // Item bauen — alle vorhandenen Spalten übernehmen, Rest defaults
            $item = [
                'type'      => 'gl',
                'nr_raw'    => $nr_raw,
                'nr_base'   => $nr_base,
                'nr_variant' => $nr_variant,
                'title'     => $title,
            ];

            // Optionale Felder aus CSV übernehmen falls vorhanden
            $optional = ['genre','mass_setting','liturgy_slot','themes','tags','composer','lyricist','source','type'];
            foreach ($optional as $key) {
                if (isset($idx[$key], $row[$idx[$key]])) {
                    $item[$key] = trim((string)$row[$idx[$key]]);
                }
            }
            if (!empty($item['type'])) $item['type'] = strtolower($item['type']);
            if (empty($item['type'])) $item['type'] = 'gl';

            $res = Cantus_DB::upsert_catalog_item($item);
            if (is_wp_error($res)) { $stats['errors']++; continue; }
            if ($res === 'inserted') $stats['inserted']++;
            if ($res === 'updated') $stats['updated']++;
        }
        fclose($fh);

        wp_redirect(add_query_arg([
            'page'               => 'isidor-cantus-import',
            'cantus_import_done' => 1,
            'inserted'           => $stats['inserted'],
            'updated'            => $stats['updated'],
            'skipped'            => $stats['skipped'],
            'errors'             => $stats['errors'],
        ], admin_url('admin.php')));
        exit;
    }

}
