<?php
/**
 * Cantus REST API
 * 
 * Endpoints:
 *   GET  /isidor/v1/cantus/messe/{id}          – Liedplan + Lesungen einer Messe
 *   GET  /isidor/v1/cantus/plan?from=&to=       – Liedplan + Lesungen für Zeitraum (Bulk)
 */
class Cantus_API {
    
    /** Slot-Labels für den JSON-Export */
    private const SLOT_LABELS = [
        1  => 'Einzug',
        2  => 'Kyrie',
        3  => 'Gloria',
        4  => 'Psalm',
        5  => 'Ruf vor dem Evangelium',
        6  => 'Offertorium',
        7  => 'Sanctus',
        8  => 'Agnus Dei',
        9  => 'Kommunion',
        10 => 'Danklied',
        11 => 'Schluss',
    ];
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }
    
    public function register_routes(): void {
        // Einzelne Messe
        register_rest_route('isidor/v1', '/cantus/messe/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_messe_songs'],
            'permission_callback' => '__return_true',
        ]);
        
        // Bulk: Zeitraum
        register_rest_route('isidor/v1', '/cantus/plan', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_plan_range'],
            'permission_callback' => '__return_true',
            'args' => [
                'from' => [
                    'required'          => true,
                    'validate_callback' => function($val) { return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $val); },
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'to' => [
                    'required'          => true,
                    'validate_callback' => function($val) { return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $val); },
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ]);
    }
    
    /* ──────────────────────────────────────────────
       Single Messe
       ────────────────────────────────────────────── */
    public function get_messe_songs($request) {
        $messe_id = (int) $request['id'];
        $messe    = get_post($messe_id);
        
        if (!$messe || $messe->post_type !== 'isidor_messe') {
            return new WP_Error('not_found', 'Messe nicht gefunden', ['status' => 404]);
        }
        
        return $this->build_messe_data($messe);
    }
    
    /* ──────────────────────────────────────────────
       Bulk Plan (Zeitraum)
       ────────────────────────────────────────────── */
    public function get_plan_range($request) {
        $from = $request['from'];
        $to   = $request['to'];
        
        $messen = get_posts([
            'post_type'      => 'isidor_messe',
            'posts_per_page' => 200,
            'post_status'    => 'publish',
            'meta_key'       => '_is_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => [[
                'key'     => '_is_date',
                'value'   => [$from, $to],
                'compare' => 'BETWEEN',
                'type'    => 'DATE',
            ]],
        ]);
        
        $plan = [];
        foreach ($messen as $messe) {
            $plan[] = $this->build_messe_data($messe);
        }
        
        // Pfarrei-Meta für die Präsentationssoftware
        $parish = [];
        if (class_exists('Isidor_Parish_Settings')) {
            $parish = [
                'name'     => Isidor_Parish_Settings::name(),
                'subtitle' => Isidor_Parish_Settings::get('subtitle'),
            ];
        }
        
        // Lesejahr
        $year  = (int) date('Y', strtotime($from));
        $cycle = class_exists('Isidor_Liturgical_Calendar')
            ? Isidor_Liturgical_Calendar::reading_cycle($year)
            : '';
        
        return [
            'parish'        => $parish,
            'reading_cycle' => $cycle,
            'from'          => $from,
            'to'            => $to,
            'count'         => count($plan),
            'messen'        => $plan,
        ];
    }
    
    /* ──────────────────────────────────────────────
       Daten-Builder pro Messe
       ────────────────────────────────────────────── */
    private function build_messe_data(WP_Post $messe): array {
        $messe_id = $messe->ID;
        $songs    = Cantus_DB::get_songs($messe_id);
        
        // Slots mit Labels aufbauen
        $slots = [];
        for ($i = 1; $i <= 11; $i++) {
            $song = $songs[$i] ?? null;
            $slot_data = [
                'slot'  => $i,
                'label' => self::SLOT_LABELS[$i],
                'song'  => null,
            ];
            
            if (is_array($song) && (!empty($song['number']) || !empty($song['free_title']))) {
                $display = '';
                if (($song['type'] ?? '') === 'free') {
                    $display = trim((string)($song['free_title'] ?? ''));
                } else {
                    $display = strtoupper($song['type'] ?? 'GL') . ' ' . ($song['number'] ?? '');
                    if (!empty($song['strophes'])) {
                        $display .= ' (Str. ' . $song['strophes'] . ')';
                    }
                }
                
                $slot_data['song'] = [
                    'type'       => $song['type'] ?? 'gl',
                    'number'     => $song['number'] ?? '',
                    'strophes'   => $song['strophes'] ?? '',
                    'free_title' => $song['free_title'] ?? '',
                    'title'      => $song['title'] ?? '',
                    'display'    => $display,
                ];
                
                // Kurzform und subtitle für Präsentationssoftware/Tagesplan
                if (!empty($song['title'])) {
                    $short = class_exists('Cantus_Frontend') 
                        ? Cantus_Frontend::short_title(trim((string)$song['title'])) 
                        : trim((string)$song['title']);
                    $slot_data['song']['short_title'] = $short;
                    $slot_data['song']['subtitle'] = [
                        'text' => trim((string)$song['title']),
                        'short' => $short,
                        'role' => 'song_subtitle',
                    ];
                }
            }
            
            $slots[] = $slot_data;
        }
        
        // Lesungen aus Post-Meta
        $lesung1       = get_post_meta($messe_id, '_is_lesung1', true);
        $antwortpsalm  = get_post_meta($messe_id, '_is_antwortpsalm', true);
        $lesung2       = get_post_meta($messe_id, '_is_lesung2', true);
        $evangelium     = get_post_meta($messe_id, '_is_evangelium', true);
        $lit_farbe     = get_post_meta($messe_id, '_is_lit_farbe', true);
        $schott_url    = get_post_meta($messe_id, '_is_schott_url', true);
        $liturgical    = get_post_meta($messe_id, '_is_liturgical', true);
        $lektionar     = get_post_meta($messe_id, '_is_lektionar', true);
        
        // Farb-Map
        $farbe_labels = ['w' => 'Weiß', 'r' => 'Rot', 'v' => 'Violett', 'g' => 'Grün'];
        
        return [
            'messe' => [
                'id'         => $messe->ID,
                'title'      => $messe->post_title,
                'date'       => get_post_meta($messe_id, '_is_date', true),
                'time'       => get_post_meta($messe_id, '_is_time', true),
                'liturgical' => $liturgical ?: null,
                'lektionar'  => $lektionar ?: null,
            ],
            'lesungen' => [
                'lesung1'        => $lesung1 ?: null,
                'antwortpsalm'   => $antwortpsalm ?: null,
                'lesung2'        => $lesung2 ?: null,
                'evangelium'     => $evangelium ?: null,
                'lit_farbe'      => $lit_farbe ?: null,
                'lit_farbe_name' => ($lit_farbe && isset($farbe_labels[$lit_farbe])) ? $farbe_labels[$lit_farbe] : null,
                'schott_url'     => $schott_url ?: null,
            ],
            'cantus' => [
                'slots'  => $slots,
                'filled' => count(array_filter($slots, function($s) { return $s['song'] !== null; })),
                'total'  => 11,
            ],
        ];
    }
}
