<?php
/**
 * Cantus Batch & Approval System
 */
class Cantus_Batch {
    
    /**
     * Hole Batches (gruppiert nach batch_id)
     */
    public static function get_batches() {
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC'
        ]);
        
        $batches = [];
        
        foreach ($messen as $messe) {
            $batch_id = get_post_meta($messe->ID, '_is_batch_id', true);
            
            // Fallback: Monat als Batch
            if (!$batch_id) {
                $date = get_post_meta($messe->ID, '_is_date', true);
                $batch_id = date('Y-m', strtotime($date));
            }
            
            if (!isset($batches[$batch_id])) {
                $batches[$batch_id] = [
                    'id' => $batch_id,
                    'label' => self::get_batch_label($batch_id),
                    'messen' => [],
                    'stats' => [
                        'total' => 0,
                        'leer' => 0,
                        'in_arbeit' => 0,
                        'bereit' => 0,
                        'zur_genehmigung' => 0,
                        'genehmigt' => 0
                    ]
                ];
            }
            
            $status = self::get_messe_status($messe->ID);
            
            $batches[$batch_id]['messen'][] = [
                'id' => $messe->ID,
                'title' => $messe->post_title,
                'date' => get_post_meta($messe->ID, '_is_date', true),
                'time' => get_post_meta($messe->ID, '_is_time', true),
                'status' => $status
            ];
            
            $batches[$batch_id]['stats']['total']++;
            $batches[$batch_id]['stats'][$status]++;
        }
        
        return $batches;
    }
    
    /**
     * Status einer Messe ermitteln
     */
    public static function get_messe_status($messe_id) {
        // Gespeicherter Status
        $saved = get_post_meta($messe_id, '_is_cantus_status', true);
        if ($saved) {
            return $saved;
        }
        
        // Auto-Detect
        $songs = Cantus_DB::get_songs($messe_id);
        $count = count($songs);
        
        if ($count === 0) return 'leer';
        if ($count < 11) return 'in_arbeit';
        return 'bereit';
    }
    
    /**
     * Status setzen
     */
    public static function set_messe_status($messe_id, $status, $user_id = null) {
        update_post_meta($messe_id, '_is_cantus_status', $status);
        
        if ($status === 'zur_genehmigung' || $status === 'genehmigt') {
            update_post_meta($messe_id, '_is_cantus_status_at', current_time('mysql'));
            
            if ($user_id) {
                update_post_meta($messe_id, '_is_cantus_status_by', $user_id);
            }
        }
    }
    
    /**
     * Batch zur Genehmigung senden
     */
    public static function submit_batch($batch_id, $messe_ids, $user_id) {
        foreach ($messe_ids as $messe_id) {
            self::set_messe_status($messe_id, 'zur_genehmigung', $user_id);
        }
        
        // Email an Pfarrer + Diakon
        self::send_approval_email($batch_id, $messe_ids, $user_id);
        
        return true;
    }
    
    /**
     * Email: Zur Genehmigung
     */
    private static function send_approval_email($batch_id, $messe_ids, $user_id) {
        // Empfänger: Pfarrer + Diakon
        $recipients = [];
        
        $pfarrer = get_users(['role' => 'isidor_pfarrer']);
        $diakone = get_users(['role' => 'isidor_diakon']);
        
        foreach (array_merge($pfarrer, $diakone) as $user) {
            if ($user->user_email) {
                $recipients[] = $user->user_email;
            }
        }
        
        if (empty($recipients)) {
            return;
        }
        
        $submitter = get_userdata($user_id);
        $batch_label = self::get_batch_label($batch_id);
        
        $subject = 'Liedplanung zur Genehmigung: ' . $batch_label;
        
        $body = "Lieber Pfarrer, liebe Diakone,\n\n";
        $body .= $submitter->display_name . " hat die Liedplanung für folgende Messen zur Genehmigung eingereicht:\n\n";
        $body .= "Batch: " . $batch_label . " (" . count($messe_ids) . " Messen)\n\n";
        $body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        
        foreach ($messe_ids as $messe_id) {
            $messe = get_post($messe_id);
            $date = get_post_meta($messe_id, '_is_date', true);
            $time = get_post_meta($messe_id, '_is_time', true);
            $songs = Cantus_DB::get_songs($messe_id);
            
            $body .= date('D d.m.Y', strtotime($date)) . " | " . $time . "\n";
            $body .= $messe->post_title . "\n";
            $body .= "─────────────────────────────\n";
            
            $slot_names = [
                1 => 'Einzug', 2 => 'Kyrie', 3 => 'Gloria', 4 => 'Psalm',
                5 => 'Ruf v. Ev.', 6 => 'Offertorium', 7 => 'Sanctus',
                8 => 'Agnus Dei', 9 => 'Kommunion', 10 => 'Danklied', 11 => 'Schluss'
            ];
            
            for ($i = 1; $i <= 11; $i++) {
                $song = $songs[$i] ?? null;
                $body .= sprintf("%-15s", $slot_names[$i] . ":");
                
                if ($song) {
                    if ($song['type'] === 'free') {
                        $body .= $song['free_title'];
                    } else {
                        $body .= strtoupper($song['type']) . " " . $song['number'];
                        if ($song['strophes']) {
                            $body .= " (Str. " . $song['strophes'] . ")";
                        }
                    }
                } else {
                    $body .= "---";
                }
                
                $body .= "\n";
            }
            
            $body .= "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        }
        
        $body .= "Ansicht im Frontend:\n";
        $body .= home_url('/?cantus_katalog=1&batch=' . $batch_id) . "\n\n";
        
        $body .= "Bei Fragen wenden Sie sich bitte an " . $submitter->display_name . "\n";
        $body .= "E-Mail: " . $submitter->user_email . "\n";
        
        wp_mail($recipients, $subject, $body);
    }
    
    /**
     * Batch-Label
     */
    private static function get_batch_label($batch_id) {
        // Format: 2026-01 oder 2026-01-batch-123
        if (preg_match('/^(\d{4})-(\d{2})/', $batch_id, $matches)) {
            $year = $matches[1];
            $month = $matches[2];
            
            $months = [
                '01' => 'Jänner', '02' => 'Februar', '03' => 'März', '04' => 'April',
                '05' => 'Mai', '06' => 'Juni', '07' => 'Juli', '08' => 'August',
                '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Dezember'
            ];
            
            return $months[$month] . ' ' . $year;
        }
        
        return $batch_id;
    }
}
