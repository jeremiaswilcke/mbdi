<?php
/**
 * Cantus Database
 */
class Cantus_DB {
    
    public static function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Tabelle: Lieder pro Messe
        $sql = "CREATE TABLE {$wpdb->prefix}isidor_cantus_songs (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED NOT NULL,
            slot_key TINYINT NOT NULL,
            type VARCHAR(10) NOT NULL DEFAULT 'gl',
            number VARCHAR(20),
            strophes VARCHAR(100),
            free_title VARCHAR(200),
            updated_by BIGINT UNSIGNED NOT NULL,
            updated_at DATETIME NOT NULL,
            KEY messe_id (messe_id),
            KEY slot_key (slot_key),
            UNIQUE KEY unique_slot (messe_id, slot_key)
        ) $charset;";
        
        dbDelta($sql);

        // Tabelle: Cantus Katalog (Master-Datenbank aus CSV)
        $sql_catalog = "CREATE TABLE {$wpdb->prefix}isidor_cantus_catalog (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(10) NOT NULL DEFAULT 'gl',
            nr_raw VARCHAR(20) NOT NULL,
            nr_base INT NULL,
            nr_variant INT NULL,
            title TEXT NULL,
            genre VARCHAR(20) NULL,
            mass_setting VARCHAR(50) NULL,
            liturgy_slot VARCHAR(50) NULL,
            themes TEXT NULL,
            tags TEXT NULL,
            composer VARCHAR(150) NULL,
            lyricist VARCHAR(150) NULL,
            source VARCHAR(150) NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY type_nr (type, nr_raw),
            KEY nr_base (nr_base),
            KEY liturgy_slot (liturgy_slot),
            KEY mass_setting (mass_setting),
            KEY genre (genre)
        ) $charset;";

        dbDelta($sql_catalog);

        
        // Rollen & Caps
        self::add_roles_and_caps();
    }
    
    private static function add_roles_and_caps() {
        // Neue Rollen
        add_role('isidor_orgel', 'Isidor Orgel', [
            'read' => true,
            'isidor_cantus_view' => true,
            'isidor_cantus_edit' => true,
            'isidor_cantus_export' => true
        ]);
        
        add_role('isidor_technik', 'Isidor Technik', [
            'read' => true,
            'isidor_cantus_view' => true,
            'isidor_cantus_edit' => true,
            'isidor_cantus_export' => true
        ]);
        
        // Bestehende Rollen
        $roles = ['administrator', 'isidor_pfarrer', 'isidor_sekretaer', 'isidor_diakon'];
        
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('isidor_cantus_view');
                $role->add_cap('isidor_cantus_edit');
                $role->add_cap('isidor_cantus_export');
            }
        }
    }
    
    /**
     * Hole Lieder für Messe
     */
    public static function get_songs($messe_id) {
        global $wpdb;
        
        $songs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_cantus_songs WHERE messe_id = %d ORDER BY slot_key",
            $messe_id
        ), ARRAY_A);
        
        // Als Array mit slot_key als Index
        $result = [];
        foreach ($songs as $song) {
            // Titel aus Katalog nachladen (für UI/JSON als Untertitel)
            $title = '';
            if (!empty($song['type']) && $song['type'] === 'free') {
                $title = !empty($song['free_title']) ? trim((string)$song['free_title']) : '';
            } else {
                $title = self::lookup_catalog_title($song['type'] ?? 'gl', $song['number'] ?? '');
            }
            if ($title !== '') {
                $song['title'] = $title;
            }
            $result[$song['slot_key']] = $song;
        }
        
        return $result;
    }
    
    /**
     * Speichere Lied
     */
    public static function save_song($messe_id, $slot_key, $data, $user_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'isidor_cantus_songs';
        
        $song_data = [
            'messe_id' => $messe_id,
            'slot_key' => $slot_key,
            'type' => $data['type'],
            'number' => $data['number'] ?? '',
            'strophes' => $data['strophes'] ?? '',
            'free_title' => $data['free_title'] ?? '',
            'updated_by' => $user_id,
            'updated_at' => current_time('mysql')
        ];
        
        // Prüfen ob schon existiert
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE messe_id = %d AND slot_key = %d",
            $messe_id, $slot_key
        ));
        
        if ($exists) {
            $wpdb->update($table, $song_data, ['id' => $exists]);
        } else {
            $wpdb->insert($table, $song_data);
        }
        
        return true;
    }
    
    /**
     * Lösche Lied
     */
    public static function delete_song($messe_id, $slot_key) {
        global $wpdb;
        
        return $wpdb->delete(
            $wpdb->prefix . 'isidor_cantus_songs',
            ['messe_id' => $messe_id, 'slot_key' => $slot_key]
        );
    }
    
    /**
     * Hole Lieder für Zeitraum
     */
    public static function get_songs_for_period($from, $to) {
        global $wpdb;
        
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [[
                'key' => '_is_date',
                'value' => [$from, $to],
                'compare' => 'BETWEEN',
                'type' => 'DATE'
            ]]
        ]);
        
        $result = [];
        
        foreach ($messen as $messe) {
            $songs = self::get_songs($messe->ID);
            
            $result[] = [
                'messe_id' => $messe->ID,
                'messe_title' => $messe->post_title,
                'messe_date' => get_post_meta($messe->ID, '_is_date', true),
                'messe_time' => get_post_meta($messe->ID, '_is_time', true),
                'songs' => $songs
            ];
        }
        
        return $result;
    }

    /**
     * Lookup title from catalog table by type + number
     */
    public static function lookup_catalog_title($type, $nr_raw) {
        global $wpdb;
        $type = $type ?: 'gl';
        $nr_raw = trim((string)$nr_raw);
        if ($nr_raw === '') return '';

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT title FROM {$wpdb->prefix}isidor_cantus_catalog WHERE type = %s AND nr_raw = %s LIMIT 1",
                $type,
                $nr_raw
            )
        );
        if (!$row || empty($row->title)) return '';
        return trim((string)$row->title);
    }

    /**
     * Upsert catalog item (used by CSV import)
     */
    public static function upsert_catalog_item($item) {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_cantus_catalog';

        $type = isset($item['type']) && $item['type'] ? sanitize_key($item['type']) : 'gl';
        $nr_raw = isset($item['nr_raw']) ? trim((string)$item['nr_raw']) : '';
        if ($nr_raw === '') return new WP_Error('cantus_catalog_invalid', 'nr_raw fehlt');

        $data = [
            'type' => $type,
            'nr_raw' => $nr_raw,
            'nr_base' => isset($item['nr_base']) && $item['nr_base'] !== '' ? intval($item['nr_base']) : null,
            'nr_variant' => isset($item['nr_variant']) && $item['nr_variant'] !== '' ? intval($item['nr_variant']) : null,
            'title' => isset($item['title']) ? sanitize_text_field($item['title']) : '',
            'genre' => isset($item['genre']) ? sanitize_text_field($item['genre']) : '',
            'mass_setting' => isset($item['mass_setting']) ? sanitize_text_field($item['mass_setting']) : '',
            'liturgy_slot' => isset($item['liturgy_slot']) ? sanitize_text_field($item['liturgy_slot']) : '',
            'themes' => isset($item['themes']) ? sanitize_text_field($item['themes']) : '',
            'tags' => isset($item['tags']) ? sanitize_text_field($item['tags']) : '',
            'composer' => isset($item['composer']) ? sanitize_text_field($item['composer']) : '',
            'lyricist' => isset($item['lyricist']) ? sanitize_text_field($item['lyricist']) : '',
            'source' => isset($item['source']) ? sanitize_text_field($item['source']) : '',
            'updated_at' => current_time('mysql'),
        ];

        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE type = %s AND nr_raw = %s LIMIT 1",
                $type, $nr_raw
            )
        );

        if ($existing) {
            $wpdb->update($table, $data, ['id' => intval($existing)]);
            return 'updated';
        } else {
            $wpdb->insert($table, $data);
            return 'inserted';
        }
    }

    /**
     * Search catalog with filters
     * Returns array of matching items (max 50)
     */
    public static function search_catalog($filters = []) {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_cantus_catalog';
        
        // Base query
        $where = ['1=1'];
        $params = [];
        
        // Text search (nr_raw or title)
        if (!empty($filters['q'])) {
            $search = '%' . $wpdb->esc_like(sanitize_text_field($filters['q'])) . '%';
            $where[] = '(nr_raw LIKE %s OR title LIKE %s)';
            $params[] = $search;
            $params[] = $search;
        }
        
        // Liturgy slot filter
        if (!empty($filters['slot'])) {
            $where[] = 'liturgy_slot = %s';
            $params[] = sanitize_text_field($filters['slot']);
        }
        
        // Mass setting filter
        if (!empty($filters['mass'])) {
            $where[] = 'mass_setting = %s';
            $params[] = sanitize_text_field($filters['mass']);
        }
        
        // Genre filter
        if (!empty($filters['genre'])) {
            $where[] = 'genre = %s';
            $params[] = sanitize_text_field($filters['genre']);
        }
        
        // Tag filter (LIKE search for comma-separated tags)
        if (!empty($filters['tag'])) {
            $tag_search = '%' . $wpdb->esc_like(sanitize_text_field($filters['tag'])) . '%';
            $where[] = 'tags LIKE %s';
            $params[] = $tag_search;
        }
        
        // Theme filter (LIKE search)
        if (!empty($filters['theme'])) {
            $theme_search = '%' . $wpdb->esc_like(sanitize_text_field($filters['theme'])) . '%';
            $where[] = 'themes LIKE %s';
            $params[] = $theme_search;
        }
        
        // Type filter (default: gl)
        $type = !empty($filters['type']) ? sanitize_key($filters['type']) : 'gl';
        $where[] = 'type = %s';
        $params[] = $type;
        
        // Build query
        $where_clause = implode(' AND ', $where);
        $sql = "SELECT nr_raw, title, genre, mass_setting, liturgy_slot, tags, themes, composer 
                FROM {$table} 
                WHERE {$where_clause} 
                ORDER BY nr_base ASC, nr_variant ASC 
                LIMIT 50";
        
        if (!empty($params)) {
            $sql = $wpdb->prepare($sql, ...$params);
        }
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        // Sanitize output
        $cleaned = [];
        foreach ($results as $row) {
            $cleaned[] = [
                'nr_raw' => $row['nr_raw'] ?? '',
                'title' => $row['title'] ?? '',
                'genre' => $row['genre'] ?? '',
                'mass_setting' => $row['mass_setting'] ?? '',
                'liturgy_slot' => $row['liturgy_slot'] ?? '',
                'tags' => $row['tags'] ?? '',
                'themes' => $row['themes'] ?? '',
                'composer' => $row['composer'] ?? ''
            ];
        }
        
        return $cleaned;
    }

}
