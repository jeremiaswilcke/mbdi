<?php
/**
 * Cantus Frontend — Liedplanung für Gottesdienste
 * 
 * Shortcodes:
 *   [cantus_planner]  – Lied-Editor
 *   [cantus_songbook]  – Liederkatalog (read-only)
 */
class Cantus_Frontend {
    
    private static $slot_names = [
        1 => 'Einzug',
        2 => 'Kyrie',
        3 => 'Gloria',
        4 => 'Psalm',
        5 => 'Ruf vor dem Evangelium',
        6 => 'Offertorium',
        7 => 'Sanctus',
        8 => 'Agnus Dei',
        9 => 'Kommunion',
        10 => 'Danklied',
        11 => 'Schluss'
    ];
    
    public function __construct() {
        add_shortcode('isidor_cantus', [$this, 'render']);
        add_shortcode('cantus_planner', [$this, 'render']);
        add_shortcode('cantus_katalog', [$this, 'render_katalog']);
        add_shortcode('cantus_songbook', [$this, 'render_katalog']);
        add_shortcode('cantus_search', [$this, 'render_search']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
        
        // AJAX
        add_action('wp_ajax_cantus_save_song', [$this, 'ajax_save_song']);
        add_action('wp_ajax_cantus_delete_song', [$this, 'ajax_delete_song']);
        add_action('wp_ajax_cantus_catalog_search', [$this, 'ajax_catalog_search']);
        add_action('wp_ajax_cantus_lookup_title', [$this, 'ajax_lookup_title']);
        add_action('wp_ajax_cantus_title_search', [$this, 'ajax_title_search']);
        add_action('wp_ajax_cantus_get_import_sources', [$this, 'ajax_get_import_sources']);
        add_action('wp_ajax_cantus_import_songs', [$this, 'ajax_import_songs']);
        
        // Sakristan-Integration: Liedblatt-Info als HTML liefern
        add_filter('isidor_cantus_get_messe_songs_html', [$this, 'render_sakristan_liedblatt'], 10, 2);
        
        // PDF/JSON Export Handler — init statt template_redirect,
        // damit Header gesendet werden bevor WordPress Output erzeugt
        add_action('init', [$this, 'handle_export']);
    }
    
    public function enqueue() {
        if (!is_singular()) return;
        $content = get_post()->post_content ?? '';
        if (!has_shortcode($content, 'isidor_cantus') 
            && !has_shortcode($content, 'cantus_planner')
            && !has_shortcode($content, 'cantus_katalog')
            && !has_shortcode($content, 'cantus_songbook')
            && !has_shortcode($content, 'cantus_search')) {
            return;
        }
        
        wp_enqueue_style('cantus', ISIDOR_SUITE_URL . 'assets/css/cantus.css', [], ISIDOR_CANTUS_VERSION);
        wp_enqueue_script('cantus', ISIDOR_SUITE_URL . 'assets/js/cantus.js', ['jquery'], ISIDOR_CANTUS_VERSION, true);
        
        wp_localize_script('cantus', 'cantusData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cantus_nonce'),
            'freeSongs' => $this->get_free_songs()
        ]);
    }
    
    public function render() {
        if (!is_user_logged_in()) {
            return '<p>Bitte einloggen.</p>';
        }
        
        $user_id = get_current_user_id();
        
        if (!current_user_can('isidor_cantus_view')) {
            return '<p>Keine Berechtigung.</p>';
        }
        
        if (isset($_GET['messe_id'])) {
            return $this->render_editor(intval($_GET['messe_id']), $user_id);
        }
        
        return $this->render_overview($user_id);
    }
    
    /* ================================================================
       ÜBERSICHT – Messen-Liste
       ================================================================ */
    private function render_overview($user_id) {
        $from = $_GET['from'] ?? date('Y-m-d');
        $to = $_GET['to'] ?? date('Y-m-d', strtotime('+28 days'));
        
        $messen = Cantus_Permissions::get_accessible_messen($user_id, $from, $to);
        
        ob_start();
        ?>
        <div class="cantus-dashboard">
            <div class="cantus-header">
                <div>
                    <h2>🎵 Liedplanung</h2>
                </div>
                <div class="cantus-actions">
                    <a href="<?php 
                        $search_page = get_page_by_path('liedplanung/liedsuche');
                        echo $search_page ? esc_url(get_permalink($search_page)) : '#'; 
                    ?>" class="cantus-btn cantus-btn-outline">🔍 Suche</a>
                    <?php if (current_user_can('isidor_cantus_export')): ?>
                        <a href="<?php echo esc_url(add_query_arg(['cantus_export' => 'pdf', 'from' => $from, 'to' => $to])); ?>" class="cantus-btn cantus-btn-outline">
                            📄 PDF
                        </a>
                        <a href="<?php echo esc_url(add_query_arg(['cantus_export' => 'json', 'from' => $from, 'to' => $to])); ?>" class="cantus-btn cantus-btn-outline">
                            { } JSON
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="cantus-filter">
                <form method="get">
                    <label>
                        <span>Von</span>
                        <input type="date" name="from" value="<?php echo esc_attr($from); ?>">
                    </label>
                    <label>
                        <span>Bis</span>
                        <input type="date" name="to" value="<?php echo esc_attr($to); ?>">
                    </label>
                    <button type="submit" class="cantus-btn">Filtern</button>
                </form>
            </div>
            
            <div class="cantus-messen-list">
                <?php if (empty($messen)): ?>
                    <div class="cantus-empty">
                        <p>📭 Keine Messen im gewählten Zeitraum.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($messen as $messe): 
                        $date = get_post_meta($messe->ID, '_is_date', true);
                        $time = get_post_meta($messe->ID, '_is_time', true);
                        $liturgical = get_post_meta($messe->ID, '_is_liturgical', true);
                        $has_readings = (bool)get_post_meta($messe->ID, '_is_evangelium', true);
                        $songs = Cantus_DB::get_songs($messe->ID);
                        $filled = count($songs);
                        $ts = strtotime($date);
                        $is_sunday = (int)date('w', $ts) === 0;
                    ?>
                        <a href="?messe_id=<?php echo $messe->ID; ?>" class="cantus-messe-card <?php echo $is_sunday ? 'cantus-messe-sunday' : ''; ?>">
                            <div class="cantus-messe-date">
                                <span class="cantus-date-day"><?php echo date('d', $ts); ?></span>
                                <span class="cantus-date-month"><?php echo date('M', $ts); ?></span>
                                <span class="cantus-date-weekday"><?php echo date('D', $ts); ?></span>
                            </div>
                            <div class="cantus-messe-info">
                                <strong><?php echo esc_html($messe->post_title); ?></strong>
                                <span class="cantus-messe-meta">
                                    <?php echo esc_html($time); ?>
                                    <?php if ($liturgical): ?>
                                        · <?php echo esc_html($liturgical); ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="cantus-messe-status">
                                <span class="cantus-progress <?php echo $filled >= 8 ? 'cantus-progress-good' : ($filled >= 4 ? 'cantus-progress-partial' : 'cantus-progress-empty'); ?>">
                                    <?php echo $filled; ?>/11
                                </span>
                                <?php if ($has_readings): ?>
                                    <span class="cantus-readings-badge" title="Lesungen vorhanden">📖</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /* ================================================================
       EDITOR – Lied-Eingabe pro Messe
       ================================================================ */
    private function render_editor($messe_id, $user_id) {
        if (!Cantus_Permissions::can_user_access_messe($user_id, $messe_id, 'edit')) {
            return '<p>Keine Berechtigung für diese Messe.</p>';
        }
        
        $messe = get_post($messe_id);
        if (!$messe || $messe->post_type !== 'isidor_messe') {
            return '<p>Messe nicht gefunden.</p>';
        }
        
        $date = get_post_meta($messe_id, '_is_date', true);
        $time = get_post_meta($messe_id, '_is_time', true);
        $liturgical = get_post_meta($messe_id, '_is_liturgical', true);
        $songs = Cantus_DB::get_songs($messe_id);
        
        // Lesungen laden
        $lesung1      = get_post_meta($messe_id, '_is_lesung1', true);
        $antwortpsalm = get_post_meta($messe_id, '_is_antwortpsalm', true);
        $lesung2      = get_post_meta($messe_id, '_is_lesung2', true);
        $evangelium    = get_post_meta($messe_id, '_is_evangelium', true);
        $lit_farbe    = get_post_meta($messe_id, '_is_lit_farbe', true);
        $schott_url   = get_post_meta($messe_id, '_is_schott_url', true);
        
        $has_any_reading = $lesung1 || $antwortpsalm || $lesung2 || $evangelium;
        $farbe_map = ['w' => ['⬜', 'Weiß'], 'r' => ['🟥', 'Rot'], 'v' => ['🟪', 'Violett'], 'g' => ['🟩', 'Grün']];
        
        $filled = count($songs);
        
        ob_start();
        ?>
        <div class="cantus-editor">
            <!-- Header -->
            <div class="cantus-editor-header">
                <div class="cantus-editor-title">
                    <a href="?" class="cantus-back-link">← Übersicht</a>
                    <h2><?php echo esc_html($messe->post_title); ?></h2>
                    <div class="cantus-editor-meta">
                        <span><?php echo date('l, j. F Y', strtotime($date)); ?></span>
                        <span>·</span>
                        <span><?php echo esc_html($time); ?> Uhr</span>
                        <?php if ($liturgical): ?>
                            <span>·</span>
                            <span class="cantus-liturgical-tag"><?php echo esc_html($liturgical); ?></span>
                        <?php endif; ?>
                        <?php if ($lit_farbe && isset($farbe_map[$lit_farbe])): ?>
                            <span class="cantus-farbe-tag"><?php echo $farbe_map[$lit_farbe][0]; ?> <?php echo esc_html($farbe_map[$lit_farbe][1]); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="cantus-editor-actions">
                    <button onclick="cantusOpenImport()" class="cantus-btn cantus-btn-outline" title="Lieder aus einer anderen Messe übernehmen">📥 Aus Messe importieren</button>
                    <span class="cantus-fill-status"><?php echo $filled; ?>/11</span>
                    <button onclick="cantusSaveAll()" class="cantus-btn cantus-btn-save">💾 Alle speichern</button>
                </div>
            </div>
            
            <?php if ($has_any_reading): ?>
            <!-- Lesungen-Info-Box -->
            <div class="cantus-readings-box">
                <div class="cantus-readings-title">
                    📖 Lesungen des Tages
                    <?php if ($schott_url): ?>
                        <a href="<?php echo esc_url($schott_url); ?>" target="_blank" rel="noopener" class="cantus-schott-link">Texte im Schott →</a>
                    <?php endif; ?>
                </div>
                <div class="cantus-readings-grid">
                    <?php if ($lesung1): ?>
                    <div class="cantus-reading-item">
                        <span class="cantus-reading-label">1. Lesung</span>
                        <span class="cantus-reading-value"><?php echo esc_html($lesung1); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($antwortpsalm): ?>
                    <div class="cantus-reading-item">
                        <span class="cantus-reading-label">Antwortpsalm</span>
                        <span class="cantus-reading-value"><?php echo esc_html($antwortpsalm); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($lesung2): ?>
                    <div class="cantus-reading-item">
                        <span class="cantus-reading-label">2. Lesung</span>
                        <span class="cantus-reading-value"><?php echo esc_html($lesung2); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($evangelium): ?>
                    <div class="cantus-reading-item">
                        <span class="cantus-reading-label">Evangelium</span>
                        <span class="cantus-reading-value"><?php echo esc_html($evangelium); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Lied-Slots -->
            <div class="cantus-slots">
                <?php foreach (self::$slot_names as $slot_key => $slot_name): 
                    $song = $songs[$slot_key] ?? null;
                    $is_filled = $song && (!empty($song['number']) || !empty($song['free_title']));
                    $type = $song['type'] ?? 'gl';
                ?>
                    <div class="cantus-slot <?php echo $is_filled ? 'cantus-slot-filled' : 'cantus-slot-empty'; ?>" data-slot="<?php echo $slot_key; ?>" data-messe="<?php echo $messe_id; ?>">
                        <div class="cantus-slot-header">
                            <div class="cantus-slot-number"><?php echo $slot_key; ?></div>
                            <strong><?php echo esc_html($slot_name); ?></strong>
                            <?php if ($is_filled): ?>
                                <span class="cantus-slot-check">✓</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="cantus-slot-body">
                            <!-- Typ-Auswahl -->
                            <div class="cantus-type-pills">
                                <label class="cantus-pill <?php echo $type === 'gl' ? 'cantus-pill-active' : ''; ?>">
                                    <input type="radio" name="type_<?php echo $slot_key; ?>" value="gl" <?php checked($type, 'gl'); ?>> GL
                                </label>
                                <label class="cantus-pill <?php echo $type === 'jd' ? 'cantus-pill-active' : ''; ?>">
                                    <input type="radio" name="type_<?php echo $slot_key; ?>" value="jd" <?php checked($type, 'jd'); ?>> JD
                                </label>
                                <label class="cantus-pill <?php echo $type === 'free' ? 'cantus-pill-active' : ''; ?>">
                                    <input type="radio" name="type_<?php echo $slot_key; ?>" value="free" <?php checked($type, 'free'); ?>> Frei
                                </label>
                            </div>
                            
                            <!-- Eingabefelder -->
                            <div class="cantus-inputs" data-type="<?php echo esc_attr($type); ?>">
                                <!-- GL/JD -->
                                <div class="cantus-number-wrapper">
                                    <input type="text" name="number_<?php echo $slot_key; ?>" placeholder="Nr." 
                                        value="<?php echo esc_attr($song['number'] ?? ''); ?>" class="cantus-number">
                                    <button type="button" class="cantus-btn-catalog" 
                                        onclick="openCatalogModal(<?php echo $slot_key; ?>, '<?php echo esc_js($slot_name); ?>')">📖</button>
                                </div>
                                
                                <!-- Strophen-Feld mit Label -->
                                <div class="cantus-strophes-wrapper">
                                    <label class="cantus-strophes-label" for="strophes_<?php echo $slot_key; ?>">Strophen</label>
                                    <input type="text" id="strophes_<?php echo $slot_key; ?>" name="strophes_<?php echo $slot_key; ?>" 
                                        placeholder="z.B. 1,2,4 oder 1-3" 
                                        value="<?php echo esc_attr($song['strophes'] ?? ''); ?>" class="cantus-strophes">
                                </div>
                                
                                <?php 
                                // Titel-Hint: Katalog-Titel anzeigen wenn Nummer vorhanden
                                $hint_title = '';
                                if (!empty($song['title'])) {
                                    $hint_title = $song['title'];
                                } elseif (!empty($song['number']) && $type !== 'free') {
                                    $hint_title = Cantus_DB::lookup_catalog_title($type, $song['number']);
                                }
                                $hint_short = self::short_title($hint_title);
                                ?>
                                <div class="cantus-title-hint" id="hint_<?php echo $slot_key; ?>"><?php echo esc_html($hint_short ?: $hint_title); ?></div>
                                
                                <!-- Frei -->
                                <div class="cantus-free-input">
                                    <?php 
                                    $free_songs = $this->get_free_songs();
                                    if (!empty($free_songs)): 
                                    ?>
                                        <select name="free_select_<?php echo $slot_key; ?>" class="cantus-free-select">
                                            <option value="">— Lied wählen —</option>
                                            <?php foreach ($free_songs as $fs): ?>
                                                <option value="<?php echo esc_attr($fs['title']); ?>" <?php selected($song['free_title'] ?? '', $fs['title']); ?>>
                                                    <?php echo esc_html($fs['title']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                            <option value="__custom__">— Manuell eingeben —</option>
                                        </select>
                                    <?php endif; ?>
                                    <input type="text" name="free_title_<?php echo $slot_key; ?>" placeholder="Liedtitel"
                                        value="<?php echo esc_attr($song['free_title'] ?? ''); ?>" class="cantus-free-title">
                                </div>
                            </div>
                            
                            <!-- Slot-Aktionen -->
                            <div class="cantus-slot-actions">
                                <button type="button" class="cantus-btn-slot-save" 
                                    onclick="cantusSave(<?php echo $messe_id; ?>, <?php echo $slot_key; ?>)">💾 Speichern</button>
                                <?php if ($is_filled): ?>
                                    <button type="button" class="cantus-btn-slot-delete" 
                                        onclick="cantusDelete(<?php echo $messe_id; ?>, <?php echo $slot_key; ?>)">🗑</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Katalog-Modal -->
            <div id="cantus-catalog-modal" class="cantus-modal" style="display:none;">
                <div class="cantus-modal-overlay" onclick="closeCatalogModal()"></div>
                <div class="cantus-modal-content">
                    <div class="cantus-modal-header">
                        <h3 id="catalog-modal-title">Lied aus Katalog wählen</h3>
                        <button type="button" class="cantus-modal-close" onclick="closeCatalogModal()">×</button>
                    </div>
                    
                    <div class="cantus-modal-body">
                        <div class="cantus-catalog-filters">
                            <input type="text" id="catalog-search" placeholder="Suche (Nummer oder Titel)" class="cantus-filter-input">
                            
                            <select id="catalog-filter-mass" class="cantus-filter-select">
                                <option value="">— Messreihe —</option>
                                <option value="haydn_messe">Haydn-Messe</option>
                                <option value="messe_fuer_verstorbene">Messe für Verstorbene</option>
                                <option value="deutsche_messe">Deutsche Messe</option>
                            </select>
                            
                            <select id="catalog-filter-genre" class="cantus-filter-select">
                                <option value="">— Genre —</option>
                                <option value="L">L (Lied)</option>
                                <option value="G">G (Gesang)</option>
                                <option value="Kv">Kv (Kehrvers)</option>
                            </select>
                            
                            <select id="catalog-filter-tag" class="cantus-filter-select">
                                <option value="">— Tag —</option>
                                <option value="NGL">NGL</option>
                                <option value="gre">Gregorianisch</option>
                            </select>
                            
                            <button type="button" class="cantus-btn cantus-btn-sm" onclick="searchCatalog()">Suchen</button>
                            <button type="button" class="cantus-btn-outline cantus-btn-sm" onclick="resetCatalogFilters()">Zurücksetzen</button>
                        </div>
                        
                        <div id="catalog-results-info" class="cantus-catalog-info"></div>
                        
                        <div id="catalog-results" class="cantus-catalog-results">
                            <p class="cantus-catalog-placeholder">Filter setzen und „Suchen" klicken</p>
                        </div>
                    </div>
                    
                    <div class="cantus-modal-footer">
                        <button type="button" class="cantus-btn-outline" onclick="closeCatalogModal()">Abbrechen</button>
                    </div>
                </div>
            </div>
            
            <!-- Import Modal -->
            <div id="cantus-import-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:999999;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
                <div style="max-width:550px;background:white;border-radius:14px;width:100%;max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,0.2);">
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                        <h3 style="margin:0;font-size:1.1em;">📥 Lieder aus Messe importieren</h3>
                        <button type="button" onclick="cantusCloseImport()" style="background:none;border:none;font-size:1.5em;cursor:pointer;color:#9ca3af;padding:0 4px;">&times;</button>
                    </div>
                    <div style="padding:16px 20px;">
                        <p style="color:#6b7280;margin:0 0 12px;">Wähle eine Messe, deren Lieder übernommen werden sollen:</p>
                        <div id="cantus-import-list" style="max-height:350px;overflow-y:auto;">
                            <p style="color:#9ca3af;text-align:center;">Lade Messen…</p>
                        </div>
                        <label style="display:flex;align-items:center;gap:8px;margin-top:12px;font-size:0.9em;color:#6b7280;">
                            <input type="checkbox" id="cantus-import-overwrite">
                            Bereits belegte Slots überschreiben
                        </label>
                    </div>
                    <div style="padding:12px 20px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;">
                        <button type="button" onclick="cantusCloseImport()" style="padding:8px 16px;border:1px solid #d1d5db;border-radius:8px;background:white;cursor:pointer;">Abbrechen</button>
                        <button type="button" id="cantus-import-btn" disabled onclick="cantusDoImport()" style="padding:8px 16px;border:none;border-radius:8px;background:#16a34a;color:white;cursor:pointer;font-weight:500;">Importieren</button>
                    </div>
                </div>
            </div>
            
            <script>
            var _cantusImportTarget = <?php echo $messe_id; ?>;
            var _cantusImportSource = null;

            function cantusOpenImport() {
                var modal = document.getElementById('cantus-import-modal');
                if (modal.parentNode !== document.body) document.body.appendChild(modal);
                modal.style.display = 'flex';
                _cantusImportSource = null;
                document.getElementById('cantus-import-btn').disabled = true;

                var fd = new FormData();
                fd.append('action', 'cantus_get_import_sources');
                fd.append('nonce', cantusData.nonce);
                fd.append('exclude_messe', _cantusImportTarget);

                fetch(cantusData.ajaxUrl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(resp){
                        var list = document.getElementById('cantus-import-list');
                        if (!resp.success || !resp.data.length) {
                            list.innerHTML = '<p style="color:#9ca3af;text-align:center;">Keine Messen mit Liedern gefunden.</p>';
                            return;
                        }
                        var h = '';
                        resp.data.forEach(function(m){
                            h += '<div class="cantus-import-row" data-id="' + m.id + '" onclick="cantusSelectImportSource(this,' + m.id + ')" style="padding:10px 12px;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:6px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;transition:all 0.15s;">';
                            h += '<span style="font-weight:500;">' + m.label + '</span>';
                            h += '<span style="color:#16a34a;font-size:0.85em;">' + m.songs + ' Lieder</span>';
                            h += '</div>';
                        });
                        list.innerHTML = h;
                    });
            }

            function cantusSelectImportSource(el, id) {
                document.querySelectorAll('.cantus-import-row').forEach(function(r){
                    r.style.borderColor = '#e5e7eb';
                    r.style.background = 'transparent';
                });
                el.style.borderColor = '#16a34a';
                el.style.background = '#f0fdf4';
                _cantusImportSource = id;
                document.getElementById('cantus-import-btn').disabled = false;
            }

            function cantusCloseImport() {
                document.getElementById('cantus-import-modal').style.display = 'none';
            }

            function cantusDoImport() {
                if (!_cantusImportSource) return;
                var btn = document.getElementById('cantus-import-btn');
                btn.disabled = true;
                btn.textContent = 'Importiere…';

                var fd = new FormData();
                fd.append('action', 'cantus_import_songs');
                fd.append('nonce', cantusData.nonce);
                fd.append('source_messe', _cantusImportSource);
                fd.append('target_messe', _cantusImportTarget);
                fd.append('overwrite', document.getElementById('cantus-import-overwrite').checked ? '1' : '0');

                fetch(cantusData.ajaxUrl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(resp){
                        if (resp.success) {
                            cantusCloseImport();
                            location.reload();
                        } else {
                            alert(resp.data && resp.data.message || 'Fehler');
                            btn.disabled = false;
                            btn.textContent = 'Importieren';
                        }
                    });
            }

            document.addEventListener('keydown', function(e){
                if (e.key === 'Escape') cantusCloseImport();
            });
            </script>
            
            <!-- Toast-Container -->
            <div id="cantus-toast" class="cantus-toast"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /* ================================================================
       AJAX: Speichern / Löschen / Suchen
       ================================================================ */
    public function ajax_save_song() {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        $messe_id = intval($_POST['messe_id']);
        $slot_key = intval($_POST['slot_key']);
        $user_id = get_current_user_id();
        
        if (!Cantus_Permissions::can_user_access_messe($user_id, $messe_id, 'edit')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $data = [
            'type' => sanitize_text_field($_POST['type'] ?? 'gl'),
            'number' => sanitize_text_field($_POST['number'] ?? ''),
            'strophes' => sanitize_text_field($_POST['strophes'] ?? ''),
            'free_title' => sanitize_text_field($_POST['free_title'] ?? ''),
        ];
        
        Cantus_DB::save_song($messe_id, $slot_key, $data, $user_id);
        
        // Slot-Name zurückgeben für Toast
        $label = self::$slot_names[$slot_key] ?? "Slot {$slot_key}";
        
        // Titel aus Katalog nachladen für Live-Anzeige
        $song_title = '';
        $song_short = '';
        if ($data['type'] !== 'free' && !empty($data['number'])) {
            $song_title = Cantus_DB::lookup_catalog_title($data['type'], $data['number']);
            $song_short = self::short_title($song_title);
        }
        
        wp_send_json_success([
            'message'    => 'Gespeichert',
            'slot'       => $slot_key,
            'label'      => $label,
            'song_title' => $song_title,
            'song_short' => $song_short,
        ]);
    }
    
    public function ajax_delete_song() {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        $messe_id = intval($_POST['messe_id']);
        $slot_key = intval($_POST['slot_key']);
        $user_id = get_current_user_id();
        
        if (!Cantus_Permissions::can_user_access_messe($user_id, $messe_id, 'edit')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        Cantus_DB::delete_song($messe_id, $slot_key);
        
        $label = self::$slot_names[$slot_key] ?? "Slot {$slot_key}";
        
        wp_send_json_success([
            'message' => 'Gelöscht',
            'slot'    => $slot_key,
            'label'   => $label,
        ]);
    }
    
    public function ajax_catalog_search() {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        if (!current_user_can('isidor_cantus_view')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $filters = [
            'q' => isset($_POST['q']) ? sanitize_text_field($_POST['q']) : '',
            'slot' => isset($_POST['slot']) ? sanitize_text_field($_POST['slot']) : '',
            'mass' => isset($_POST['mass']) ? sanitize_text_field($_POST['mass']) : '',
            'genre' => isset($_POST['genre']) ? sanitize_text_field($_POST['genre']) : '',
            'tag' => isset($_POST['tag']) ? sanitize_text_field($_POST['tag']) : '',
            'theme' => isset($_POST['theme']) ? sanitize_text_field($_POST['theme']) : '',
            'type' => isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'gl'
        ];
        
        $results = Cantus_DB::search_catalog($filters);
        
        wp_send_json_success(['results' => $results]);
    }
    
    /**
     * AJAX: Live Title Lookup — Nummer eingeben → Titel zurück
     */
    public function ajax_lookup_title() {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        if (!current_user_can('isidor_cantus_view')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $type = sanitize_text_field($_POST['type'] ?? 'gl');
        $number = sanitize_text_field($_POST['number'] ?? '');
        
        if ($number === '') {
            wp_send_json_success(['title' => '', 'short' => '']);
            return;
        }
        
        $title = Cantus_DB::lookup_catalog_title($type, $number);
        
        wp_send_json_success([
            'title' => $title,
            'short' => self::short_title($title),
        ]);
    }
    
    /**
     * Kürzt einen Liedtitel auf die ersten ~4 Wörter
     */
    public static function short_title(string $title, int $max_words = 4): string {
        if ($title === '') return '';
        // Klammer-Zusätze am Anfang entfernen (z.B. "(L)" "(G, Rohr)")
        $clean = preg_replace('/^\s*\([^)]*\)\s*/', '', $title);
        if ($clean === '') $clean = $title;
        $words = preg_split('/\s+/', trim($clean));
        if (count($words) <= $max_words) return trim($clean);
        return implode(' ', array_slice($words, 0, $max_words)) . ' …';
    }
    
    private function get_free_songs() {
        $songs = get_option('isidor_cantus_free_songs', '[]');
        return json_decode($songs, true) ?: [];
    }
    
    /* ================================================================
       SAKRISTAN-INTEGRATION: Liedblatt-Info für Sakristei
       ================================================================ */
    public function render_sakristan_liedblatt(string $html, int $messe_id): string {
        $songs = Cantus_DB::get_songs($messe_id);
        if (empty($songs)) {
            return '<p style="color:#94a3b8;font-style:italic;">Noch keine Lieder geplant.</p>';
        }
        
        $out = '<table class="sakr-liedblatt" style="width:100%;border-collapse:collapse;font-size:0.9em;">';
        foreach (self::$slot_names as $slot_key => $slot_name) {
            $song = $songs[$slot_key] ?? null;
            if (!$song) continue;
            
            $type = $song['type'] ?? 'gl';
            $display = '';
            $title = '';
            
            if ($type === 'free') {
                $display = '<em>' . esc_html($song['free_title'] ?? '') . '</em>';
            } else {
                $display = '<strong>' . strtoupper($type) . ' ' . esc_html($song['number'] ?? '') . '</strong>';
                if (!empty($song['strophes'])) {
                    $display .= ' <span style="color:#94a3b8;">(Str. ' . esc_html($song['strophes']) . ')</span>';
                }
                // Titel aus Katalog
                $title = $song['title'] ?? '';
                if ($title) {
                    $short = self::short_title($title);
                    $display .= '<br><span style="color:#718096;font-size:0.85em;font-style:italic;">' . esc_html($short) . '</span>';
                }
            }
            
            $out .= '<tr style="border-bottom:1px solid #e2e8f0;">';
            $out .= '<td style="padding:4px 8px 4px 0;color:#64748b;white-space:nowrap;vertical-align:top;">' . esc_html($slot_name) . '</td>';
            $out .= '<td style="padding:4px 0;vertical-align:top;">' . $display . '</td>';
            $out .= '</tr>';
        }
        $out .= '</table>';
        
        return $out;
    }
    
    /* ================================================================
       KATALOG – Liederkatalog (read-only)
       ================================================================ */
    public function render_katalog() {
        $from = $_GET['from'] ?? date('Y-m-d');
        $to = $_GET['to'] ?? date('Y-m-d', strtotime('+3 months'));
        $batch_id = $_GET['batch'] ?? null;
        
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [[
                'key' => '_is_date',
                'value' => [$from, $to],
                'compare' => 'BETWEEN',
                'type' => 'DATE'
            ]]
        ]);
        
        if ($batch_id) {
            $messen = array_filter($messen, function($m) use ($batch_id) {
                $m_batch = get_post_meta($m->ID, '_is_batch_id', true);
                if (!$m_batch) {
                    $date = get_post_meta($m->ID, '_is_date', true);
                    $m_batch = date('Y-m', strtotime($date));
                }
                return $m_batch === $batch_id;
            });
        }
        
        ob_start();
        ?>
        <div class="cantus-katalog">
            <h2>📚 Liederkatalog</h2>
            
            <?php foreach ($messen as $messe): 
                $date = get_post_meta($messe->ID, '_is_date', true);
                $time = get_post_meta($messe->ID, '_is_time', true);
                $songs = Cantus_DB::get_songs($messe->ID);
                
                // Lesungen
                $lesung1      = get_post_meta($messe->ID, '_is_lesung1', true);
                $antwortpsalm = get_post_meta($messe->ID, '_is_antwortpsalm', true);
                $lesung2      = get_post_meta($messe->ID, '_is_lesung2', true);
                $evangelium    = get_post_meta($messe->ID, '_is_evangelium', true);
                $has_readings  = $lesung1 || $antwortpsalm || $lesung2 || $evangelium;
            ?>
                <div class="cantus-katalog-messe">
                    <div class="cantus-katalog-header">
                        <h3><?php echo date('l, j. F Y', strtotime($date)); ?> · <?php echo esc_html($time); ?></h3>
                        <p><?php echo esc_html($messe->post_title); ?></p>
                    </div>
                    
                    <?php if ($has_readings): ?>
                    <div class="cantus-katalog-readings">
                        <?php if ($lesung1): ?><span><strong>L1:</strong> <?php echo esc_html($lesung1); ?></span><?php endif; ?>
                        <?php if ($antwortpsalm): ?><span><strong>AP:</strong> <?php echo esc_html($antwortpsalm); ?></span><?php endif; ?>
                        <?php if ($lesung2): ?><span><strong>L2:</strong> <?php echo esc_html($lesung2); ?></span><?php endif; ?>
                        <?php if ($evangelium): ?><span><strong>Ev:</strong> <?php echo esc_html($evangelium); ?></span><?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <table class="cantus-katalog-table">
                        <?php for ($i = 1; $i <= 11; $i++): 
                            $song = $songs[$i] ?? null;
                        ?>
                            <tr class="<?php echo $song ? '' : 'cantus-katalog-empty-row'; ?>">
                                <td><strong><?php echo $i; ?>.</strong> <?php echo esc_html(self::$slot_names[$i]); ?></td>
                                <td>
                                    <?php if ($song): ?>
                                        <?php if ($song['type'] === 'free'): ?>
                                            <em><?php echo esc_html($song['free_title']); ?></em>
                                        <?php else: ?>
                                            <strong><?php echo strtoupper($song['type']); ?> <?php echo esc_html($song['number']); ?></strong>
                                            <?php if (!empty($song['strophes'])): ?>
                                                <span class="strophes">(Str. <?php echo esc_html($song['strophes']); ?>)</span>
                                            <?php endif; ?>
                                            <?php 
                                            $display_title = $song['title'] ?? '';
                                            if (!$display_title && !empty($song['number'])) {
                                                $display_title = Cantus_DB::lookup_catalog_title($song['type'] ?? 'gl', $song['number']);
                                            }
                                            if ($display_title): 
                                                $short = self::short_title($display_title);
                                            ?>
                                                <span class="cantus-song-subtitle"><?php echo esc_html($short); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="cantus-katalog-dash">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endfor; ?>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ================================================================
       IMPORT — Lieder aus anderer Messe übernehmen
       ================================================================ */

    /**
     * AJAX: Messen mit Liedern laden (als Import-Quellen)
     */
    public function ajax_get_import_sources(): void {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        if (!current_user_can('isidor_cantus_edit') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $exclude_messe = intval($_POST['exclude_messe'] ?? 0);
        
        global $wpdb;
        // Messen mit mindestens einem Lied, sortiert nach Datum absteigend
        $table = $wpdb->prefix . 'isidor_cantus_songs';
        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT DISTINCT s.messe_id, 
                   p.post_title, 
                   pm_date.meta_value AS messe_date,
                   pm_time.meta_value AS messe_time,
                   COUNT(s.id) AS song_count
            FROM {$table} s
            JOIN {$wpdb->posts} p ON p.ID = s.messe_id AND p.post_type = 'isidor_messe'
            LEFT JOIN {$wpdb->postmeta} pm_date ON pm_date.post_id = s.messe_id AND pm_date.meta_key = '_is_date'
            LEFT JOIN {$wpdb->postmeta} pm_time ON pm_time.post_id = s.messe_id AND pm_time.meta_key = '_is_time'
            WHERE s.messe_id != %d
            GROUP BY s.messe_id
            HAVING song_count > 0
            ORDER BY pm_date.meta_value DESC
            LIMIT 30
        ", $exclude_messe), ARRAY_A);
        
        $sources = [];
        foreach ($rows as $r) {
            $d = $r['messe_date'] ? wp_date('D d.m.Y', strtotime($r['messe_date'])) : '?';
            $sources[] = [
                'id'    => (int) $r['messe_id'],
                'label' => $d . ' ' . ($r['messe_time'] ?? '') . ' — ' . $r['post_title'],
                'songs' => (int) $r['song_count'],
            ];
        }
        
        wp_send_json_success($sources);
    }

    /**
     * AJAX: Lieder aus Quell-Messe in Ziel-Messe kopieren
     */
    public function ajax_import_songs(): void {
        check_ajax_referer('cantus_nonce', 'nonce');
        
        if (!current_user_can('isidor_cantus_edit') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $source_messe = intval($_POST['source_messe'] ?? 0);
        $target_messe = intval($_POST['target_messe'] ?? 0);
        $overwrite = ($_POST['overwrite'] ?? '0') === '1';
        
        if (!$source_messe || !$target_messe) {
            wp_send_json_error(['message' => 'Quell- und Ziel-Messe erforderlich']);
        }
        
        $source_songs = Cantus_DB::get_songs($source_messe);
        if (empty($source_songs)) {
            wp_send_json_error(['message' => 'Keine Lieder in der Quell-Messe']);
        }
        
        $user_id = get_current_user_id();
        $imported = 0;
        $skipped = 0;
        
        foreach ($source_songs as $slot_key => $song) {
            // Prüfen ob Ziel-Slot bereits belegt
            if (!$overwrite) {
                $existing = Cantus_DB::get_songs($target_messe);
                if (isset($existing[$slot_key]) && (!empty($existing[$slot_key]['number']) || !empty($existing[$slot_key]['free_title']))) {
                    $skipped++;
                    continue;
                }
            }
            
            Cantus_DB::save_song($target_messe, $slot_key, [
                'type'       => $song['type'] ?? 'gl',
                'number'     => $song['number'] ?? '',
                'strophes'   => $song['strophes'] ?? '',
                'free_title' => $song['free_title'] ?? '',
            ], $user_id);
            $imported++;
        }
        
        wp_send_json_success([
            'message'  => "{$imported} Lieder importiert" . ($skipped ? ", {$skipped} übersprungen (bereits belegt)" : ''),
            'imported' => $imported,
            'skipped'  => $skipped,
        ]);
    }

    /* ================================================================
       EXPORT HANDLER — PDF & JSON Download
       ================================================================ */
    public function handle_export(): void {
        if (empty($_GET['cantus_export'])) return;
        
        // Debug log
        error_log('[Cantus Export] format=' . ($_GET['cantus_export'] ?? '') . ' user=' . get_current_user_id() . ' logged_in=' . (is_user_logged_in() ? 'yes' : 'no'));
        
        // Capability check mit Fallback für Admins
        if (!is_user_logged_in()) {
            error_log('[Cantus Export] ABORTED: not logged in');
            return;
        }
        $can_export = current_user_can('isidor_cantus_export') || current_user_can('isidor_cantus_view') || current_user_can('manage_options');
        if (!$can_export) {
            error_log('[Cantus Export] ABORTED: no permission');
            return;
        }

        $format = sanitize_text_field($_GET['cantus_export']);
        $from   = sanitize_text_field($_GET['from'] ?? date('Y-m-d'));
        $to     = sanitize_text_field($_GET['to'] ?? date('Y-m-d', strtotime('+28 days')));

        if ($format === 'pdf') {
            require_once ISIDOR_SUITE_PATH . 'includes/cantus/class-cantus-pdf.php';
            Cantus_PDF::generate($from, $to);
            // generate() ruft exit() auf
        }

        if ($format === 'json') {
            $data = Cantus_DB::get_songs_for_period($from, $to);
            $json = [];
            foreach ($data as $messe) {
                $songs_out = [];
                foreach ($messe['songs'] as $sk => $s) {
                    $songs_out[] = [
                        'slot'       => $sk,
                        'slot_name'  => self::$slot_names[$sk] ?? "Slot {$sk}",
                        'type'       => $s['type'] ?? 'gl',
                        'number'     => $s['number'] ?? '',
                        'strophes'   => $s['strophes'] ?? '',
                        'free_title' => $s['free_title'] ?? '',
                        'title'      => $s['title'] ?? '',
                    ];
                }
                $json[] = [
                    'messe_id'    => $messe['messe_id'],
                    'title'       => $messe['messe_title'],
                    'date'        => $messe['messe_date'],
                    'time'        => $messe['messe_time'],
                    'songs'       => $songs_out,
                ];
            }

            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="liedplan_' . $from . '_' . $to . '.json"');
            echo json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /* ================================================================
       AJAX: Titelsuche — "Großer Gott" → alle passenden Lieder
       ================================================================ */
    public function ajax_title_search(): void {
        check_ajax_referer('cantus_nonce', 'nonce');

        if (!current_user_can('isidor_cantus_view')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $q = sanitize_text_field($_POST['q'] ?? '');
        if (mb_strlen($q) < 2) {
            wp_send_json_success(['results' => []]);
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'isidor_cantus_catalog';
        $like  = '%' . $wpdb->esc_like($q) . '%';

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT type, nr_raw, title, genre, composer
                 FROM {$table}
                 WHERE title LIKE %s
                 ORDER BY 
                    CASE WHEN title LIKE %s THEN 0 ELSE 1 END,
                    nr_base ASC, nr_variant ASC
                 LIMIT 25",
                $like,
                $wpdb->esc_like($q) . '%' // Treffer am Anfang zuerst
            ),
            ARRAY_A
        );

        $cleaned = [];
        foreach ($results as $row) {
            $cleaned[] = [
                'type'     => $row['type'] ?? 'gl',
                'nr_raw'   => $row['nr_raw'] ?? '',
                'title'    => $row['title'] ?? '',
                'genre'    => $row['genre'] ?? '',
                'composer' => $row['composer'] ?? '',
            ];
        }

        wp_send_json_success(['results' => $cleaned]);
    }

    /* ================================================================
       SHORTCODE: Liedsuche — [cantus_search]
       Frontend-Suchmaske für den Katalog
       ================================================================ */
    public function render_search(): string {
        if (!is_user_logged_in() || !current_user_can('isidor_cantus_view')) {
            return '<p>Keine Berechtigung.</p>';
        }

        ob_start();
        ?>
        <div class="cantus-search-app">
            <div class="cantus-search-header">
                <h2>🔍 Liedsuche</h2>
                <p>Suche nach Titel, Nummer oder Stichwort im Gotteslob-Katalog.</p>
            </div>

            <div class="cantus-search-box">
                <div class="cantus-search-input-wrap">
                    <input type="text" id="cantus-search-input" 
                           placeholder="Titel eingeben, z.B. &quot;Großer Gott&quot; oder &quot;Lobe den Herren&quot;…" 
                           class="cantus-search-input" autocomplete="off">
                    <div class="cantus-search-spinner" id="cantus-search-spinner" style="display:none;">⏳</div>
                </div>
                <div class="cantus-search-hint">Mindestens 2 Zeichen · Ergebnisse erscheinen automatisch</div>
            </div>

            <div id="cantus-search-results" class="cantus-search-results"></div>

            <!-- Toast -->
            <div id="cantus-toast" class="cantus-toast"></div>
        </div>
        <?php
        return ob_get_clean();
    }
}

