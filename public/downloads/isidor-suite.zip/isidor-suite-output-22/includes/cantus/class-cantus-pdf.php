<?php
/**
 * Cantus PDF — Liedplan DIN A4 Querformat
 * 
 * Optimiertes Layout:
 *   - A4 quer (297 x 210 mm), 5mm Rand
 *   - Nutzbar: 287mm
 *   - Messe-Info: 42mm, 11 Slots je ~22.3mm
 *   - Dunkler Header, alternating rows, Sonntage blau
 *   - Titel in Zeile 2 grau/kursiv, max 16 Zeichen
 */
class Cantus_PDF {
    
    private static array $slot_names = [
        1 => 'Einzug',     2 => 'Kyrie',     3 => 'Gloria',
        4 => 'Antiphon',   5 => 'Ruf v.d.E', 6 => 'Offert.',
        7 => 'Sanctus',    8 => 'Agnus Dei', 9 => 'Kommun.',
        10 => 'Danklied',  11 => 'Schluss'
    ];
    
    // Page (mm) — A4 landscape
    private const PW  = 297;
    private const PH  = 210;
    private const ML  = 5;
    private const MR  = 5;
    private const MT  = 12;
    private const MB  = 8;
    
    // Column widths
    private const INFO_W = 42;
    private const SLOT_W = 22.27;   // (297-5-5-42) / 11 = 22.27
    
    private const HEADER_H = 7;
    private const ROW_H    = 9;
    
    /**
     * PDF generieren und als Download senden
     */
    public static function generate(string $from, string $to): void {
        try {
            $fpdf_path = self::find_fpdf();
            if (!$fpdf_path) {
                wp_die('FPDF nicht gefunden. Bitte fpdf.php nach isidor-suite/lib/fpdf/ kopieren.');
            }
            require_once $fpdf_path;

            $data = Cantus_DB::get_songs_for_period($from, $to);
            if (empty($data)) {
                wp_die('Keine Messen im Zeitraum.');
            }

            while (ob_get_level()) { ob_end_clean(); }
            
            $parish = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : get_bloginfo('name');
            $from_f = self::fdate($from);
            $to_f   = self::fdate($to);
            $uw     = self::PW - self::ML - self::MR;  // 287
            
            $pdf = new FPDF('L', 'mm', 'A4');
            $pdf->SetAutoPageBreak(false);
            $pdf->SetMargins(self::ML, self::MT, self::MR);
            
            // Calculate rows per page
            $title_h  = 11;  // title block height
            $footer_h = 6;
            $body_h   = self::PH - self::MT - $title_h - self::HEADER_H - self::MB - $footer_h;
            $rpp      = (int) floor($body_h / self::ROW_H);
            
            $total = count($data);
            $ri = 0;
            $pn = 0;
            
            while ($ri < $total) {
                $pdf->AddPage();
                $pn++;
                
                // ── Title ──
                $pdf->SetXY(self::ML, self::MT);
                $pdf->SetFont('Helvetica', 'B', 13);
                $pdf->Cell($uw * 0.6, 8, self::s('Liedplan ' . $parish), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 9);
                $pdf->Cell($uw * 0.4, 8, self::s($from_f . '  -  ' . $to_f), 0, 1, 'R');
                
                // Separator line
                $pdf->SetDrawColor(200, 200, 200);
                $pdf->SetLineWidth(0.3);
                $sep_y = $pdf->GetY() + 0.5;
                $pdf->Line(self::ML, $sep_y, self::ML + $uw, $sep_y);
                
                // ── Header ──
                $hy = $sep_y + 1;
                self::renderHeader($pdf, $hy, $uw);
                
                // ── Rows ──
                $cy = $hy + self::HEADER_H;
                $row_n = 0;
                
                while ($ri < $total && $row_n < $rpp) {
                    self::renderRow($pdf, $cy, $data[$ri], $row_n);
                    $cy += self::ROW_H;
                    $ri++;
                    $row_n++;
                }
                
                // Fill empty rows
                while ($row_n < $rpp) {
                    self::renderEmptyRow($pdf, $cy, $row_n);
                    $cy += self::ROW_H;
                    $row_n++;
                }
                
                // ── Footer ──
                $pdf->SetFont('Helvetica', '', 6);
                $pdf->SetTextColor(140, 140, 140);
                $pdf->SetXY(self::ML, self::PH - self::MB);
                $pdf->Cell($uw, 4, self::s($parish . '  |  Liedplan  |  ' . date('d.m.Y') . '  |  Seite ' . $pn), 0, 0, 'C');
                $pdf->SetTextColor(0, 0, 0);
            }
            
            $fn = 'Liedplan_' . str_replace('-', '', $from) . '_' . str_replace('-', '', $to) . '.pdf';
            $pdf->Output('D', $fn);
            exit;
        } catch (\Throwable $e) {
            error_log('[Cantus PDF ERROR] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            wp_die('PDF-Fehler: ' . esc_html($e->getMessage()));
        }
    }
    
    // ─── Header ───
    
    private static function renderHeader($p, float $y): void {
        $x = self::ML;
        
        $p->SetFillColor(45, 50, 58);
        $p->SetTextColor(255, 255, 255);
        $p->SetDrawColor(45, 50, 58);
        $p->SetLineWidth(0.1);
        
        // Messe column
        $p->SetFont('Helvetica', 'B', 7.5);
        $p->Rect($x, $y, self::INFO_W, self::HEADER_H, 'F');
        $p->SetXY($x + 1.5, $y + 1.5);
        $p->Cell(self::INFO_W - 3, 4, 'Messe', 0, 0, 'L');
        $x += self::INFO_W;
        
        // Slot columns
        for ($i = 1; $i <= 11; $i++) {
            $p->Rect($x, $y, self::SLOT_W, self::HEADER_H, 'F');
            $nm = self::$slot_names[$i];
            $sz = (mb_strlen($nm) > 7) ? 6 : 7;
            $p->SetFont('Helvetica', 'B', $sz);
            $p->SetXY($x, $y + 1.5);
            $p->Cell(self::SLOT_W, 4, self::s($nm), 0, 0, 'C');
            $x += self::SLOT_W;
        }
        
        $p->SetTextColor(0, 0, 0);
    }
    
    // ─── Data Row ───
    
    private static function renderRow($p, float $y, array $m, int $n): void {
        $x = self::ML;
        $date = $m['messe_date'] ?? '';
        $time = $m['messe_time'] ?? '';
        $sun  = $date && (int) date('w', strtotime($date)) === 0;
        
        // Row background
        if ($sun)           { $p->SetFillColor(232, 240, 254); }
        elseif ($n % 2 == 0){ $p->SetFillColor(248, 248, 248); }
        else                { $p->SetFillColor(255, 255, 255); }
        
        $p->SetDrawColor(215, 215, 215);
        $p->SetLineWidth(0.1);
        
        // ── Messe-Info ──
        $p->Rect($x, $y, self::INFO_W, self::ROW_H, 'FD');
        
        // Date
        $p->SetFont('Helvetica', ($sun ? 'B' : ''), 7);
        $ds = $date ? self::sday($date) . ' ' . date('d.m.y', strtotime($date)) : '';
        $p->SetXY($x + 1, $y + 0.5);
        $p->Cell(26, 3.5, self::s($ds), 0, 0, 'L');
        
        // Time
        $ts = $time ? substr($time, 0, 5) : '';
        $p->SetFont('Helvetica', '', 7);
        $p->SetXY($x + 27, $y + 0.5);
        $p->Cell(14, 3.5, self::s($ts), 0, 0, 'R');
        
        // Liturgical name
        $mid = (int) ($m['messe_id'] ?? 0);
        $lit = $mid ? (get_post_meta($mid, '_is_liturgical', true) ?: '') : '';
        $sub = $lit ?: self::t($m['messe_title'] ?? '', 30);
        $spc = $mid ? (bool) get_post_meta($mid, '_is_special', true) : false;
        if ($spc && $sub) $sub = '* ' . $sub;
        
        if ($sub) {
            $p->SetFont('Helvetica', 'I', 6);
            $p->SetTextColor(100, 100, 100);
            $p->SetXY($x + 1, $y + 4.3);
            $p->Cell(self::INFO_W - 2, 3.5, self::s(self::t($sub, 30)), 0, 0, 'L');
            $p->SetTextColor(0, 0, 0);
        }
        $x += self::INFO_W;
        
        // ── Song Cells ──
        $songs = $m['songs'] ?? [];
        for ($i = 1; $i <= 11; $i++) {
            $p->Rect($x, $y, self::SLOT_W, self::ROW_H, 'FD');
            if (isset($songs[$i])) {
                self::renderSong($p, $x, $y, $songs[$i]);
            }
            $x += self::SLOT_W;
        }
    }
    
    // ─── Song Cell ───
    
    private static function renderSong($p, float $x, float $y, array $s): void {
        $w = self::SLOT_W;
        
        // Free text
        if (($s['type'] ?? '') === 'free') {
            $p->SetFont('Helvetica', 'I', 6.5);
            $p->SetTextColor(80, 80, 80);
            $p->SetXY($x + 0.3, $y + 2);
            $p->Cell($w - 0.6, 5, self::s(self::t($s['free_title'] ?? '', 18)), 0, 0, 'C');
            $p->SetTextColor(0, 0, 0);
            return;
        }
        
        $type = strtoupper($s['type'] ?? 'GL');
        $nr   = trim($s['number'] ?? '');
        $str  = trim($s['strophes'] ?? '');
        if (!$nr) return;
        
        // Line 1: "GL 155" bold + strophes small
        $nr_text = self::s($type . ' ' . $nr);
        $p->SetFont('Helvetica', 'B', 8.5);
        $nw = $p->GetStringWidth($nr_text);
        
        $show_str = '';
        if ($str) {
            $p->SetFont('Helvetica', '', 5.5);
            $show_str = self::s($str);
            $sw = $p->GetStringWidth($show_str);
            if ($nw + $sw + 1.5 > $w - 1) {
                $show_str = ''; // Doesn't fit
            }
        }
        
        if ($show_str) {
            // Number + strophes
            $p->SetFont('Helvetica', '', 5.5);
            $sw = $p->GetStringWidth($show_str);
            $tw = $nw + $sw + 1;
            $sx = $x + ($w - $tw) / 2;
            
            $p->SetFont('Helvetica', 'B', 8.5);
            $p->SetXY($sx, $y + 0.3);
            $p->Cell($nw, 4, $nr_text, 0, 0, 'L');
            
            $p->SetFont('Helvetica', '', 5.5);
            $p->SetTextColor(100, 100, 100);
            $p->SetXY($sx + $nw + 0.5, $y + 1.2);
            $p->Cell(0, 3, $show_str, 0, 0, 'L');
            $p->SetTextColor(0, 0, 0);
        } else {
            // Number only
            $p->SetFont('Helvetica', 'B', 8.5);
            $p->SetXY($x + 0.3, $y + 0.3);
            $p->Cell($w - 0.6, 4, $nr_text, 0, 0, 'C');
        }
        
        // Line 2: Title (small italic gray)
        $title = $s['title'] ?? '';
        if (!$title && $nr) {
            $title = Cantus_DB::lookup_catalog_title($s['type'] ?? 'gl', $nr);
        }
        if ($title) {
            $p->SetFont('Helvetica', 'I', 5.5);
            $p->SetTextColor(130, 130, 130);
            $p->SetXY($x + 0.3, $y + 4.8);
            $p->Cell($w - 0.6, 3.5, self::s(self::t($title, 17)), 0, 0, 'C');
            $p->SetTextColor(0, 0, 0);
        }
    }
    
    // ─── Empty Row ───
    
    private static function renderEmptyRow($p, float $y, int $n): void {
        $x = self::ML;
        $p->SetFillColor($n % 2 == 0 ? 248 : 255, $n % 2 == 0 ? 248 : 255, $n % 2 == 0 ? 248 : 255);
        $p->SetDrawColor(230, 230, 230);
        $p->SetLineWidth(0.1);
        
        $p->Rect($x, $y, self::INFO_W, self::ROW_H, 'FD');
        $x += self::INFO_W;
        for ($i = 1; $i <= 11; $i++) {
            $p->Rect($x, $y, self::SLOT_W, self::ROW_H, 'FD');
            $x += self::SLOT_W;
        }
    }
    
    // ─── Helpers ───
    
    private static function find_fpdf() {
        $base = defined('ISIDOR_SUITE_PATH') ? ISIDOR_SUITE_PATH : dirname(__DIR__, 2) . '/';
        foreach ([
            $base . 'lib/fpdf/fpdf.php',
            $base . 'lib/fpdf.php',
            ABSPATH . 'wp-content/plugins/fpdf/fpdf.php',
        ] as $p) {
            if (file_exists($p)) return $p;
        }
        return null;
    }
    
    /** UTF-8 -> Latin-1 */
    private static function s(string $t): string {
        if ($t === '') return $t;
        if (function_exists('iconv')) {
            $c = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $t);
            if ($c !== false) return $c;
        }
        $t = str_replace(
            ["\xE2\x80\x93","\xE2\x80\x94","\xE2\x80\xA6","\xE2\x80\xA2",
             "\xE2\x80\x9E","\xE2\x80\x9C","\xE2\x80\x9D","\xE2\x80\x98",
             "\xE2\x80\x99","\xE2\x80\xA0","\xC2\xA0"],
            ['-','-','...','*','"','"','"',"'","'",'+',' '], $t
        );
        return mb_convert_encoding($t, 'ISO-8859-1', 'UTF-8');
    }
    
    private static function fdate(string $d): string {
        $m = ['','Jaenner','Februar','Maerz','April','Mai','Juni',
              'Juli','August','September','Oktober','November','Dezember'];
        $ts = strtotime($d);
        return (int)date('j',$ts) . '. ' . $m[(int)date('n',$ts)] . ' ' . date('Y',$ts);
    }
    
    private static function sday(string $d): string {
        return ['So','Mo','Di','Mi','Do','Fr','Sa'][(int) date('w', strtotime($d))];
    }
    
    private static function t(string $t, int $m): string {
        return mb_strlen($t) <= $m ? $t : mb_substr($t, 0, $m - 1) . '.';
    }
}
