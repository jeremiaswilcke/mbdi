<?php
/**
 * Cantus Permissions
 */
class Cantus_Permissions {
    
    /**
     * Prüfe ob User Messe sehen darf
     */
    public static function can_user_access_messe($user_id, $messe_id, $mode = 'view') {
        $user = get_userdata($user_id);
        
        if (!$user) {
            return false;
        }
        
        // Capability-Prüfung
        $cap = 'isidor_cantus_' . $mode;
        if (!user_can($user_id, $cap)) {
            return false;
        }
        
        // Rollen die IMMER alles sehen
        $full_access_roles = [
            'administrator',
            'isidor_pfarrer',
            'isidor_sekretaer',
            'isidor_diakon',
            'isidor_orgel',
            'isidor_technik'
        ];
        
        foreach ($full_access_roles as $role) {
            if (in_array($role, $user->roles)) {
                return true;
            }
        }
        
        // Delegation prüfen
        $delegate_mode = get_post_meta($messe_id, '_isidor_delegate_mode', true);
        $delegate_users = get_post_meta($messe_id, '_isidor_delegate_users', true);
        
        if (!$delegate_users || !is_array($delegate_users)) {
            $delegate_users = [];
        }
        
        // none: Jeder mit Cap darf
        if ($delegate_mode !== 'exclusive') {
            return true;
        }
        
        // exclusive: Nur delegierte User
        return in_array($user_id, $delegate_users);
    }
    
    /**
     * Hole Messen die User sehen darf
     */
    public static function get_accessible_messen($user_id, $from_date, $to_date) {
        $user = get_userdata($user_id);
        
        if (!$user || !user_can($user_id, 'isidor_cantus_view')) {
            return [];
        }
        
        // Volle Rechte?
        $full_access_roles = [
            'administrator',
            'isidor_pfarrer',
            'isidor_sekretaer',
            'isidor_diakon',
            'isidor_orgel',
            'isidor_technik'
        ];
        
        $has_full_access = false;
        foreach ($full_access_roles as $role) {
            if (in_array($role, $user->roles)) {
                $has_full_access = true;
                break;
            }
        }
        
        // Alle Messen holen
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [[
                'key' => '_is_date',
                'value' => [$from_date, $to_date],
                'compare' => 'BETWEEN',
                'type' => 'DATE'
            ]]
        ]);
        
        if ($has_full_access) {
            return $messen;
        }
        
        // Nur exclusive delegierte Messen
        $accessible = [];
        
        foreach ($messen as $messe) {
            $delegate_mode = get_post_meta($messe->ID, '_isidor_delegate_mode', true);
            $delegate_users = get_post_meta($messe->ID, '_isidor_delegate_users', true);
            
            if ($delegate_mode !== 'exclusive') {
                $accessible[] = $messe;
            } elseif (is_array($delegate_users) && in_array($user_id, $delegate_users)) {
                $accessible[] = $messe;
            }
        }
        
        return $accessible;
    }
}
