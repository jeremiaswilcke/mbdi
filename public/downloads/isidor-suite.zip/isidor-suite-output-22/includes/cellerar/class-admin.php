<?php
/**
 * Admin functionality for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Admin
 * Handles admin panel and settings
 */
class Isidor_Cellerar_Admin {

    /**
     * Initialize admin functionality
     */
    public static function init(): void {
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
    }

    /**
     * Add admin menu
     */
    public static function add_menu(): void {
        add_menu_page(
            __('Isidor Cellerar', 'isidor-cellerar'),
            __('Cellerar', 'isidor-cellerar'),
            'isidor_cellerar_read',
            'isidor-cellerar',
            [self::class, 'render_dashboard'],
            'dashicons-money-alt',
            30
        );

        add_submenu_page(
            'isidor-cellerar',
            __('Dashboard', 'isidor-cellerar'),
            __('Dashboard', 'isidor-cellerar'),
            'isidor_cellerar_read',
            'isidor-cellerar',
            [self::class, 'render_dashboard']
        );

        add_submenu_page(
            'isidor-cellerar',
            __('Audit-Log', 'isidor-cellerar'),
            __('Audit-Log', 'isidor-cellerar'),
            'isidor_cellerar_manage_settings',
            'isidor-cellerar-audit',
            [self::class, 'render_audit']
        );

        add_submenu_page(
            'isidor-cellerar',
            __('Einstellungen', 'isidor-cellerar'),
            __('Einstellungen', 'isidor-cellerar'),
            'isidor_cellerar_manage_settings',
            'isidor-cellerar-settings',
            [self::class, 'render_settings']
        );
    }

    /**
     * Enqueue admin scripts
     */
    public static function enqueue_scripts(string $hook): void {
        if (strpos($hook, 'isidor-cellerar') === false) {
            return;
        }

        wp_enqueue_style(
            'isidor-cellerar-admin',
            ISIDOR_SUITE_URL . 'assets/css/admin.css',
            [],
            ISIDOR_CELLERAR_VERSION
        );
    }

    /**
     * Render dashboard page
     */
    public static function render_dashboard(): void {
        $summary = Isidor_Cellerar_Statistics::get_summary();
        $open_expenses = Isidor_Cellerar_Statistics::get_open_expenses_summary();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Isidor Cellerar Dashboard', 'isidor-cellerar'); ?></h1>

            <div class="ic-admin-cards">
                <div class="ic-admin-card ic-admin-card-income">
                    <h3><?php esc_html_e('Einnahmen', 'isidor-cellerar'); ?></h3>
                    <p class="ic-admin-card-value"><?php echo esc_html($summary['income_formatted']); ?></p>
                </div>
                <div class="ic-admin-card ic-admin-card-expense">
                    <h3><?php esc_html_e('Ausgaben', 'isidor-cellerar'); ?></h3>
                    <p class="ic-admin-card-value"><?php echo esc_html($summary['expense_formatted']); ?></p>
                </div>
                <div class="ic-admin-card ic-admin-card-balance">
                    <h3><?php esc_html_e('Saldo', 'isidor-cellerar'); ?></h3>
                    <p class="ic-admin-card-value"><?php echo esc_html($summary['balance_formatted']); ?></p>
                </div>
                <div class="ic-admin-card ic-admin-card-pending">
                    <h3><?php esc_html_e('Offene Ausgaben', 'isidor-cellerar'); ?></h3>
                    <p class="ic-admin-card-value"><?php echo esc_html($open_expenses['total_open']['count']); ?> (<?php echo esc_html($open_expenses['total_open']['formatted']); ?>)</p>
                </div>
            </div>

            <div class="ic-admin-info">
                <h2><?php esc_html_e('Frontend-Nutzung', 'isidor-cellerar'); ?></h2>
                <p><?php esc_html_e('Fügen Sie einen der folgenden Shortcodes in eine Seite ein:', 'isidor-cellerar'); ?></p>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Shortcode', 'isidor-cellerar'); ?></th>
                            <th><?php esc_html_e('Beschreibung', 'isidor-cellerar'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[isidor_cellerar_app]</code></td>
                            <td><?php esc_html_e('Vollständige Finanz-App mit allen Tabs (Einnahmen, Ausgaben, Statistik, Export)', 'isidor-cellerar'); ?></td>
                        </tr>
                        <tr>
                            <td><code>[isidor_cellerar_my_submissions]</code></td>
                            <td><?php esc_html_e('Zeigt nur die eigenen Ausgaben-Einreichungen des angemeldeten Benutzers', 'isidor-cellerar'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="ic-admin-info">
                <h2><?php esc_html_e('Berechtigungen', 'isidor-cellerar'); ?></h2>
                <p><?php esc_html_e('Die folgenden Capabilities steuern den Zugriff:', 'isidor-cellerar'); ?></p>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Capability', 'isidor-cellerar'); ?></th>
                            <th><?php esc_html_e('Beschreibung', 'isidor-cellerar'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (Isidor_Cellerar_Roles::get_capabilities() as $cap): ?>
                        <tr>
                            <td><code><?php echo esc_html($cap); ?></code></td>
                            <td><?php echo esc_html(Isidor_Cellerar_Roles::get_capability_label($cap)); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Render audit log page
     */
    public static function render_audit(): void {
        $page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $per_page = 50;
        $offset = ($page - 1) * $per_page;

        $logs = Isidor_Cellerar_Audit::get_logs([
            'limit' => $per_page,
            'offset' => $offset,
        ]);
        $total = Isidor_Cellerar_Audit::get_logs_count([]);
        $total_pages = ceil($total / $per_page);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Audit-Log', 'isidor-cellerar'); ?></h1>
            
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Zeitpunkt', 'isidor-cellerar'); ?></th>
                        <th><?php esc_html_e('Aktion', 'isidor-cellerar'); ?></th>
                        <th><?php esc_html_e('Entität', 'isidor-cellerar'); ?></th>
                        <th><?php esc_html_e('Benutzer', 'isidor-cellerar'); ?></th>
                        <th><?php esc_html_e('IP', 'isidor-cellerar'); ?></th>
                        <th><?php esc_html_e('Details', 'isidor-cellerar'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="6"><?php esc_html_e('Keine Einträge gefunden.', 'isidor-cellerar'); ?></td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo esc_html(gmdate('d.m.Y H:i:s', strtotime($log['created_at']))); ?></td>
                        <td><?php echo esc_html(Isidor_Cellerar_Audit::get_action_label($log['action'])); ?></td>
                        <td>
                            <?php echo esc_html(Isidor_Cellerar_Audit::get_entity_type_label($log['entity_type'])); ?>
                            <?php if ($log['entity_id']): ?>
                            <code>#<?php echo esc_html($log['entity_id']); ?></code>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                            $user = get_userdata($log['user_id']);
                            echo esc_html($user ? $user->display_name : '#' . $log['user_id']);
                            ?>
                        </td>
                        <td><code><?php echo esc_html($log['ip_address'] ?? '-'); ?></code></td>
                        <td><?php echo esc_html($log['details'] ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if ($total_pages > 1): ?>
            <div class="tablenav">
                <div class="tablenav-pages">
                    <?php
                    echo paginate_links([
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $page,
                    ]);
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render settings page
     */
    public static function render_settings(): void {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Isidor Cellerar Einstellungen', 'isidor-cellerar'); ?></h1>
            
            <div class="ic-admin-info">
                <h2><?php esc_html_e('Plugin-Status', 'isidor-cellerar'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Version', 'isidor-cellerar'); ?></th>
                        <td><?php echo esc_html(ISIDOR_CELLERAR_VERSION); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Datenbank-Tabellen', 'isidor-cellerar'); ?></th>
                        <td>
                            <?php if (Isidor_Cellerar_Database::tables_exist()): ?>
                            <span style="color: green;">✓ <?php esc_html_e('Vorhanden', 'isidor-cellerar'); ?></span>
                            <?php else: ?>
                            <span style="color: red;">✗ <?php esc_html_e('Fehlen', 'isidor-cellerar'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('CPT isidor_messe', 'isidor-cellerar'); ?></th>
                        <td>
                            <?php if (post_type_exists('isidor_messe')): ?>
                            <span style="color: green;">✓ <?php esc_html_e('Vorhanden', 'isidor-cellerar'); ?></span>
                            <?php else: ?>
                            <span style="color: orange;">⚠ <?php esc_html_e('Nicht vorhanden (Pfarrcafé eingeschränkt)', 'isidor-cellerar'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="ic-admin-info">
                <h2><?php esc_html_e('Rollen-Mapping', 'isidor-cellerar'); ?></h2>
                <p><?php esc_html_e('Die folgenden Rollen haben standardmäßig Zugriff:', 'isidor-cellerar'); ?></p>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Rolle', 'isidor-cellerar'); ?></th>
                            <th><?php esc_html_e('Berechtigungen', 'isidor-cellerar'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (Isidor_Cellerar_Roles::get_role_capabilities() as $role => $caps): ?>
                        <tr>
                            <td><code><?php echo esc_html($role); ?></code></td>
                            <td>
                                <?php 
                                $labels = array_map(function($cap) {
                                    return Isidor_Cellerar_Roles::get_capability_label($cap);
                                }, $caps);
                                echo esc_html(implode(', ', $labels)); 
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}
