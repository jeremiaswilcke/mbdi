<?php
/**
 * Audit logging for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Audit
 * Handles revision-safe audit logging for all operations
 */
class Isidor_Cellerar_Audit {

    /**
     * Log an action
     *
     * @param string $action Action performed (create, update, delete, export, status_change, etc.)
     * @param string $entity_type Type of entity (entry, expense, file)
     * @param int $entity_id ID of the entity
     * @param array|null $old_values Previous values (for updates)
     * @param array|null $new_values New values (for creates/updates)
     * @param string|null $details Additional details
     */
    public static function log(
        string $action,
        string $entity_type,
        int $entity_id,
        ?array $old_values = null,
        ?array $new_values = null,
        ?string $details = null
    ) {
        global $wpdb;
        
        $user_id = get_current_user_id();
        $ip_address = self::get_client_ip();
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) 
            ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) 
            : null;
        
        // Limit user agent length
        if ($user_agent !== null && strlen($user_agent) > 500) {
            $user_agent = substr($user_agent, 0, 500);
        }
        
        $table = Isidor_Cellerar_Database::get_audit_table();
        
        $result = $wpdb->insert(
            $table,
            [
                'action' => $action,
                'entity_type' => $entity_type,
                'entity_id' => $entity_id,
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'user_agent' => $user_agent,
                'old_values' => $old_values !== null ? wp_json_encode($old_values) : null,
                'new_values' => $new_values !== null ? wp_json_encode($new_values) : null,
                'details' => $details,
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            error_log('Isidor Cellerar: Failed to log audit entry - ' . $wpdb->last_error);
            return false;
        }
        
        return (int) $wpdb->insert_id;
    }

    /**
     * Log entry creation
     */
    public static function log_entry_created(int $entry_id, array $data) {
        return self::log('create', 'entry', $entry_id, null, $data);
    }

    /**
     * Log entry update
     */
    public static function log_entry_updated(int $entry_id, array $old_data, array $new_data) {
        return self::log('update', 'entry', $entry_id, $old_data, $new_data);
    }

    /**
     * Log entry deletion
     */
    public static function log_entry_deleted(int $entry_id, array $data) {
        return self::log('delete', 'entry', $entry_id, $data, null);
    }

    /**
     * Log expense status change
     */
    public static function log_status_change(
        int $expense_id,
        string $old_status,
        string $new_status,
        ?string $reason = null
    ) {
        $details = $reason !== null 
            ? sprintf(__('Status geändert: %s → %s. Grund: %s', 'isidor-cellerar'), $old_status, $new_status, $reason)
            : sprintf(__('Status geändert: %s → %s', 'isidor-cellerar'), $old_status, $new_status);
        
        return self::log(
            'status_change',
            'expense',
            $expense_id,
            ['status' => $old_status],
            ['status' => $new_status],
            $details
        );
    }

    /**
     * Log file upload
     */
    public static function log_file_uploaded(int $file_id, int $entry_id, string $filename) {
        return self::log(
            'upload',
            'file',
            $file_id,
            null,
            ['entry_id' => $entry_id, 'filename' => $filename],
            sprintf(__('Datei hochgeladen: %s', 'isidor-cellerar'), $filename)
        );
    }

    /**
     * Log file deletion
     */
    public static function log_file_deleted(int $file_id, string $filename) {
        return self::log(
            'delete',
            'file',
            $file_id,
            ['filename' => $filename],
            null,
            sprintf(__('Datei gelöscht: %s', 'isidor-cellerar'), $filename)
        );
    }

    /**
     * Log export action
     */
    public static function log_export(string $format, array $filters, int $record_count) {
        return self::log(
            'export',
            'data',
            0,
            null,
            [
                'format' => $format,
                'filters' => $filters,
                'record_count' => $record_count,
            ],
            sprintf(
                __('Export durchgeführt: %d Datensätze im Format %s', 'isidor-cellerar'),
                $record_count,
                strtoupper($format)
            )
        );
    }

    /**
     * Get audit log entries
     *
     * @param array $args Query arguments
     */
    public static function get_logs(array $args = []): array {
        global $wpdb;
        
        $defaults = [
            'entity_type' => null,
            'entity_id' => null,
            'action' => null,
            'user_id' => null,
            'date_from' => null,
            'date_to' => null,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'created_at',
            'order' => 'DESC',
        ];
        
        $args = wp_parse_args($args, $defaults);
        $table = Isidor_Cellerar_Database::get_audit_table();
        
        $where = ['1=1'];
        $values = [];
        
        if ($args['entity_type'] !== null) {
            $where[] = 'entity_type = %s';
            $values[] = $args['entity_type'];
        }
        
        if ($args['entity_id'] !== null) {
            $where[] = 'entity_id = %d';
            $values[] = $args['entity_id'];
        }
        
        if ($args['action'] !== null) {
            $where[] = 'action = %s';
            $values[] = $args['action'];
        }
        
        if ($args['user_id'] !== null) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }
        
        if ($args['date_from'] !== null) {
            $where[] = 'created_at >= %s';
            $values[] = $args['date_from'];
        }
        
        if ($args['date_to'] !== null) {
            $where[] = 'created_at <= %s';
            $values[] = $args['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Sanitize orderby
        $allowed_orderby = ['created_at', 'action', 'entity_type', 'user_id'];
        $orderby = in_array($args['orderby'], $allowed_orderby, true) ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);
        
        $sql = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $values[] = $limit;
        $values[] = $offset;
        
        if (!empty($values)) {
            $sql = $wpdb->prepare($sql, $values);
        }
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        // Decode JSON values
        foreach ($results as &$row) {
            if (!empty($row['old_values'])) {
                $row['old_values'] = json_decode($row['old_values'], true);
            }
            if (!empty($row['new_values'])) {
                $row['new_values'] = json_decode($row['new_values'], true);
            }
        }
        
        return $results ?: [];
    }

    /**
     * Get audit log count
     */
    public static function get_logs_count(array $args = []): int {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_audit_table();
        
        $where = ['1=1'];
        $values = [];
        
        if (!empty($args['entity_type'])) {
            $where[] = 'entity_type = %s';
            $values[] = $args['entity_type'];
        }
        
        if (!empty($args['entity_id'])) {
            $where[] = 'entity_id = %d';
            $values[] = $args['entity_id'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        $sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_clause}";
        
        if (!empty($values)) {
            $sql = $wpdb->prepare($sql, $values);
        }
        
        return (int) $wpdb->get_var($sql);
    }

    /**
     * Get client IP address
     */
    private static function get_client_ip(){
        $ip_keys = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = sanitize_text_field(wp_unslash($_SERVER[$key]));
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ips = explode(',', $ip);
                    $ip = trim($ips[0]);
                }
                // Validate IP
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return null;
    }

    /**
     * Get action label for display
     */
    public static function get_action_label(string $action): string {
        $labels = [
            'create' => __('Erstellt', 'isidor-cellerar'),
            'update' => __('Aktualisiert', 'isidor-cellerar'),
            'delete' => __('Gelöscht', 'isidor-cellerar'),
            'status_change' => __('Status geändert', 'isidor-cellerar'),
            'upload' => __('Hochgeladen', 'isidor-cellerar'),
            'export' => __('Exportiert', 'isidor-cellerar'),
        ];
        
        return $labels[$action] ?? $action;
    }

    /**
     * Get entity type label for display
     */
    public static function get_entity_type_label(string $entity_type): string {
        $labels = [
            'entry' => __('Eintrag', 'isidor-cellerar'),
            'expense' => __('Ausgabe', 'isidor-cellerar'),
            'file' => __('Datei', 'isidor-cellerar'),
            'data' => __('Daten', 'isidor-cellerar'),
        ];
        
        return $labels[$entity_type] ?? $entity_type;
    }

    /**
     * Clean old audit logs (optional maintenance)
     *
     * @param int $days_to_keep Number of days to keep logs
     */
    public static function cleanup_old_logs(int $days_to_keep = 365): int {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_audit_table();
        $cutoff_date = gmdate('Y-m-d H:i:s', strtotime("-{$days_to_keep} days"));
        
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE created_at < %s",
                $cutoff_date
            )
        );
        
        return $deleted !== false ? $deleted : 0;
    }
}
