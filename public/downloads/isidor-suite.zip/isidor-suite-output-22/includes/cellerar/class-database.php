<?php
/**
 * Database management for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Database
 * Handles all database operations including table creation and schema management
 */
class Isidor_Cellerar_Database {

    /**
     * Get the entries table name
     */
    public static function get_entries_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_cellerar_entries';
    }

    /**
     * Get the expenses table name
     */
    public static function get_expenses_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_cellerar_expenses';
    }

    /**
     * Get the files table name
     */
    public static function get_files_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_cellerar_files';
    }

    /**
     * Get the audit table name
     */
    public static function get_audit_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_cellerar_audit';
    }

    /**
     * Create all database tables
     */
    public static function create_tables(): void {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        // Entries table (income records)
        $entries_table = self::get_entries_table();
        $sql_entries = "CREATE TABLE {$entries_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            type ENUM('income', 'expense') NOT NULL DEFAULT 'income',
            subtype VARCHAR(50) NOT NULL,
            messe_id BIGINT UNSIGNED NULL,
            entry_date DATE NOT NULL,
            amount_cents BIGINT NOT NULL,
            currency CHAR(3) NOT NULL DEFAULT 'EUR',
            method VARCHAR(100) NULL,
            note TEXT NULL,
            category VARCHAR(100) NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_type (type),
            KEY idx_subtype (subtype),
            KEY idx_messe_id (messe_id),
            KEY idx_entry_date (entry_date),
            KEY idx_user_id (user_id),
            KEY idx_type_subtype (type, subtype),
            KEY idx_date_type (entry_date, type)
        ) {$charset_collate};";
        
        dbDelta($sql_entries);
        
        // Expenses table (expense workflow records)
        $expenses_table = self::get_expenses_table();
        $sql_expenses = "CREATE TABLE {$expenses_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            entry_id BIGINT UNSIGNED NOT NULL,
            status ENUM('submitted', 'reviewed', 'approved', 'reimbursed', 'rejected') NOT NULL DEFAULT 'submitted',
            submitted_by BIGINT UNSIGNED NOT NULL,
            reviewed_by BIGINT UNSIGNED NULL,
            approved_by BIGINT UNSIGNED NULL,
            submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_at DATETIME NULL,
            approved_at DATETIME NULL,
            reimbursed_at DATETIME NULL,
            rejected_at DATETIME NULL,
            rejection_reason TEXT NULL,
            notes TEXT NULL,
            PRIMARY KEY (id),
            KEY idx_entry_id (entry_id),
            KEY idx_status (status),
            KEY idx_submitted_by (submitted_by),
            KEY idx_submitted_at (submitted_at)
        ) {$charset_collate};";
        
        dbDelta($sql_expenses);
        
        // Files table (receipts/attachments)
        $files_table = self::get_files_table();
        $sql_files = "CREATE TABLE {$files_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            entry_id BIGINT UNSIGNED NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_type VARCHAR(100) NOT NULL,
            file_size BIGINT UNSIGNED NOT NULL,
            uploaded_by BIGINT UNSIGNED NOT NULL,
            uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_entry_id (entry_id),
            KEY idx_uploaded_by (uploaded_by)
        ) {$charset_collate};";
        
        dbDelta($sql_files);
        
        // Audit table (revision log)
        $audit_table = self::get_audit_table();
        $sql_audit = "CREATE TABLE {$audit_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            action VARCHAR(50) NOT NULL,
            entity_type VARCHAR(50) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            ip_address VARCHAR(45) NULL,
            user_agent VARCHAR(500) NULL,
            old_values LONGTEXT NULL,
            new_values LONGTEXT NULL,
            details TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_action (action),
            KEY idx_entity (entity_type, entity_id),
            KEY idx_user_id (user_id),
            KEY idx_created_at (created_at)
        ) {$charset_collate};";
        
        dbDelta($sql_audit);
    }

    /**
     * Check if all required tables exist
     */
    public static function tables_exist(): bool {
        global $wpdb;
        
        $tables = [
            self::get_entries_table(),
            self::get_expenses_table(),
            self::get_files_table(),
            self::get_audit_table(),
        ];
        
        foreach ($tables as $table) {
            $result = $wpdb->get_var(
                $wpdb->prepare("SHOW TABLES LIKE %s", $table)
            );
            if ($result !== $table) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Drop all tables (use with caution!)
     */
    public static function drop_tables(): void {
        global $wpdb;
        
        $tables = [
            self::get_files_table(),
            self::get_expenses_table(),
            self::get_audit_table(),
            self::get_entries_table(),
        ];
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
    }

    /**
     * Get valid entry subtypes
     */
    public static function get_valid_subtypes(): array {
        return [
            'income' => ['klingelbeutel', 'pfarrcafe', 'sonstige'],
            'expense' => ['ausgabe'],
        ];
    }

    /**
     * Get valid expense statuses
     */
    public static function get_valid_statuses(): array {
        return ['submitted', 'reviewed', 'approved', 'reimbursed', 'rejected'];
    }

    /**
     * Validate subtype for type
     */
    public static function is_valid_subtype(string $type, string $subtype): bool {
        $valid = self::get_valid_subtypes();
        return isset($valid[$type]) && in_array($subtype, $valid[$type], true);
    }

    /**
     * Validate expense status
     */
    public static function is_valid_status(string $status): bool {
        return in_array($status, self::get_valid_statuses(), true);
    }

    /**
     * Get status flow (which statuses can transition to which)
     */
    public static function get_status_transitions(): array {
        return [
            'submitted' => ['reviewed', 'rejected'],
            'reviewed' => ['approved', 'rejected'],
            'approved' => ['reimbursed', 'rejected'],
            'reimbursed' => [],
            'rejected' => [],
        ];
    }

    /**
     * Check if status transition is valid
     */
    public static function is_valid_transition(string $from, string $to): bool {
        $transitions = self::get_status_transitions();
        return isset($transitions[$from]) && in_array($to, $transitions[$from], true);
    }
}
