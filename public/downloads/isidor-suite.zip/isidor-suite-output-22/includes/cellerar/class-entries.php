<?php
/**
 * Entries management for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Entries
 * Handles all entry (income/expense) operations
 */
class Isidor_Cellerar_Entries {

    /**
     * Create a new entry
     *
     * @param array $data Entry data
     * @return int|WP_Error Entry ID on success, WP_Error on failure
     */
    public static function create(array $data) {
        global $wpdb;
        
        // Validate required fields
        $required = ['type', 'subtype', 'entry_date', 'amount_cents'];
        foreach ($required as $field) {
            if (empty($data[$field]) && $data[$field] !== 0) {
                return new WP_Error(
                    'missing_field',
                    sprintf(__('Pflichtfeld fehlt: %s', 'isidor-cellerar'), $field)
                );
            }
        }
        
        // Validate type and subtype
        if (!Isidor_Cellerar_Database::is_valid_subtype($data['type'], $data['subtype'])) {
            return new WP_Error(
                'invalid_subtype',
                __('Ungültiger Subtyp für diesen Typ.', 'isidor-cellerar')
            );
        }
        
        // Validate pfarrcafe requires messe_id
        if ($data['subtype'] === 'pfarrcafe') {
            if (empty($data['messe_id'])) {
                return new WP_Error(
                    'messe_required',
                    __('Pfarrcafé-Einnahmen benötigen eine zugeordnete Messe.', 'isidor-cellerar')
                );
            }
            
            // Verify messe exists
            if (!self::messe_exists((int) $data['messe_id'])) {
                return new WP_Error(
                    'messe_not_found',
                    __('Die angegebene Messe wurde nicht gefunden.', 'isidor-cellerar')
                );
            }
        }
        
        // Validate amount
        $amount_cents = (int) $data['amount_cents'];
        if ($amount_cents <= 0) {
            return new WP_Error(
                'invalid_amount',
                __('Der Betrag muss größer als 0 sein.', 'isidor-cellerar')
            );
        }
        
        // Validate date
        $entry_date = sanitize_text_field($data['entry_date']);
        if (!self::is_valid_date($entry_date)) {
            return new WP_Error(
                'invalid_date',
                __('Ungültiges Datum.', 'isidor-cellerar')
            );
        }
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $insert_data = [
            'type' => sanitize_text_field($data['type']),
            'subtype' => sanitize_text_field($data['subtype']),
            'messe_id' => !empty($data['messe_id']) ? absint($data['messe_id']) : null,
            'entry_date' => $entry_date,
            'amount_cents' => $amount_cents,
            'currency' => !empty($data['currency']) ? strtoupper(sanitize_text_field($data['currency'])) : 'EUR',
            'method' => !empty($data['method']) ? sanitize_text_field($data['method']) : null,
            'note' => !empty($data['note']) ? sanitize_textarea_field($data['note']) : null,
            'category' => !empty($data['category']) ? sanitize_text_field($data['category']) : null,
            'user_id' => get_current_user_id(),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ];
        
        $format = ['%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s'];
        
        // Handle null messe_id
        if ($insert_data['messe_id'] === null) {
            $format[2] = null;
        }
        
        $result = $wpdb->insert($table, $insert_data, $format);
        
        if ($result === false) {
            error_log('Isidor Cellerar: Failed to create entry - ' . $wpdb->last_error);
            return new WP_Error(
                'db_error',
                __('Datenbankfehler beim Erstellen des Eintrags.', 'isidor-cellerar')
            );
        }
        
        $entry_id = (int) $wpdb->insert_id;
        
        // Log audit
        Isidor_Cellerar_Audit::log_entry_created($entry_id, $insert_data);
        
        return $entry_id;
    }

    /**
     * Get a single entry by ID
     *
     * @param int $entry_id Entry ID
     * @return array|null Entry data or null if not found
     */
    public static function get(int $entry_id){
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $entry = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $entry_id),
            ARRAY_A
        );
        
        return $entry ?: null;
    }

    /**
     * Update an entry
     *
     * @param int $entry_id Entry ID
     * @param array $data Data to update
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public static function update(int $entry_id, array $data) {
        global $wpdb;
        
        $old_entry = self::get($entry_id);
        
        if ($old_entry === null) {
            return new WP_Error(
                'not_found',
                __('Eintrag nicht gefunden.', 'isidor-cellerar')
            );
        }
        
        // Build update data
        $update_data = [];
        $format = [];
        
        $allowed_fields = [
            'subtype' => '%s',
            'messe_id' => '%d',
            'entry_date' => '%s',
            'amount_cents' => '%d',
            'currency' => '%s',
            'method' => '%s',
            'note' => '%s',
            'category' => '%s',
        ];
        
        foreach ($allowed_fields as $field => $field_format) {
            if (array_key_exists($field, $data)) {
                if ($field === 'messe_id' && empty($data[$field])) {
                    $update_data[$field] = null;
                } elseif ($field === 'amount_cents') {
                    $update_data[$field] = absint($data[$field]);
                } elseif ($field === 'entry_date') {
                    if (!self::is_valid_date($data[$field])) {
                        return new WP_Error('invalid_date', __('Ungültiges Datum.', 'isidor-cellerar'));
                    }
                    $update_data[$field] = sanitize_text_field($data[$field]);
                } elseif ($field === 'note') {
                    $update_data[$field] = sanitize_textarea_field($data[$field]);
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
                $format[] = $field_format;
            }
        }
        
        if (empty($update_data)) {
            return new WP_Error(
                'no_changes',
                __('Keine Änderungen angegeben.', 'isidor-cellerar')
            );
        }
        
        // Validate pfarrcafe requires messe_id
        $new_subtype = $update_data['subtype'] ?? $old_entry['subtype'];
        $new_messe_id = array_key_exists('messe_id', $update_data) ? $update_data['messe_id'] : $old_entry['messe_id'];
        
        if ($new_subtype === 'pfarrcafe' && empty($new_messe_id)) {
            return new WP_Error(
                'messe_required',
                __('Pfarrcafé-Einnahmen benötigen eine zugeordnete Messe.', 'isidor-cellerar')
            );
        }
        
        $update_data['updated_at'] = current_time('mysql');
        $format[] = '%s';
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $result = $wpdb->update(
            $table,
            $update_data,
            ['id' => $entry_id],
            $format,
            ['%d']
        );
        
        if ($result === false) {
            error_log('Isidor Cellerar: Failed to update entry - ' . $wpdb->last_error);
            return new WP_Error(
                'db_error',
                __('Datenbankfehler beim Aktualisieren des Eintrags.', 'isidor-cellerar')
            );
        }
        
        // Log audit
        Isidor_Cellerar_Audit::log_entry_updated($entry_id, $old_entry, $update_data);
        
        return true;
    }

    /**
     * Delete an entry
     *
     * @param int $entry_id Entry ID
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public static function delete(int $entry_id) {
        global $wpdb;
        
        $entry = self::get($entry_id);
        
        if ($entry === null) {
            return new WP_Error(
                'not_found',
                __('Eintrag nicht gefunden.', 'isidor-cellerar')
            );
        }
        
        // Check if entry has expense workflow
        $expenses_table = Isidor_Cellerar_Database::get_expenses_table();
        $has_expense = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$expenses_table} WHERE entry_id = %d", $entry_id)
        );
        
        if ($has_expense > 0) {
            // Delete expense workflow first
            $wpdb->delete($expenses_table, ['entry_id' => $entry_id], ['%d']);
        }
        
        // Delete associated files
        Isidor_Cellerar_Files::delete_by_entry($entry_id);
        
        // Delete the entry
        $table = Isidor_Cellerar_Database::get_entries_table();
        $result = $wpdb->delete($table, ['id' => $entry_id], ['%d']);
        
        if ($result === false) {
            error_log('Isidor Cellerar: Failed to delete entry - ' . $wpdb->last_error);
            return new WP_Error(
                'db_error',
                __('Datenbankfehler beim Löschen des Eintrags.', 'isidor-cellerar')
            );
        }
        
        // Log audit
        Isidor_Cellerar_Audit::log_entry_deleted($entry_id, $entry);
        
        return true;
    }

    /**
     * Query entries with filters
     *
     * @param array $args Query arguments
     * @return array Array with 'items' and 'total'
     */
    public static function query(array $args = []): array {
        global $wpdb;
        
        $defaults = [
            'type' => null,
            'subtype' => null,
            'messe_id' => null,
            'user_id' => null,
            'date_from' => null,
            'date_to' => null,
            'category' => null,
            'search' => null,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'entry_date',
            'order' => 'DESC',
        ];
        
        $args = wp_parse_args($args, $defaults);
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ['1=1'];
        $values = [];
        
        if ($args['type'] !== null) {
            $where[] = 'type = %s';
            $values[] = $args['type'];
        }
        
        if ($args['subtype'] !== null) {
            $where[] = 'subtype = %s';
            $values[] = $args['subtype'];
        }
        
        if ($args['messe_id'] !== null) {
            $where[] = 'messe_id = %d';
            $values[] = $args['messe_id'];
        }
        
        if ($args['user_id'] !== null) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }
        
        if ($args['date_from'] !== null) {
            $where[] = 'entry_date >= %s';
            $values[] = $args['date_from'];
        }
        
        if ($args['date_to'] !== null) {
            $where[] = 'entry_date <= %s';
            $values[] = $args['date_to'];
        }
        
        if ($args['category'] !== null) {
            $where[] = 'category = %s';
            $values[] = $args['category'];
        }
        
        if ($args['search'] !== null) {
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(note LIKE %s OR category LIKE %s OR method LIKE %s)';
            $values[] = $search_term;
            $values[] = $search_term;
            $values[] = $search_term;
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Count total
        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_clause}";
        if (!empty($values)) {
            $count_sql = $wpdb->prepare($count_sql, $values);
        }
        $total = (int) $wpdb->get_var($count_sql);
        
        // Sanitize orderby
        $allowed_orderby = ['id', 'entry_date', 'amount_cents', 'type', 'subtype', 'created_at'];
        $orderby = in_array($args['orderby'], $allowed_orderby, true) ? $args['orderby'] : 'entry_date';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);
        
        // Get items
        $sql = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $values[] = $limit;
        $values[] = $offset;
        
        $sql = $wpdb->prepare($sql, $values);
        $items = $wpdb->get_results($sql, ARRAY_A);
        
        return [
            'items' => $items ?: [],
            'total' => $total,
        ];
    }

    /**
     * Get entries for a specific messe
     */
    public static function get_by_messe(int $messe_id): array {
        return self::query(['messe_id' => $messe_id, 'limit' => 100])['items'];
    }

    /**
     * Get entries by user
     */
    public static function get_by_user(int $user_id, int $limit = 50): array {
        return self::query(['user_id' => $user_id, 'limit' => $limit])['items'];
    }

    /**
     * Check if a messe exists
     */
    private static function messe_exists(int $messe_id): bool {
        if (!post_type_exists('isidor_messe')) {
            return false;
        }
        
        $post = get_post($messe_id);
        return $post !== null && $post->post_type === 'isidor_messe';
    }

    /**
     * Validate date format (Y-m-d)
     */
    private static function is_valid_date(string $date): bool {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    /**
     * Convert cents to formatted currency string
     */
    public static function format_amount(int $cents, string $currency = 'EUR'): string {
        $amount = $cents / 100;
        
        $symbols = [
            'EUR' => '€',
            'USD' => '$',
            'CHF' => 'CHF',
        ];
        
        $symbol = $symbols[$currency] ?? $currency;
        
        return number_format($amount, 2, ',', '.') . ' ' . $symbol;
    }

    /**
     * Parse amount string to cents
     */
    public static function parse_amount_to_cents($amount): int {
        if (is_int($amount)) {
            return $amount * 100;
        }
        
        if (is_float($amount)) {
            return (int) round($amount * 100);
        }
        
        // Handle string with comma as decimal separator
        $amount = str_replace([' ', '€', '$', 'EUR', 'USD', 'CHF'], '', $amount);
        $amount = str_replace('.', '', $amount); // Remove thousand separator
        $amount = str_replace(',', '.', $amount); // Convert decimal separator
        
        return (int) round((float) $amount * 100);
    }

    /**
     * Get subtype label
     */
    public static function get_subtype_label(string $subtype): string {
        $labels = [
            'klingelbeutel' => __('Klingelbeutel', 'isidor-cellerar'),
            'pfarrcafe' => __('Pfarrcafé', 'isidor-cellerar'),
            'sonstige' => __('Sonstige', 'isidor-cellerar'),
            'ausgabe' => __('Ausgabe', 'isidor-cellerar'),
        ];
        
        return $labels[$subtype] ?? $subtype;
    }

    /**
     * Get type label
     */
    public static function get_type_label(string $type): string {
        $labels = [
            'income' => __('Einnahme', 'isidor-cellerar'),
            'expense' => __('Ausgabe', 'isidor-cellerar'),
        ];
        
        return $labels[$type] ?? $type;
    }

    /**
     * Get available categories for expenses
     */
    public static function get_expense_categories(): array {
        return apply_filters('isidor_cellerar_expense_categories', [
            'material' => __('Material', 'isidor-cellerar'),
            'reparatur' => __('Reparatur', 'isidor-cellerar'),
            'reinigung' => __('Reinigung', 'isidor-cellerar'),
            'liturgie' => __('Liturgie', 'isidor-cellerar'),
            'veranstaltung' => __('Veranstaltung', 'isidor-cellerar'),
            'verwaltung' => __('Verwaltung', 'isidor-cellerar'),
            'sonstiges' => __('Sonstiges', 'isidor-cellerar'),
        ]);
    }

    /**
     * Get available categories for pfarrcafe
     */
    public static function get_pfarrcafe_categories(): array {
        return apply_filters('isidor_cellerar_pfarrcafe_categories', [
            'getraenke' => __('Getränke', 'isidor-cellerar'),
            'kuchen' => __('Kuchen', 'isidor-cellerar'),
            'snacks' => __('Snacks', 'isidor-cellerar'),
            'sonstiges' => __('Sonstiges', 'isidor-cellerar'),
        ]);
    }
}
