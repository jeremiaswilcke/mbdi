<?php
/**
 * Expenses workflow management for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Expenses
 * Handles expense approval workflow
 */
class Isidor_Cellerar_Expenses {

    /**
     * Create expense entry with workflow
     *
     * @param array $data Entry data
     * @return int|WP_Error Entry ID on success, WP_Error on failure
     */
    public static function submit(array $data) {
        global $wpdb;
        
        // Force type to expense
        $data['type'] = 'expense';
        $data['subtype'] = 'ausgabe';
        
        // Create the base entry
        $entry_id = Isidor_Cellerar_Entries::create($data);
        
        if (is_wp_error($entry_id)) {
            return $entry_id;
        }
        
        // Create expense workflow record
        $table = Isidor_Cellerar_Database::get_expenses_table();
        
        $result = $wpdb->insert(
            $table,
            [
                'entry_id' => $entry_id,
                'status' => 'submitted',
                'submitted_by' => get_current_user_id(),
                'submitted_at' => current_time('mysql'),
                'notes' => !empty($data['expense_notes']) ? sanitize_textarea_field($data['expense_notes']) : null,
            ],
            ['%d', '%s', '%d', '%s', '%s']
        );
        
        if ($result === false) {
            // Rollback: delete the entry
            Isidor_Cellerar_Entries::delete($entry_id);
            
            return new WP_Error(
                'db_error',
                __('Datenbankfehler beim Erstellen des Ausgaben-Workflows.', 'isidor-cellerar')
            );
        }
        
        $expense_id = (int) $wpdb->insert_id;
        
        // Log audit
        Isidor_Cellerar_Audit::log('create', 'expense', $expense_id, null, [
            'entry_id' => $entry_id,
            'status' => 'submitted',
        ]);
        
        // Send notification email
        Isidor_Cellerar_Mail::send_submission_notification($entry_id, $expense_id);
        
        return $entry_id;
    }

    /**
     * Get expense workflow by entry ID
     */
    public static function get_by_entry(int $entry_id){
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_expenses_table();
        
        $expense = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE entry_id = %d", $entry_id),
            ARRAY_A
        );
        
        return $expense ?: null;
    }

    /**
     * Get expense workflow by ID
     */
    public static function get(int $expense_id){
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_expenses_table();
        
        $expense = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $expense_id),
            ARRAY_A
        );
        
        return $expense ?: null;
    }

    /**
     * Update expense status
     *
     * @param int $expense_id Expense ID
     * @param string $new_status New status
     * @param string|null $reason Rejection reason (if rejecting)
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public static function update_status(int $expense_id, string $new_status, ?string $reason = null) {
        global $wpdb;
        
        $expense = self::get($expense_id);
        
        if ($expense === null) {
            return new WP_Error('not_found', __('Ausgabe nicht gefunden.', 'isidor-cellerar'));
        }
        
        $old_status = $expense['status'];
        
        // Validate status transition
        if (!Isidor_Cellerar_Database::is_valid_transition($old_status, $new_status)) {
            return new WP_Error(
                'invalid_transition',
                sprintf(
                    __('Ungültiger Statuswechsel von %s nach %s.', 'isidor-cellerar'),
                    self::get_status_label($old_status),
                    self::get_status_label($new_status)
                )
            );
        }
        
        $table = Isidor_Cellerar_Database::get_expenses_table();
        $user_id = get_current_user_id();
        $now = current_time('mysql');
        
        $update_data = ['status' => $new_status];
        $format = ['%s'];
        
        // Set appropriate fields based on new status
        switch ($new_status) {
            case 'reviewed':
                $update_data['reviewed_by'] = $user_id;
                $update_data['reviewed_at'] = $now;
                $format[] = '%d';
                $format[] = '%s';
                break;
                
            case 'approved':
                $update_data['approved_by'] = $user_id;
                $update_data['approved_at'] = $now;
                $format[] = '%d';
                $format[] = '%s';
                break;
                
            case 'reimbursed':
                $update_data['reimbursed_at'] = $now;
                $format[] = '%s';
                break;
                
            case 'rejected':
                $update_data['rejected_at'] = $now;
                $update_data['rejection_reason'] = $reason !== null ? sanitize_textarea_field($reason) : null;
                $format[] = '%s';
                $format[] = '%s';
                break;
        }
        
        $result = $wpdb->update(
            $table,
            $update_data,
            ['id' => $expense_id],
            $format,
            ['%d']
        );
        
        if ($result === false) {
            return new WP_Error(
                'db_error',
                __('Datenbankfehler beim Aktualisieren des Status.', 'isidor-cellerar')
            );
        }
        
        // Log audit
        Isidor_Cellerar_Audit::log_status_change($expense_id, $old_status, $new_status, $reason);
        
        // Send notification emails based on status change
        self::send_status_notification($expense_id, $expense['entry_id'], $old_status, $new_status);
        
        return true;
    }

    /**
     * Review an expense (mark as reviewed)
     */
    public static function review(int $expense_id) {
        if (!current_user_can('isidor_cellerar_approve_expense')) {
            return new WP_Error('permission_denied', __('Keine Berechtigung.', 'isidor-cellerar'));
        }
        
        return self::update_status($expense_id, 'reviewed');
    }

    /**
     * Approve an expense
     */
    public static function approve(int $expense_id) {
        if (!current_user_can('isidor_cellerar_approve_expense')) {
            return new WP_Error('permission_denied', __('Keine Berechtigung.', 'isidor-cellerar'));
        }
        
        return self::update_status($expense_id, 'approved');
    }

    /**
     * Mark expense as reimbursed
     */
    public static function reimburse(int $expense_id) {
        if (!current_user_can('isidor_cellerar_approve_expense')) {
            return new WP_Error('permission_denied', __('Keine Berechtigung.', 'isidor-cellerar'));
        }
        
        return self::update_status($expense_id, 'reimbursed');
    }

    /**
     * Reject an expense
     */
    public static function reject(int $expense_id, string $reason) {
        if (!current_user_can('isidor_cellerar_approve_expense')) {
            return new WP_Error('permission_denied', __('Keine Berechtigung.', 'isidor-cellerar'));
        }
        
        if (empty($reason)) {
            return new WP_Error('reason_required', __('Bitte geben Sie einen Ablehnungsgrund an.', 'isidor-cellerar'));
        }
        
        return self::update_status($expense_id, 'rejected', $reason);
    }

    /**
     * Query expenses with filters
     */
    public static function query(array $args = []): array {
        global $wpdb;
        
        $defaults = [
            'status' => null,
            'submitted_by' => null,
            'date_from' => null,
            'date_to' => null,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'submitted_at',
            'order' => 'DESC',
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $expenses_table = Isidor_Cellerar_Database::get_expenses_table();
        $entries_table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ['1=1'];
        $values = [];
        
        if ($args['status'] !== null) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "e.status IN ({$placeholders})";
                $values = array_merge($values, $args['status']);
            } else {
                $where[] = 'e.status = %s';
                $values[] = $args['status'];
            }
        }
        
        if ($args['submitted_by'] !== null) {
            $where[] = 'e.submitted_by = %d';
            $values[] = $args['submitted_by'];
        }
        
        if ($args['date_from'] !== null) {
            $where[] = 'e.submitted_at >= %s';
            $values[] = $args['date_from'];
        }
        
        if ($args['date_to'] !== null) {
            $where[] = 'e.submitted_at <= %s';
            $values[] = $args['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Count total
        $count_sql = "SELECT COUNT(*) FROM {$expenses_table} e WHERE {$where_clause}";
        if (!empty($values)) {
            $count_sql = $wpdb->prepare($count_sql, $values);
        }
        $total = (int) $wpdb->get_var($count_sql);
        
        // Sanitize orderby
        $allowed_orderby = ['id', 'submitted_at', 'status', 'reviewed_at', 'approved_at'];
        $orderby = in_array($args['orderby'], $allowed_orderby, true) ? 'e.' . $args['orderby'] : 'e.submitted_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);
        
        // Get items with entry details
        $sql = "SELECT e.*, 
                       en.amount_cents, en.currency, en.entry_date, en.note, en.category, en.method
                FROM {$expenses_table} e
                LEFT JOIN {$entries_table} en ON e.entry_id = en.id
                WHERE {$where_clause}
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $values[] = $limit;
        $values[] = $offset;
        
        $sql = $wpdb->prepare($sql, $values);
        $items = $wpdb->get_results($sql, ARRAY_A);
        
        // Add user info
        foreach ($items as &$item) {
            $submitter = get_userdata($item['submitted_by']);
            $item['submitter_name'] = $submitter ? $submitter->display_name : __('Unbekannt', 'isidor-cellerar');
            $item['submitter_email'] = $submitter ? $submitter->user_email : '';
            
            if (!empty($item['reviewed_by'])) {
                $reviewer = get_userdata($item['reviewed_by']);
                $item['reviewer_name'] = $reviewer ? $reviewer->display_name : __('Unbekannt', 'isidor-cellerar');
            }
            
            if (!empty($item['approved_by'])) {
                $approver = get_userdata($item['approved_by']);
                $item['approver_name'] = $approver ? $approver->display_name : __('Unbekannt', 'isidor-cellerar');
            }
        }
        
        return [
            'items' => $items ?: [],
            'total' => $total,
        ];
    }

    /**
     * Get pending expenses (for approvers)
     */
    public static function get_pending(): array {
        return self::query([
            'status' => ['submitted', 'reviewed'],
            'orderby' => 'submitted_at',
            'order' => 'ASC',
        ]);
    }

    /**
     * Get user's submissions
     */
    public static function get_user_submissions(?int $user_id = null): array {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        return self::query([
            'submitted_by' => $user_id,
            'limit' => 100,
        ]);
    }

    /**
     * Send status notification email
     */
    private static function send_status_notification(
        int $expense_id,
        int $entry_id,
        string $old_status,
        string $new_status
    ): void {
        $expense = self::get($expense_id);
        if (!$expense) {
            return;
        }
        
        switch ($new_status) {
            case 'reviewed':
                Isidor_Cellerar_Mail::send_status_update_to_approvers($entry_id, $expense_id, $new_status);
                break;
                
            case 'approved':
            case 'rejected':
                Isidor_Cellerar_Mail::send_status_update_to_submitter($entry_id, $expense_id, $new_status);
                break;
                
            case 'reimbursed':
                Isidor_Cellerar_Mail::send_reimbursement_confirmation($entry_id, $expense_id);
                break;
        }
    }

    /**
     * Get status label
     */
    public static function get_status_label(string $status): string {
        $labels = [
            'submitted' => __('Eingereicht', 'isidor-cellerar'),
            'reviewed' => __('Geprüft', 'isidor-cellerar'),
            'approved' => __('Genehmigt', 'isidor-cellerar'),
            'reimbursed' => __('Erstattet', 'isidor-cellerar'),
            'rejected' => __('Abgelehnt', 'isidor-cellerar'),
        ];
        
        return $labels[$status] ?? $status;
    }

    /**
     * Get status color class
     */
    public static function get_status_color(string $status): string {
        $colors = [
            'submitted' => 'status-pending',
            'reviewed' => 'status-info',
            'approved' => 'status-success',
            'reimbursed' => 'status-complete',
            'rejected' => 'status-error',
        ];
        
        return $colors[$status] ?? 'status-default';
    }

    /**
     * Get available actions for current status
     */
    public static function get_available_actions(string $status): array {
        $transitions = Isidor_Cellerar_Database::get_status_transitions();
        $available = $transitions[$status] ?? [];
        
        $actions = [];
        foreach ($available as $target_status) {
            $actions[$target_status] = self::get_action_label($target_status);
        }
        
        return $actions;
    }

    /**
     * Get action label
     */
    private static function get_action_label(string $status): string {
        $labels = [
            'reviewed' => __('Prüfen', 'isidor-cellerar'),
            'approved' => __('Genehmigen', 'isidor-cellerar'),
            'reimbursed' => __('Als erstattet markieren', 'isidor-cellerar'),
            'rejected' => __('Ablehnen', 'isidor-cellerar'),
        ];
        
        return $labels[$status] ?? $status;
    }
}
