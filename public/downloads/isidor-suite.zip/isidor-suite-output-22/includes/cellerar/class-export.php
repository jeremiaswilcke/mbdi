<?php
/**
 * Export functionality for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Export
 * Handles data export in various formats
 */
class Isidor_Cellerar_Export {

    /**
     * Export entries to CSV
     *
     * @param array $filters Query filters
     * @return string CSV content
     */
    public static function to_csv(array $filters = []): string {
        $entries = self::get_export_data($filters);
        
        if (empty($entries)) {
            return '';
        }
        
        $output = fopen('php://temp', 'r+');
        
        // Add UTF-8 BOM for Excel compatibility
        fwrite($output, "\xEF\xBB\xBF");
        
        // Header row
        $headers = [
            'ID',
            'Typ',
            'Subtyp',
            'Datum',
            'Betrag',
            'Währung',
            'Kategorie',
            'Methode',
            'Messe ID',
            'Notiz',
            'Benutzer',
            'Erstellt am',
            'Status',
        ];
        fputcsv($output, $headers, ';');
        
        // Data rows
        foreach ($entries as $entry) {
            $row = [
                $entry['id'],
                Isidor_Cellerar_Entries::get_type_label($entry['type']),
                Isidor_Cellerar_Entries::get_subtype_label($entry['subtype']),
                $entry['entry_date'],
                number_format($entry['amount_cents'] / 100, 2, ',', '.'),
                $entry['currency'],
                $entry['category'] ?? '',
                $entry['method'] ?? '',
                $entry['messe_id'] ?? '',
                $entry['note'] ?? '',
                $entry['user_name'] ?? '',
                $entry['created_at'],
                $entry['expense_status'] ?? '',
            ];
            fputcsv($output, $row, ';');
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        // Log audit
        Isidor_Cellerar_Audit::log_export('csv', $filters, count($entries));
        
        return $csv;
    }

    /**
     * Export entries to JSON
     *
     * @param array $filters Query filters
     * @return string JSON content
     */
    public static function to_json(array $filters = []): string {
        $entries = self::get_export_data($filters);
        
        $export_data = [
            'generated_at' => current_time('c'),
            'generated_by' => wp_get_current_user()->display_name,
            'filters' => $filters,
            'total_count' => count($entries),
            'entries' => [],
        ];
        
        foreach ($entries as $entry) {
            $export_data['entries'][] = [
                'id' => (int) $entry['id'],
                'type' => $entry['type'],
                'type_label' => Isidor_Cellerar_Entries::get_type_label($entry['type']),
                'subtype' => $entry['subtype'],
                'subtype_label' => Isidor_Cellerar_Entries::get_subtype_label($entry['subtype']),
                'entry_date' => $entry['entry_date'],
                'amount_cents' => (int) $entry['amount_cents'],
                'amount_formatted' => Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']),
                'currency' => $entry['currency'],
                'category' => $entry['category'],
                'method' => $entry['method'],
                'messe_id' => $entry['messe_id'] ? (int) $entry['messe_id'] : null,
                'note' => $entry['note'],
                'user_id' => (int) $entry['user_id'],
                'user_name' => $entry['user_name'],
                'created_at' => $entry['created_at'],
                'updated_at' => $entry['updated_at'],
                'expense_status' => $entry['expense_status'] ?? null,
            ];
        }
        
        // Log audit
        Isidor_Cellerar_Audit::log_export('json', $filters, count($entries));
        
        return wp_json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Generate downloadable export
     *
     * @param string $format Export format (csv, json)
     * @param array $filters Query filters
     */
    public static function download(string $format, array $filters = []): void {
        if (!current_user_can('isidor_cellerar_export')) {
            wp_die(__('Keine Berechtigung für Export.', 'isidor-cellerar'));
        }
        
        $filename = sprintf(
            'isidor-cellerar-export-%s.%s',
            gmdate('Y-m-d-His'),
            $format
        );
        
        switch ($format) {
            case 'csv':
                $content = self::to_csv($filters);
                $mime_type = 'text/csv; charset=utf-8';
                break;
                
            case 'json':
                $content = self::to_json($filters);
                $mime_type = 'application/json; charset=utf-8';
                break;
                
            default:
                wp_die(__('Ungültiges Export-Format.', 'isidor-cellerar'));
        }
        
        // Clear any output buffers
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        // Send headers
        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($content));
        header('Cache-Control: private, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        echo $content;
        exit;
    }

    /**
     * Get export data with all necessary joins
     *
     * @param array $filters Query filters
     * @return array Export data
     */
    private static function get_export_data(array $filters = []): array {
        global $wpdb;
        
        $entries_table = Isidor_Cellerar_Database::get_entries_table();
        $expenses_table = Isidor_Cellerar_Database::get_expenses_table();
        
        $where = ['1=1'];
        $values = [];
        
        if (!empty($filters['type'])) {
            $where[] = 'e.type = %s';
            $values[] = $filters['type'];
        }
        
        if (!empty($filters['subtype'])) {
            $where[] = 'e.subtype = %s';
            $values[] = $filters['subtype'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = 'e.entry_date >= %s';
            $values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'e.entry_date <= %s';
            $values[] = $filters['date_to'];
        }
        
        if (!empty($filters['messe_id'])) {
            $where[] = 'e.messe_id = %d';
            $values[] = $filters['messe_id'];
        }
        
        if (!empty($filters['category'])) {
            $where[] = 'e.category = %s';
            $values[] = $filters['category'];
        }
        
        if (!empty($filters['status'])) {
            $where[] = 'ex.status = %s';
            $values[] = $filters['status'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        $sql = "SELECT e.*, ex.status as expense_status
                FROM {$entries_table} e
                LEFT JOIN {$expenses_table} ex ON e.id = ex.entry_id
                WHERE {$where_clause}
                ORDER BY e.entry_date DESC, e.id DESC";
        
        if (!empty($values)) {
            $sql = $wpdb->prepare($sql, $values);
        }
        
        $entries = $wpdb->get_results($sql, ARRAY_A);
        
        // Add user names
        foreach ($entries as &$entry) {
            $user = get_userdata($entry['user_id']);
            $entry['user_name'] = $user ? $user->display_name : __('Unbekannt', 'isidor-cellerar');
        }
        
        return $entries ?: [];
    }

    /**
     * Generate reimbursement confirmation PDF content
     *
     * @param int $entry_id Entry ID
     * @param int $expense_id Expense ID
     * @return array PDF data (or HTML for display)
     */
    public static function generate_reimbursement_confirmation(int $entry_id, int $expense_id): array {
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        $expense = Isidor_Cellerar_Expenses::get($expense_id);
        
        if (!$entry || !$expense) {
            return ['error' => __('Eintrag nicht gefunden.', 'isidor-cellerar')];
        }
        
        $submitter = get_userdata($expense['submitted_by']);
        $approver = !empty($expense['approved_by']) ? get_userdata($expense['approved_by']) : null;
        
        $data = [
            'reference' => sprintf('IC-%06d', $entry_id),
            'date' => gmdate('d.m.Y'),
            'entry' => [
                'id' => $entry_id,
                'date' => gmdate('d.m.Y', strtotime($entry['entry_date'])),
                'amount' => Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']),
                'category' => $entry['category'] ?? __('Keine Kategorie', 'isidor-cellerar'),
                'note' => $entry['note'] ?? '',
            ],
            'submitter' => [
                'name' => $submitter ? $submitter->display_name : __('Unbekannt', 'isidor-cellerar'),
                'email' => $submitter ? $submitter->user_email : '',
            ],
            'approver' => [
                'name' => $approver ? $approver->display_name : __('Unbekannt', 'isidor-cellerar'),
            ],
            'workflow' => [
                'submitted_at' => gmdate('d.m.Y H:i', strtotime($expense['submitted_at'])),
                'approved_at' => $expense['approved_at'] ? gmdate('d.m.Y H:i', strtotime($expense['approved_at'])) : '',
                'reimbursed_at' => $expense['reimbursed_at'] ? gmdate('d.m.Y H:i', strtotime($expense['reimbursed_at'])) : '',
            ],
        ];
        
        return $data;
    }

    /**
     * Get available export formats
     */
    public static function get_available_formats(): array {
        return [
            'csv' => [
                'label' => 'CSV',
                'description' => __('Kompatibel mit Excel, Google Sheets', 'isidor-cellerar'),
                'mime' => 'text/csv',
            ],
            'json' => [
                'label' => 'JSON',
                'description' => __('Maschinenlesbar für Integrationen', 'isidor-cellerar'),
                'mime' => 'application/json',
            ],
        ];
    }

    /**
     * Get export filters schema
     */
    public static function get_filter_schema(): array {
        return [
            'type' => [
                'type' => 'select',
                'label' => __('Typ', 'isidor-cellerar'),
                'options' => [
                    '' => __('Alle', 'isidor-cellerar'),
                    'income' => __('Einnahmen', 'isidor-cellerar'),
                    'expense' => __('Ausgaben', 'isidor-cellerar'),
                ],
            ],
            'date_from' => [
                'type' => 'date',
                'label' => __('Von Datum', 'isidor-cellerar'),
            ],
            'date_to' => [
                'type' => 'date',
                'label' => __('Bis Datum', 'isidor-cellerar'),
            ],
            'category' => [
                'type' => 'text',
                'label' => __('Kategorie', 'isidor-cellerar'),
            ],
            'status' => [
                'type' => 'select',
                'label' => __('Status (Ausgaben)', 'isidor-cellerar'),
                'options' => [
                    '' => __('Alle', 'isidor-cellerar'),
                    'submitted' => __('Eingereicht', 'isidor-cellerar'),
                    'reviewed' => __('Geprüft', 'isidor-cellerar'),
                    'approved' => __('Genehmigt', 'isidor-cellerar'),
                    'reimbursed' => __('Erstattet', 'isidor-cellerar'),
                    'rejected' => __('Abgelehnt', 'isidor-cellerar'),
                ],
            ],
        ];
    }
}
