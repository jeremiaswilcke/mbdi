<?php
/**
 * File management for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Files
 * Handles file uploads and management for receipts/attachments
 */
class Isidor_Cellerar_Files {

    /**
     * Allowed file types
     */
    private const ALLOWED_TYPES = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
    ];

    /**
     * Maximum file size in bytes (5 MB)
     */
    private const MAX_FILE_SIZE = 5 * 1024 * 1024;

    /**
     * Upload directory name
     */
    private const UPLOAD_DIR = 'isidor-cellerar';

    /**
     * Upload a file for an entry
     *
     * @param int $entry_id Entry ID
     * @param array $file $_FILES array element
     * @return int|WP_Error File ID on success, WP_Error on failure
     */
    public static function upload(int $entry_id, array $file) {
        global $wpdb;
        
        // Check if entry exists
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        if ($entry === null) {
            return new WP_Error('entry_not_found', __('Eintrag nicht gefunden.', 'isidor-cellerar'));
        }
        
        // Validate file
        $validation = self::validate_file($file);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Get upload directory
        $upload_dir = self::get_upload_dir();
        if (is_wp_error($upload_dir)) {
            return $upload_dir;
        }
        
        // Generate unique filename
        $extension = self::ALLOWED_TYPES[$file['type']];
        $filename = sprintf(
            'entry-%d-%s.%s',
            $entry_id,
            wp_generate_password(16, false),
            $extension
        );
        
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            return new WP_Error('upload_failed', __('Datei konnte nicht hochgeladen werden.', 'isidor-cellerar'));
        }
        
        // Set correct permissions
        chmod($filepath, 0644);
        
        // Store in database
        $table = Isidor_Cellerar_Database::get_files_table();
        
        $result = $wpdb->insert(
            $table,
            [
                'entry_id' => $entry_id,
                'file_name' => sanitize_file_name($file['name']),
                'file_path' => $upload_dir['subdir'] . '/' . $filename,
                'file_type' => $file['type'],
                'file_size' => $file['size'],
                'uploaded_by' => get_current_user_id(),
                'uploaded_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%d', '%d', '%s']
        );
        
        if ($result === false) {
            // Clean up: delete the uploaded file
            @unlink($filepath);
            return new WP_Error('db_error', __('Datenbankfehler beim Speichern der Datei.', 'isidor-cellerar'));
        }
        
        $file_id = (int) $wpdb->insert_id;
        
        // Log audit
        Isidor_Cellerar_Audit::log_file_uploaded($file_id, $entry_id, $file['name']);
        
        return $file_id;
    }

    /**
     * Get file by ID
     */
    public static function get(int $file_id){
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_files_table();
        
        $file = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $file_id),
            ARRAY_A
        );
        
        if ($file) {
            $file['url'] = self::get_file_url($file['file_path']);
        }
        
        return $file ?: null;
    }

    /**
     * Get files for an entry
     */
    public static function get_by_entry(int $entry_id): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_files_table();
        
        $files = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE entry_id = %d ORDER BY uploaded_at DESC", $entry_id),
            ARRAY_A
        );
        
        foreach ($files as &$file) {
            $file['url'] = self::get_file_url($file['file_path']);
        }
        
        return $files ?: [];
    }

    /**
     * Delete a file
     */
    public static function delete(int $file_id) {
        global $wpdb;
        
        $file = self::get($file_id);
        
        if ($file === null) {
            return new WP_Error('not_found', __('Datei nicht gefunden.', 'isidor-cellerar'));
        }
        
        // Delete physical file
        $upload_dir = wp_upload_dir();
        $filepath = $upload_dir['basedir'] . $file['file_path'];
        
        if (file_exists($filepath)) {
            @unlink($filepath);
        }
        
        // Delete from database
        $table = Isidor_Cellerar_Database::get_files_table();
        $result = $wpdb->delete($table, ['id' => $file_id], ['%d']);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Datenbankfehler beim Löschen der Datei.', 'isidor-cellerar'));
        }
        
        // Log audit
        Isidor_Cellerar_Audit::log_file_deleted($file_id, $file['file_name']);
        
        return true;
    }

    /**
     * Delete all files for an entry
     */
    public static function delete_by_entry(int $entry_id): void {
        $files = self::get_by_entry($entry_id);
        
        foreach ($files as $file) {
            self::delete($file['id']);
        }
    }

    /**
     * Validate uploaded file
     */
    private static function validate_file(array $file) {
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error_messages = [
                UPLOAD_ERR_INI_SIZE => __('Die Datei überschreitet die maximale Upload-Größe.', 'isidor-cellerar'),
                UPLOAD_ERR_FORM_SIZE => __('Die Datei überschreitet die maximale Formulargröße.', 'isidor-cellerar'),
                UPLOAD_ERR_PARTIAL => __('Die Datei wurde nur teilweise hochgeladen.', 'isidor-cellerar'),
                UPLOAD_ERR_NO_FILE => __('Keine Datei hochgeladen.', 'isidor-cellerar'),
                UPLOAD_ERR_NO_TMP_DIR => __('Temporäres Verzeichnis fehlt.', 'isidor-cellerar'),
                UPLOAD_ERR_CANT_WRITE => __('Fehler beim Schreiben der Datei.', 'isidor-cellerar'),
            ];
            
            $message = $error_messages[$file['error']] ?? __('Unbekannter Upload-Fehler.', 'isidor-cellerar');
            return new WP_Error('upload_error', $message);
        }
        
        // Check file size
        if ($file['size'] > self::MAX_FILE_SIZE) {
            return new WP_Error(
                'file_too_large',
                sprintf(
                    __('Die Datei ist zu groß. Maximum: %d MB.', 'isidor-cellerar'),
                    self::MAX_FILE_SIZE / (1024 * 1024)
                )
            );
        }
        
        // Check file type
        if (!isset(self::ALLOWED_TYPES[$file['type']])) {
            return new WP_Error(
                'invalid_file_type',
                __('Ungültiger Dateityp. Erlaubt: PDF, JPG, PNG.', 'isidor-cellerar')
            );
        }
        
        // Verify actual file type (not just the claimed MIME type)
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $actual_type = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!isset(self::ALLOWED_TYPES[$actual_type])) {
            return new WP_Error(
                'invalid_file_type',
                __('Der Dateityp stimmt nicht mit dem deklarierten Typ überein.', 'isidor-cellerar')
            );
        }
        
        // Additional security: check for PHP code in images
        if (str_starts_with($actual_type, 'image/')) {
            $contents = file_get_contents($file['tmp_name'], false, null, 0, 1024);
            if ($contents !== false && preg_match('/<\?php/i', $contents)) {
                return new WP_Error(
                    'security_error',
                    __('Die Datei enthält ungültigen Inhalt.', 'isidor-cellerar')
                );
            }
        }
        
        return true;
    }

    /**
     * Get upload directory
     */
    private static function get_upload_dir() {
        $upload_dir = wp_upload_dir();
        
        if ($upload_dir['error']) {
            return new WP_Error('upload_dir_error', $upload_dir['error']);
        }
        
        $subdir = '/' . self::UPLOAD_DIR . '/' . gmdate('Y/m');
        $path = $upload_dir['basedir'] . $subdir;
        
        // Create directory if it doesn't exist
        if (!file_exists($path)) {
            if (!wp_mkdir_p($path)) {
                return new WP_Error(
                    'mkdir_failed',
                    __('Konnte Upload-Verzeichnis nicht erstellen.', 'isidor-cellerar')
                );
            }
            
            // Create index.php for security
            $index_file = $path . '/index.php';
            if (!file_exists($index_file)) {
                file_put_contents($index_file, '<?php // Silence is golden.');
            }
            
            // Create .htaccess for additional security
            $htaccess_file = dirname($path) . '/.htaccess';
            if (!file_exists($htaccess_file)) {
                $htaccess_content = "# Disable script execution\n";
                $htaccess_content .= "<Files *.php>\n";
                $htaccess_content .= "deny from all\n";
                $htaccess_content .= "</Files>\n";
                file_put_contents($htaccess_file, $htaccess_content);
            }
        }
        
        return [
            'path' => $path,
            'url' => $upload_dir['baseurl'] . $subdir,
            'subdir' => $subdir,
        ];
    }

    /**
     * Get file URL
     */
    public static function get_file_url(string $file_path): string {
        $upload_dir = wp_upload_dir();
        return $upload_dir['baseurl'] . $file_path;
    }

    /**
     * Get file path
     */
    public static function get_file_path(string $file_path): string {
        $upload_dir = wp_upload_dir();
        return $upload_dir['basedir'] . $file_path;
    }

    /**
     * Serve file for download (with permission check)
     */
    public static function serve_file(int $file_id): void {
        $file = self::get($file_id);
        
        if ($file === null) {
            wp_die(__('Datei nicht gefunden.', 'isidor-cellerar'), '', ['response' => 404]);
        }
        
        // Check permission
        $entry = Isidor_Cellerar_Entries::get($file['entry_id']);
        if (!$entry) {
            wp_die(__('Zugriff verweigert.', 'isidor-cellerar'), '', ['response' => 403]);
        }
        
        // Allow access if user is the uploader, entry owner, or has approval rights
        $current_user_id = get_current_user_id();
        $can_access = (int) $file['uploaded_by'] === $current_user_id
                   || (int) $entry['user_id'] === $current_user_id
                   || current_user_can('isidor_cellerar_approve_expense')
                   || current_user_can('isidor_cellerar_export');
        
        if (!$can_access) {
            wp_die(__('Zugriff verweigert.', 'isidor-cellerar'), '', ['response' => 403]);
        }
        
        $filepath = self::get_file_path($file['file_path']);
        
        if (!file_exists($filepath)) {
            wp_die(__('Datei nicht gefunden.', 'isidor-cellerar'), '', ['response' => 404]);
        }
        
        // Set headers
        header('Content-Type: ' . $file['file_type']);
        header('Content-Disposition: inline; filename="' . $file['file_name'] . '"');
        header('Content-Length: ' . $file['file_size']);
        header('Cache-Control: private, max-age=3600');
        
        // Output file
        readfile($filepath);
        exit;
    }

    /**
     * Format file size for display
     */
    public static function format_file_size(int $bytes): string {
        $units = ['B', 'KB', 'MB', 'GB'];
        $unit = 0;
        
        while ($bytes >= 1024 && $unit < count($units) - 1) {
            $bytes /= 1024;
            $unit++;
        }
        
        return round($bytes, 2) . ' ' . $units[$unit];
    }

    /**
     * Get file type icon class
     */
    public static function get_file_icon(string $file_type): string {
        $icons = [
            'application/pdf' => 'dashicons-pdf',
            'image/jpeg' => 'dashicons-format-image',
            'image/png' => 'dashicons-format-image',
        ];
        
        return $icons[$file_type] ?? 'dashicons-media-default';
    }

    /**
     * Get allowed file types for frontend
     */
    public static function get_allowed_types_string(): string {
        return '.pdf,.jpg,.jpeg,.png';
    }

    /**
     * Get maximum file size for frontend
     */
    public static function get_max_file_size(): int {
        return self::MAX_FILE_SIZE;
    }
}
