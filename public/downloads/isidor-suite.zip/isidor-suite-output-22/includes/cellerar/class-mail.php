<?php
/**
 * Email notifications for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Mail
 * Handles all email notifications
 */
class Isidor_Cellerar_Mail {

    /**
     * Send submission notification to approvers
     *
     * @param int $entry_id Entry ID
     * @param int $expense_id Expense ID
     */
    public static function send_submission_notification(int $entry_id, int $expense_id): bool {
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        $expense = Isidor_Cellerar_Expenses::get($expense_id);
        
        if (!$entry || !$expense) {
            return false;
        }
        
        $submitter = get_userdata($expense['submitted_by']);
        $approvers = Isidor_Cellerar_Roles::get_approvers();
        
        if (empty($approvers)) {
            return false;
        }
        
        $subject = sprintf(
            __('Ausgabe eingereicht – Isidor Cellerar', 'isidor-cellerar')
        );
        
        $amount = Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']);
        
        $message = self::get_template('submission', [
            'submitter_name' => $submitter ? $submitter->display_name : __('Unbekannt', 'isidor-cellerar'),
            'amount' => $amount,
            'date' => gmdate('d.m.Y', strtotime($entry['entry_date'])),
            'category' => $entry['category'] ?? __('Keine Kategorie', 'isidor-cellerar'),
            'note' => $entry['note'] ?? '',
            'entry_id' => $entry_id,
            'review_url' => self::get_app_url(),
        ]);
        
        $recipients = array_map(function ($user) {
            return $user->user_email;
        }, $approvers);
        
        return self::send($recipients, $subject, $message);
    }

    /**
     * Send status update to submitter
     *
     * @param int $entry_id Entry ID
     * @param int $expense_id Expense ID
     * @param string $new_status New status
     */
    public static function send_status_update_to_submitter(int $entry_id, int $expense_id, string $new_status): bool {
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        $expense = Isidor_Cellerar_Expenses::get($expense_id);
        
        if (!$entry || !$expense) {
            return false;
        }
        
        $submitter = get_userdata($expense['submitted_by']);
        
        if (!$submitter) {
            return false;
        }
        
        $status_label = Isidor_Cellerar_Expenses::get_status_label($new_status);
        $amount = Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']);
        
        $subject = sprintf(
            __('Ausgabe %s – Isidor Cellerar', 'isidor-cellerar'),
            $status_label
        );
        
        $template_data = [
            'recipient_name' => $submitter->display_name,
            'amount' => $amount,
            'date' => gmdate('d.m.Y', strtotime($entry['entry_date'])),
            'status' => $status_label,
            'entry_id' => $entry_id,
            'view_url' => self::get_app_url(),
        ];
        
        // Add rejection reason if applicable
        if ($new_status === 'rejected' && !empty($expense['rejection_reason'])) {
            $template_data['rejection_reason'] = $expense['rejection_reason'];
        }
        
        $message = self::get_template('status_update', $template_data);
        
        return self::send([$submitter->user_email], $subject, $message);
    }

    /**
     * Send status update to approvers (for reviewed status)
     *
     * @param int $entry_id Entry ID
     * @param int $expense_id Expense ID
     * @param string $new_status New status
     */
    public static function send_status_update_to_approvers(int $entry_id, int $expense_id, string $new_status): bool {
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        $expense = Isidor_Cellerar_Expenses::get($expense_id);
        
        if (!$entry || !$expense) {
            return false;
        }
        
        $approvers = Isidor_Cellerar_Roles::get_approvers();
        
        if (empty($approvers)) {
            return false;
        }
        
        $submitter = get_userdata($expense['submitted_by']);
        $reviewer = get_userdata($expense['reviewed_by']);
        
        $status_label = Isidor_Cellerar_Expenses::get_status_label($new_status);
        $amount = Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']);
        
        $subject = sprintf(
            __('Ausgabe %s – Wartet auf Genehmigung', 'isidor-cellerar'),
            $status_label
        );
        
        $message = self::get_template('reviewed', [
            'submitter_name' => $submitter ? $submitter->display_name : __('Unbekannt', 'isidor-cellerar'),
            'reviewer_name' => $reviewer ? $reviewer->display_name : __('Unbekannt', 'isidor-cellerar'),
            'amount' => $amount,
            'date' => gmdate('d.m.Y', strtotime($entry['entry_date'])),
            'category' => $entry['category'] ?? __('Keine Kategorie', 'isidor-cellerar'),
            'entry_id' => $entry_id,
            'approve_url' => self::get_app_url(),
        ]);
        
        $recipients = array_map(function ($user) {
            return $user->user_email;
        }, $approvers);
        
        return self::send($recipients, $subject, $message);
    }

    /**
     * Send reimbursement confirmation
     *
     * @param int $entry_id Entry ID
     * @param int $expense_id Expense ID
     */
    public static function send_reimbursement_confirmation(int $entry_id, int $expense_id): bool {
        $entry = Isidor_Cellerar_Entries::get($entry_id);
        $expense = Isidor_Cellerar_Expenses::get($expense_id);
        
        if (!$entry || !$expense) {
            return false;
        }
        
        $submitter = get_userdata($expense['submitted_by']);
        
        if (!$submitter) {
            return false;
        }
        
        $amount = Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']);
        
        $subject = __('Ihre Ausgabe wurde erstattet – Isidor Cellerar', 'isidor-cellerar');
        
        $message = self::get_template('reimbursement', [
            'recipient_name' => $submitter->display_name,
            'amount' => $amount,
            'date' => gmdate('d.m.Y', strtotime($entry['entry_date'])),
            'category' => $entry['category'] ?? __('Keine Kategorie', 'isidor-cellerar'),
            'reference' => sprintf('IC-%06d', $entry_id),
            'reimbursed_at' => gmdate('d.m.Y', strtotime($expense['reimbursed_at'])),
        ]);
        
        return self::send([$submitter->user_email], $subject, $message);
    }

    /**
     * Get email template
     *
     * @param string $template Template name
     * @param array $data Template data
     * @return string Rendered template
     */
    private static function get_template(string $template, array $data): string {
        $templates = [
            'submission' => self::get_submission_template(),
            'status_update' => self::get_status_update_template(),
            'reviewed' => self::get_reviewed_template(),
            'reimbursement' => self::get_reimbursement_template(),
        ];
        
        $content = $templates[$template] ?? '';
        
        // Replace placeholders
        foreach ($data as $key => $value) {
            $content = str_replace('{{' . $key . '}}', esc_html($value), $content);
        }
        
        // Wrap in base template
        return self::wrap_template($content);
    }

    /**
     * Get submission email template
     */
    private static function get_submission_template(): string {
        return '
<h2>' . __('Neue Ausgabe eingereicht', 'isidor-cellerar') . '</h2>
<p>' . __('{{submitter_name}} hat eine neue Ausgabe zur Prüfung eingereicht.', 'isidor-cellerar') . '</p>

<table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9; width: 30%;"><strong>' . __('Betrag', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{amount}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Datum', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{date}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Kategorie', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{category}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Notiz', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{note}}</td>
    </tr>
</table>

<p style="margin-top: 20px;">
    <a href="{{review_url}}" style="display: inline-block; padding: 12px 24px; background: #2563eb; color: white; text-decoration: none; border-radius: 6px;">' . __('Jetzt prüfen', 'isidor-cellerar') . '</a>
</p>';
    }

    /**
     * Get status update email template
     */
    private static function get_status_update_template(): string {
        return '
<h2>' . __('Status-Update für Ihre Ausgabe', 'isidor-cellerar') . '</h2>
<p>' . __('Hallo {{recipient_name}},', 'isidor-cellerar') . '</p>
<p>' . __('Der Status Ihrer Ausgabe wurde aktualisiert.', 'isidor-cellerar') . '</p>

<table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9; width: 30%;"><strong>' . __('Neuer Status', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;"><strong>{{status}}</strong></td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Betrag', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{amount}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Datum', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{date}}</td>
    </tr>
</table>

<p style="margin-top: 20px;">
    <a href="{{view_url}}" style="display: inline-block; padding: 12px 24px; background: #2563eb; color: white; text-decoration: none; border-radius: 6px;">' . __('Details ansehen', 'isidor-cellerar') . '</a>
</p>';
    }

    /**
     * Get reviewed email template
     */
    private static function get_reviewed_template(): string {
        return '
<h2>' . __('Ausgabe wartet auf Genehmigung', 'isidor-cellerar') . '</h2>
<p>' . __('Eine Ausgabe wurde von {{reviewer_name}} geprüft und wartet auf Genehmigung.', 'isidor-cellerar') . '</p>

<table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9; width: 30%;"><strong>' . __('Eingereicht von', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{submitter_name}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Betrag', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{amount}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Datum', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{date}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Kategorie', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{category}}</td>
    </tr>
</table>

<p style="margin-top: 20px;">
    <a href="{{approve_url}}" style="display: inline-block; padding: 12px 24px; background: #16a34a; color: white; text-decoration: none; border-radius: 6px;">' . __('Genehmigen', 'isidor-cellerar') . '</a>
</p>';
    }

    /**
     * Get reimbursement confirmation template
     */
    private static function get_reimbursement_template(): string {
        return '
<h2>' . __('Erstattungsbestätigung', 'isidor-cellerar') . '</h2>
<p>' . __('Hallo {{recipient_name}},', 'isidor-cellerar') . '</p>
<p>' . __('Ihre Ausgabe wurde erstattet.', 'isidor-cellerar') . '</p>

<table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9; width: 30%;"><strong>' . __('Referenz', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{reference}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Betrag', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;"><strong>{{amount}}</strong></td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Ausgabedatum', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{date}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Kategorie', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{category}}</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background: #f9f9f9;"><strong>' . __('Erstattet am', 'isidor-cellerar') . '</strong></td>
        <td style="padding: 8px; border: 1px solid #ddd;">{{reimbursed_at}}</td>
    </tr>
</table>

<p>' . __('Vielen Dank für Ihre Mitarbeit!', 'isidor-cellerar') . '</p>';
    }

    /**
     * Wrap content in base email template
     */
    private static function wrap_template(string $content): string {
        $site_name = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_bloginfo('name');
        
        return '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; background: #f4f4f5;">
    <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <div style="background: white; border-radius: 8px; padding: 32px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 24px;">
                <h1 style="margin: 0; color: #18181b; font-size: 20px;">' . esc_html($site_name) . '</h1>
                <p style="margin: 4px 0 0; color: #71717a; font-size: 14px;">Isidor Cellerar</p>
            </div>
            
            ' . $content . '
            
            <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 32px 0;">
            
            <p style="margin: 0; color: #a1a1aa; font-size: 12px; text-align: center;">
                ' . __('Diese E-Mail wurde automatisch von Isidor Cellerar generiert.', 'isidor-cellerar') . '
            </p>
        </div>
    </div>
</body>
</html>';
    }

    /**
     * Send email
     *
     * @param array $recipients Email addresses
     * @param string $subject Email subject
     * @param string $message HTML message
     * @return bool Success status
     */
    private static function send(array $recipients, string $subject, string $message): bool {
        if (empty($recipients)) {
            return false;
        }
        
        $sender_name = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_bloginfo('name');
        $sender_email = class_exists('Isidor_Parish_Settings') && Isidor_Parish_Settings::get('email')
            ? Isidor_Parish_Settings::get('email')
            : get_option('admin_email');
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $sender_name . ' <' . $sender_email . '>',
        ];
        
        // Send to each recipient individually for privacy
        $success = true;
        foreach ($recipients as $recipient) {
            if (!wp_mail($recipient, $subject, $message, $headers)) {
                $success = false;
                error_log(sprintf('Isidor Cellerar: Failed to send email to %s', $recipient));
            }
        }
        
        return $success;
    }

    /**
     * Get the URL to the frontend app
     */
    private static function get_app_url(): string {
        // Try to find a page with our shortcode
        global $wpdb;
        
        $page_id = $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE '%[isidor_cellerar_app]%'
             LIMIT 1"
        );
        
        if ($page_id) {
            return get_permalink($page_id);
        }
        
        // Fallback to home URL
        return home_url();
    }
}
