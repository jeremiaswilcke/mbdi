<?php
/**
 * REST API endpoints for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_REST_API
 * Handles all REST API endpoints
 */
class Isidor_Cellerar_REST_API {

    private const NAMESPACE = 'isidor/v1';

    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function register_routes(): void {
        // Finances overview
        register_rest_route(self::NAMESPACE, '/finances', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_finances'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // Statistics
        register_rest_route(self::NAMESPACE, '/finances/stats', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_stats'],
            'permission_callback' => [self::class, 'check_stats_permission'],
        ]);

        // Create income
        register_rest_route(self::NAMESPACE, '/income', [
            'methods' => 'POST',
            'callback' => [self::class, 'create_income'],
            'permission_callback' => [self::class, 'check_income_permission'],
        ]);

        // Create expense
        register_rest_route(self::NAMESPACE, '/expense', [
            'methods' => 'POST',
            'callback' => [self::class, 'create_expense'],
            'permission_callback' => [self::class, 'check_expense_permission'],
        ]);

        // Get/Update/Delete entry
        register_rest_route(self::NAMESPACE, '/entry/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [self::class, 'get_entry'],
                'permission_callback' => [self::class, 'check_read_permission'],
            ],
            [
                'methods' => 'PUT',
                'callback' => [self::class, 'update_entry'],
                'permission_callback' => [self::class, 'check_edit_permission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [self::class, 'delete_entry'],
                'permission_callback' => [self::class, 'check_delete_permission'],
            ],
        ]);

        // Expense status workflow
        register_rest_route(self::NAMESPACE, '/expense/(?P<id>\d+)/status', [
            'methods' => 'PUT',
            'callback' => [self::class, 'update_expense_status'],
            'permission_callback' => [self::class, 'check_approve_permission'],
        ]);

        // Pending expenses
        register_rest_route(self::NAMESPACE, '/expenses/pending', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_pending_expenses'],
            'permission_callback' => [self::class, 'check_approve_permission'],
        ]);

        // User submissions
        register_rest_route(self::NAMESPACE, '/my-submissions', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_my_submissions'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // File operations
        register_rest_route(self::NAMESPACE, '/entry/(?P<id>\d+)/file', [
            'methods' => 'POST',
            'callback' => [self::class, 'upload_file'],
            'permission_callback' => [self::class, 'check_file_permission'],
        ]);

        register_rest_route(self::NAMESPACE, '/entry/(?P<id>\d+)/files', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_entry_files'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        register_rest_route(self::NAMESPACE, '/file/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [self::class, 'delete_file'],
            'permission_callback' => [self::class, 'check_file_delete_permission'],
        ]);

        // Messen dropdown
        register_rest_route(self::NAMESPACE, '/messen', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_messen'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // Export
        register_rest_route(self::NAMESPACE, '/export/(?P<format>csv|json)', [
            'methods' => 'GET',
            'callback' => [self::class, 'export_data'],
            'permission_callback' => [self::class, 'check_export_permission'],
        ]);

        // Monthly chart
        register_rest_route(self::NAMESPACE, '/stats/monthly', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_monthly_chart'],
            'permission_callback' => [self::class, 'check_stats_permission'],
        ]);
    }

    // Permission callbacks
    public static function check_read_permission(): bool {
        return current_user_can('isidor_cellerar_read');
    }

    public static function check_income_permission(): bool {
        return current_user_can('isidor_cellerar_add_income');
    }

    public static function check_expense_permission(): bool {
        return current_user_can('isidor_cellerar_add_expense');
    }

    public static function check_approve_permission(): bool {
        return current_user_can('isidor_cellerar_approve_expense');
    }

    public static function check_export_permission(): bool {
        return current_user_can('isidor_cellerar_export');
    }

    public static function check_stats_permission(): bool {
        return current_user_can('isidor_cellerar_view_stats');
    }

    public static function check_edit_permission(WP_REST_Request $request): bool {
        if (!current_user_can('isidor_cellerar_read')) {
            return false;
        }
        $entry = Isidor_Cellerar_Entries::get((int) $request->get_param('id'));
        if (!$entry) {
            return false;
        }
        return (int) $entry['user_id'] === get_current_user_id()
            || current_user_can('isidor_cellerar_approve_expense');
    }

    public static function check_delete_permission(WP_REST_Request $request): bool {
        return self::check_edit_permission($request);
    }

    public static function check_file_permission(WP_REST_Request $request): bool {
        $entry = Isidor_Cellerar_Entries::get((int) $request->get_param('id'));
        if (!$entry) {
            return false;
        }
        return (int) $entry['user_id'] === get_current_user_id()
            || current_user_can('isidor_cellerar_approve_expense');
    }

    public static function check_file_delete_permission(WP_REST_Request $request): bool {
        $file = Isidor_Cellerar_Files::get((int) $request->get_param('id'));
        if (!$file) {
            return false;
        }
        return (int) $file['uploaded_by'] === get_current_user_id()
            || current_user_can('isidor_cellerar_approve_expense');
    }

    // GET /finances
    public static function get_finances(WP_REST_Request $request): WP_REST_Response {
        $args = [
            'type' => $request->get_param('type'),
            'subtype' => $request->get_param('subtype'),
            'date_from' => $request->get_param('date_from'),
            'date_to' => $request->get_param('date_to'),
            'category' => $request->get_param('category'),
            'messe_id' => $request->get_param('messe_id'),
            'search' => $request->get_param('search'),
            'limit' => $request->get_param('limit') ?: 50,
            'offset' => $request->get_param('offset') ?: 0,
            'orderby' => $request->get_param('orderby') ?: 'entry_date',
            'order' => $request->get_param('order') ?: 'DESC',
        ];

        $result = Isidor_Cellerar_Entries::query($args);

        foreach ($result['items'] as &$item) {
            $item['amount_formatted'] = Isidor_Cellerar_Entries::format_amount((int) $item['amount_cents'], $item['currency']);
            $item['type_label'] = Isidor_Cellerar_Entries::get_type_label($item['type']);
            $item['subtype_label'] = Isidor_Cellerar_Entries::get_subtype_label($item['subtype']);

            if ($item['type'] === 'expense') {
                $expense = Isidor_Cellerar_Expenses::get_by_entry((int) $item['id']);
                if ($expense) {
                    $item['expense_status'] = $expense['status'];
                    $item['expense_status_label'] = Isidor_Cellerar_Expenses::get_status_label($expense['status']);
                }
            }
            $item['file_count'] = count(Isidor_Cellerar_Files::get_by_entry((int) $item['id']));
        }

        return new WP_REST_Response(['success' => true, 'data' => $result]);
    }

    // GET /finances/stats
    public static function get_stats(WP_REST_Request $request): WP_REST_Response {
        $filters = [
            'date_from' => $request->get_param('date_from'),
            'date_to' => $request->get_param('date_to'),
        ];

        return new WP_REST_Response([
            'success' => true,
            'data' => [
                'summary' => Isidor_Cellerar_Statistics::get_summary($filters),
                'income_breakdown' => Isidor_Cellerar_Statistics::get_income_breakdown($filters),
                'top_expense_categories' => Isidor_Cellerar_Statistics::get_top_categories('expense', 5, $filters),
                'open_expenses' => Isidor_Cellerar_Statistics::get_open_expenses_summary(),
            ],
        ]);
    }

    // POST /income
    public static function create_income(WP_REST_Request $request): WP_REST_Response {
        $data = [
            'type' => 'income',
            'subtype' => sanitize_text_field($request->get_param('subtype') ?? 'klingelbeutel'),
            'entry_date' => sanitize_text_field($request->get_param('entry_date')),
            'amount_cents' => Isidor_Cellerar_Entries::parse_amount_to_cents($request->get_param('amount')),
            'currency' => sanitize_text_field($request->get_param('currency') ?? 'EUR'),
            'method' => sanitize_text_field($request->get_param('method') ?? ''),
            'note' => sanitize_textarea_field($request->get_param('note') ?? ''),
            'category' => sanitize_text_field($request->get_param('category') ?? ''),
            'messe_id' => $request->get_param('messe_id') ? absint($request->get_param('messe_id')) : null,
        ];

        $result = Isidor_Cellerar_Entries::create($data);

        if (is_wp_error($result)) {
            return new WP_REST_Response([
                'success' => false,
                'error' => $result->get_error_message(),
            ], 400);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => ['id' => $result],
        ], 201);
    }

    // POST /expense
    public static function create_expense(WP_REST_Request $request): WP_REST_Response {
        $data = [
            'entry_date' => sanitize_text_field($request->get_param('entry_date')),
            'amount_cents' => Isidor_Cellerar_Entries::parse_amount_to_cents($request->get_param('amount')),
            'currency' => sanitize_text_field($request->get_param('currency') ?? 'EUR'),
            'method' => sanitize_text_field($request->get_param('method') ?? ''),
            'note' => sanitize_textarea_field($request->get_param('note') ?? ''),
            'category' => sanitize_text_field($request->get_param('category') ?? ''),
            'expense_notes' => sanitize_textarea_field($request->get_param('expense_notes') ?? ''),
        ];

        $result = Isidor_Cellerar_Expenses::submit($data);

        if (is_wp_error($result)) {
            return new WP_REST_Response([
                'success' => false,
                'error' => $result->get_error_message(),
            ], 400);
        }

        return new WP_REST_Response([
            'success' => true,
            'data' => ['id' => $result],
        ], 201);
    }

    // GET /entry/{id}
    public static function get_entry(WP_REST_Request $request): WP_REST_Response {
        $entry = Isidor_Cellerar_Entries::get((int) $request->get_param('id'));

        if (!$entry) {
            return new WP_REST_Response(['success' => false, 'error' => 'Not found'], 404);
        }

        $entry['amount_formatted'] = Isidor_Cellerar_Entries::format_amount((int) $entry['amount_cents'], $entry['currency']);
        $entry['files'] = Isidor_Cellerar_Files::get_by_entry((int) $entry['id']);

        if ($entry['type'] === 'expense') {
            $expense = Isidor_Cellerar_Expenses::get_by_entry((int) $entry['id']);
            if ($expense) {
                $entry['expense'] = $expense;
                $entry['expense']['status_label'] = Isidor_Cellerar_Expenses::get_status_label($expense['status']);
                $entry['expense']['available_actions'] = Isidor_Cellerar_Expenses::get_available_actions($expense['status']);
            }
        }

        return new WP_REST_Response(['success' => true, 'data' => $entry]);
    }

    // PUT /entry/{id}
    public static function update_entry(WP_REST_Request $request): WP_REST_Response {
        $entry_id = (int) $request->get_param('id');
        $data = [];

        $fields = ['entry_date', 'method', 'note', 'category'];
        foreach ($fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $data[$field] = $field === 'note' ? sanitize_textarea_field($value) : sanitize_text_field($value);
            }
        }

        if ($request->get_param('amount') !== null) {
            $data['amount_cents'] = Isidor_Cellerar_Entries::parse_amount_to_cents($request->get_param('amount'));
        }

        $result = Isidor_Cellerar_Entries::update($entry_id, $data);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 400);
        }

        return new WP_REST_Response(['success' => true]);
    }

    // DELETE /entry/{id}
    public static function delete_entry(WP_REST_Request $request): WP_REST_Response {
        $result = Isidor_Cellerar_Entries::delete((int) $request->get_param('id'));

        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 400);
        }

        return new WP_REST_Response(['success' => true]);
    }

    // PUT /expense/{id}/status
    public static function update_expense_status(WP_REST_Request $request): WP_REST_Response {
        $expense_id = (int) $request->get_param('id');
        $new_status = sanitize_text_field($request->get_param('status'));
        $reason = sanitize_textarea_field($request->get_param('reason') ?? '');

        $result = Isidor_Cellerar_Expenses::update_status($expense_id, $new_status, $reason ?: null);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 400);
        }

        return new WP_REST_Response(['success' => true]);
    }

    // GET /expenses/pending
    public static function get_pending_expenses(WP_REST_Request $request): WP_REST_Response {
        $result = Isidor_Cellerar_Expenses::get_pending();
        return new WP_REST_Response(['success' => true, 'data' => $result]);
    }

    // GET /my-submissions
    public static function get_my_submissions(WP_REST_Request $request): WP_REST_Response {
        $result = Isidor_Cellerar_Expenses::get_user_submissions();
        return new WP_REST_Response(['success' => true, 'data' => $result]);
    }

    // POST /entry/{id}/file
    public static function upload_file(WP_REST_Request $request): WP_REST_Response {
        $entry_id = (int) $request->get_param('id');
        $files = $request->get_file_params();

        if (empty($files['file'])) {
            return new WP_REST_Response(['success' => false, 'error' => 'No file uploaded'], 400);
        }

        $result = Isidor_Cellerar_Files::upload($entry_id, $files['file']);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 400);
        }

        $file = Isidor_Cellerar_Files::get($result);
        return new WP_REST_Response(['success' => true, 'data' => $file], 201);
    }

    // GET /entry/{id}/files
    public static function get_entry_files(WP_REST_Request $request): WP_REST_Response {
        $files = Isidor_Cellerar_Files::get_by_entry((int) $request->get_param('id'));
        return new WP_REST_Response(['success' => true, 'data' => $files]);
    }

    // DELETE /file/{id}
    public static function delete_file(WP_REST_Request $request): WP_REST_Response {
        $result = Isidor_Cellerar_Files::delete((int) $request->get_param('id'));

        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 400);
        }

        return new WP_REST_Response(['success' => true]);
    }

    // GET /messen
    public static function get_messen(WP_REST_Request $request): WP_REST_Response {
        if (!post_type_exists('isidor_messe')) {
            return new WP_REST_Response(['success' => true, 'data' => []]);
        }

        $args = [
            'post_type' => 'isidor_messe',
            'posts_per_page' => 100,
            'orderby' => 'meta_value',
            'meta_key' => '_is_date',
            'order' => 'DESC',
        ];

        // Optional date filter
        if ($request->get_param('date_from')) {
            $args['meta_query'][] = [
                'key' => '_is_date',
                'value' => $request->get_param('date_from'),
                'compare' => '>=',
                'type' => 'DATE',
            ];
        }

        $messen = get_posts($args);
        $data = [];

        foreach ($messen as $messe) {
            $data[] = [
                'id' => $messe->ID,
                'title' => $messe->post_title,
                'date' => get_post_meta($messe->ID, '_is_date', true),
                'time' => get_post_meta($messe->ID, '_is_time', true),
            ];
        }

        return new WP_REST_Response(['success' => true, 'data' => $data]);
    }

    // GET /export/{format}
    public static function export_data(WP_REST_Request $request): void {
        $format = $request->get_param('format');
        $filters = [
            'type' => $request->get_param('type'),
            'date_from' => $request->get_param('date_from'),
            'date_to' => $request->get_param('date_to'),
            'category' => $request->get_param('category'),
            'status' => $request->get_param('status'),
        ];

        Isidor_Cellerar_Export::download($format, array_filter($filters));
    }

    // GET /stats/monthly
    public static function get_monthly_chart(WP_REST_Request $request): WP_REST_Response {
        $months = $request->get_param('months') ?: 12;
        $data = Isidor_Cellerar_Statistics::get_monthly_chart((int) $months);
        return new WP_REST_Response(['success' => true, 'data' => $data]);
    }
}
