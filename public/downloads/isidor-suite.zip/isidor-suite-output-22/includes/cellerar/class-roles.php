<?php
/**
 * Roles and Capabilities management for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Roles
 * Manages custom capabilities for the plugin
 */
class Isidor_Cellerar_Roles {

    /**
     * All custom capabilities
     */
    private const CAPABILITIES = [
        'isidor_cellerar_read',
        'isidor_cellerar_add_income',
        'isidor_cellerar_add_expense',
        'isidor_cellerar_approve_expense',
        'isidor_cellerar_export',
        'isidor_cellerar_view_stats',
        'isidor_cellerar_manage_settings',
    ];

    /**
     * Target roles and their assigned capabilities
     */
    private const ROLE_CAPABILITIES = [
        'administrator' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
            'isidor_cellerar_approve_expense',
            'isidor_cellerar_export',
            'isidor_cellerar_view_stats',
            'isidor_cellerar_manage_settings',
        ],
        'isidor_vvr' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
            'isidor_cellerar_approve_expense',
            'isidor_cellerar_export',
            'isidor_cellerar_view_stats',
        ],
        'isidor_pfarrer' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
            'isidor_cellerar_approve_expense',
            'isidor_cellerar_export',
            'isidor_cellerar_view_stats',
        ],
        'isidor_diakon' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
            'isidor_cellerar_view_stats',
        ],
        'isidor_sekretaer' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
            'isidor_cellerar_view_stats',
        ],
        'isidor_mesner' => [
            'isidor_cellerar_read',
            'isidor_cellerar_add_income',
            'isidor_cellerar_add_expense',
        ],
    ];

    /**
     * Get all capabilities
     */
    public static function get_capabilities(): array {
        return self::CAPABILITIES;
    }

    /**
     * Get role capabilities mapping
     */
    public static function get_role_capabilities(): array {
        return self::ROLE_CAPABILITIES;
    }

    /**
     * Add capabilities to roles
     */
    public static function add_capabilities(): void {
        foreach (self::ROLE_CAPABILITIES as $role_name => $caps) {
            $role = get_role($role_name);
            
            if ($role === null) {
                continue; // Role doesn't exist, skip
            }
            
            foreach ($caps as $cap) {
                $role->add_cap($cap);
            }
        }
    }

    /**
     * Remove capabilities from all roles
     */
    public static function remove_capabilities(): void {
        global $wp_roles;
        
        if (!isset($wp_roles)) {
            $wp_roles = new WP_Roles();
        }
        
        foreach ($wp_roles->roles as $role_name => $role_info) {
            $role = get_role($role_name);
            
            if ($role === null) {
                continue;
            }
            
            foreach (self::CAPABILITIES as $cap) {
                $role->remove_cap($cap);
            }
        }
    }

    /**
     * Check if user has any Cellerar capability
     */
    public static function user_has_access(?int $user_id = null): bool {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        if ($user_id === 0) {
            return false;
        }
        
        $user = get_userdata($user_id);
        
        if (!$user) {
            return false;
        }
        
        foreach (self::CAPABILITIES as $cap) {
            if ($user->has_cap($cap)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Get list of users with approval capability
     */
    public static function get_approvers(): array {
        $users = get_users([
            'capability' => 'isidor_cellerar_approve_expense',
            'fields' => ['ID', 'display_name', 'user_email'],
        ]);
        
        return $users;
    }

    /**
     * Get capability label for display
     */
    public static function get_capability_label(string $cap): string {
        $labels = [
            'isidor_cellerar_read' => __('Cellerar lesen', 'isidor-cellerar'),
            'isidor_cellerar_add_income' => __('Einnahmen hinzufügen', 'isidor-cellerar'),
            'isidor_cellerar_add_expense' => __('Ausgaben hinzufügen', 'isidor-cellerar'),
            'isidor_cellerar_approve_expense' => __('Ausgaben genehmigen', 'isidor-cellerar'),
            'isidor_cellerar_export' => __('Export', 'isidor-cellerar'),
            'isidor_cellerar_view_stats' => __('Statistiken ansehen', 'isidor-cellerar'),
            'isidor_cellerar_manage_settings' => __('Einstellungen verwalten', 'isidor-cellerar'),
        ];
        
        return $labels[$cap] ?? $cap;
    }

    /**
     * Check if current user can perform specific action
     */
    public static function current_user_can(string $capability): bool {
        return current_user_can($capability);
    }

    /**
     * Verify user capability and die if not allowed
     */
    public static function verify_capability(string $capability): void {
        if (!current_user_can($capability)) {
            wp_die(
                esc_html__('Sie haben keine Berechtigung für diese Aktion.', 'isidor-cellerar'),
                esc_html__('Zugriff verweigert', 'isidor-cellerar'),
                ['response' => 403]
            );
        }
    }

    /**
     * Get user's capabilities summary
     */
    public static function get_user_capabilities_summary(?int $user_id = null): array {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        $summary = [];
        
        foreach (self::CAPABILITIES as $cap) {
            $summary[$cap] = user_can($user_id, $cap);
        }
        
        return $summary;
    }
}
