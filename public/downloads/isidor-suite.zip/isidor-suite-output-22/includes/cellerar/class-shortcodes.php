<?php
/**
 * Shortcodes for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Shortcodes
 * Handles shortcode registration and rendering
 */
class Isidor_Cellerar_Shortcodes {

    /**
     * Initialize shortcodes
     */
    public static function init(): void {
        add_shortcode('isidor_cellerar_app', [self::class, 'render_app']);
        add_shortcode('isidor_cellerar_my_submissions', [self::class, 'render_my_submissions']);
        add_shortcode('isidor_cellerar_submit_expense', [self::class, 'render_submit_expense']);
    }

    /**
     * Render expense submission shortcode
     */
    public static function render_submit_expense(array $atts = []): string {
        if (!is_user_logged_in()) {
            return self::render_login_required();
        }
        return self::render_app(['view' => 'submit']);
    }

    /**
     * Render main app shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string HTML output
     */
    public static function render_app(array $atts = []): string {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return self::render_login_required();
        }

        // Check if user has any permission
        if (!Isidor_Cellerar_Roles::user_has_access()) {
            return self::render_access_denied();
        }

        // Check if CPT exists (warning only)
        $messe_warning = '';
        if (!post_type_exists('isidor_messe')) {
            $messe_warning = '<div class="ic-notice ic-notice-warning">' .
                '<span class="ic-notice-icon">⚠️</span>' .
                '<span>' . esc_html__('Der CPT "isidor_messe" wurde nicht gefunden. Pfarrcafé-Einnahmen können nicht einer Messe zugeordnet werden.', 'isidor-cellerar') . '</span>' .
            '</div>';
        }

        $user_caps = Isidor_Cellerar_Roles::get_user_capabilities_summary();

        ob_start();
        ?>
        <div id="isidor-cellerar-app" class="ic-app" data-caps='<?php echo esc_attr(wp_json_encode($user_caps)); ?>'>
            <?php echo $messe_warning; ?>
            
            <!-- Tab Navigation -->
            <nav class="ic-tabs" role="tablist">
                <?php if ($user_caps['isidor_cellerar_add_income']): ?>
                <button class="ic-tab active" data-tab="income" role="tab" aria-selected="true">
                    <span class="ic-tab-icon">📥</span>
                    <?php esc_html_e('Einnahmen', 'isidor-cellerar'); ?>
                </button>
                <?php endif; ?>
                
                <?php if ($user_caps['isidor_cellerar_add_expense']): ?>
                <button class="ic-tab" data-tab="expenses" role="tab">
                    <span class="ic-tab-icon">📤</span>
                    <?php esc_html_e('Ausgaben', 'isidor-cellerar'); ?>
                </button>
                <?php endif; ?>
                
                <?php if ($user_caps['isidor_cellerar_view_stats']): ?>
                <button class="ic-tab" data-tab="stats" role="tab">
                    <span class="ic-tab-icon">📊</span>
                    <?php esc_html_e('Statistik', 'isidor-cellerar'); ?>
                </button>
                <?php endif; ?>
                
                <?php if ($user_caps['isidor_cellerar_export']): ?>
                <button class="ic-tab" data-tab="export" role="tab">
                    <span class="ic-tab-icon">📁</span>
                    <?php esc_html_e('Export', 'isidor-cellerar'); ?>
                </button>
                <?php endif; ?>
            </nav>

            <!-- Tab Content -->
            <div class="ic-tab-content">
                <!-- Income Tab -->
                <?php if ($user_caps['isidor_cellerar_add_income']): ?>
                <div class="ic-panel active" id="ic-panel-income" role="tabpanel">
                    <?php echo self::render_income_panel(); ?>
                </div>
                <?php endif; ?>

                <!-- Expenses Tab -->
                <?php if ($user_caps['isidor_cellerar_add_expense']): ?>
                <div class="ic-panel" id="ic-panel-expenses" role="tabpanel">
                    <?php echo self::render_expenses_panel($user_caps['isidor_cellerar_approve_expense']); ?>
                </div>
                <?php endif; ?>

                <!-- Statistics Tab -->
                <?php if ($user_caps['isidor_cellerar_view_stats']): ?>
                <div class="ic-panel" id="ic-panel-stats" role="tabpanel">
                    <?php echo self::render_stats_panel(); ?>
                </div>
                <?php endif; ?>

                <!-- Export Tab -->
                <?php if ($user_caps['isidor_cellerar_export']): ?>
                <div class="ic-panel" id="ic-panel-export" role="tabpanel">
                    <?php echo self::render_export_panel(); ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Modal Container -->
            <div id="ic-modal" class="ic-modal" aria-hidden="true">
                <div class="ic-modal-overlay"></div>
                <div class="ic-modal-container">
                    <div class="ic-modal-header">
                        <h3 class="ic-modal-title"></h3>
                        <button type="button" class="ic-modal-close" aria-label="<?php esc_attr_e('Schließen', 'isidor-cellerar'); ?>">&times;</button>
                    </div>
                    <div class="ic-modal-body"></div>
                    <div class="ic-modal-footer"></div>
                </div>
            </div>

            <!-- Toast Notifications -->
            <div id="ic-toasts" class="ic-toasts" aria-live="polite"></div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render income panel
     */
    private static function render_income_panel(): string {
        $subtypes = [
            'klingelbeutel' => __('Klingelbeutel', 'isidor-cellerar'),
            'pfarrcafe' => __('Pfarrcafé', 'isidor-cellerar'),
            'sonstige' => __('Sonstige', 'isidor-cellerar'),
        ];

        ob_start();
        ?>
        <div class="ic-section">
            <h3 class="ic-section-title"><?php esc_html_e('Neue Einnahme erfassen', 'isidor-cellerar'); ?></h3>
            
            <form id="ic-income-form" class="ic-form">
                <?php wp_nonce_field('isidor_cellerar_nonce', 'ic_nonce'); ?>
                
                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-income-subtype"><?php esc_html_e('Typ', 'isidor-cellerar'); ?> *</label>
                        <select id="ic-income-subtype" name="subtype" required>
                            <?php foreach ($subtypes as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="ic-form-group">
                        <label for="ic-income-date"><?php esc_html_e('Datum', 'isidor-cellerar'); ?> *</label>
                        <input type="date" id="ic-income-date" name="entry_date" required value="<?php echo esc_attr(gmdate('Y-m-d')); ?>">
                    </div>
                </div>

                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-income-amount"><?php esc_html_e('Betrag (€)', 'isidor-cellerar'); ?> *</label>
                        <input type="text" id="ic-income-amount" name="amount" required placeholder="0,00" pattern="[0-9]+([,\.][0-9]{1,2})?" inputmode="decimal">
                    </div>
                    
                    <div class="ic-form-group ic-form-group-messe" style="display: none;">
                        <label for="ic-income-messe"><?php esc_html_e('Messe', 'isidor-cellerar'); ?> <span class="ic-required-marker">*</span></label>
                        <select id="ic-income-messe" name="messe_id">
                            <option value=""><?php esc_html_e('Messe auswählen...', 'isidor-cellerar'); ?></option>
                        </select>
                    </div>
                </div>

                <div class="ic-form-row ic-form-group-category" style="display: none;">
                    <div class="ic-form-group">
                        <label for="ic-income-category"><?php esc_html_e('Kategorie', 'isidor-cellerar'); ?></label>
                        <select id="ic-income-category" name="category">
                            <option value=""><?php esc_html_e('Keine', 'isidor-cellerar'); ?></option>
                            <?php foreach (Isidor_Cellerar_Entries::get_pfarrcafe_categories() as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="ic-form-group">
                    <label for="ic-income-note"><?php esc_html_e('Notiz', 'isidor-cellerar'); ?></label>
                    <textarea id="ic-income-note" name="note" rows="2" placeholder="<?php esc_attr_e('Optionale Anmerkungen...', 'isidor-cellerar'); ?>"></textarea>
                </div>

                <div class="ic-form-actions">
                    <button type="submit" class="ic-btn ic-btn-primary">
                        <span class="ic-btn-icon">💾</span>
                        <?php esc_html_e('Speichern', 'isidor-cellerar'); ?>
                    </button>
                </div>
            </form>
        </div>

        <div class="ic-section">
            <div class="ic-section-header">
                <h3 class="ic-section-title"><?php esc_html_e('Einnahmen-Übersicht', 'isidor-cellerar'); ?></h3>
                <div class="ic-filters">
                    <input type="date" id="ic-income-filter-from" placeholder="Von">
                    <input type="date" id="ic-income-filter-to" placeholder="Bis">
                    <button type="button" class="ic-btn ic-btn-secondary ic-btn-sm" id="ic-income-filter-apply">
                        <?php esc_html_e('Filtern', 'isidor-cellerar'); ?>
                    </button>
                </div>
            </div>
            
            <div id="ic-income-list" class="ic-list">
                <div class="ic-loading"><?php esc_html_e('Wird geladen...', 'isidor-cellerar'); ?></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render expenses panel
     */
    private static function render_expenses_panel(bool $can_approve): string {
        $categories = Isidor_Cellerar_Entries::get_expense_categories();

        ob_start();
        ?>
        <div class="ic-section">
            <h3 class="ic-section-title"><?php esc_html_e('Neue Ausgabe einreichen', 'isidor-cellerar'); ?></h3>
            
            <form id="ic-expense-form" class="ic-form" enctype="multipart/form-data">
                <?php wp_nonce_field('isidor_cellerar_nonce', 'ic_nonce'); ?>
                
                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-expense-date"><?php esc_html_e('Datum', 'isidor-cellerar'); ?> *</label>
                        <input type="date" id="ic-expense-date" name="entry_date" required value="<?php echo esc_attr(gmdate('Y-m-d')); ?>">
                    </div>
                    
                    <div class="ic-form-group">
                        <label for="ic-expense-amount"><?php esc_html_e('Betrag (€)', 'isidor-cellerar'); ?> *</label>
                        <input type="text" id="ic-expense-amount" name="amount" required placeholder="0,00" pattern="[0-9]+([,\.][0-9]{1,2})?" inputmode="decimal">
                    </div>
                </div>

                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-expense-category"><?php esc_html_e('Kategorie', 'isidor-cellerar'); ?> *</label>
                        <select id="ic-expense-category" name="category" required>
                            <option value=""><?php esc_html_e('Auswählen...', 'isidor-cellerar'); ?></option>
                            <?php foreach ($categories as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="ic-form-group">
                        <label for="ic-expense-method"><?php esc_html_e('Zahlungsart', 'isidor-cellerar'); ?></label>
                        <select id="ic-expense-method" name="method">
                            <option value=""><?php esc_html_e('Nicht angegeben', 'isidor-cellerar'); ?></option>
                            <option value="bar"><?php esc_html_e('Bar', 'isidor-cellerar'); ?></option>
                            <option value="ueberweisung"><?php esc_html_e('Überweisung', 'isidor-cellerar'); ?></option>
                            <option value="karte"><?php esc_html_e('Karte', 'isidor-cellerar'); ?></option>
                        </select>
                    </div>
                </div>

                <div class="ic-form-group">
                    <label for="ic-expense-note"><?php esc_html_e('Beschreibung', 'isidor-cellerar'); ?> *</label>
                    <textarea id="ic-expense-note" name="note" rows="3" required placeholder="<?php esc_attr_e('Wofür wurde das Geld ausgegeben?', 'isidor-cellerar'); ?>"></textarea>
                </div>

                <div class="ic-form-group">
                    <label for="ic-expense-file"><?php esc_html_e('Beleg (optional)', 'isidor-cellerar'); ?></label>
                    <div class="ic-file-upload">
                        <input type="file" id="ic-expense-file" name="file" accept=".pdf,.jpg,.jpeg,.png">
                        <div class="ic-file-upload-info">
                            <span class="ic-file-upload-icon">📎</span>
                            <span><?php esc_html_e('PDF, JPG oder PNG (max. 5 MB)', 'isidor-cellerar'); ?></span>
                        </div>
                        <div class="ic-file-preview" style="display: none;"></div>
                    </div>
                </div>

                <div class="ic-form-actions">
                    <button type="submit" class="ic-btn ic-btn-primary">
                        <span class="ic-btn-icon">📤</span>
                        <?php esc_html_e('Einreichen', 'isidor-cellerar'); ?>
                    </button>
                </div>
            </form>
        </div>

        <?php if ($can_approve): ?>
        <div class="ic-section">
            <h3 class="ic-section-title"><?php esc_html_e('Offene Ausgaben', 'isidor-cellerar'); ?></h3>
            <div id="ic-pending-expenses" class="ic-list">
                <div class="ic-loading"><?php esc_html_e('Wird geladen...', 'isidor-cellerar'); ?></div>
            </div>
        </div>
        <?php endif; ?>

        <div class="ic-section">
            <h3 class="ic-section-title"><?php esc_html_e('Meine Einreichungen', 'isidor-cellerar'); ?></h3>
            <div id="ic-my-submissions" class="ic-list">
                <div class="ic-loading"><?php esc_html_e('Wird geladen...', 'isidor-cellerar'); ?></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render statistics panel
     */
    private static function render_stats_panel(): string {
        ob_start();
        ?>
        <div class="ic-section">
            <div class="ic-section-header">
                <h3 class="ic-section-title"><?php esc_html_e('Finanzübersicht', 'isidor-cellerar'); ?></h3>
                <div class="ic-filters">
                    <input type="date" id="ic-stats-filter-from" placeholder="Von">
                    <input type="date" id="ic-stats-filter-to" placeholder="Bis">
                    <button type="button" class="ic-btn ic-btn-secondary ic-btn-sm" id="ic-stats-filter-apply">
                        <?php esc_html_e('Aktualisieren', 'isidor-cellerar'); ?>
                    </button>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="ic-stats-cards">
                <div class="ic-stat-card ic-stat-income">
                    <div class="ic-stat-icon">📥</div>
                    <div class="ic-stat-content">
                        <span class="ic-stat-label"><?php esc_html_e('Einnahmen', 'isidor-cellerar'); ?></span>
                        <span class="ic-stat-value" id="ic-stat-income">-</span>
                    </div>
                </div>
                <div class="ic-stat-card ic-stat-expense">
                    <div class="ic-stat-icon">📤</div>
                    <div class="ic-stat-content">
                        <span class="ic-stat-label"><?php esc_html_e('Ausgaben', 'isidor-cellerar'); ?></span>
                        <span class="ic-stat-value" id="ic-stat-expense">-</span>
                    </div>
                </div>
                <div class="ic-stat-card ic-stat-balance">
                    <div class="ic-stat-icon">💰</div>
                    <div class="ic-stat-content">
                        <span class="ic-stat-label"><?php esc_html_e('Saldo', 'isidor-cellerar'); ?></span>
                        <span class="ic-stat-value" id="ic-stat-balance">-</span>
                    </div>
                </div>
            </div>

            <!-- Monthly Chart -->
            <div class="ic-chart-container">
                <h4><?php esc_html_e('Monatsverlauf', 'isidor-cellerar'); ?></h4>
                <canvas id="ic-monthly-chart"></canvas>
            </div>

            <!-- Breakdowns -->
            <div class="ic-stats-row">
                <div class="ic-stats-col">
                    <h4><?php esc_html_e('Einnahmen nach Typ', 'isidor-cellerar'); ?></h4>
                    <div id="ic-income-breakdown" class="ic-breakdown-list"></div>
                </div>
                <div class="ic-stats-col">
                    <h4><?php esc_html_e('Top Ausgabenkategorien', 'isidor-cellerar'); ?></h4>
                    <div id="ic-expense-breakdown" class="ic-breakdown-list"></div>
                </div>
            </div>

            <!-- Open Expenses -->
            <div class="ic-stats-open">
                <h4><?php esc_html_e('Offene Ausgaben', 'isidor-cellerar'); ?></h4>
                <div id="ic-open-expenses-stats" class="ic-stats-cards ic-stats-cards-sm"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render export panel
     */
    private static function render_export_panel(): string {
        $formats = Isidor_Cellerar_Export::get_available_formats();

        ob_start();
        ?>
        <div class="ic-section">
            <h3 class="ic-section-title"><?php esc_html_e('Daten exportieren', 'isidor-cellerar'); ?></h3>

            <form id="ic-export-form" class="ic-form">
                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-export-type"><?php esc_html_e('Typ', 'isidor-cellerar'); ?></label>
                        <select id="ic-export-type" name="type">
                            <option value=""><?php esc_html_e('Alle', 'isidor-cellerar'); ?></option>
                            <option value="income"><?php esc_html_e('Nur Einnahmen', 'isidor-cellerar'); ?></option>
                            <option value="expense"><?php esc_html_e('Nur Ausgaben', 'isidor-cellerar'); ?></option>
                        </select>
                    </div>
                    
                    <div class="ic-form-group">
                        <label for="ic-export-format"><?php esc_html_e('Format', 'isidor-cellerar'); ?></label>
                        <select id="ic-export-format" name="format" required>
                            <?php foreach ($formats as $value => $info): ?>
                            <option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($info['label'] . ' - ' . $info['description']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="ic-form-row">
                    <div class="ic-form-group">
                        <label for="ic-export-from"><?php esc_html_e('Von Datum', 'isidor-cellerar'); ?></label>
                        <input type="date" id="ic-export-from" name="date_from">
                    </div>
                    
                    <div class="ic-form-group">
                        <label for="ic-export-to"><?php esc_html_e('Bis Datum', 'isidor-cellerar'); ?></label>
                        <input type="date" id="ic-export-to" name="date_to">
                    </div>
                </div>

                <div class="ic-form-actions">
                    <button type="submit" class="ic-btn ic-btn-primary">
                        <span class="ic-btn-icon">📥</span>
                        <?php esc_html_e('Export starten', 'isidor-cellerar'); ?>
                    </button>
                </div>
            </form>

            <div class="ic-export-info">
                <p><strong><?php esc_html_e('Hinweis:', 'isidor-cellerar'); ?></strong> <?php esc_html_e('Jeder Export wird im Audit-Log protokolliert.', 'isidor-cellerar'); ?></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render my submissions shortcode
     */
    public static function render_my_submissions(array $atts = []): string {
        if (!is_user_logged_in()) {
            return self::render_login_required();
        }

        if (!current_user_can('isidor_cellerar_read')) {
            return self::render_access_denied();
        }

        ob_start();
        ?>
        <div id="isidor-cellerar-submissions" class="ic-app ic-app-submissions">
            <h3 class="ic-section-title"><?php esc_html_e('Meine Ausgaben-Einreichungen', 'isidor-cellerar'); ?></h3>
            <div id="ic-submissions-list" class="ic-list">
                <div class="ic-loading"><?php esc_html_e('Wird geladen...', 'isidor-cellerar'); ?></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render login required message
     */
    private static function render_login_required(): string {
        return '<div class="ic-notice ic-notice-info">' .
            '<span class="ic-notice-icon">🔐</span>' .
            '<span>' . esc_html__('Bitte melden Sie sich an, um auf das Finanzsystem zuzugreifen.', 'isidor-cellerar') . '</span>' .
            '<a href="' . esc_url(wp_login_url(get_permalink())) . '" class="ic-btn ic-btn-primary ic-btn-sm">' . esc_html__('Anmelden', 'isidor-cellerar') . '</a>' .
        '</div>';
    }

    /**
     * Render access denied message
     */
    private static function render_access_denied(): string {
        return '<div class="ic-notice ic-notice-error">' .
            '<span class="ic-notice-icon">🚫</span>' .
            '<span>' . esc_html__('Sie haben keine Berechtigung, auf das Finanzsystem zuzugreifen.', 'isidor-cellerar') . '</span>' .
        '</div>';
    }
}
