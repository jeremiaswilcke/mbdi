<?php
/**
 * Statistics and reporting for Isidor Cellerar
 *
 * @package IsidorCellerar
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Isidor_Cellerar_Statistics
 * Handles statistics generation and analysis
 */
class Isidor_Cellerar_Statistics {

    /**
     * Get summary statistics
     *
     * @param array $filters Optional filters (date_from, date_to)
     */
    public static function get_summary(array $filters = []): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ['1=1'];
        $values = [];
        
        if (!empty($filters['date_from'])) {
            $where[] = 'entry_date >= %s';
            $values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'entry_date <= %s';
            $values[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Get income total
        $income_sql = "SELECT COALESCE(SUM(amount_cents), 0) FROM {$table} WHERE type = 'income' AND {$where_clause}";
        if (!empty($values)) {
            $income_sql = $wpdb->prepare($income_sql, $values);
        }
        $income_total = (int) $wpdb->get_var($income_sql);
        
        // Get expense total
        $expense_sql = "SELECT COALESCE(SUM(amount_cents), 0) FROM {$table} WHERE type = 'expense' AND {$where_clause}";
        if (!empty($values)) {
            $expense_sql = $wpdb->prepare($expense_sql, $values);
        }
        $expense_total = (int) $wpdb->get_var($expense_sql);
        
        // Calculate balance
        $balance = $income_total - $expense_total;
        
        return [
            'income_total' => $income_total,
            'expense_total' => $expense_total,
            'balance' => $balance,
            'income_formatted' => Isidor_Cellerar_Entries::format_amount($income_total),
            'expense_formatted' => Isidor_Cellerar_Entries::format_amount($expense_total),
            'balance_formatted' => Isidor_Cellerar_Entries::format_amount($balance),
        ];
    }

    /**
     * Get monthly chart data
     *
     * @param int $months Number of months to include
     */
    public static function get_monthly_chart(int $months = 12): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        $start_date = gmdate('Y-m-01', strtotime("-{$months} months"));
        
        // Get monthly income
        $income_sql = $wpdb->prepare(
            "SELECT DATE_FORMAT(entry_date, '%%Y-%%m') as month, 
                    COALESCE(SUM(amount_cents), 0) as total
             FROM {$table}
             WHERE type = 'income' AND entry_date >= %s
             GROUP BY DATE_FORMAT(entry_date, '%%Y-%%m')
             ORDER BY month ASC",
            $start_date
        );
        $income_data = $wpdb->get_results($income_sql, ARRAY_A);
        
        // Get monthly expenses
        $expense_sql = $wpdb->prepare(
            "SELECT DATE_FORMAT(entry_date, '%%Y-%%m') as month, 
                    COALESCE(SUM(amount_cents), 0) as total
             FROM {$table}
             WHERE type = 'expense' AND entry_date >= %s
             GROUP BY DATE_FORMAT(entry_date, '%%Y-%%m')
             ORDER BY month ASC",
            $start_date
        );
        $expense_data = $wpdb->get_results($expense_sql, ARRAY_A);
        
        // Build combined dataset
        $income_by_month = [];
        foreach ($income_data as $row) {
            $income_by_month[$row['month']] = (int) $row['total'];
        }
        
        $expense_by_month = [];
        foreach ($expense_data as $row) {
            $expense_by_month[$row['month']] = (int) $row['total'];
        }
        
        $labels = [];
        $income_values = [];
        $expense_values = [];
        $balance_values = [];
        
        $month_names = [
            '01' => 'Jan', '02' => 'Feb', '03' => 'Mär', '04' => 'Apr',
            '05' => 'Mai', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug',
            '09' => 'Sep', '10' => 'Okt', '11' => 'Nov', '12' => 'Dez',
        ];
        
        for ($i = $months; $i >= 0; $i--) {
            $month = gmdate('Y-m', strtotime("-{$i} months"));
            $month_num = substr($month, 5, 2);
            $year = substr($month, 2, 2);
            
            $labels[] = $month_names[$month_num] . ' ' . $year;
            
            $income = $income_by_month[$month] ?? 0;
            $expense = $expense_by_month[$month] ?? 0;
            
            $income_values[] = $income / 100;
            $expense_values[] = $expense / 100;
            $balance_values[] = ($income - $expense) / 100;
        }
        
        return [
            'labels' => $labels,
            'datasets' => [
                [
                    'label' => __('Einnahmen', 'isidor-cellerar'),
                    'data' => $income_values,
                    'color' => '#22c55e',
                ],
                [
                    'label' => __('Ausgaben', 'isidor-cellerar'),
                    'data' => $expense_values,
                    'color' => '#ef4444',
                ],
                [
                    'label' => __('Saldo', 'isidor-cellerar'),
                    'data' => $balance_values,
                    'color' => '#3b82f6',
                ],
            ],
        ];
    }

    /**
     * Get top categories
     *
     * @param string $type 'income' or 'expense'
     * @param int $limit Number of categories to return
     * @param array $filters Optional filters
     */
    public static function get_top_categories(string $type, int $limit = 10, array $filters = []): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ['type = %s'];
        $values = [$type];
        
        if (!empty($filters['date_from'])) {
            $where[] = 'entry_date >= %s';
            $values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'entry_date <= %s';
            $values[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        $values[] = $limit;
        
        $sql = $wpdb->prepare(
            "SELECT COALESCE(category, 'ohne Kategorie') as category, 
                    SUM(amount_cents) as total,
                    COUNT(*) as count
             FROM {$table}
             WHERE {$where_clause}
             GROUP BY category
             ORDER BY total DESC
             LIMIT %d",
            $values
        );
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        foreach ($results as &$row) {
            $row['total'] = (int) $row['total'];
            $row['count'] = (int) $row['count'];
            $row['formatted'] = Isidor_Cellerar_Entries::format_amount($row['total']);
        }
        
        return $results ?: [];
    }

    /**
     * Get income breakdown by subtype
     *
     * @param array $filters Optional filters
     */
    public static function get_income_breakdown(array $filters = []): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ["type = 'income'"];
        $values = [];
        
        if (!empty($filters['date_from'])) {
            $where[] = 'entry_date >= %s';
            $values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'entry_date <= %s';
            $values[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        $sql = "SELECT subtype, 
                       SUM(amount_cents) as total,
                       COUNT(*) as count
                FROM {$table}
                WHERE {$where_clause}
                GROUP BY subtype
                ORDER BY total DESC";
        
        if (!empty($values)) {
            $sql = $wpdb->prepare($sql, $values);
        }
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        foreach ($results as &$row) {
            $row['total'] = (int) $row['total'];
            $row['count'] = (int) $row['count'];
            $row['formatted'] = Isidor_Cellerar_Entries::format_amount($row['total']);
            $row['label'] = Isidor_Cellerar_Entries::get_subtype_label($row['subtype']);
        }
        
        return $results ?: [];
    }

    /**
     * Get messe ranking (by income)
     *
     * @param int $limit Number of masses to return
     * @param array $filters Optional filters
     */
    public static function get_messe_ranking(int $limit = 10, array $filters = []): array {
        global $wpdb;
        
        if (!post_type_exists('isidor_messe')) {
            return [];
        }
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $where = ["type = 'income'", 'messe_id IS NOT NULL'];
        $values = [];
        
        if (!empty($filters['date_from'])) {
            $where[] = 'entry_date >= %s';
            $values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'entry_date <= %s';
            $values[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        $values[] = $limit;
        
        $sql = $wpdb->prepare(
            "SELECT messe_id, 
                    SUM(amount_cents) as total,
                    COUNT(*) as entry_count
             FROM {$table}
             WHERE {$where_clause}
             GROUP BY messe_id
             ORDER BY total DESC
             LIMIT %d",
            $values
        );
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        foreach ($results as &$row) {
            $row['total'] = (int) $row['total'];
            $row['entry_count'] = (int) $row['entry_count'];
            $row['formatted'] = Isidor_Cellerar_Entries::format_amount($row['total']);
            
            // Get messe info
            $messe = get_post($row['messe_id']);
            if ($messe) {
                $row['messe_title'] = $messe->post_title;
                $row['messe_date'] = get_post_meta($messe->ID, '_is_date', true);
                $row['messe_time'] = get_post_meta($messe->ID, '_is_time', true);
            } else {
                $row['messe_title'] = __('Messe nicht gefunden', 'isidor-cellerar');
                $row['messe_date'] = '';
                $row['messe_time'] = '';
            }
        }
        
        return $results ?: [];
    }

    /**
     * Get open expenses summary
     */
    public static function get_open_expenses_summary(): array {
        global $wpdb;
        
        $expenses_table = Isidor_Cellerar_Database::get_expenses_table();
        $entries_table = Isidor_Cellerar_Database::get_entries_table();
        
        $sql = "SELECT ex.status, 
                       COUNT(*) as count,
                       COALESCE(SUM(en.amount_cents), 0) as total
                FROM {$expenses_table} ex
                LEFT JOIN {$entries_table} en ON ex.entry_id = en.id
                WHERE ex.status NOT IN ('reimbursed', 'rejected')
                GROUP BY ex.status";
        
        $results = $wpdb->get_results($sql, ARRAY_A);
        
        $summary = [
            'submitted' => ['count' => 0, 'total' => 0],
            'reviewed' => ['count' => 0, 'total' => 0],
            'approved' => ['count' => 0, 'total' => 0],
        ];
        
        foreach ($results as $row) {
            $summary[$row['status']] = [
                'count' => (int) $row['count'],
                'total' => (int) $row['total'],
                'formatted' => Isidor_Cellerar_Entries::format_amount((int) $row['total']),
            ];
        }
        
        $summary['total_open'] = [
            'count' => $summary['submitted']['count'] + $summary['reviewed']['count'] + $summary['approved']['count'],
            'total' => $summary['submitted']['total'] + $summary['reviewed']['total'] + $summary['approved']['total'],
        ];
        $summary['total_open']['formatted'] = Isidor_Cellerar_Entries::format_amount($summary['total_open']['total']);
        
        return $summary;
    }

    /**
     * Get year-over-year comparison
     */
    public static function get_year_comparison(int $year1, int $year2): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $get_year_totals = function (int $year) use ($wpdb, $table): array {
            $sql = $wpdb->prepare(
                "SELECT type, SUM(amount_cents) as total
                 FROM {$table}
                 WHERE YEAR(entry_date) = %d
                 GROUP BY type",
                $year
            );
            
            $results = $wpdb->get_results($sql, ARRAY_A);
            
            $totals = ['income' => 0, 'expense' => 0];
            foreach ($results as $row) {
                $totals[$row['type']] = (int) $row['total'];
            }
            
            return $totals;
        };
        
        $year1_totals = $get_year_totals($year1);
        $year2_totals = $get_year_totals($year2);
        
        $income_change = $year1_totals['income'] > 0 
            ? (($year2_totals['income'] - $year1_totals['income']) / $year1_totals['income']) * 100 
            : 0;
        
        $expense_change = $year1_totals['expense'] > 0 
            ? (($year2_totals['expense'] - $year1_totals['expense']) / $year1_totals['expense']) * 100 
            : 0;
        
        return [
            'year1' => [
                'year' => $year1,
                'income' => $year1_totals['income'],
                'expense' => $year1_totals['expense'],
                'balance' => $year1_totals['income'] - $year1_totals['expense'],
            ],
            'year2' => [
                'year' => $year2,
                'income' => $year2_totals['income'],
                'expense' => $year2_totals['expense'],
                'balance' => $year2_totals['income'] - $year2_totals['expense'],
            ],
            'changes' => [
                'income_percent' => round($income_change, 1),
                'expense_percent' => round($expense_change, 1),
            ],
        ];
    }

    /**
     * Get date range for filters
     */
    public static function get_date_range(): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $result = $wpdb->get_row(
            "SELECT MIN(entry_date) as min_date, MAX(entry_date) as max_date FROM {$table}",
            ARRAY_A
        );
        
        return [
            'min_date' => $result['min_date'] ?? gmdate('Y-m-d'),
            'max_date' => $result['max_date'] ?? gmdate('Y-m-d'),
        ];
    }

    /**
     * Get available years for filtering
     */
    public static function get_available_years(): array {
        global $wpdb;
        
        $table = Isidor_Cellerar_Database::get_entries_table();
        
        $years = $wpdb->get_col(
            "SELECT DISTINCT YEAR(entry_date) as year FROM {$table} ORDER BY year DESC"
        );
        
        return array_map('intval', $years);
    }
}
