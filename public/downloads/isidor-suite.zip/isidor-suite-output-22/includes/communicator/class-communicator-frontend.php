<?php

/**
 * Isidor Communicator Frontend
 * 
 * Shortcodes:
 * - [isidor_communicator] — Haupt-Chat-Interface
 */

if (!defined('ABSPATH')) exit;

class Isidor_Communicator_Frontend {
    
    public function __construct() {
        add_shortcode('isidor_communicator', [$this, 'render']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    }
    
    public function enqueue(): void {
        if (!is_singular()) return;
        
        $content = get_post()->post_content ?? '';
        if (!has_shortcode($content, 'isidor_communicator')) return;
        
        wp_enqueue_style(
            'isidor-communicator',
            ISIDOR_SUITE_URL . 'assets/css/communicator.css',
            ['isidor-shell'],
            ISIDOR_SUITE_VERSION
        );
        
        wp_enqueue_script(
            'isidor-communicator',
            ISIDOR_SUITE_URL . 'assets/js/communicator.js',
            ['jquery'],
            ISIDOR_SUITE_VERSION,
            true
        );
        
        wp_localize_script('isidor-communicator', 'isidorComm', [
            'restUrl' => rest_url('isidor/v1/comm/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'userId' => get_current_user_id(),
            'userName' => wp_get_current_user()->display_name,
            'pollInterval' => 5000, // 5 Sekunden
        ]);
        
        // Media Library für Bild-Upload
        wp_enqueue_media();
    }
    
    public function render($atts): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte anmelden um den Chat zu nutzen.</p>';
        }
        
        if (!current_user_can('isidor_comm_view')) {
            return '<p>Keine Berechtigung für den Communicator.</p>';
        }
        
        $can_create_group = current_user_can('isidor_comm_create_group');
        
        ob_start();
        ?>
        <div class="comm-app" id="comm-app">
            <!-- Sidebar: Raumliste -->
            <div class="comm-sidebar">
                <div class="comm-sidebar-header">
                    <h3>💬 Chats</h3>
                    <div class="comm-sidebar-actions">
                        <button type="button" class="comm-btn-icon" onclick="commStartDM()" title="Neue Direktnachricht">
                            ✉️
                        </button>
                        <?php if ($can_create_group): ?>
                            <button type="button" class="comm-btn-icon" onclick="commShowCreateGroup()" title="Neue Gruppe">
                                ➕
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="comm-room-list" id="comm-room-list">
                    <div class="comm-loading">Lade Chats...</div>
                </div>
            </div>
            
            <!-- Main: Chat-Bereich -->
            <div class="comm-main">
                <div class="comm-placeholder" id="comm-placeholder">
                    <div class="comm-placeholder-icon">💬</div>
                    <h3>Willkommen im Communicator</h3>
                    <p>Wähle einen Chat aus der Liste oder starte eine neue Unterhaltung.</p>
                </div>
                
                <div class="comm-chat" id="comm-chat" style="display:none;">
                    <div class="comm-chat-header" id="comm-chat-header">
                        <button type="button" class="comm-back-btn" onclick="commCloseChat()">←</button>
                        <div class="comm-chat-title">
                            <span class="comm-chat-icon" id="comm-chat-icon">💬</span>
                            <span class="comm-chat-name" id="comm-chat-name">Chat</span>
                        </div>
                        <div class="comm-chat-actions">
                            <button type="button" class="comm-btn-icon" onclick="commShowRoomInfo()" title="Info">ℹ️</button>
                        </div>
                    </div>
                    
                    <div class="comm-messages" id="comm-messages">
                        <!-- Messages werden via JS geladen -->
                    </div>
                    
                    <div class="comm-input-area">
                        <button type="button" class="comm-attach-btn" onclick="commAttachFile()" title="Datei anhängen">
                            📎
                        </button>
                        <input type="text" id="comm-message-input" class="comm-input" 
                               placeholder="Nachricht schreiben..." 
                               onkeypress="if(event.key==='Enter')commSendMessage()">
                        <button type="button" class="comm-send-btn" onclick="commSendMessage()">
                            ➤
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Modal: Neue Gruppe -->
            <div class="comm-modal" id="comm-modal-group" style="display:none;">
                <div class="comm-modal-content">
                    <div class="comm-modal-header">
                        <h3>Neue Gruppe erstellen</h3>
                        <button type="button" class="comm-modal-close" onclick="commCloseModal('group')">✕</button>
                    </div>
                    <div class="comm-modal-body">
                        <div class="comm-form-row">
                            <label>Gruppenname</label>
                            <input type="text" id="group-name" placeholder="z.B. Ministranten">
                        </div>
                        <div class="comm-form-row">
                            <label>Beschreibung (optional)</label>
                            <input type="text" id="group-description" placeholder="Kurze Beschreibung...">
                        </div>
                        <div class="comm-form-row">
                            <label>Icon</label>
                            <div class="comm-icon-picker" id="group-icon-picker">
                                <button type="button" class="comm-icon-btn active" data-icon="💬">💬</button>
                                <button type="button" class="comm-icon-btn" data-icon="⛪">⛪</button>
                                <button type="button" class="comm-icon-btn" data-icon="🎵">🎵</button>
                                <button type="button" class="comm-icon-btn" data-icon="📖">📖</button>
                                <button type="button" class="comm-icon-btn" data-icon="🕯️">🕯️</button>
                                <button type="button" class="comm-icon-btn" data-icon="👥">👥</button>
                                <button type="button" class="comm-icon-btn" data-icon="📢">📢</button>
                                <button type="button" class="comm-icon-btn" data-icon="❤️">❤️</button>
                            </div>
                        </div>
                        <div class="comm-form-row">
                            <label>Mitglieder hinzufügen</label>
                            <div class="comm-user-select" id="group-members">
                                <!-- User-Checkboxen werden via JS geladen -->
                            </div>
                        </div>
                    </div>
                    <div class="comm-modal-footer">
                        <button type="button" class="comm-btn comm-btn-outline" onclick="commCloseModal('group')">Abbrechen</button>
                        <button type="button" class="comm-btn comm-btn-primary" onclick="commCreateGroup()">Gruppe erstellen</button>
                    </div>
                </div>
            </div>
            
            <!-- Modal: DM starten -->
            <div class="comm-modal" id="comm-modal-dm" style="display:none;">
                <div class="comm-modal-content">
                    <div class="comm-modal-header">
                        <h3>Neue Direktnachricht</h3>
                        <button type="button" class="comm-modal-close" onclick="commCloseModal('dm')">✕</button>
                    </div>
                    <div class="comm-modal-body">
                        <div class="comm-form-row">
                            <label>Empfänger wählen</label>
                            <div class="comm-user-list" id="dm-user-list">
                                <!-- User-Liste wird via JS geladen -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Toast -->
            <div id="comm-toast" class="comm-toast"></div>
        </div>
        <?php
        return ob_get_clean();
    }
}
