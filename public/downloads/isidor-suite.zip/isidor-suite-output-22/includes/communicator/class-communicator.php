<?php

/**
 * Isidor Communicator — Interner Pfarr-Messenger
 * 
 * Features:
 * - Gruppen-Chats (Ministranten, Lektoren, Chor, PGR...)
 * - Direktnachrichten (1:1)
 * - Dateien/Bilder teilen
 * - Gelesen-Status
 * - Live-Updates via AJAX-Polling
 * 
 * DB-Tabellen:
 * - isidor_comm_rooms        — Chat-Räume
 * - isidor_comm_participants — Raum-Mitglieder
 * - isidor_comm_messages     — Nachrichten
 * - isidor_comm_read         — Gelesen-Status
 */

if (!defined('ABSPATH')) exit;

class Isidor_Communicator {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Activation
        register_activation_hook(ISIDOR_SUITE_FILE, [$this, 'activate']);
        
        // Admin
        add_action('admin_menu', [$this, 'add_admin_menu'], 25);
        add_action('admin_init', [$this, 'maybe_setup_capabilities']);
        
        // REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }
    
    /**
     * Capabilities einmalig setzen (nach Update)
     */
    public function maybe_setup_capabilities(): void {
        if (get_option('isidor_comm_caps_set') !== ISIDOR_SUITE_VERSION) {
            $this->setup_capabilities();
            update_option('isidor_comm_caps_set', ISIDOR_SUITE_VERSION);
        }
    }
    
    /* ================================================================
       ACTIVATION — DB-Tabellen erstellen
       ================================================================ */
    
    public function activate(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        // Räume (Gruppen oder DMs)
        $sql_rooms = "CREATE TABLE {$wpdb->prefix}isidor_comm_rooms (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type ENUM('group', 'dm') NOT NULL DEFAULT 'group',
            name VARCHAR(100) NULL,
            description TEXT NULL,
            icon VARCHAR(10) DEFAULT '💬',
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            KEY type (type),
            KEY created_by (created_by)
        ) $charset;";
        dbDelta($sql_rooms);
        
        // Teilnehmer
        $sql_participants = "CREATE TABLE {$wpdb->prefix}isidor_comm_participants (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            role ENUM('admin', 'member') NOT NULL DEFAULT 'member',
            joined_at DATETIME NOT NULL,
            UNIQUE KEY room_user (room_id, user_id),
            KEY user_id (user_id)
        ) $charset;";
        dbDelta($sql_participants);
        
        // Nachrichten
        $sql_messages = "CREATE TABLE {$wpdb->prefix}isidor_comm_messages (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            message TEXT NOT NULL,
            attachment_url VARCHAR(500) NULL,
            attachment_type VARCHAR(50) NULL,
            created_at DATETIME NOT NULL,
            edited_at DATETIME NULL,
            deleted_at DATETIME NULL,
            KEY room_id (room_id),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset;";
        dbDelta($sql_messages);
        
        // Gelesen-Status
        $sql_read = "CREATE TABLE {$wpdb->prefix}isidor_comm_read (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            last_read_at DATETIME NOT NULL,
            last_message_id BIGINT UNSIGNED DEFAULT 0,
            UNIQUE KEY room_user (room_id, user_id)
        ) $charset;";
        dbDelta($sql_read);
        
        // Capabilities
        $this->setup_capabilities();
    }
    
    private function setup_capabilities(): void {
        $admin_roles = ['administrator', 'isidor_pfarrer_godmode', 'isidor_sekretaer'];
        $user_roles = ['isidor_diakon', 'isidor_liturg_kantor', 'isidor_mesner', 
                       'isidor_ministrant', 'isidor_mitarbeiter', 'isidor_ag_leiter',
                       'isidor_pgr', 'isidor_vvr'];
        
        // Admins: alles
        foreach ($admin_roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('isidor_comm_view');
                $role->add_cap('isidor_comm_send');
                $role->add_cap('isidor_comm_create_group');
                $role->add_cap('isidor_comm_admin');
            }
        }
        
        // Normale User: lesen + senden
        foreach ($user_roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('isidor_comm_view');
                $role->add_cap('isidor_comm_send');
            }
        }
    }
    
    /* ================================================================
       ADMIN MENU
       ================================================================ */
    
    public function add_admin_menu(): void {
        // Use manage_options as fallback for admins who don't have the custom cap yet
        $cap = current_user_can('isidor_comm_admin') ? 'isidor_comm_admin' : 'manage_options';
        add_submenu_page(
            'isidor-os',
            'Communicator',
            '💬 Communicator',
            $cap,
            'isidor-communicator',
            [$this, 'render_admin_page']
        );
    }
    
    public function render_admin_page(): void {
        $rooms = $this->get_all_rooms();
        ?>
        <div class="wrap">
            <h1>💬 Communicator — Verwaltung</h1>
            
            <div style="background:#fff; padding:20px; border-radius:8px; margin-top:20px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h2>Gruppen-Chats</h2>
                
                <?php if (empty($rooms)): ?>
                    <p>Noch keine Gruppen vorhanden.</p>
                <?php else: ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Typ</th>
                                <th>Teilnehmer</th>
                                <th>Nachrichten</th>
                                <th>Erstellt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rooms as $room): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($room->icon . ' ' . $room->name); ?></strong>
                                        <?php if ($room->description): ?>
                                            <br><small><?php echo esc_html($room->description); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $room->type === 'dm' ? 'Direktnachricht' : 'Gruppe'; ?></td>
                                    <td><?php echo intval($room->participant_count); ?></td>
                                    <td><?php echo intval($room->message_count); ?></td>
                                    <td><?php echo esc_html(wp_date('d.m.Y H:i', strtotime($room->created_at))); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                
                <p style="margin-top:20px;">
                    <a href="<?php echo esc_url($this->get_frontend_url()); ?>" class="button button-primary" target="_blank">
                        📱 Zum Frontend-Chat
                    </a>
                </p>
            </div>
        </div>
        <?php
    }
    
    /* ================================================================
       REST API
       ================================================================ */
    
    public function register_rest_routes(): void {
        $namespace = 'isidor/v1';
        
        // Räume
        register_rest_route($namespace, '/comm/rooms', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_rooms'],
            'permission_callback' => function() { return current_user_can('isidor_comm_view'); },
        ]);
        
        register_rest_route($namespace, '/comm/rooms', [
            'methods' => 'POST',
            'callback' => [$this, 'api_create_room'],
            'permission_callback' => function() { return current_user_can('isidor_comm_create_group'); },
        ]);
        
        // Nachrichten
        register_rest_route($namespace, '/comm/rooms/(?P<room_id>\d+)/messages', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_messages'],
            'permission_callback' => function() { return current_user_can('isidor_comm_view'); },
        ]);
        
        register_rest_route($namespace, '/comm/rooms/(?P<room_id>\d+)/messages', [
            'methods' => 'POST',
            'callback' => [$this, 'api_send_message'],
            'permission_callback' => function() { return current_user_can('isidor_comm_send'); },
        ]);
        
        // Gelesen markieren
        register_rest_route($namespace, '/comm/rooms/(?P<room_id>\d+)/read', [
            'methods' => 'POST',
            'callback' => [$this, 'api_mark_read'],
            'permission_callback' => function() { return current_user_can('isidor_comm_view'); },
        ]);
        
        // Ungelesene Anzahl
        register_rest_route($namespace, '/comm/unread', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_unread_count'],
            'permission_callback' => function() { return current_user_can('isidor_comm_view'); },
        ]);
        
        // DM starten
        register_rest_route($namespace, '/comm/dm/(?P<user_id>\d+)', [
            'methods' => 'POST',
            'callback' => [$this, 'api_start_dm'],
            'permission_callback' => function() { return current_user_can('isidor_comm_send'); },
        ]);
        
        // User-Liste
        register_rest_route($namespace, '/comm/users', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_users'],
            'permission_callback' => function() { return current_user_can('isidor_comm_view'); },
        ]);
    }
    
    /* ================================================================
       API HANDLERS
       ================================================================ */
    
    public function api_get_rooms(\WP_REST_Request $request): \WP_REST_Response {
        $user_id = get_current_user_id();
        $rooms = $this->get_user_rooms($user_id);
        
        return new \WP_REST_Response(['rooms' => $rooms], 200);
    }
    
    public function api_create_room(\WP_REST_Request $request): \WP_REST_Response {
        $name = sanitize_text_field($request->get_param('name') ?? '');
        $description = sanitize_textarea_field($request->get_param('description') ?? '');
        $icon = sanitize_text_field($request->get_param('icon') ?? '💬');
        $members = $request->get_param('members') ?? [];
        
        if (empty($name)) {
            return new \WP_REST_Response(['error' => 'Name erforderlich'], 400);
        }
        
        $room_id = $this->create_room('group', $name, $description, $icon, $members);
        
        if (!$room_id) {
            return new \WP_REST_Response(['error' => 'Fehler beim Erstellen'], 500);
        }
        
        return new \WP_REST_Response(['room_id' => $room_id], 201);
    }
    
    public function api_get_messages(\WP_REST_Request $request): \WP_REST_Response {
        $room_id = (int) $request->get_param('room_id');
        $user_id = get_current_user_id();
        $since = $request->get_param('since') ?? null;
        $limit = (int) ($request->get_param('limit') ?? 50);
        
        if (!$this->is_room_participant($room_id, $user_id)) {
            return new \WP_REST_Response(['error' => 'Kein Zugriff'], 403);
        }
        
        $messages = $this->get_messages($room_id, $since, $limit);
        
        return new \WP_REST_Response(['messages' => $messages], 200);
    }
    
    public function api_send_message(\WP_REST_Request $request): \WP_REST_Response {
        $room_id = (int) $request->get_param('room_id');
        $user_id = get_current_user_id();
        $message = sanitize_textarea_field($request->get_param('message') ?? '');
        $attachment_url = esc_url_raw($request->get_param('attachment_url') ?? '');
        $attachment_type = sanitize_text_field($request->get_param('attachment_type') ?? '');
        
        if (!$this->is_room_participant($room_id, $user_id)) {
            return new \WP_REST_Response(['error' => 'Kein Zugriff'], 403);
        }
        
        if (empty($message) && empty($attachment_url)) {
            return new \WP_REST_Response(['error' => 'Nachricht leer'], 400);
        }
        
        $msg_id = $this->send_message($room_id, $user_id, $message, $attachment_url, $attachment_type);
        
        if (!$msg_id) {
            return new \WP_REST_Response(['error' => 'Fehler beim Senden'], 500);
        }
        
        return new \WP_REST_Response(['message_id' => $msg_id], 201);
    }
    
    public function api_mark_read(\WP_REST_Request $request): \WP_REST_Response {
        $room_id = (int) $request->get_param('room_id');
        $user_id = get_current_user_id();
        
        $this->mark_room_read($room_id, $user_id);
        
        return new \WP_REST_Response(['success' => true], 200);
    }
    
    public function api_get_unread_count(\WP_REST_Request $request): \WP_REST_Response {
        $user_id = get_current_user_id();
        $count = $this->get_unread_count($user_id);
        
        return new \WP_REST_Response(['unread' => $count], 200);
    }
    
    public function api_start_dm(\WP_REST_Request $request): \WP_REST_Response {
        $target_user_id = (int) $request->get_param('user_id');
        $user_id = get_current_user_id();
        
        if ($target_user_id === $user_id) {
            return new \WP_REST_Response(['error' => 'Kann keine DM an sich selbst senden'], 400);
        }
        
        // Prüfen ob DM schon existiert
        $existing = $this->find_dm_room($user_id, $target_user_id);
        if ($existing) {
            return new \WP_REST_Response(['room_id' => $existing], 200);
        }
        
        // Neue DM erstellen
        $target_user = get_userdata($target_user_id);
        if (!$target_user) {
            return new \WP_REST_Response(['error' => 'User nicht gefunden'], 404);
        }
        
        $room_id = $this->create_dm($user_id, $target_user_id);
        
        return new \WP_REST_Response(['room_id' => $room_id], 201);
    }
    
    public function api_get_users(\WP_REST_Request $request): \WP_REST_Response {
        $users = get_users([
            'meta_query' => [
                'relation' => 'OR',
                ['key' => 'isidor_app_permissions', 'compare' => 'EXISTS'],
            ],
            'orderby' => 'display_name',
            'order' => 'ASC',
        ]);
        
        // Fallback: alle User mit Isidor-Rollen
        if (empty($users)) {
            $users = get_users([
                'role__in' => [
                    'administrator', 'isidor_pfarrer_godmode', 'isidor_sekretaer',
                    'isidor_diakon', 'isidor_liturg_kantor', 'isidor_mesner',
                    'isidor_ministrant', 'isidor_mitarbeiter'
                ],
                'orderby' => 'display_name',
            ]);
        }
        
        $result = [];
        foreach ($users as $u) {
            $result[] = [
                'id' => $u->ID,
                'name' => $u->display_name,
                'avatar' => get_avatar_url($u->ID, ['size' => 40]),
            ];
        }
        
        return new \WP_REST_Response(['users' => $result], 200);
    }
    
    /* ================================================================
       DB OPERATIONS
       ================================================================ */
    
    public function create_room(string $type, string $name, string $description, string $icon, array $member_ids){
        global $wpdb;
        $user_id = get_current_user_id();
        $now = current_time('mysql');
        
        $wpdb->insert(
            $wpdb->prefix . 'isidor_comm_rooms',
            [
                'type' => $type,
                'name' => $name,
                'description' => $description,
                'icon' => $icon,
                'created_by' => $user_id,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            ['%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );
        
        $room_id = (int) $wpdb->insert_id;
        if (!$room_id) return null;
        
        // Creator als Admin hinzufügen
        $this->add_participant($room_id, $user_id, 'admin');
        
        // Weitere Mitglieder
        foreach ($member_ids as $mid) {
            $mid = (int) $mid;
            if ($mid && $mid !== $user_id) {
                $this->add_participant($room_id, $mid, 'member');
            }
        }
        
        return $room_id;
    }
    
    public function create_dm(int $user1, int $user2){
        global $wpdb;
        $now = current_time('mysql');
        
        $wpdb->insert(
            $wpdb->prefix . 'isidor_comm_rooms',
            [
                'type' => 'dm',
                'name' => null,
                'created_by' => $user1,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            ['%s', '%s', '%d', '%s', '%s']
        );
        
        $room_id = (int) $wpdb->insert_id;
        if (!$room_id) return null;
        
        $this->add_participant($room_id, $user1, 'member');
        $this->add_participant($room_id, $user2, 'member');
        
        return $room_id;
    }
    
    public function add_participant(int $room_id, int $user_id, string $role = 'member'): bool {
        global $wpdb;
        
        return (bool) $wpdb->insert(
            $wpdb->prefix . 'isidor_comm_participants',
            [
                'room_id' => $room_id,
                'user_id' => $user_id,
                'role' => $role,
                'joined_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s']
        );
    }
    
    public function is_room_participant(int $room_id, int $user_id): bool {
        global $wpdb;
        
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT 1 FROM {$wpdb->prefix}isidor_comm_participants 
             WHERE room_id = %d AND user_id = %d",
            $room_id, $user_id
        ));
    }
    
    public function find_dm_room(int $user1, int $user2){
        global $wpdb;
        
        $room_id = $wpdb->get_var($wpdb->prepare(
            "SELECT r.id FROM {$wpdb->prefix}isidor_comm_rooms r
             JOIN {$wpdb->prefix}isidor_comm_participants p1 ON r.id = p1.room_id AND p1.user_id = %d
             JOIN {$wpdb->prefix}isidor_comm_participants p2 ON r.id = p2.room_id AND p2.user_id = %d
             WHERE r.type = 'dm'
             LIMIT 1",
            $user1, $user2
        ));
        
        return $room_id ? (int) $room_id : null;
    }
    
    public function send_message(int $room_id, int $user_id, string $message, string $attachment_url = '', string $attachment_type = ''){
        global $wpdb;
        $now = current_time('mysql');
        
        $wpdb->insert(
            $wpdb->prefix . 'isidor_comm_messages',
            [
                'room_id' => $room_id,
                'user_id' => $user_id,
                'message' => $message,
                'attachment_url' => $attachment_url ?: null,
                'attachment_type' => $attachment_type ?: null,
                'created_at' => $now,
            ],
            ['%d', '%d', '%s', '%s', '%s', '%s']
        );
        
        $msg_id = (int) $wpdb->insert_id;
        
        if ($msg_id) {
            // Room updated_at aktualisieren
            $wpdb->update(
                $wpdb->prefix . 'isidor_comm_rooms',
                ['updated_at' => $now],
                ['id' => $room_id]
            );
        }
        
        return $msg_id ?: null;
    }
    
    public function get_messages(int $room_id, ?string $since = null, int $limit = 50): array {
        global $wpdb;
        
        $where = $since 
            ? $wpdb->prepare("AND m.created_at > %s", $since)
            : "";
        
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, u.display_name as user_name
             FROM {$wpdb->prefix}isidor_comm_messages m
             JOIN {$wpdb->users} u ON m.user_id = u.ID
             WHERE m.room_id = %d AND m.deleted_at IS NULL
             {$where}
             ORDER BY m.created_at ASC
             LIMIT %d",
            $room_id, $limit
        ), ARRAY_A);
        
        foreach ($rows as &$row) {
            $row['avatar'] = get_avatar_url($row['user_id'], ['size' => 40]);
            $row['is_mine'] = (int) $row['user_id'] === get_current_user_id();
        }
        
        return $rows;
    }
    
    public function get_user_rooms(int $user_id): array {
        global $wpdb;
        
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, 
                    (SELECT COUNT(*) FROM {$wpdb->prefix}isidor_comm_participants WHERE room_id = r.id) as participant_count,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}isidor_comm_messages WHERE room_id = r.id AND deleted_at IS NULL) as message_count,
                    (SELECT message FROM {$wpdb->prefix}isidor_comm_messages WHERE room_id = r.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1) as last_message,
                    (SELECT created_at FROM {$wpdb->prefix}isidor_comm_messages WHERE room_id = r.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1) as last_message_at,
                    COALESCE(rd.last_message_id, 0) as last_read_id
             FROM {$wpdb->prefix}isidor_comm_rooms r
             JOIN {$wpdb->prefix}isidor_comm_participants p ON r.id = p.room_id
             LEFT JOIN {$wpdb->prefix}isidor_comm_read rd ON r.id = rd.room_id AND rd.user_id = %d
             WHERE p.user_id = %d
             ORDER BY r.updated_at DESC",
            $user_id, $user_id
        ), ARRAY_A);
        
        // DM-Namen auflösen
        foreach ($rows as &$row) {
            if ($row['type'] === 'dm') {
                $other_user = $this->get_dm_other_user((int)$row['id'], $user_id);
                $row['name'] = $other_user ? $other_user->display_name : 'Unbekannt';
                $row['avatar'] = $other_user ? get_avatar_url($other_user->ID, ['size' => 40]) : '';
            }
            
            // Ungelesene Nachrichten zählen
            $row['unread'] = $this->count_unread_in_room((int)$row['id'], $user_id);
        }
        
        return $rows;
    }
    
    public function get_all_rooms(): array {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT r.*, 
                    (SELECT COUNT(*) FROM {$wpdb->prefix}isidor_comm_participants WHERE room_id = r.id) as participant_count,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}isidor_comm_messages WHERE room_id = r.id AND deleted_at IS NULL) as message_count
             FROM {$wpdb->prefix}isidor_comm_rooms r
             ORDER BY r.updated_at DESC"
        );
    }
    
    private function get_dm_other_user(int $room_id, int $current_user_id): ?\WP_User {
        global $wpdb;
        
        $other_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}isidor_comm_participants 
             WHERE room_id = %d AND user_id != %d LIMIT 1",
            $room_id, $current_user_id
        ));
        
        return $other_id ? get_userdata((int)$other_id) : null;
    }
    
    public function mark_room_read(int $room_id, int $user_id): void {
        global $wpdb;
        
        $last_msg_id = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(id) FROM {$wpdb->prefix}isidor_comm_messages WHERE room_id = %d",
            $room_id
        ));
        
        $wpdb->replace(
            $wpdb->prefix . 'isidor_comm_read',
            [
                'room_id' => $room_id,
                'user_id' => $user_id,
                'last_read_at' => current_time('mysql'),
                'last_message_id' => $last_msg_id ?: 0,
            ],
            ['%d', '%d', '%s', '%d']
        );
    }
    
    public function count_unread_in_room(int $room_id, int $user_id): int {
        global $wpdb;
        
        $last_read = $wpdb->get_var($wpdb->prepare(
            "SELECT last_message_id FROM {$wpdb->prefix}isidor_comm_read 
             WHERE room_id = %d AND user_id = %d",
            $room_id, $user_id
        )) ?: 0;
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_comm_messages 
             WHERE room_id = %d AND id > %d AND user_id != %d AND deleted_at IS NULL",
            $room_id, $last_read, $user_id
        ));
    }
    
    public function get_unread_count(int $user_id): int {
        $rooms = $this->get_user_rooms($user_id);
        $total = 0;
        foreach ($rooms as $room) {
            $total += (int) ($room['unread'] ?? 0);
        }
        return $total;
    }
    
    /* ================================================================
       HELPERS
       ================================================================ */
    
    public function get_frontend_url(): string {
        global $wpdb;
        
        $page_id = $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' AND post_status = 'publish' 
             AND post_content LIKE '%[isidor_communicator%' 
             LIMIT 1"
        );
        
        return $page_id ? get_permalink($page_id) : home_url('/app/nachrichten/');
    }
}
