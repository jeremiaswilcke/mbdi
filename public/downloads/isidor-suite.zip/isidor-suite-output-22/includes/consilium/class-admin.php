<?php
/**
 * Isidor Consilium - Admin
 *
 * WordPress Admin-Seiten für die Sitzungsverwaltung.
 *
 * @package IsidorSuite
 * @subpackage Consilium
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_Admin {

    public static function init(): void {
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
    }

    // =========================================================================
    // MENU
    // =========================================================================

    public static function add_menu(): void {
        add_submenu_page(
            'isidor-os',
            __('Consilium Sitzungen', 'isidor-suite'),
            __('🏛️ Consilium', 'isidor-suite'),
            'isidor_consilium_manage',
            'isidor-consilium',
            [self::class, 'render_sessions_list']
        );

        // Hidden submenus (accessible via URL only)
        add_submenu_page(
            null,
            __('Sitzung bearbeiten', 'isidor-suite'),
            '',
            'isidor_consilium_manage',
            'isidor-consilium-edit',
            [self::class, 'render_session_editor']
        );

        add_submenu_page(
            null,
            __('Live-Sitzung', 'isidor-suite'),
            '',
            'isidor_consilium_manage',
            'isidor-consilium-live',
            [self::class, 'render_live_session']
        );

        add_submenu_page(
            null,
            __('Archivzugriff verwalten', 'isidor-suite'),
            '',
            'isidor_consilium_admin',
            'isidor-consilium-archive-access',
            [self::class, 'render_archive_access']
        );
    }

    // =========================================================================
    // ASSETS
    // =========================================================================

    public static function enqueue_scripts(string $hook): void {
        if (strpos($hook, 'isidor-consilium') === false) {
            return;
        }

        wp_enqueue_style(
            'isidor-consilium-admin',
            ISIDOR_SUITE_URL . 'assets/css/consilium-admin.css',
            [],
            ISIDOR_CONSILIUM_VERSION
        );

        wp_enqueue_script('jquery-ui-sortable');

        wp_enqueue_script(
            'isidor-consilium-admin',
            ISIDOR_SUITE_URL . 'assets/js/consilium-admin.js',
            ['jquery', 'jquery-ui-sortable'],
            ISIDOR_CONSILIUM_VERSION,
            true
        );

        wp_localize_script('isidor-consilium-admin', 'consiliumAdmin', [
            'restUrl'   => rest_url('isidor/v1/consilium/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'adminUrl'  => admin_url('admin.php'),
            'pollInterval'     => 3000,
            'autosaveInterval' => 10000,
            'i18n' => [
                'loading'              => __('Wird geladen...', 'isidor-suite'),
                'error'                => __('Ein Fehler ist aufgetreten.', 'isidor-suite'),
                'saved'                => __('Gespeichert.', 'isidor-suite'),
                'confirmDelete'        => __('Wirklich löschen?', 'isidor-suite'),
                'confirmComplete'      => __('Sitzung wirklich abschließen? Es wird ein PDF-Protokoll erstellt und an alle Teilnehmer gesendet.', 'isidor-suite'),
                'confirmStart'         => __('Sitzung jetzt starten?', 'isidor-suite'),
                'confirmFinalize'      => __('Protokoll endgültig ablegen und an alle Teilnehmer versenden?', 'isidor-suite'),
                'invitationsSent'      => __('Einladungen gesendet.', 'isidor-suite'),
                'sessionCompleted'     => __('Sitzung abgeschlossen.', 'isidor-suite'),
                'protocolDraftSaved'   => __('Protokoll zwischengespeichert.', 'isidor-suite'),
                'protocolFinalized'    => __('Protokoll endgültig abgelegt und versendet.', 'isidor-suite'),
                'voteStarted'         => __('Abstimmung gestartet.', 'isidor-suite'),
                'voteStopped'         => __('Abstimmung beendet.', 'isidor-suite'),
                'noTopics'            => __('Noch keine TOPs angelegt.', 'isidor-suite'),
                'addTopicPlaceholder' => __('Titel des neuen TOP...', 'isidor-suite'),
                'searchUsers'         => __('Benutzer suchen...', 'isidor-suite'),
            ],
        ]);
    }

    // =========================================================================
    // PAGE 1: SESSION LIST
    // =========================================================================

    public static function render_sessions_list(): void {
        global $wpdb;
        $table = Isidor_Consilium_Database::get_sessions_table();
        $participants_table = Isidor_Consilium_Database::get_participants_table();

        // Filter params
        $filter_gremium = sanitize_text_field($_GET['gremium'] ?? '');
        $filter_status = sanitize_text_field($_GET['status'] ?? '');
        $filter_year = intval($_GET['year'] ?? 0);

        $where = ['1=1'];
        $params = [];

        if ($filter_gremium && in_array($filter_gremium, Isidor_Consilium_Database::get_valid_gremiums(), true)) {
            $where[] = 's.gremium = %s';
            $params[] = $filter_gremium;
        }
        if ($filter_status && in_array($filter_status, Isidor_Consilium_Database::get_valid_statuses(), true)) {
            $where[] = 's.status = %s';
            $params[] = $filter_status;
        }
        if ($filter_year > 0) {
            $where[] = 'YEAR(s.session_date) = %d';
            $params[] = $filter_year;
        }

        $where_sql = implode(' AND ', $where);

        $query = "SELECT s.*, (SELECT COUNT(*) FROM {$participants_table} WHERE session_id = s.id) AS participant_count
                  FROM {$table} s WHERE {$where_sql} ORDER BY s.session_date DESC, s.time_start DESC";

        $sessions = !empty($params)
            ? $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A)
            : $wpdb->get_results($query, ARRAY_A);

        // Get available years
        $years = $wpdb->get_col("SELECT DISTINCT YEAR(session_date) FROM {$table} ORDER BY 1 DESC");

        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php _e('Consilium — Sitzungen', 'isidor-suite'); ?></h1>
            <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-consilium-edit')); ?>" class="page-title-action">
                <?php _e('Neue Sitzung', 'isidor-suite'); ?>
            </a>
            <?php if (current_user_can('isidor_consilium_admin')): ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-consilium-archive-access')); ?>" class="page-title-action">
                <?php _e('Archivzugriff verwalten', 'isidor-suite'); ?>
            </a>
            <?php endif; ?>
            <hr class="wp-header-end">

            <!-- Filters -->
            <div class="consilium-filters" style="margin: 15px 0; display: flex; gap: 10px; align-items: center;">
                <form method="get" style="display: flex; gap: 10px; align-items: center;">
                    <input type="hidden" name="page" value="isidor-consilium">

                    <select name="gremium">
                        <option value=""><?php _e('Alle Gremien', 'isidor-suite'); ?></option>
                        <?php foreach (Isidor_Consilium_Database::get_valid_gremiums() as $g): ?>
                            <option value="<?php echo esc_attr($g); ?>" <?php selected($filter_gremium, $g); ?>>
                                <?php echo esc_html(Isidor_Consilium_Database::get_gremium_short_label($g)); ?>
                                (<?php echo esc_html(Isidor_Consilium_Database::get_gremium_label($g)); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <select name="status">
                        <option value=""><?php _e('Alle Status', 'isidor-suite'); ?></option>
                        <?php foreach (Isidor_Consilium_Database::get_valid_statuses() as $s): ?>
                            <option value="<?php echo esc_attr($s); ?>" <?php selected($filter_status, $s); ?>>
                                <?php echo esc_html(Isidor_Consilium_Database::get_status_label($s)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <select name="year">
                        <option value=""><?php _e('Alle Jahre', 'isidor-suite'); ?></option>
                        <?php foreach ($years as $y): ?>
                            <option value="<?php echo esc_attr($y); ?>" <?php selected($filter_year, (int)$y); ?>><?php echo esc_html($y); ?></option>
                        <?php endforeach; ?>
                    </select>

                    <button type="submit" class="button"><?php _e('Filtern', 'isidor-suite'); ?></button>
                </form>
            </div>

            <!-- Sessions Table -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:22%"><?php _e('Titel', 'isidor-suite'); ?></th>
                        <th style="width:10%"><?php _e('Gremium', 'isidor-suite'); ?></th>
                        <th style="width:10%"><?php _e('Datum', 'isidor-suite'); ?></th>
                        <th style="width:10%"><?php _e('Uhrzeit', 'isidor-suite'); ?></th>
                        <th style="width:7%"><?php _e('Teiln.', 'isidor-suite'); ?></th>
                        <th style="width:10%"><?php _e('Status', 'isidor-suite'); ?></th>
                        <th style="width:10%"><?php _e('Protokoll', 'isidor-suite'); ?></th>
                        <th style="width:21%"><?php _e('Aktionen', 'isidor-suite'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sessions)): ?>
                        <tr>
                            <td colspan="8"><em><?php _e('Keine Sitzungen gefunden.', 'isidor-suite'); ?></em></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($sessions as $session): ?>
                            <tr>
                                <td><strong><?php echo esc_html($session['title']); ?></strong></td>
                                <td>
                                    <span class="consilium-badge consilium-badge--<?php echo esc_attr($session['gremium']); ?>">
                                        <?php echo esc_html(Isidor_Consilium_Database::get_gremium_short_label($session['gremium'])); ?>
                                    </span>
                                    <?php if ($session['gremium'] === 'sonstige' && !empty($session['custom_gremium_label'])): ?>
                                        <br><small><?php echo esc_html($session['custom_gremium_label']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(date_i18n('d.m.Y', strtotime($session['session_date']))); ?></td>
                                <td>
                                    <?php if ($session['time_start']): ?>
                                        <?php echo esc_html(date_i18n('H:i', strtotime($session['time_start']))); ?>
                                        <?php if ($session['time_end']): ?>
                                            — <?php echo esc_html(date_i18n('H:i', strtotime($session['time_end']))); ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($session['participant_count']); ?></td>
                                <td>
                                    <span class="consilium-status consilium-status--<?php echo esc_attr($session['status']); ?>">
                                        <?php echo esc_html(Isidor_Consilium_Database::get_status_label($session['status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="consilium-protocol-status consilium-protocol-status--<?php echo esc_attr($session['protocol_status'] ?? 'none'); ?>">
                                        <?php echo esc_html(Isidor_Consilium_Database::get_protocol_status_label($session['protocol_status'] ?? 'none')); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-consilium-edit&id=' . $session['id'])); ?>" class="button button-small">
                                        <?php _e('Bearbeiten', 'isidor-suite'); ?>
                                    </a>
                                    <?php if ($session['status'] === 'active'): ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-consilium-live&id=' . $session['id'])); ?>" class="button button-small button-primary">
                                            <?php _e('Live', 'isidor-suite'); ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (in_array($session['status'], ['completed', 'archived'], true)): ?>
                                        <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=consilium_generate_pdf&id=' . $session['id'] . '&_wpnonce=' . wp_create_nonce('consilium_pdf'))); ?>" class="button button-small" target="_blank">
                                            <?php _e('PDF', 'isidor-suite'); ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    // =========================================================================
    // PAGE 2: SESSION EDITOR
    // =========================================================================

    public static function render_session_editor(): void {
        global $wpdb;
        $id = intval($_GET['id'] ?? 0);
        $session = null;

        if ($id > 0) {
            $session = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
                $id
            ), ARRAY_A);
        }

        $is_new = !$session;
        $page_title = $is_new ? __('Neue Sitzung', 'isidor-suite') : __('Sitzung bearbeiten', 'isidor-suite');
        $protocol_status = $session['protocol_status'] ?? 'none';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($page_title); ?></h1>

            <div id="consilium-editor" class="consilium-editor" data-session-id="<?php echo esc_attr($id); ?>">

                <!-- Session Metadata -->
                <div class="consilium-editor__grid">
                    <div class="consilium-editor__main">
                        <div class="isidor-card">
                            <h3><?php _e('Sitzungsdaten', 'isidor-suite'); ?></h3>

                            <table class="form-table">
                                <tr>
                                    <th><label for="consilium-title"><?php _e('Titel', 'isidor-suite'); ?></label></th>
                                    <td><input type="text" id="consilium-title" class="regular-text" value="<?php echo esc_attr($session['title'] ?? ''); ?>" required></td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-gremium"><?php _e('Gremium', 'isidor-suite'); ?></label></th>
                                    <td>
                                        <select id="consilium-gremium">
                                            <option value="pgr" <?php selected($session['gremium'] ?? '', 'pgr'); ?>>PGR (Pfarrgemeinderat)</option>
                                            <option value="vvr" <?php selected($session['gremium'] ?? '', 'vvr'); ?>>VVR (Vermögensverwaltungsrat)</option>
                                            <option value="liturgieausschuss" <?php selected($session['gremium'] ?? '', 'liturgieausschuss'); ?>>Liturgieausschuss</option>
                                            <option value="sonstige" <?php selected($session['gremium'] ?? '', 'sonstige'); ?>>Sonstige</option>
                                        </select>
                                        <div id="consilium-custom-gremium-wrap" style="margin-top:8px;<?php echo ($session['gremium'] ?? '') !== 'sonstige' ? 'display:none;' : ''; ?>">
                                            <input type="text" id="consilium-custom-gremium" class="regular-text" 
                                                   placeholder="<?php esc_attr_e('Bezeichnung eingeben (z.B. Finanzausschuss)...', 'isidor-suite'); ?>"
                                                   value="<?php echo esc_attr($session['custom_gremium_label'] ?? ''); ?>">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-date"><?php _e('Datum', 'isidor-suite'); ?></label></th>
                                    <td><input type="date" id="consilium-date" value="<?php echo esc_attr($session['session_date'] ?? ''); ?>" required></td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-time-start"><?php _e('Uhrzeit Start', 'isidor-suite'); ?></label></th>
                                    <td><input type="time" id="consilium-time-start" value="<?php echo esc_attr($session['time_start'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-time-end"><?php _e('Uhrzeit Ende', 'isidor-suite'); ?></label></th>
                                    <td><input type="time" id="consilium-time-end" value="<?php echo esc_attr($session['time_end'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-location"><?php _e('Ort', 'isidor-suite'); ?></label></th>
                                    <td><input type="text" id="consilium-location" class="regular-text" value="<?php echo esc_attr($session['location'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-topic-deadline"><?php _e('TOP-Vorschlag Deadline', 'isidor-suite'); ?></label></th>
                                    <td>
                                        <input type="date" id="consilium-topic-deadline" value="<?php echo esc_attr($session['topic_deadline'] ?? ''); ?>">
                                        <p class="description"><?php _e('Bis wann Teilnehmer Themen einreichen können', 'isidor-suite'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="consilium-reminder-days"><?php _e('Erinnerung (Tage vorher)', 'isidor-suite'); ?></label></th>
                                    <td>
                                        <input type="number" id="consilium-reminder-days" min="0" max="30" value="<?php echo esc_attr($session['reminder_days'] ?? 3); ?>" style="width:80px;">
                                        <p class="description"><?php _e('Automatische Erinnerungsmail an ausstehende RSVPs (0 = deaktiviert)', 'isidor-suite'); ?></p>
                                    </td>
                                </tr>
                            </table>

                            <p>
                                <button type="button" class="button button-primary" id="consilium-save-session">
                                    <?php _e('Sitzung speichern', 'isidor-suite'); ?>
                                </button>
                                <span id="consilium-save-status" style="margin-left: 10px;"></span>
                            </p>
                        </div>

                        <!-- Topics (only for existing sessions) -->
                        <?php if (!$is_new): ?>
                        <div class="isidor-card">
                            <h3><?php _e('Tagesordnungspunkte (TOPs)', 'isidor-suite'); ?></h3>

                            <div id="consilium-topics-list" class="consilium-topics-list">
                                <p class="consilium-loading"><?php _e('Wird geladen...', 'isidor-suite'); ?></p>
                            </div>

                            <div class="consilium-add-topic" style="margin-top: 15px; display: flex; gap: 10px;">
                                <input type="text" id="consilium-new-topic-title" class="regular-text" placeholder="<?php esc_attr_e('Titel des neuen TOP...', 'isidor-suite'); ?>">
                                <button type="button" class="button" id="consilium-add-topic"><?php _e('TOP hinzufügen', 'isidor-suite'); ?></button>
                            </div>
                        </div>

                        <!-- Participants -->
                        <div class="isidor-card">
                            <h3><?php _e('Teilnehmer', 'isidor-suite'); ?></h3>

                            <div id="consilium-participants-list" class="consilium-participants-list">
                                <p class="consilium-loading"><?php _e('Wird geladen...', 'isidor-suite'); ?></p>
                            </div>

                            <div class="consilium-add-participant" style="margin-top: 15px; display: flex; gap: 10px; position: relative;">
                                <input type="text" id="consilium-user-search" class="regular-text" placeholder="<?php esc_attr_e('Benutzer suchen...', 'isidor-suite'); ?>" autocomplete="off">
                                <div id="consilium-user-suggestions" class="consilium-suggestions" style="display:none;"></div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Sidebar -->
                    <div class="consilium-editor__sidebar">
                        <div class="isidor-card">
                            <h3><?php _e('Status & Aktionen', 'isidor-suite'); ?></h3>

                            <?php if (!$is_new): ?>
                                <p>
                                    <strong><?php _e('Status:', 'isidor-suite'); ?></strong>
                                    <span class="consilium-status consilium-status--<?php echo esc_attr($session['status']); ?>">
                                        <?php echo esc_html(Isidor_Consilium_Database::get_status_label($session['status'])); ?>
                                    </span>
                                </p>

                                <p>
                                    <strong><?php _e('Protokoll:', 'isidor-suite'); ?></strong>
                                    <span class="consilium-protocol-status consilium-protocol-status--<?php echo esc_attr($protocol_status); ?>">
                                        <?php echo esc_html(Isidor_Consilium_Database::get_protocol_status_label($protocol_status)); ?>
                                    </span>
                                </p>

                                <div class="consilium-actions" style="display: flex; flex-direction: column; gap: 8px;">
                                    <?php if (in_array($session['status'], ['draft', 'invited'])): ?>
                                        <button type="button" class="button" id="consilium-send-invitations">
                                            <?php echo $session['invitation_sent_at'] ? __('Einladungen erneut senden', 'isidor-suite') : __('Einladungen senden', 'isidor-suite'); ?>
                                        </button>
                                        <?php if ($session['invitation_sent_at']): ?>
                                            <small style="color:#6b7280;">Gesendet: <?php echo esc_html(date_i18n('d.m.Y H:i', strtotime($session['invitation_sent_at']))); ?></small>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if ($session['status'] === 'invited'): ?>
                                        <button type="button" class="button" id="consilium-send-reminder" title="Erinnerung an Teilnehmer ohne RSVP">
                                            ⏰ <?php _e('Erinnerung senden', 'isidor-suite'); ?>
                                        </button>
                                        <button type="button" class="button button-primary" id="consilium-start-session">
                                            🔴 <?php _e('Sitzung starten (Live)', 'isidor-suite'); ?>
                                        </button>
                                    <?php endif; ?>

                                    <?php if ($session['status'] === 'draft'): ?>
                                        <button type="button" class="button button-primary" id="consilium-start-session">
                                            🔴 <?php _e('Sitzung starten (Live)', 'isidor-suite'); ?>
                                        </button>
                                    <?php endif; ?>

                                    <?php if ($session['status'] === 'active'): ?>
                                        <?php
                                        // Find live dashboard page
                                        $live_page = $wpdb->get_row("SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status='publish' AND post_content LIKE '%[isidor_consilium_live%' LIMIT 1");
                                        $live_url = $live_page ? add_query_arg('session_id', $id, get_permalink($live_page->ID)) : '';
                                        ?>
                                        <?php if ($live_url): ?>
                                            <a href="<?php echo esc_url($live_url); ?>" class="button button-primary" target="_blank">
                                                🔴 <?php _e('Live-Dashboard öffnen', 'isidor-suite'); ?>
                                            </a>
                                        <?php endif; ?>
                                        <button type="button" class="button" id="consilium-send-invitations">
                                            <?php _e('Einladungen (erneut) senden', 'isidor-suite'); ?>
                                        </button>
                                    <?php endif; ?>

                                    <?php if ($session['status'] === 'completed'): ?>
                                        <?php if ($protocol_status === 'finalized'): ?>
                                            <button type="button" class="button button-primary" id="consilium-send-protocol">
                                                📧 <?php _e('Protokoll versenden', 'isidor-suite'); ?>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="button" id="consilium-save-protocol-draft">
                                                <?php _e('Protokoll zwischenspeichern', 'isidor-suite'); ?>
                                            </button>
                                            <button type="button" class="button button-primary" id="consilium-finalize-protocol">
                                                <?php _e('Endgültig ablegen', 'isidor-suite'); ?>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (in_array($session['status'], ['completed', 'archived'], true)): ?>
                                        <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=consilium_generate_pdf&id=' . $id . '&_wpnonce=' . wp_create_nonce('consilium_pdf'))); ?>" class="button" target="_blank">
                                            📄 <?php _e('PDF anzeigen', 'isidor-suite'); ?>
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($session['status'] === 'draft'): ?>
                                        <button type="button" class="button consilium-btn-danger" id="consilium-delete-session">
                                            <?php _e('Sitzung löschen', 'isidor-suite'); ?>
                                        </button>
                                    <?php endif; ?>
                                </div>

                                <?php
                                // RSVP Summary 
                                if (!$is_new && in_array($session['status'], ['invited', 'active', 'completed'])):
                                    $rsvp = Isidor_Consilium_Database::get_rsvp_summary($id);
                                ?>
                                <div style="margin-top:16px;padding-top:12px;border-top:1px solid #e5e7eb;">
                                    <strong>RSVP-Übersicht</strong>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:8px;">
                                        <span>✅ Zusage: <strong><?php echo $rsvp['accepted']; ?></strong></span>
                                        <span>❌ Absage: <strong><?php echo $rsvp['declined']; ?></strong></span>
                                        <span>❓ Vielleicht: <strong><?php echo $rsvp['maybe']; ?></strong></span>
                                        <span>⏳ Offen: <strong><?php echo $rsvp['pending']; ?></strong></span>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <p><em><?php _e('Bitte speichern Sie die Sitzung, um TOPs und Teilnehmer hinzuzufügen.', 'isidor-suite'); ?></em></p>
                            <?php endif; ?>
                        </div>

                        <?php if (!$is_new): ?>
                        <div class="isidor-card">
                            <h3><?php _e('Info', 'isidor-suite'); ?></h3>
                            <p><small>
                                <?php _e('Erstellt:', 'isidor-suite'); ?> <?php echo esc_html(date_i18n('d.m.Y H:i', strtotime($session['created_at']))); ?><br>
                                <?php _e('Aktualisiert:', 'isidor-suite'); ?> <?php echo esc_html(date_i18n('d.m.Y H:i', strtotime($session['updated_at']))); ?>
                            </small></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // =========================================================================
    // PAGE 3: LIVE SESSION
    // =========================================================================

    public static function render_live_session(): void {
        global $wpdb;
        $id = intval($_GET['id'] ?? 0);

        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$session) {
            echo '<div class="wrap"><div class="notice notice-error"><p>' . esc_html__('Sitzung nicht gefunden.', 'isidor-suite') . '</p></div></div>';
            return;
        }

        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d ORDER BY sort_order ASC",
            $id
        ), ARRAY_A);

        $participants = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, u.display_name, u.user_email FROM " . Isidor_Consilium_Database::get_participants_table() . " p LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID WHERE p.session_id = %d",
            $id
        ), ARRAY_A);

        $votes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d ORDER BY created_at ASC",
            $id
        ), ARRAY_A);

        $gremium_label = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
        $protocol_status = $session['protocol_status'] ?? 'none';

        ?>
        <div class="wrap consilium-live-wrap">
            <div class="consilium-live-header">
                <h1><?php echo esc_html($session['title']); ?></h1>
                <span class="consilium-badge consilium-badge--<?php echo esc_attr($session['gremium']); ?>">
                    <?php echo esc_html(Isidor_Consilium_Database::get_gremium_short_label($session['gremium'])); ?>
                </span>
                <span class="consilium-live-date"><?php echo esc_html(date_i18n('d.m.Y', strtotime($session['session_date']))); ?></span>
                <span class="consilium-live-location"><?php echo esc_html($session['location'] ?: ''); ?></span>

                <div class="consilium-live-header-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-consilium-edit&id=' . $id)); ?>" class="button"><?php _e('Zurück zum Editor', 'isidor-suite'); ?></a>

                    <?php if ($session['status'] === 'active'): ?>
                        <button type="button" class="button" id="consilium-save-protocol-draft" data-session-id="<?php echo esc_attr($id); ?>">
                            <?php _e('Zwischenspeichern', 'isidor-suite'); ?>
                        </button>
                        <button type="button" class="button button-primary" id="consilium-complete-session" data-session-id="<?php echo esc_attr($id); ?>">
                            <?php _e('Sitzung abschließen', 'isidor-suite'); ?>
                        </button>
                    <?php endif; ?>

                    <?php if ($session['status'] === 'completed' && $protocol_status !== 'finalized'): ?>
                        <button type="button" class="button" id="consilium-save-protocol-draft" data-session-id="<?php echo esc_attr($id); ?>">
                            <?php _e('Zwischenspeichern', 'isidor-suite'); ?>
                        </button>
                        <button type="button" class="button button-primary" id="consilium-finalize-protocol" data-session-id="<?php echo esc_attr($id); ?>">
                            <?php _e('Endgültig ablegen & versenden', 'isidor-suite'); ?>
                        </button>
                    <?php endif; ?>

                    <?php if ($protocol_status === 'finalized'): ?>
                        <span class="consilium-protocol-status consilium-protocol-status--finalized" style="padding: 6px 12px;">
                            ✅ <?php _e('Protokoll endgültig abgelegt', 'isidor-suite'); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="consilium-live-layout" data-session-id="<?php echo esc_attr($id); ?>">
                <!-- Left: Topics Navigation -->
                <div class="consilium-live-sidebar">
                    <h3><?php _e('Tagesordnung', 'isidor-suite'); ?></h3>
                    <ul id="consilium-live-topics" class="consilium-live-topics">
                        <?php foreach ($topics as $i => $topic): ?>
                            <li class="consilium-live-topic <?php echo $i === 0 ? 'consilium-live-topic--active' : ''; ?>"
                                data-topic-id="<?php echo esc_attr($topic['id']); ?>">
                                <span class="consilium-live-topic__number"><?php echo ($i + 1); ?></span>
                                <span class="consilium-live-topic__title"><?php echo esc_html($topic['title']); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <hr>

                    <!-- Attendance -->
                    <h3><?php _e('Anwesenheit', 'isidor-suite'); ?></h3>
                    <div id="consilium-attendance" class="consilium-attendance">
                        <?php foreach ($participants as $p): ?>
                            <label class="consilium-attendance__item">
                                <input type="checkbox" class="consilium-attendance__check"
                                       data-user-id="<?php echo esc_attr($p['user_id']); ?>"
                                       <?php checked($p['attended'], 1); ?>>
                                <?php echo esc_html($p['display_name']); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Center: Protocol Editor -->
                <div class="consilium-live-main">
                    <div id="consilium-protocol-header">
                        <h2 id="consilium-active-topic-title"><?php echo esc_html(!empty($topics) ? 'TOP 1: ' . $topics[0]['title'] : __('Kein TOP vorhanden', 'isidor-suite')); ?></h2>
                        <span id="consilium-autosave-status" class="consilium-autosave-status"></span>
                    </div>

                    <div id="consilium-protocol-editor" class="consilium-protocol-editor">
                        <?php
                        if (!empty($topics)) {
                            $first_topic_id = $topics[0]['id'];
                            $protocol = $wpdb->get_row($wpdb->prepare(
                                "SELECT content FROM " . Isidor_Consilium_Database::get_protocols_table() . " WHERE topic_id = %d",
                                $first_topic_id
                            ), ARRAY_A);
                            $initial_content = $protocol['content'] ?? '';
                        } else {
                            $initial_content = '';
                            $first_topic_id = 0;
                        }

                        // Protocol is editable unless finalized
                        $readonly = ($protocol_status === 'finalized');

                        wp_editor($initial_content, 'consilium_protocol', [
                            'textarea_name' => 'consilium_protocol',
                            'media_buttons' => false,
                            'textarea_rows' => 20,
                            'teeny'         => false,
                            'quicktags'     => true,
                            'tinymce'       => $readonly ? false : [
                                'toolbar1' => 'formatselect,bold,italic,underline,strikethrough,|,bullist,numlist,|,blockquote,hr,|,link,unlink,|,undo,redo',
                                'toolbar2' => '',
                            ],
                        ]);
                        ?>
                    </div>
                    <input type="hidden" id="consilium-active-topic-id" value="<?php echo esc_attr($first_topic_id); ?>">
                </div>

                <!-- Right: Voting Panel -->
                <div class="consilium-live-voting">
                    <h3><?php _e('Abstimmung', 'isidor-suite'); ?></h3>

                    <?php if ($session['status'] === 'active'): ?>
                    <!-- Create vote form -->
                    <div id="consilium-vote-create" class="consilium-vote-create">
                        <div style="margin-bottom: 8px;">
                            <label><?php _e('Titel:', 'isidor-suite'); ?></label>
                            <input type="text" id="consilium-vote-title" class="widefat" placeholder="<?php esc_attr_e('Abstimmungstitel...', 'isidor-suite'); ?>">
                        </div>
                        <div style="margin-bottom: 8px;">
                            <label><?php _e('Modus:', 'isidor-suite'); ?></label>
                            <select id="consilium-vote-mode" class="widefat">
                                <option value="open"><?php _e('Offen', 'isidor-suite'); ?></option>
                                <option value="secret"><?php _e('Geheim', 'isidor-suite'); ?></option>
                            </select>
                        </div>
                        <div style="margin-bottom: 8px;">
                            <label><?php _e('Optionen:', 'isidor-suite'); ?></label>
                            <input type="text" id="consilium-vote-options" class="widefat" value="Ja, Nein, Enthaltung" placeholder="Ja, Nein, Enthaltung">
                            <p class="description"><?php _e('Kommagetrennt', 'isidor-suite'); ?></p>
                        </div>
                        <button type="button" class="button" id="consilium-create-vote">
                            <?php _e('Abstimmung erstellen', 'isidor-suite'); ?>
                        </button>
                    </div>
                    <?php endif; ?>

                    <!-- Active/Past Votes -->
                    <div id="consilium-votes-list" class="consilium-votes-list" style="margin-top: 15px;">
                        <?php foreach ($votes as $vote): ?>
                            <div class="consilium-vote-card consilium-vote-card--<?php echo esc_attr($vote['status']); ?>" data-vote-id="<?php echo esc_attr($vote['id']); ?>">
                                <div class="consilium-vote-card__header">
                                    <strong><?php echo esc_html($vote['title']); ?></strong>
                                    <span class="consilium-badge consilium-badge--<?php echo esc_attr($vote['mode']); ?>">
                                        <?php echo esc_html($vote['mode'] === 'secret' ? 'Geheim' : 'Offen'); ?>
                                    </span>
                                </div>
                                <?php if ($vote['status'] === 'pending'): ?>
                                    <button type="button" class="button button-small consilium-start-vote" data-vote-id="<?php echo esc_attr($vote['id']); ?>">
                                        <?php _e('Starten', 'isidor-suite'); ?>
                                    </button>
                                <?php elseif ($vote['status'] === 'active'): ?>
                                    <div class="consilium-vote-live" data-vote-id="<?php echo esc_attr($vote['id']); ?>">
                                        <div class="consilium-vote-progress">
                                            <span class="consilium-vote-progress__text"><?php _e('Läuft...', 'isidor-suite'); ?></span>
                                        </div>
                                        <button type="button" class="button button-small consilium-stop-vote" data-vote-id="<?php echo esc_attr($vote['id']); ?>">
                                            <?php _e('Beenden', 'isidor-suite'); ?>
                                        </button>
                                    </div>
                                <?php elseif ($vote['status'] === 'closed'): ?>
                                    <div class="consilium-vote-results" data-vote-id="<?php echo esc_attr($vote['id']); ?>">
                                        <span class="consilium-loading"><?php _e('Ergebnisse laden...', 'isidor-suite'); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // =========================================================================
    // PAGE 4: ARCHIVE ACCESS MANAGEMENT
    // =========================================================================

    public static function render_archive_access(): void {
        if (!current_user_can('isidor_consilium_admin')) {
            wp_die(__('Keine Berechtigung.', 'isidor-suite'));
        }

        // Handle form submission
        if (!empty($_POST['consilium_archive_access_nonce']) && wp_verify_nonce($_POST['consilium_archive_access_nonce'], 'consilium_archive_access')) {
            $user_ids = isset($_POST['archive_users']) ? array_map('intval', $_POST['archive_users']) : [];
            $all_gremiums = Isidor_Consilium_Database::get_valid_gremiums();

            // Get all users to update
            $all_user_ids = array_unique(array_merge(
                $user_ids,
                self::get_all_archive_user_ids()
            ));

            foreach ($all_user_ids as $uid) {
                $granted = [];
                foreach ($all_gremiums as $g) {
                    if (!empty($_POST['archive_access'][$uid][$g])) {
                        $granted[] = $g;
                    }
                }
                Isidor_Consilium_Database::set_user_archive_access($uid, $granted, get_current_user_id());
            }

            echo '<div class="notice notice-success"><p>' . esc_html__('Archivzugriff aktualisiert.', 'isidor-suite') . '</p></div>';
        }

        // Get all WordPress users
        $users = get_users(['orderby' => 'display_name', 'order' => 'ASC', 'number' => 200]);
        $gremiums = Isidor_Consilium_Database::get_valid_gremiums();

        ?>
        <div class="wrap">
            <h1><?php _e('Consilium — Archivzugriff verwalten', 'isidor-suite'); ?></h1>
            <p class="description">
                <?php _e('Hier können Sie festlegen, welche Benutzer auf das Archiv der jeweiligen Gremien zugreifen dürfen. Aktivieren Sie die entsprechenden Checkboxen.', 'isidor-suite'); ?>
            </p>

            <form method="post">
                <?php wp_nonce_field('consilium_archive_access', 'consilium_archive_access_nonce'); ?>

                <table class="wp-list-table widefat fixed striped" style="margin-top: 15px;">
                    <thead>
                        <tr>
                            <th style="width: 30%;"><?php _e('Benutzer', 'isidor-suite'); ?></th>
                            <th style="width: 12%;"><?php _e('E-Mail', 'isidor-suite'); ?></th>
                            <?php foreach ($gremiums as $g): ?>
                                <th style="width: 12%; text-align: center;">
                                    <?php echo esc_html(Isidor_Consilium_Database::get_gremium_short_label($g)); ?><br>
                                    <small><?php _e('Archiv', 'isidor-suite'); ?></small>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <?php $user_access = Isidor_Consilium_Database::get_user_archive_access($user->ID); ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($user->display_name); ?></strong>
                                    <input type="hidden" name="archive_users[]" value="<?php echo esc_attr($user->ID); ?>">
                                </td>
                                <td><small><?php echo esc_html($user->user_email); ?></small></td>
                                <?php foreach ($gremiums as $g): ?>
                                    <td style="text-align: center;">
                                        <input type="checkbox" 
                                               name="archive_access[<?php echo esc_attr($user->ID); ?>][<?php echo esc_attr($g); ?>]" 
                                               value="1"
                                               <?php checked(in_array($g, $user_access, true)); ?>>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <p style="margin-top: 15px;">
                    <button type="submit" class="button button-primary"><?php _e('Archivzugriff speichern', 'isidor-suite'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private static function get_all_archive_user_ids(): array {
        global $wpdb;
        $table = Isidor_Consilium_Database::get_archive_access_table();
        return $wpdb->get_col("SELECT DISTINCT user_id FROM {$table}");
    }
}
