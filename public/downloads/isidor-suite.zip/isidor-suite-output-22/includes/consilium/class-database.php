<?php
/**
 * Isidor Consilium - Database
 *
 * Erstellt und verwaltet die Datenbanktabellen für das Consilium-Modul
 * (PGR/VVR/Liturgieausschuss/Sonstige Sitzungsverwaltung).
 *
 * @package IsidorSuite
 * @subpackage Consilium
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_Database {

    // =========================================================================
    // TABLE NAME GETTERS
    // =========================================================================

    public static function get_sessions_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_sessions';
    }

    public static function get_topics_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_topics';
    }

    public static function get_participants_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_participants';
    }

    public static function get_protocols_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_protocols';
    }

    public static function get_votes_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_votes';
    }

    public static function get_ballots_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_ballots';
    }

    public static function get_archive_access_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_archive_access';
    }

    public static function get_reminder_log_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'isidor_consilium_reminder_log';
    }

    // =========================================================================
    // TABLE CREATION
    // =========================================================================

    public static function create_tables(): void {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // 1. Sessions — extended with invitation tracking, RSVP deadline, reminders
        $table = self::get_sessions_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            gremium varchar(30) NOT NULL DEFAULT 'pgr',
            custom_gremium_label varchar(255) DEFAULT NULL,
            session_date date NOT NULL,
            time_start time DEFAULT NULL,
            time_end time DEFAULT NULL,
            location varchar(255) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            protocol_status varchar(20) NOT NULL DEFAULT 'none',
            topic_deadline date DEFAULT NULL,
            reminder_days int NOT NULL DEFAULT 3,
            reminder_sent tinyint(1) NOT NULL DEFAULT 0,
            invitation_sent_at datetime DEFAULT NULL,
            created_by bigint(20) UNSIGNED NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_gremium (gremium),
            KEY idx_status (status),
            KEY idx_protocol_status (protocol_status),
            KEY idx_session_date (session_date),
            KEY idx_created_by (created_by)
        ) {$charset_collate};";
        dbDelta($sql);

        // 2. Topics (TOPs) — with submission workflow + Berichterstatter
        $table = self::get_topics_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id bigint(20) UNSIGNED NOT NULL,
            sort_order int UNSIGNED NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL,
            description text DEFAULT NULL,
            reporter_user_id bigint(20) UNSIGNED DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'planned',
            submitted_by bigint(20) UNSIGNED DEFAULT NULL,
            submitted_at datetime DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_session_id (session_id),
            KEY idx_sort_order (session_id,sort_order),
            KEY idx_status (status)
        ) {$charset_collate};";
        dbDelta($sql);

        // 3. Participants — with RSVP
        $table = self::get_participants_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            invited_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            attended tinyint(1) NOT NULL DEFAULT 0,
            rsvp varchar(20) NOT NULL DEFAULT 'pending',
            rsvp_at datetime DEFAULT NULL,
            rsvp_token varchar(64) DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uk_session_user (session_id,user_id),
            KEY idx_session_id (session_id),
            KEY idx_user_id (user_id),
            KEY idx_rsvp_token (rsvp_token)
        ) {$charset_collate};";
        dbDelta($sql);

        // 4. Protocols
        $table = self::get_protocols_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id bigint(20) UNSIGNED NOT NULL,
            topic_id bigint(20) UNSIGNED NOT NULL,
            content longtext DEFAULT NULL,
            updated_by bigint(20) UNSIGNED DEFAULT NULL,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uk_session_topic (session_id,topic_id),
            KEY idx_topic_id (topic_id)
        ) {$charset_collate};";
        dbDelta($sql);

        // 5. Votes — with advance/live timing
        $table = self::get_votes_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id bigint(20) UNSIGNED NOT NULL,
            topic_id bigint(20) UNSIGNED DEFAULT NULL,
            title varchar(255) NOT NULL,
            mode varchar(10) NOT NULL DEFAULT 'open',
            timing varchar(10) NOT NULL DEFAULT 'live',
            options longtext DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            closed_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_session_id (session_id),
            KEY idx_topic_id (topic_id),
            KEY idx_status (status)
        ) {$charset_collate};";
        dbDelta($sql);

        // 6. Ballots
        $table = self::get_ballots_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vote_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            choice varchar(255) NOT NULL,
            voted_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uk_vote_user (vote_id,user_id),
            KEY idx_vote_id (vote_id)
        ) {$charset_collate};";
        dbDelta($sql);

        // 7. Archive Access — per-user per-gremium archive access control
        $table = self::get_archive_access_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            gremium varchar(30) NOT NULL,
            granted_by bigint(20) UNSIGNED NOT NULL,
            granted_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uk_user_gremium (user_id,gremium),
            KEY idx_user_id (user_id),
            KEY idx_gremium (gremium)
        ) {$charset_collate};";
        dbDelta($sql);

        // 8. Reminder Log — tracks sent emails
        $table = self::get_reminder_log_table();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            sent_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            type varchar(20) NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uk_session_user_type (session_id,user_id,type),
            KEY idx_session_id (session_id)
        ) {$charset_collate};";
        dbDelta($sql);
    }

    // =========================================================================
    // VALIDATION HELPERS
    // =========================================================================

    public static function get_valid_statuses(): array {
        return ['draft', 'invited', 'active', 'completed', 'archived'];
    }

    /**
     * Protocol statuses:
     * - none:      Kein Protokoll begonnen
     * - draft:     Zwischengespeichert (halb bearbeitet)
     * - finalized: Endgültig abgelegt und verschickt
     */
    public static function get_valid_protocol_statuses(): array {
        return ['none', 'draft', 'finalized'];
    }

    public static function get_valid_gremiums(): array {
        return ['pgr', 'vvr', 'liturgieausschuss', 'sonstige'];
    }

    public static function get_valid_vote_modes(): array {
        return ['open', 'secret'];
    }

    public static function get_valid_vote_statuses(): array {
        return ['pending', 'active', 'closed'];
    }

    public static function get_gremium_label(string $gremium, ?string $custom_label = null): string {
        if ($gremium === 'sonstige' && !empty($custom_label)) {
            return $custom_label;
        }
        $labels = [
            'pgr'               => 'Pfarrgemeinderat',
            'vvr'               => 'Vermögensverwaltungsrat',
            'liturgieausschuss'  => 'Liturgieausschuss',
            'sonstige'           => 'Sonstige',
        ];
        return $labels[$gremium] ?? $gremium;
    }

    public static function get_gremium_short_label(string $gremium): string {
        $labels = [
            'pgr'               => 'PGR',
            'vvr'               => 'VVR',
            'liturgieausschuss'  => 'LA',
            'sonstige'           => 'SONST',
        ];
        return $labels[$gremium] ?? strtoupper($gremium);
    }

    public static function get_status_label(string $status): string {
        $labels = [
            'draft'     => 'Entwurf',
            'invited'   => 'Eingeladen',
            'active'    => 'Laufend',
            'completed' => 'Abgeschlossen',
            'archived'  => 'Archiviert',
        ];
        return $labels[$status] ?? $status;
    }

    public static function get_protocol_status_label(string $status): string {
        $labels = [
            'none'      => 'Kein Protokoll',
            'draft'     => 'Zwischengespeichert',
            'finalized' => 'Endgültig',
        ];
        return $labels[$status] ?? $status;
    }

    public static function get_valid_rsvp_statuses(): array {
        return ['pending', 'accepted', 'declined', 'maybe'];
    }

    public static function get_rsvp_label(string $rsvp): string {
        $labels = [
            'pending'  => 'Ausstehend',
            'accepted' => 'Zugesagt',
            'declined' => 'Abgesagt',
            'maybe'    => 'Vielleicht',
        ];
        return $labels[$rsvp] ?? $rsvp;
    }

    public static function get_valid_topic_statuses(): array {
        return ['planned', 'submitted', 'accepted', 'rejected'];
    }

    public static function get_topic_status_label(string $status): string {
        $labels = [
            'planned'   => 'Geplant',
            'submitted' => 'Eingereicht',
            'accepted'  => 'Angenommen',
            'rejected'  => 'Abgelehnt',
        ];
        return $labels[$status] ?? $status;
    }

    public static function get_valid_vote_timings(): array {
        return ['advance', 'live'];
    }

    // =========================================================================
    // RSVP HELPERS
    // =========================================================================

    /**
     * Generate unique RSVP token for a participant
     */
    public static function generate_rsvp_token(int $session_id, int $user_id): string {
        global $wpdb;
        $token = wp_generate_password(48, false);
        $wpdb->update(
            self::get_participants_table(),
            ['rsvp_token' => $token],
            ['session_id' => $session_id, 'user_id' => $user_id],
            ['%s'],
            ['%d', '%d']
        );
        return $token;
    }

    /**
     * Lookup participant by RSVP token
     */
    public static function get_participant_by_token(string $token): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::get_participants_table() . " WHERE rsvp_token = %s",
            $token
        ), ARRAY_A);
        return $row ?: null;
    }

    /**
     * Set RSVP status
     */
    public static function set_rsvp(int $session_id, int $user_id, string $rsvp): bool {
        global $wpdb;
        if (!in_array($rsvp, self::get_valid_rsvp_statuses(), true)) return false;
        return (bool) $wpdb->update(
            self::get_participants_table(),
            ['rsvp' => $rsvp, 'rsvp_at' => current_time('mysql')],
            ['session_id' => $session_id, 'user_id' => $user_id],
            ['%s', '%s'],
            ['%d', '%d']
        );
    }

    /**
     * Get RSVP summary for a session
     */
    public static function get_rsvp_summary(int $session_id): array {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT rsvp, COUNT(*) as cnt FROM " . self::get_participants_table() . " WHERE session_id = %d GROUP BY rsvp",
            $session_id
        ), ARRAY_A);
        $summary = ['pending' => 0, 'accepted' => 0, 'declined' => 0, 'maybe' => 0];
        foreach ($rows as $r) {
            $summary[$r['rsvp']] = (int) $r['cnt'];
        }
        return $summary;
    }

    // =========================================================================
    // ARCHIVE ACCESS HELPERS
    // =========================================================================

    /**
     * Prüft, ob ein User Zugriff auf das Archiv eines Gremiums hat
     */
    public static function user_has_archive_access(int $user_id, string $gremium): bool {
        global $wpdb;
        $table = self::get_archive_access_table();
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND gremium = %s",
            $user_id, $gremium
        ));
    }

    /**
     * Gibt alle Archiv-Zugänge eines Users zurück
     */
    public static function get_user_archive_access(int $user_id): array {
        global $wpdb;
        $table = self::get_archive_access_table();
        return $wpdb->get_col($wpdb->prepare(
            "SELECT gremium FROM {$table} WHERE user_id = %d",
            $user_id
        ));
    }

    /**
     * Setzt Archiv-Zugriff für einen User
     */
    public static function set_user_archive_access(int $user_id, array $gremiums, int $granted_by): void {
        global $wpdb;
        $table = self::get_archive_access_table();

        // Bestehende entfernen
        $wpdb->delete($table, ['user_id' => $user_id], ['%d']);

        // Neue setzen
        foreach ($gremiums as $gremium) {
            if (in_array($gremium, self::get_valid_gremiums(), true)) {
                $wpdb->insert($table, [
                    'user_id'    => $user_id,
                    'gremium'    => $gremium,
                    'granted_by' => $granted_by,
                    'granted_at' => current_time('mysql'),
                ], ['%d', '%s', '%d', '%s']);
            }
        }
    }

    /**
     * Gibt alle User mit Archiv-Zugriff für ein Gremium zurück
     */
    public static function get_archive_users(string $gremium): array {
        global $wpdb;
        $table = self::get_archive_access_table();
        return $wpdb->get_results($wpdb->prepare(
            "SELECT aa.*, u.display_name, u.user_email 
             FROM {$table} aa 
             LEFT JOIN {$wpdb->users} u ON aa.user_id = u.ID 
             WHERE aa.gremium = %s 
             ORDER BY u.display_name ASC",
            $gremium
        ), ARRAY_A);
    }

    // =========================================================================
    // TABLE MANAGEMENT
    // =========================================================================

    public static function tables_exist(): bool {
        global $wpdb;

        $tables = [
            self::get_sessions_table(),
            self::get_topics_table(),
            self::get_participants_table(),
            self::get_protocols_table(),
            self::get_votes_table(),
            self::get_ballots_table(),
            self::get_archive_access_table(),
            self::get_reminder_log_table(),
        ];

        foreach ($tables as $table) {
            $result = $wpdb->get_var($wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table
            ));
            if ($result !== $table) {
                return false;
            }
        }

        return true;
    }

    public static function drop_tables(): void {
        global $wpdb;

        // Drop in reverse dependency order
        $tables = [
            self::get_reminder_log_table(),
            self::get_archive_access_table(),
            self::get_ballots_table(),
            self::get_votes_table(),
            self::get_protocols_table(),
            self::get_participants_table(),
            self::get_topics_table(),
            self::get_sessions_table(),
        ];

        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
    }
}
