<?php
/**
 * Isidor Consilium - Mail
 *
 * E-Mail-Versand: Einladungen (mit RSVP), Erinnerungen, Protokolle.
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_Mail {

    // =========================================================================
    // EINLADUNG
    // =========================================================================

    public static function send_invitation(int $session_id): array {
        global $wpdb;

        $session = self::get_session($session_id);
        if (!$session) return ['sent' => 0, 'failed' => 0, 'error' => 'Sitzung nicht gefunden.'];

        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d AND status IN ('planned','accepted') ORDER BY sort_order",
            $session_id
        ), ARRAY_A);

        $participants = self::get_participants($session_id);
        if (empty($participants)) return ['sent' => 0, 'failed' => 0, 'error' => 'Keine Teilnehmer.'];

        $has_advance_votes = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d AND timing = 'advance'",
            $session_id
        ));

        // Generate invitation PDF
        $pdf_path = null;
        if (class_exists('Isidor_Consilium_PDF')) {
            $pdf_path = Isidor_Consilium_PDF::generate_invitation($session_id);
        }

        $tops_html = self::build_tops_html($topics);
        $meta = self::build_session_meta($session);
        $app_url = self::get_app_url();
        $vote_url = self::get_vote_url();
        $gremium_label = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
        $subject = 'Einladung: ' . $session['title'] . ' – ' . date_i18n('d.m.Y', strtotime($session['session_date']));

        $sent = 0;
        $failed = 0;

        foreach ($participants as $p) {
            if (empty($p['user_email'])) continue;

            // Generate RSVP token
            $token = Isidor_Consilium_Database::generate_rsvp_token($session_id, (int) $p['user_id']);

            // RSVP URLs
            $rsvp_base = add_query_arg([
                'consilium_rsvp' => 1,
                'token'          => $token,
            ], home_url('/'));

            $rsvp_accept  = add_query_arg('response', 'accepted', $rsvp_base);
            $rsvp_decline = add_query_arg('response', 'declined', $rsvp_base);
            $rsvp_maybe   = add_query_arg('response', 'maybe', $rsvp_base);

            // Topic submission URL
            $submit_url = isidor_app_link('sitzungen') . '&session_id=' . $session_id . '#submit-topic';

            $rsvp_buttons = '
                <div style="margin:20px 0;text-align:center;">
                    <p style="font-weight:600;margin-bottom:12px;">Ihre Rückmeldung:</p>
                    <a href="' . esc_url($rsvp_accept) . '" style="display:inline-block;padding:10px 20px;background:#16a34a;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">✅ Zusage</a>
                    <a href="' . esc_url($rsvp_decline) . '" style="display:inline-block;padding:10px 20px;background:#dc2626;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">❌ Absage</a>
                    <a href="' . esc_url($rsvp_maybe) . '" style="display:inline-block;padding:10px 20px;background:#d97706;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">❓ Vielleicht</a>
                </div>';

            $extra_buttons = '';
            if ($session['topic_deadline'] && $session['topic_deadline'] >= current_time('Y-m-d')) {
                $extra_buttons .= '<a href="' . esc_url($submit_url) . '" style="display:inline-block;padding:10px 20px;background:#7c3aed;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">📝 Thema einreichen</a>';
            }
            if ($has_advance_votes) {
                $vote_app_url = isidor_app_link('sitzungen') . '&session_id=' . $session_id . '#vote';
                $extra_buttons .= '<a href="' . esc_url($vote_app_url) . '" style="display:inline-block;padding:10px 20px;background:#059669;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">🗳️ Zur Abstimmung</a>';
            }

            $deadline_note = '';
            if ($session['topic_deadline']) {
                $deadline_note = '<p style="color:#6b7280;font-size:0.85em;">Themenvorschläge können bis <strong>' . date_i18n('d.m.Y', strtotime($session['topic_deadline'])) . '</strong> eingereicht werden.</p>';
            }

            $body = '
                <h2 style="color:#16a34a;margin:0 0 20px 0;">Einladung zur Sitzung</h2>
                <p>Hallo ' . esc_html($p['display_name'] ?: 'Mitglied') . ',</p>
                <p>Sie werden herzlich zur folgenden Sitzung eingeladen:</p>
                ' . $meta . '
                <h3 style="margin:25px 0 10px 0;">Tagesordnung</h3>
                <ol style="margin:0;padding-left:20px;">' . ($tops_html ?: '<li><em>Noch keine TOPs</em></li>') . '</ol>
                ' . $deadline_note . '
                ' . $rsvp_buttons . '
                ' . ($extra_buttons ? '<p style="text-align:center;margin:15px 0;">' . $extra_buttons . '</p>' : '') . '
                <p style="color:#6b7280;font-size:0.9em;margin-top:25px;">Mit freundlichen Grüßen</p>';

            $html = self::wrap_template($body);
            $attachments = $pdf_path && file_exists($pdf_path) ? [$pdf_path] : [];

            if (self::send_email($p['user_email'], $subject, $html, $attachments)) {
                $sent++;
                // Log invitation
                self::log_send($session_id, (int) $p['user_id'], 'invitation');
            } else {
                $failed++;
            }
        }

        // Update session status and invitation timestamp
        $wpdb->update(
            Isidor_Consilium_Database::get_sessions_table(),
            ['status' => 'invited', 'invitation_sent_at' => current_time('mysql'), 'updated_at' => current_time('mysql')],
            ['id' => $session_id]
        );

        // Clean up temp PDF
        if ($pdf_path && file_exists($pdf_path)) @unlink($pdf_path);

        return ['sent' => $sent, 'failed' => $failed];
    }

    // =========================================================================
    // ERINNERUNG
    // =========================================================================

    public static function send_reminder(int $session_id): array {
        global $wpdb;

        $session = self::get_session($session_id);
        if (!$session) return ['sent' => 0, 'failed' => 0, 'error' => 'Sitzung nicht gefunden.'];

        // Get participants who haven't RSVPed
        $participants = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, u.display_name, u.user_email 
             FROM " . Isidor_Consilium_Database::get_participants_table() . " p 
             LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID 
             WHERE p.session_id = %d AND p.rsvp = 'pending'",
            $session_id
        ), ARRAY_A);

        if (empty($participants)) return ['sent' => 0, 'failed' => 0, 'info' => 'Alle haben geantwortet.'];

        $meta = self::build_session_meta($session);
        $subject = 'Erinnerung: ' . $session['title'] . ' – ' . date_i18n('d.m.Y', strtotime($session['session_date']));
        $sent = 0;
        $failed = 0;

        foreach ($participants as $p) {
            if (empty($p['user_email'])) continue;

            // Check if reminder already sent
            $already_sent = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_reminder_log_table() . " WHERE session_id = %d AND user_id = %d AND type = 'reminder'",
                $session_id, $p['user_id']
            ));
            if ($already_sent) continue;

            $token = $p['rsvp_token'] ?: Isidor_Consilium_Database::generate_rsvp_token($session_id, (int) $p['user_id']);
            $rsvp_base = add_query_arg(['consilium_rsvp' => 1, 'token' => $token], home_url('/'));

            $body = '
                <h2 style="color:#d97706;margin:0 0 20px 0;">⏰ Erinnerung</h2>
                <p>Hallo ' . esc_html($p['display_name'] ?: 'Mitglied') . ',</p>
                <p>wir möchten Sie an die bevorstehende Sitzung erinnern. Bitte geben Sie Ihre Rückmeldung:</p>
                ' . $meta . '
                <div style="margin:20px 0;text-align:center;">
                    <a href="' . esc_url(add_query_arg('response', 'accepted', $rsvp_base)) . '" style="display:inline-block;padding:10px 20px;background:#16a34a;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">✅ Zusage</a>
                    <a href="' . esc_url(add_query_arg('response', 'declined', $rsvp_base)) . '" style="display:inline-block;padding:10px 20px;background:#dc2626;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">❌ Absage</a>
                    <a href="' . esc_url(add_query_arg('response', 'maybe', $rsvp_base)) . '" style="display:inline-block;padding:10px 20px;background:#d97706;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;margin:0 4px;">❓ Vielleicht</a>
                </div>
                <p style="color:#6b7280;font-size:0.9em;">Mit freundlichen Grüßen</p>';

            if (self::send_email($p['user_email'], $subject, self::wrap_template($body))) {
                $sent++;
                self::log_send($session_id, (int) $p['user_id'], 'reminder');
            } else {
                $failed++;
            }
        }

        // Mark reminder as sent on session
        $wpdb->update(
            Isidor_Consilium_Database::get_sessions_table(),
            ['reminder_sent' => 1],
            ['id' => $session_id]
        );

        return ['sent' => $sent, 'failed' => $failed];
    }

    // =========================================================================
    // PROTOKOLL
    // =========================================================================

    public static function send_finalized_protocol(int $session_id, string $pdf_path): array {
        global $wpdb;

        $session = self::get_session($session_id);
        if (!$session) return ['sent' => 0, 'failed' => 0, 'error' => 'Sitzung nicht gefunden.'];

        $participants = self::get_participants($session_id);
        $gremium_label = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
        $date_formatted = date_i18n('d.m.Y', strtotime($session['session_date']));
        $app_url = isidor_app_link('sitzungen');

        $subject = 'Protokoll: ' . $session['title'] . ' – ' . $date_formatted;
        $sent = 0;
        $failed = 0;

        foreach ($participants as $p) {
            if (empty($p['user_email'])) continue;

            $body = '
                <h2 style="color:#059669;margin:0 0 20px 0;">📋 Sitzungsprotokoll</h2>
                <p>Hallo ' . esc_html($p['display_name'] ?: 'Mitglied') . ',</p>
                <p>anbei erhalten Sie das Protokoll der Sitzung des ' . esc_html($gremium_label) . ' vom ' . esc_html($date_formatted) . ' als PDF.</p>
                <p><a href="' . esc_url($app_url . '&session_id=' . $session_id) . '" style="display:inline-block;padding:10px 24px;background:#16a34a;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">📄 Protokoll online ansehen</a></p>
                <p style="color:#6b7280;font-size:0.9em;margin-top:25px;">Mit freundlichen Grüßen</p>';

            $attachments = file_exists($pdf_path) ? [$pdf_path] : [];
            if (self::send_email($p['user_email'], $subject, self::wrap_template($body), $attachments)) {
                $sent++;
                self::log_send($session_id, (int) $p['user_id'], 'protocol');
            } else {
                $failed++;
            }
        }

        return ['sent' => $sent, 'failed' => $failed];
    }

    // =========================================================================
    // WP-CRON: Automatische Erinnerung
    // =========================================================================

    public static function cron_send_reminders(): void {
        global $wpdb;
        $table = Isidor_Consilium_Database::get_sessions_table();

        // Find sessions where: status=invited, reminder_sent=0, session_date within reminder_days
        $sessions = $wpdb->get_results(
            "SELECT * FROM {$table} 
             WHERE status = 'invited' 
             AND reminder_sent = 0 
             AND reminder_days > 0 
             AND session_date >= CURDATE()
             AND DATEDIFF(session_date, CURDATE()) <= reminder_days",
            ARRAY_A
        );

        foreach ($sessions as $s) {
            self::send_reminder((int) $s['id']);
            error_log('[Consilium Cron] Erinnerung gesendet für Sitzung #' . $s['id']);
        }
    }

    // =========================================================================
    // RSVP HANDLER (non-REST, via URL query param)
    // =========================================================================

    public static function handle_rsvp(): void {
        if (empty($_GET['consilium_rsvp']) || empty($_GET['token']) || empty($_GET['response'])) {
            return;
        }

        $token = sanitize_text_field($_GET['token']);
        $response = sanitize_text_field($_GET['response']);

        if (!in_array($response, ['accepted', 'declined', 'maybe'], true)) {
            wp_die('Ungültige Antwort.');
        }

        $participant = Isidor_Consilium_Database::get_participant_by_token($token);
        if (!$participant) {
            wp_die('Ungültiger oder abgelaufener Link.');
        }

        Isidor_Consilium_Database::set_rsvp(
            (int) $participant['session_id'],
            (int) $participant['user_id'],
            $response
        );

        $labels = ['accepted' => 'Zusage', 'declined' => 'Absage', 'maybe' => 'Vielleicht'];
        $emoji = ['accepted' => '✅', 'declined' => '❌', 'maybe' => '❓'];

        $html = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><title>RSVP</title></head>
            <body style="margin:0;padding:40px 20px;background:#f3f4f6;font-family:Arial,sans-serif;text-align:center;">
                <div style="max-width:400px;margin:0 auto;background:#fff;padding:40px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
                    <div style="font-size:3em;margin-bottom:16px;">' . ($emoji[$response] ?? '') . '</div>
                    <h2 style="margin:0 0 8px;">Vielen Dank!</h2>
                    <p style="color:#6b7280;">Ihre Rückmeldung wurde gespeichert: <strong>' . esc_html($labels[$response] ?? $response) . '</strong></p>
                    <p style="margin-top:20px;"><a href="' . esc_url(isidor_app_link('sitzungen')) . '" style="color:#16a34a;">Zur App</a></p>
                </div>
            </body></html>';

        echo $html;
        exit;
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private static function get_session(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d", $id
        ), ARRAY_A);
        return $row ?: null;
    }

    private static function get_participants(int $session_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, u.display_name, u.user_email 
             FROM " . Isidor_Consilium_Database::get_participants_table() . " p 
             LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID 
             WHERE p.session_id = %d",
            $session_id
        ), ARRAY_A);
    }

    private static function build_tops_html(array $topics): string {
        $html = '';
        foreach ($topics as $i => $t) {
            $badge = '';
            if (($t['status'] ?? '') === 'submitted' || ($t['status'] ?? '') === 'accepted') {
                $badge = ' <span style="font-size:0.8em;color:#7c3aed;">(eingereicht)</span>';
            }
            $reporter = '';
            if (!empty($t['reporter_user_id'])) {
                $ru = get_userdata((int) $t['reporter_user_id']);
                if ($ru) $reporter = ' <span style="font-size:0.85em;color:#6b7280;">— ' . esc_html($ru->display_name) . '</span>';
            }
            $html .= '<li style="margin-bottom:4px;">' . esc_html($t['title']) . $badge . $reporter . '</li>';
        }
        return $html;
    }

    private static function build_session_meta(array $session): string {
        $gremium_label = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
        $date_formatted = date_i18n('l, d. F Y', strtotime($session['session_date']));
        $time_str = '';
        if ($session['time_start']) {
            $time_str = date_i18n('H:i', strtotime($session['time_start']));
            if ($session['time_end']) $time_str .= ' – ' . date_i18n('H:i', strtotime($session['time_end']));
            $time_str .= ' Uhr';
        }

        return '
            <table style="width:100%;border-collapse:collapse;margin:20px 0;">
                <tr><td style="padding:8px 12px;background:#f5f3ff;font-weight:600;width:120px;">Gremium</td><td style="padding:8px 12px;background:#f5f3ff;">' . esc_html($gremium_label) . '</td></tr>
                <tr><td style="padding:8px 12px;font-weight:600;">Datum</td><td style="padding:8px 12px;">' . esc_html($date_formatted) . '</td></tr>
                ' . ($time_str ? '<tr><td style="padding:8px 12px;background:#f5f3ff;font-weight:600;">Uhrzeit</td><td style="padding:8px 12px;background:#f5f3ff;">' . esc_html($time_str) . '</td></tr>' : '') . '
                <tr><td style="padding:8px 12px;font-weight:600;">Ort</td><td style="padding:8px 12px;">' . esc_html($session['location'] ?: '—') . '</td></tr>
            </table>';
    }

    private static function log_send(int $session_id, int $user_id, string $type): void {
        global $wpdb;
        $wpdb->replace(Isidor_Consilium_Database::get_reminder_log_table(), [
            'session_id' => $session_id,
            'user_id'    => $user_id,
            'type'       => $type,
            'sent_at'    => current_time('mysql'),
        ]);
    }

    private static function wrap_template(string $content): string {
        $parish_name = class_exists('Isidor_Parish_Settings')
            ? (get_option('isidor_parish_settings', [])['name'] ?? get_bloginfo('name'))
            : get_bloginfo('name');

        return '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;">
            <div style="max-width:600px;margin:0 auto;padding:20px;">
                <div style="background:#16a34a;padding:20px;border-radius:8px 8px 0 0;text-align:center;">
                    <h1 style="margin:0;color:#fff;font-size:1.3em;">🏛️ ' . esc_html($parish_name) . '</h1>
                </div>
                <div style="background:#fff;padding:30px;border-radius:0 0 8px 8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    ' . $content . '
                </div>
                <div style="text-align:center;padding:15px;color:#9ca3af;font-size:0.8em;">
                    Isidor Suite — Consilium
                </div>
            </div>
        </body></html>';
    }

    private static function send_email(string $to, string $subject, string $html, array $attachments = []): bool {
        $from_name = get_bloginfo('name');
        $from_email = get_option('admin_email');

        if (class_exists('Isidor_Parish_Settings')) {
            $settings = get_option('isidor_parish_settings', []);
            if (!empty($settings['email'])) $from_email = $settings['email'];
            if (!empty($settings['name']))  $from_name = $settings['name'];
        }

        return wp_mail($to, $subject, $html, [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ], $attachments);
    }

    public static function get_app_url(): string {
        global $wpdb;
        $page = $wpdb->get_row("SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status='publish' AND post_content LIKE '%[isidor_consilium_app%' LIMIT 1");
        return $page ? get_permalink($page->ID) : home_url('/');
    }

    public static function get_vote_url(): string {
        global $wpdb;
        $page = $wpdb->get_row("SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status='publish' AND post_content LIKE '%[isidor_consilium_vote%' LIMIT 1");
        return $page ? get_permalink($page->ID) : self::get_app_url();
    }
}
