<?php
/**
 * Isidor Consilium - PDF
 *
 * Generiert Einladungs- und Protokoll-PDFs mit Pfarr-Logo.
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_PDF {

    private static function find_fpdf(): ?string {
        $base = defined('ISIDOR_SUITE_PATH') ? ISIDOR_SUITE_PATH : dirname(__DIR__, 2) . '/';
        foreach ([
            $base . 'lib/fpdf/fpdf.php',
            $base . 'lib/fpdf.php',
            ABSPATH . 'wp-content/plugins/fpdf/fpdf.php',
        ] as $p) {
            if (file_exists($p)) return $p;
        }
        return null;
    }

    private static function s(string $t): string {
        if ($t === '') return $t;
        if (function_exists('iconv')) {
            $c = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $t);
            if ($c !== false) return $c;
        }
        return mb_convert_encoding($t, 'ISO-8859-1', 'UTF-8');
    }

    private static function get_parish(): array {
        $settings = get_option('isidor_parish_settings', []);
        return [
            'name'    => $settings['name'] ?? get_bloginfo('name'),
            'address' => $settings['address'] ?? '',
            'phone'   => $settings['phone'] ?? '',
            'email'   => $settings['email'] ?? get_option('admin_email'),
            'logo'    => $settings['logo_path'] ?? '',
        ];
    }

    // =========================================================================
    // EINLADUNG PDF
    // =========================================================================

    /**
     * Generate invitation PDF, returns temp file path or null
     */
    public static function generate_invitation(int $session_id): ?string {
        $fpdf = self::find_fpdf();
        if (!$fpdf) return null;
        require_once $fpdf;

        global $wpdb;
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d", $session_id
        ), ARRAY_A);
        if (!$session) return null;

        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d AND status IN ('planned','accepted') ORDER BY sort_order",
            $session_id
        ), ARRAY_A);

        $parish = self::get_parish();
        $gremium = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);

        try {
            $pdf = new \FPDF('P', 'mm', 'A4');
            $pdf->SetAutoPageBreak(true, 20);
            $pdf->AddPage();

            // ── Header / Logo ──
            self::render_letterhead($pdf, $parish);

            // ── Title ──
            $pdf->Ln(8);
            $pdf->SetFont('Helvetica', 'B', 16);
            $pdf->Cell(0, 10, self::s('Einladung'), 0, 1, 'L');

            $pdf->SetFont('Helvetica', '', 11);
            $pdf->Cell(0, 6, self::s('zur Sitzung des ' . $gremium), 0, 1, 'L');
            $pdf->Ln(6);

            // ── Session details ──
            $pdf->SetFont('Helvetica', 'B', 10);
            $pdf->SetFillColor(245, 243, 255);

            $details = [
                'Datum'   => date_i18n('l, d. F Y', strtotime($session['session_date'])),
                'Uhrzeit' => '',
                'Ort'     => $session['location'] ?: '—',
            ];
            if ($session['time_start']) {
                $t = date_i18n('H:i', strtotime($session['time_start']));
                if ($session['time_end']) $t .= ' - ' . date_i18n('H:i', strtotime($session['time_end']));
                $t .= ' Uhr';
                $details['Uhrzeit'] = $t;
            } else {
                unset($details['Uhrzeit']);
            }

            $fill = true;
            foreach ($details as $label => $value) {
                $pdf->SetFont('Helvetica', 'B', 10);
                $pdf->Cell(35, 7, self::s($label), 0, 0, 'L', $fill);
                $pdf->SetFont('Helvetica', '', 10);
                $pdf->Cell(0, 7, self::s($value), 0, 1, 'L', $fill);
                $fill = !$fill;
            }

            // ── Tagesordnung ──
            $pdf->Ln(8);
            $pdf->SetFont('Helvetica', 'B', 13);
            $pdf->Cell(0, 8, self::s('Tagesordnung'), 0, 1, 'L');
            $pdf->SetDrawColor(200, 200, 200);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(3);

            if (!empty($topics)) {
                foreach ($topics as $i => $top) {
                    $pdf->SetFont('Helvetica', 'B', 10);
                    $nr = ($i + 1) . '.';
                    $pdf->Cell(10, 7, self::s($nr), 0, 0, 'R');
                    $pdf->SetFont('Helvetica', '', 10);
                    $title = $top['title'];
                    if (($top['status'] ?? '') === 'submitted' || ($top['status'] ?? '') === 'accepted') {
                        $title .= '  (eingereicht)';
                    }
                    // Berichterstatter/in
                    $reporter = '';
                    if (!empty($top['reporter_user_id'])) {
                        $ru = get_userdata((int) $top['reporter_user_id']);
                        if ($ru) $reporter = $ru->display_name;
                    }
                    if ($reporter) {
                        $pdf->Cell(130, 7, self::s($title), 0, 0, 'L');
                        $pdf->SetFont('Helvetica', 'I', 9);
                        $pdf->SetTextColor(100, 100, 100);
                        $pdf->Cell(0, 7, self::s($reporter), 0, 1, 'R');
                        $pdf->SetTextColor(0, 0, 0);
                    } else {
                        $pdf->Cell(0, 7, self::s($title), 0, 1, 'L');
                    }

                    if (!empty($top['description'])) {
                        $pdf->SetFont('Helvetica', 'I', 9);
                        $pdf->SetTextColor(100, 100, 100);
                        $pdf->SetX(20);
                        $pdf->MultiCell(0, 5, self::s($top['description']));
                        $pdf->SetTextColor(0, 0, 0);
                        $pdf->Ln(1);
                    }
                }
            } else {
                $pdf->SetFont('Helvetica', 'I', 10);
                $pdf->Cell(0, 7, self::s('Noch keine Tagesordnungspunkte'), 0, 1, 'L');
            }

            // ── RSVP note ──
            $pdf->Ln(8);
            $pdf->SetFont('Helvetica', '', 10);
            $pdf->MultiCell(0, 6, self::s('Bitte geben Sie Ihre Rueckmeldung (Zusage/Absage) per E-Mail oder ueber den Link in der Einladungsmail.'));

            if ($session['topic_deadline']) {
                $pdf->Ln(3);
                $pdf->SetFont('Helvetica', 'I', 9);
                $pdf->Cell(0, 6, self::s('Themenvorschlaege bis: ' . date_i18n('d.m.Y', strtotime($session['topic_deadline']))), 0, 1, 'L');
            }

            // ── Footer ──
            $pdf->Ln(10);
            $pdf->SetFont('Helvetica', '', 9);
            $pdf->SetTextColor(130, 130, 130);
            $pdf->Cell(0, 5, self::s('Erstellt am ' . date_i18n('d.m.Y') . ' | ' . $parish['name']), 0, 1, 'C');
            $pdf->SetTextColor(0, 0, 0);

            // Save to temp file
            $tmp = wp_tempnam('consilium_einladung_');
            $pdf->Output('F', $tmp);
            return $tmp;
        } catch (\Throwable $e) {
            error_log('[Consilium PDF] Invitation error: ' . $e->getMessage());
            return null;
        }
    }

    // =========================================================================
    // PROTOKOLL PDF
    // =========================================================================

    public static function generate_protocol(int $session_id): ?string {
        $fpdf = self::find_fpdf();
        if (!$fpdf) return null;
        require_once $fpdf;

        global $wpdb;
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d", $session_id
        ), ARRAY_A);
        if (!$session) return null;

        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d AND status IN ('planned','accepted') ORDER BY sort_order",
            $session_id
        ), ARRAY_A);

        $protocols = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_protocols_table() . " WHERE session_id = %d",
            $session_id
        ), ARRAY_A);
        $protocol_map = [];
        foreach ($protocols as $p) {
            $protocol_map[$p['topic_id']] = $p['content'];
        }

        $participants = $wpdb->get_results($wpdb->prepare(
            "SELECT p.attended, u.display_name FROM " . Isidor_Consilium_Database::get_participants_table() . " p LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID WHERE p.session_id = %d ORDER BY u.display_name",
            $session_id
        ), ARRAY_A);

        $votes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d AND status = 'closed'",
            $session_id
        ), ARRAY_A);

        $parish = self::get_parish();
        $gremium = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);

        try {
            $pdf = new \FPDF('P', 'mm', 'A4');
            $pdf->SetAutoPageBreak(true, 20);
            $pdf->AddPage();

            self::render_letterhead($pdf, $parish);

            // Title
            $pdf->Ln(8);
            $pdf->SetFont('Helvetica', 'B', 16);
            $pdf->Cell(0, 10, self::s('Protokoll'), 0, 1, 'L');
            $pdf->SetFont('Helvetica', '', 11);
            $pdf->Cell(0, 6, self::s($gremium . ' — ' . date_i18n('d.m.Y', strtotime($session['session_date']))), 0, 1);
            $pdf->Ln(4);

            // Session details
            $pdf->SetFont('Helvetica', 'B', 10);
            $pdf->SetFillColor(245, 243, 255);
            $meta = [
                'Titel'    => $session['title'],
                'Datum'    => date_i18n('l, d. F Y', strtotime($session['session_date'])),
                'Ort'      => $session['location'] ?: '-',
            ];
            if ($session['time_start']) {
                $t = date_i18n('H:i', strtotime($session['time_start']));
                if ($session['time_end']) $t .= ' - ' . date_i18n('H:i', strtotime($session['time_end']));
                $meta['Uhrzeit'] = $t;
            }

            $fill = true;
            foreach ($meta as $k => $v) {
                $pdf->SetFont('Helvetica', 'B', 9);
                $pdf->Cell(30, 6, self::s($k), 0, 0, 'L', $fill);
                $pdf->SetFont('Helvetica', '', 9);
                $pdf->Cell(0, 6, self::s($v), 0, 1, 'L', $fill);
                $fill = !$fill;
            }

            // Attendance
            $pdf->Ln(5);
            $pdf->SetFont('Helvetica', 'B', 11);
            $pdf->Cell(0, 7, self::s('Anwesenheit'), 0, 1);
            $pdf->SetDrawColor(200, 200, 200);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(2);

            $present = [];
            $absent = [];
            foreach ($participants as $pa) {
                if ($pa['attended']) {
                    $present[] = $pa['display_name'];
                } else {
                    $absent[] = $pa['display_name'];
                }
            }

            $pdf->SetFont('Helvetica', '', 9);
            if ($present) {
                $pdf->SetFont('Helvetica', 'B', 9);
                $pdf->Cell(22, 5, self::s('Anwesend:'), 0, 0);
                $pdf->SetFont('Helvetica', '', 9);
                $pdf->MultiCell(0, 5, self::s(implode(', ', $present)));
            }
            if ($absent) {
                $pdf->SetFont('Helvetica', 'B', 9);
                $pdf->Cell(22, 5, self::s('Entschuldigt:'), 0, 0);
                $pdf->SetFont('Helvetica', '', 9);
                $pdf->MultiCell(0, 5, self::s(implode(', ', $absent)));
            }

            // Topics + Protocols
            $pdf->Ln(5);
            $pdf->SetFont('Helvetica', 'B', 11);
            $pdf->Cell(0, 7, self::s('Tagesordnung & Beschluesse'), 0, 1);
            $pdf->SetDrawColor(200, 200, 200);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(3);

            foreach ($topics as $i => $top) {
                $pdf->SetFont('Helvetica', 'B', 10);
                $topLabel = 'TOP ' . ($i + 1) . ': ' . $top['title'];
                $reporter = '';
                if (!empty($top['reporter_user_id'])) {
                    $ru = get_userdata((int) $top['reporter_user_id']);
                    if ($ru) $reporter = $ru->display_name;
                }
                if ($reporter) {
                    $pdf->Cell(140, 7, self::s($topLabel), 0, 0);
                    $pdf->SetFont('Helvetica', 'I', 9);
                    $pdf->SetTextColor(100, 100, 100);
                    $pdf->Cell(0, 7, self::s($reporter), 0, 1, 'R');
                    $pdf->SetTextColor(0, 0, 0);
                } else {
                    $pdf->Cell(0, 7, self::s($topLabel), 0, 1);
                }

                $content = $protocol_map[$top['id']] ?? '';
                if ($content) {
                    $pdf->SetFont('Helvetica', '', 9);
                    // Strip HTML tags from rich text content
                    $plain = strip_tags(html_entity_decode($content));
                    $pdf->MultiCell(0, 5, self::s($plain));
                } else {
                    $pdf->SetFont('Helvetica', 'I', 9);
                    $pdf->SetTextColor(150, 150, 150);
                    $pdf->Cell(0, 5, self::s('Kein Protokoll'), 0, 1);
                    $pdf->SetTextColor(0, 0, 0);
                }

                // Votes for this topic
                foreach ($votes as $v) {
                    if ((int)($v['topic_id'] ?? 0) !== (int) $top['id']) continue;
                    self::render_vote_result($pdf, $v);
                }

                $pdf->Ln(3);
            }

            // Votes without topic
            $orphan_votes = array_filter($votes, fn($v) => empty($v['topic_id']));
            if ($orphan_votes) {
                $pdf->Ln(3);
                $pdf->SetFont('Helvetica', 'B', 11);
                $pdf->Cell(0, 7, self::s('Weitere Abstimmungen'), 0, 1);
                $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
                $pdf->Ln(2);
                foreach ($orphan_votes as $v) {
                    self::render_vote_result($pdf, $v);
                }
            }

            // Footer
            $pdf->Ln(8);
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->SetTextColor(130, 130, 130);
            $pdf->Cell(0, 5, self::s('Protokoll erstellt am ' . date_i18n('d.m.Y H:i') . ' | ' . $parish['name']), 0, 1, 'C');

            $tmp = wp_tempnam('consilium_protokoll_');
            $pdf->Output('F', $tmp);
            return $tmp;
        } catch (\Throwable $e) {
            error_log('[Consilium PDF] Protocol error: ' . $e->getMessage());
            return null;
        }
    }

    // =========================================================================
    // SHARED RENDERING
    // =========================================================================

    private static function render_letterhead(\FPDF $pdf, array $parish): void {
        $x_start = 10;

        // Try to render logo
        $logo_rendered = false;
        if (!empty($parish['logo'])) {
            $logo_path = $parish['logo'];
            // If it's an attachment ID
            if (is_numeric($logo_path)) {
                $logo_path = get_attached_file((int) $logo_path);
            }
            // If it's a URL, convert to path
            if (str_starts_with($logo_path, 'http')) {
                $upload_dir = wp_upload_dir();
                $logo_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $logo_path);
            }
            if ($logo_path && file_exists($logo_path)) {
                try {
                    $pdf->Image($logo_path, 10, 10, 25);
                    $x_start = 40;
                    $logo_rendered = true;
                } catch (\Throwable $e) {
                    // Logo failed, continue without
                }
            }
        }

        // Parish name
        $pdf->SetXY($x_start, 10);
        $pdf->SetFont('Helvetica', 'B', 14);
        $pdf->Cell(0, 8, self::s($parish['name']), 0, 1);

        // Address + contact
        $pdf->SetX($x_start);
        $pdf->SetFont('Helvetica', '', 8);
        $pdf->SetTextColor(100, 100, 100);
        $parts = array_filter([$parish['address'], $parish['phone'], $parish['email']]);
        if ($parts) {
            $pdf->Cell(0, 4, self::s(implode('  |  ', $parts)), 0, 1);
        }
        $pdf->SetTextColor(0, 0, 0);

        // Separator line
        $pdf->Ln(2);
        $pdf->SetDrawColor(16, 163, 10); // Green accent
        $pdf->SetLineWidth(0.5);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->SetLineWidth(0.2);
        $pdf->Ln(2);
    }

    private static function render_vote_result(\FPDF $pdf, array $vote): void {
        global $wpdb;
        $ballots_table = Isidor_Consilium_Database::get_ballots_table();

        $options = json_decode($vote['options'], true) ?: [];
        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$ballots_table} WHERE vote_id = %d", $vote['id']
        ));

        $pdf->SetFont('Helvetica', 'B', 9);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 6, self::s('Abstimmung: ' . $vote['title'] . ' (' . ($vote['mode'] === 'secret' ? 'geheim' : 'offen') . ', ' . $total . ' Stimmen)'), 0, 1, 'L', true);

        foreach ($options as $opt) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$ballots_table} WHERE vote_id = %d AND choice = %s",
                $vote['id'], $opt
            ));
            $pct = $total > 0 ? round(($count / $total) * 100) : 0;

            $pdf->SetFont('Helvetica', '', 9);
            $pdf->Cell(60, 5, self::s('  ' . $opt), 0, 0);
            $pdf->Cell(20, 5, self::s($count . ' (' . $pct . '%)'), 0, 1);
        }
        $pdf->Ln(2);
    }
}
