<?php
/**
 * Isidor Consilium - REST API
 *
 * Alle REST-Endpoints für das Consilium-Modul.
 *
 * @package IsidorSuite
 * @subpackage Consilium
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_REST_API {

    private const API_NAMESPACE = 'isidor/v1';

    // =========================================================================
    // INITIALIZATION
    // =========================================================================

    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function register_routes(): void {
        // Sessions
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_sessions'],  'permission_callback' => [self::class, 'check_view_permission']],
            ['methods' => 'POST', 'callback' => [self::class, 'create_session'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)', [
            ['methods' => 'GET',    'callback' => [self::class, 'get_session'],    'permission_callback' => [self::class, 'check_view_permission']],
            ['methods' => 'PUT',    'callback' => [self::class, 'update_session'], 'permission_callback' => [self::class, 'check_manage_permission']],
            ['methods' => 'DELETE', 'callback' => [self::class, 'delete_session'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        // Topics
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/topics', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_topics'],  'permission_callback' => [self::class, 'check_view_permission']],
            ['methods' => 'POST', 'callback' => [self::class, 'create_topic'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/topics/(?P<id>\d+)', [
            ['methods' => 'PUT',    'callback' => [self::class, 'update_topic'], 'permission_callback' => [self::class, 'check_manage_permission']],
            ['methods' => 'DELETE', 'callback' => [self::class, 'delete_topic'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/topics/reorder', [
            'methods' => 'PUT', 'callback' => [self::class, 'reorder_topics'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Participants
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/participants', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_participants'],  'permission_callback' => [self::class, 'check_view_permission']],
            ['methods' => 'POST', 'callback' => [self::class, 'add_participant'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/participants/(?P<user_id>\d+)', [
            'methods' => 'DELETE', 'callback' => [self::class, 'remove_participant'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/attendance', [
            'methods' => 'PUT', 'callback' => [self::class, 'update_attendance'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Protocols
        register_rest_route(self::API_NAMESPACE, '/consilium/protocols/(?P<topic_id>\d+)', [
            ['methods' => 'GET', 'callback' => [self::class, 'get_protocol'], 'permission_callback' => [self::class, 'check_view_permission']],
            ['methods' => 'PUT', 'callback' => [self::class, 'save_protocol'], 'permission_callback' => [self::class, 'check_manage_permission']],
        ]);

        // Protocol draft/finalize
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/protocol-draft', [
            'methods' => 'POST', 'callback' => [self::class, 'save_protocol_draft'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/protocol-finalize', [
            'methods' => 'POST', 'callback' => [self::class, 'finalize_protocol'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Votes
        register_rest_route(self::API_NAMESPACE, '/consilium/votes', [
            'methods' => 'POST', 'callback' => [self::class, 'create_vote'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/votes/(?P<id>\d+)/start', [
            'methods' => 'PUT', 'callback' => [self::class, 'start_vote'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/votes/(?P<id>\d+)/stop', [
            'methods' => 'PUT', 'callback' => [self::class, 'stop_vote'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/votes/(?P<id>\d+)/results', [
            'methods' => 'GET', 'callback' => [self::class, 'get_vote_results'], 'permission_callback' => [self::class, 'check_view_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/votes/(?P<id>\d+)/cast', [
            'methods' => 'POST', 'callback' => [self::class, 'cast_vote'], 'permission_callback' => [self::class, 'check_vote_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/votes/(?P<id>\d+)/status', [
            'methods' => 'GET', 'callback' => [self::class, 'get_vote_status'], 'permission_callback' => [self::class, 'check_vote_permission'],
        ]);

        // Session actions
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/send-invitations', [
            'methods' => 'POST', 'callback' => [self::class, 'send_invitations'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/complete', [
            'methods' => 'POST', 'callback' => [self::class, 'complete_session'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // User search for participant picker
        register_rest_route(self::API_NAMESPACE, '/consilium/users/search', [
            'methods' => 'GET', 'callback' => [self::class, 'search_users'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Archive access
        register_rest_route(self::API_NAMESPACE, '/consilium/archive-access/(?P<user_id>\d+)', [
            ['methods' => 'GET', 'callback' => [self::class, 'get_archive_access'], 'permission_callback' => [self::class, 'check_admin_permission']],
            ['methods' => 'PUT', 'callback' => [self::class, 'set_archive_access'], 'permission_callback' => [self::class, 'check_admin_permission']],
        ]);

        // RSVP
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/rsvp', [
            'methods' => 'POST', 'callback' => [self::class, 'set_rsvp'], 'permission_callback' => [self::class, 'check_vote_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/rsvp-summary', [
            'methods' => 'GET', 'callback' => [self::class, 'get_rsvp_summary'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Topic submissions
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/submit-topic', [
            'methods' => 'POST', 'callback' => [self::class, 'submit_topic'], 'permission_callback' => [self::class, 'check_vote_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/topics/(?P<id>\d+)/accept', [
            'methods' => 'PUT', 'callback' => [self::class, 'accept_topic'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/topics/(?P<id>\d+)/reject', [
            'methods' => 'PUT', 'callback' => [self::class, 'reject_topic'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Live Dashboard
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/live-state', [
            'methods' => 'GET', 'callback' => [self::class, 'get_live_state'], 'permission_callback' => [self::class, 'check_view_permission'],
        ]);

        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/start', [
            'methods' => 'POST', 'callback' => [self::class, 'start_session'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Send reminder
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/send-reminder', [
            'methods' => 'POST', 'callback' => [self::class, 'send_reminder'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Send protocol
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/send-protocol', [
            'methods' => 'POST', 'callback' => [self::class, 'send_protocol_mail'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);

        // Invitation PDF (generate/download)
        register_rest_route(self::API_NAMESPACE, '/consilium/sessions/(?P<id>\d+)/invitation-pdf', [
            'methods' => 'GET', 'callback' => [self::class, 'get_invitation_pdf'], 'permission_callback' => [self::class, 'check_manage_permission'],
        ]);
    }

    // =========================================================================
    // PERMISSION CALLBACKS
    // =========================================================================

    public static function check_view_permission(): bool {
        return current_user_can('isidor_consilium_view');
    }

    public static function check_manage_permission(): bool {
        return current_user_can('isidor_consilium_manage');
    }

    public static function check_vote_permission(): bool {
        return current_user_can('isidor_consilium_vote');
    }

    public static function check_admin_permission(): bool {
        return current_user_can('isidor_consilium_admin');
    }

    // =========================================================================
    // SESSIONS
    // =========================================================================

    public static function get_sessions(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $table = Isidor_Consilium_Database::get_sessions_table();

        $where = ['1=1'];
        $params = [];

        $gremium = $request->get_param('gremium');
        if ($gremium && in_array($gremium, Isidor_Consilium_Database::get_valid_gremiums(), true)) {
            $where[] = 'gremium = %s';
            $params[] = $gremium;
        }

        $status = $request->get_param('status');
        if ($status && in_array($status, Isidor_Consilium_Database::get_valid_statuses(), true)) {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        // Archive access check for non-admin users viewing archived sessions
        if ($status === 'archived' && !current_user_can('isidor_consilium_admin')) {
            $user_id = get_current_user_id();
            $accessible = Isidor_Consilium_Database::get_user_archive_access($user_id);
            if (empty($accessible)) {
                return new \WP_REST_Response(['success' => true, 'data' => [], 'total' => 0]);
            }
            $placeholders = implode(',', array_fill(0, count($accessible), '%s'));
            $where[] = "gremium IN ({$placeholders})";
            $params = array_merge($params, $accessible);
        }

        $year = intval($request->get_param('year'));
        if ($year > 0) {
            $where[] = 'YEAR(session_date) = %d';
            $params[] = $year;
        }

        $where_sql = implode(' AND ', $where);
        $limit = min(intval($request->get_param('limit') ?: 50), 200);
        $offset = max(intval($request->get_param('offset') ?: 0), 0);

        $query = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY session_date DESC, time_start DESC LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;

        $sessions = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

        // Enrich with participant count and labels
        $participants_table = Isidor_Consilium_Database::get_participants_table();
        foreach ($sessions as &$session) {
            $session['participant_count'] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$participants_table} WHERE session_id = %d",
                $session['id']
            ));
            $session['gremium_label'] = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
            $session['gremium_short'] = Isidor_Consilium_Database::get_gremium_short_label($session['gremium']);
            $session['status_label'] = Isidor_Consilium_Database::get_status_label($session['status']);
            $session['protocol_status_label'] = Isidor_Consilium_Database::get_protocol_status_label($session['protocol_status'] ?? 'none');
        }

        $count_params = array_slice($params, 0, -2);
        if (!empty($count_params)) {
            $total = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}",
                $count_params
            ));
        } else {
            $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$where_sql}");
        }

        return new \WP_REST_Response([
            'success' => true,
            'data'    => $sessions,
            'total'   => $total,
        ]);
    }

    public static function create_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;

        $title = sanitize_text_field($request->get_param('title'));
        $gremium = sanitize_text_field($request->get_param('gremium'));
        $session_date = sanitize_text_field($request->get_param('session_date'));

        if (empty($title) || empty($gremium) || empty($session_date)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Titel, Gremium und Datum sind Pflichtfelder.'], 400);
        }

        if (!in_array($gremium, Isidor_Consilium_Database::get_valid_gremiums(), true)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiges Gremium.'], 400);
        }

        $custom_label = null;
        if ($gremium === 'sonstige') {
            $custom_label = sanitize_text_field($request->get_param('custom_gremium_label')) ?: null;
        }

        $wpdb->insert(
            Isidor_Consilium_Database::get_sessions_table(),
            [
                'title'                => $title,
                'gremium'              => $gremium,
                'custom_gremium_label' => $custom_label,
                'session_date'         => $session_date,
                'time_start'           => sanitize_text_field($request->get_param('time_start')) ?: null,
                'time_end'             => sanitize_text_field($request->get_param('time_end')) ?: null,
                'location'             => sanitize_text_field($request->get_param('location')) ?: null,
                'topic_deadline'       => sanitize_text_field($request->get_param('topic_deadline')) ?: null,
                'reminder_days'        => intval($request->get_param('reminder_days') ?? 3),
                'status'               => 'draft',
                'protocol_status'      => 'none',
                'created_by'           => get_current_user_id(),
                'created_at'           => current_time('mysql'),
                'updated_at'           => current_time('mysql'),
            ]
        );

        $id = $wpdb->insert_id;
        if (!$id) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Fehler beim Erstellen.'], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => ['id' => $id]], 201);
    }

    public static function get_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));

        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        $session['gremium_label'] = Isidor_Consilium_Database::get_gremium_label($session['gremium'], $session['custom_gremium_label'] ?? null);
        $session['gremium_short'] = Isidor_Consilium_Database::get_gremium_short_label($session['gremium']);
        $session['status_label'] = Isidor_Consilium_Database::get_status_label($session['status']);
        $session['protocol_status_label'] = Isidor_Consilium_Database::get_protocol_status_label($session['protocol_status'] ?? 'none');

        // Load topics with reporter name
        $topics_raw = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d ORDER BY sort_order ASC",
            $id
        ), ARRAY_A);
        $session['topics'] = [];
        foreach ($topics_raw as $t) {
            $t['reporter_name'] = '';
            if (!empty($t['reporter_user_id'])) {
                $ru = get_userdata((int) $t['reporter_user_id']);
                $t['reporter_name'] = $ru ? $ru->display_name : '';
            }
            $session['topics'][] = $t;
        }

        // Load participants with user data
        $participants_raw = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d",
            $id
        ), ARRAY_A);

        $session['participants'] = [];
        foreach ($participants_raw as $p) {
            $user = get_userdata($p['user_id']);
            if ($user) {
                $session['participants'][] = [
                    'id'         => $p['id'],
                    'user_id'    => (int) $p['user_id'],
                    'name'       => $user->display_name,
                    'email'      => $user->user_email,
                    'invited_at' => $p['invited_at'],
                    'attended'   => (bool) $p['attended'],
                    'rsvp'       => $p['rsvp'] ?? 'pending',
                    'rsvp_at'    => $p['rsvp_at'] ?? null,
                ];
            }
        }

        // RSVP summary
        $session['rsvp_summary'] = Isidor_Consilium_Database::get_rsvp_summary($id);

        // Load votes for this session
        $session['votes'] = $wpdb->get_results($wpdb->prepare(
            "SELECT id, session_id, topic_id, title, mode, status, created_at, closed_at FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d ORDER BY created_at ASC",
            $id
        ), ARRAY_A);

        return new \WP_REST_Response(['success' => true, 'data' => $session]);
    }

    public static function update_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_sessions_table();

        $session = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        if ($session['status'] === 'archived') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Archivierte Sitzungen können nicht bearbeitet werden.'], 403);
        }

        $data = [];
        $format = [];

        $fields = [
            'title'                => '%s',
            'gremium'              => '%s',
            'custom_gremium_label' => '%s',
            'session_date'         => '%s',
            'time_start'           => '%s',
            'time_end'             => '%s',
            'location'             => '%s',
            'topic_deadline'       => '%s',
            'reminder_days'        => '%d',
            'status'               => '%s',
        ];

        foreach ($fields as $field => $fmt) {
            $value = $request->get_param($field);
            if ($value !== null) {
                if ($field === 'gremium' && !in_array($value, Isidor_Consilium_Database::get_valid_gremiums(), true)) {
                    return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiges Gremium.'], 400);
                }
                if ($field === 'status' && !in_array($value, Isidor_Consilium_Database::get_valid_statuses(), true)) {
                    return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiger Status.'], 400);
                }
                $data[$field] = sanitize_text_field($value);
                $format[] = $fmt;
            }
        }

        if (empty($data)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Keine Daten zum Aktualisieren.'], 400);
        }

        $data['updated_at'] = current_time('mysql');
        $format[] = '%s';

        $wpdb->update($table, $data, ['id' => $id], $format, ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Sitzung aktualisiert.']);
    }

    public static function delete_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_sessions_table();

        $session = $wpdb->get_row($wpdb->prepare("SELECT status FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        if ($session['status'] !== 'draft') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Nur Entwürfe können gelöscht werden.'], 403);
        }

        // Cascade delete
        $vote_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d",
            $id
        ));
        if (!empty($vote_ids)) {
            $placeholders = implode(',', array_fill(0, count($vote_ids), '%d'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM " . Isidor_Consilium_Database::get_ballots_table() . " WHERE vote_id IN ({$placeholders})",
                $vote_ids
            ));
        }

        $wpdb->delete(Isidor_Consilium_Database::get_votes_table(), ['session_id' => $id], ['%d']);
        $wpdb->delete(Isidor_Consilium_Database::get_protocols_table(), ['session_id' => $id], ['%d']);
        $wpdb->delete(Isidor_Consilium_Database::get_participants_table(), ['session_id' => $id], ['%d']);
        $wpdb->delete(Isidor_Consilium_Database::get_topics_table(), ['session_id' => $id], ['%d']);
        $wpdb->delete($table, ['id' => $id], ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Sitzung gelöscht.']);
    }

    // =========================================================================
    // TOPICS
    // =========================================================================

    public static function get_topics(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));

        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d ORDER BY sort_order ASC",
            $session_id
        ), ARRAY_A);

        return new \WP_REST_Response(['success' => true, 'data' => $topics]);
    }

    public static function create_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_topics_table();

        $title = sanitize_text_field($request->get_param('title'));
        if (empty($title)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Titel ist ein Pflichtfeld.'], 400);
        }

        $max_order = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(sort_order) FROM {$table} WHERE session_id = %d",
            $session_id
        ));

        $wpdb->insert($table, [
            'session_id'       => $session_id,
            'sort_order'       => $max_order + 1,
            'title'            => $title,
            'description'      => sanitize_textarea_field($request->get_param('description') ?: ''),
            'reporter_user_id' => intval($request->get_param('reporter_user_id')) ?: null,
            'created_at'       => current_time('mysql'),
        ]);

        $id = $wpdb->insert_id;
        if (!$id) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Fehler beim Erstellen.'], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => ['id' => $id, 'sort_order' => $max_order + 1]], 201);
    }

    public static function update_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_topics_table();

        $data = [];
        $format = [];

        $title = $request->get_param('title');
        if ($title !== null) {
            $data['title'] = sanitize_text_field($title);
            $format[] = '%s';
        }

        $description = $request->get_param('description');
        if ($description !== null) {
            $data['description'] = sanitize_textarea_field($description);
            $format[] = '%s';
        }

        $reporter = $request->get_param('reporter_user_id');
        if ($reporter !== null) {
            $data['reporter_user_id'] = intval($reporter) ?: null;
            $format[] = '%d';
        }

        if (empty($data)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Keine Daten.'], 400);
        }

        $wpdb->update($table, $data, ['id' => $id], $format, ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'TOP aktualisiert.']);
    }

    public static function delete_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));

        $wpdb->delete(Isidor_Consilium_Database::get_protocols_table(), ['topic_id' => $id], ['%d']);

        $vote_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE topic_id = %d",
            $id
        ));
        if (!empty($vote_ids)) {
            $placeholders = implode(',', array_fill(0, count($vote_ids), '%d'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM " . Isidor_Consilium_Database::get_ballots_table() . " WHERE vote_id IN ({$placeholders})",
                $vote_ids
            ));
        }
        $wpdb->delete(Isidor_Consilium_Database::get_votes_table(), ['topic_id' => $id], ['%d']);
        $wpdb->delete(Isidor_Consilium_Database::get_topics_table(), ['id' => $id], ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'TOP gelöscht.']);
    }

    public static function reorder_topics(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $order = $request->get_param('order');
        $table = Isidor_Consilium_Database::get_topics_table();

        if (!is_array($order)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'order muss ein Array sein.'], 400);
        }

        foreach ($order as $index => $topic_id) {
            $wpdb->update($table, ['sort_order' => $index], ['id' => intval($topic_id)], ['%d'], ['%d']);
        }

        return new \WP_REST_Response(['success' => true, 'message' => 'Reihenfolge aktualisiert.']);
    }

    // =========================================================================
    // PARTICIPANTS
    // =========================================================================

    public static function get_participants(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d",
            $session_id
        ), ARRAY_A);

        $participants = [];
        foreach ($rows as $row) {
            $user = get_userdata($row['user_id']);
            if ($user) {
                $participants[] = [
                    'id'         => $row['id'],
                    'user_id'    => (int) $row['user_id'],
                    'name'       => $user->display_name,
                    'email'      => $user->user_email,
                    'invited_at' => $row['invited_at'],
                    'attended'   => (bool) $row['attended'],
                ];
            }
        }

        return new \WP_REST_Response(['success' => true, 'data' => $participants]);
    }

    public static function add_participant(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));
        $user_id = intval($request->get_param('user_id'));

        if (!$user_id || !get_userdata($user_id)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiger Benutzer.'], 400);
        }

        $result = $wpdb->insert(
            Isidor_Consilium_Database::get_participants_table(),
            [
                'session_id' => $session_id,
                'user_id'    => $user_id,
                'invited_at' => current_time('mysql'),
                'attended'   => 0,
            ],
            ['%d', '%d', '%s', '%d']
        );

        if ($result === false) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Teilnehmer existiert bereits oder Fehler.'], 409);
        }

        return new \WP_REST_Response(['success' => true, 'data' => ['id' => $wpdb->insert_id]], 201);
    }

    public static function remove_participant(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));
        $user_id = intval($request->get_param('user_id'));

        $wpdb->delete(
            Isidor_Consilium_Database::get_participants_table(),
            ['session_id' => $session_id, 'user_id' => $user_id],
            ['%d', '%d']
        );

        return new \WP_REST_Response(['success' => true, 'message' => 'Teilnehmer entfernt.']);
    }

    public static function update_attendance(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = intval($request->get_param('id'));
        $attendance = $request->get_param('attendance');

        if (!is_array($attendance)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'attendance muss ein Array sein.'], 400);
        }

        $table = Isidor_Consilium_Database::get_participants_table();
        foreach ($attendance as $user_id => $attended) {
            $wpdb->update(
                $table,
                ['attended' => $attended ? 1 : 0],
                ['session_id' => $session_id, 'user_id' => intval($user_id)],
                ['%d'],
                ['%d', '%d']
            );
        }

        return new \WP_REST_Response(['success' => true, 'message' => 'Anwesenheit aktualisiert.']);
    }

    // =========================================================================
    // PROTOCOLS
    // =========================================================================

    public static function get_protocol(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $topic_id = intval($request->get_param('topic_id'));

        $protocol = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_protocols_table() . " WHERE topic_id = %d",
            $topic_id
        ), ARRAY_A);

        return new \WP_REST_Response([
            'success' => true,
            'data'    => $protocol ?: ['topic_id' => $topic_id, 'content' => '', 'updated_by' => null, 'updated_at' => null],
        ]);
    }

    public static function save_protocol(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $topic_id = intval($request->get_param('topic_id'));
        $content = wp_kses_post($request->get_param('content') ?: '');

        $topic = $wpdb->get_row($wpdb->prepare(
            "SELECT session_id FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE id = %d",
            $topic_id
        ), ARRAY_A);

        if (!$topic) {
            return new \WP_REST_Response(['success' => false, 'message' => 'TOP nicht gefunden.'], 404);
        }

        // Check if protocol is already finalized
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT protocol_status FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $topic['session_id']
        ), ARRAY_A);

        if ($session && $session['protocol_status'] === 'finalized') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Protokoll ist bereits endgültig abgelegt.'], 403);
        }

        $table = Isidor_Consilium_Database::get_protocols_table();

        $wpdb->replace($table, [
            'session_id' => $topic['session_id'],
            'topic_id'   => $topic_id,
            'content'    => $content,
            'updated_by' => get_current_user_id(),
            'updated_at' => current_time('mysql'),
        ], ['%d', '%d', '%s', '%d', '%s']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Protokoll gespeichert.']);
    }

    /**
     * Protokoll zwischenspeichern (halb bearbeitet)
     */
    public static function save_protocol_draft(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_sessions_table();

        $session = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        if (($session['protocol_status'] ?? 'none') === 'finalized') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Protokoll ist bereits endgültig abgelegt.'], 403);
        }

        $wpdb->update($table, [
            'protocol_status' => 'draft',
            'updated_at'      => current_time('mysql'),
        ], ['id' => $id], ['%s', '%s'], ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Protokoll zwischengespeichert.']);
    }

    /**
     * Protokoll endgültig ablegen und versenden
     */
    public static function finalize_protocol(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_sessions_table();

        $session = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        if (($session['protocol_status'] ?? 'none') === 'finalized') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Protokoll ist bereits endgültig abgelegt.'], 403);
        }

        // Update protocol_status to finalized
        $wpdb->update($table, [
            'protocol_status' => 'finalized',
            'status'          => 'archived',
            'updated_at'      => current_time('mysql'),
        ], ['id' => $id], ['%s', '%s', '%s'], ['%d']);

        // Generate PDF
        $pdf_path = Isidor_Consilium_PDF::generate($id, true);

        // Send finalization email with PDF
        $mail_result = ['sent' => 0, 'failed' => 0];
        if ($pdf_path && file_exists($pdf_path)) {
            $mail_result = Isidor_Consilium_Mail::send_finalized_protocol($id, $pdf_path);
            @unlink($pdf_path);
        }

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Protokoll endgültig abgelegt und versendet.',
            'data'    => [
                'pdf_generated' => !empty($pdf_path),
                'emails'        => $mail_result,
            ],
        ]);
    }

    // =========================================================================
    // VOTES
    // =========================================================================

    public static function create_vote(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;

        $session_id = intval($request->get_param('session_id'));
        $topic_id = intval($request->get_param('topic_id')) ?: null;
        $title = sanitize_text_field($request->get_param('title'));
        $mode = sanitize_text_field($request->get_param('mode') ?: 'open');
        $timing = sanitize_text_field($request->get_param('timing') ?: 'live');
        $options = $request->get_param('options');

        if (empty($title)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Titel ist Pflicht.'], 400);
        }

        if (!in_array($mode, Isidor_Consilium_Database::get_valid_vote_modes(), true)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiger Modus.'], 400);
        }

        if (!in_array($timing, ['advance', 'live'], true)) {
            $timing = 'live';
        }

        if (empty($options) || !is_array($options)) {
            $options = ['Ja', 'Nein', 'Enthaltung'];
        } else {
            $options = array_map('sanitize_text_field', $options);
        }

        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT status FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $session_id
        ), ARRAY_A);

        // Allow creating advance votes on draft/invited sessions, live votes only on active
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }
        if ($timing === 'live' && $session['status'] !== 'active') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Live-Abstimmungen nur bei aktiver Sitzung.'], 400);
        }

        $wpdb->insert(Isidor_Consilium_Database::get_votes_table(), [
            'session_id' => $session_id,
            'topic_id'   => $topic_id,
            'title'      => $title,
            'mode'       => $mode,
            'timing'     => $timing,
            'options'    => wp_json_encode($options),
            'status'     => $timing === 'advance' ? 'active' : 'pending',
            'created_at' => current_time('mysql'),
        ]);

        $id = $wpdb->insert_id;
        if (!$id) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Fehler beim Erstellen.'], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => ['id' => $id]], 201);
    }

    public static function start_vote(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_votes_table();

        $vote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$vote) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Abstimmung nicht gefunden.'], 404);
        }

        if ($vote['status'] !== 'pending') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Abstimmung kann nur aus dem Status "pending" gestartet werden.'], 400);
        }

        $active = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE session_id = %d AND status = 'active'",
            $vote['session_id']
        ));

        if ($active > 0) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Es läuft bereits eine Abstimmung in dieser Sitzung.'], 409);
        }

        $wpdb->update($table, ['status' => 'active'], ['id' => $id], ['%s'], ['%d']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Abstimmung gestartet.']);
    }

    public static function stop_vote(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_votes_table();

        $vote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$vote || $vote['status'] !== 'active') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Abstimmung nicht aktiv.'], 400);
        }

        $wpdb->update($table, [
            'status'    => 'closed',
            'closed_at' => current_time('mysql'),
        ], ['id' => $id], ['%s', '%s'], ['%d']);

        $results = self::build_vote_results($id, $vote);

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Abstimmung beendet.',
            'data'    => $results,
        ]);
    }

    public static function get_vote_results(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_votes_table();

        $vote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$vote) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Abstimmung nicht gefunden.'], 404);
        }

        if ($vote['status'] !== 'closed' && $vote['mode'] !== 'open') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ergebnisse noch nicht verfügbar.'], 403);
        }

        $results = self::build_vote_results($id, $vote);

        return new \WP_REST_Response(['success' => true, 'data' => $results]);
    }

    public static function cast_vote(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $choice = sanitize_text_field($request->get_param('choice'));
        $user_id = get_current_user_id();

        $vote = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$vote || $vote['status'] !== 'active') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Abstimmung ist nicht aktiv.'], 400);
        }

        $is_participant = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d AND user_id = %d",
            $vote['session_id'],
            $user_id
        ));

        if (!$is_participant) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sie sind kein Teilnehmer dieser Sitzung.'], 403);
        }

        $options = json_decode($vote['options'], true) ?: [];
        if (!in_array($choice, $options, true)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ungültige Auswahl.'], 400);
        }

        $result = $wpdb->insert(
            Isidor_Consilium_Database::get_ballots_table(),
            [
                'vote_id'  => $id,
                'user_id'  => $user_id,
                'choice'   => $choice,
                'voted_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s']
        );

        if ($result === false) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sie haben bereits abgestimmt.'], 409);
        }

        return new \WP_REST_Response(['success' => true, 'message' => 'Stimme abgegeben.']);
    }

    public static function get_vote_status(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));

        $vote = $wpdb->get_row($wpdb->prepare(
            "SELECT id, session_id, status, mode FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$vote) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Nicht gefunden.'], 404);
        }

        $total_eligible = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d",
            $vote['session_id']
        ));

        $votes_cast = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_ballots_table() . " WHERE vote_id = %d",
            $id
        ));

        $user_voted = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_ballots_table() . " WHERE vote_id = %d AND user_id = %d",
            $id,
            get_current_user_id()
        ));

        return new \WP_REST_Response([
            'success' => true,
            'data'    => [
                'status'         => $vote['status'],
                'mode'           => $vote['mode'],
                'total_eligible' => $total_eligible,
                'votes_cast'     => $votes_cast,
                'user_voted'     => $user_voted,
            ],
        ]);
    }

    // =========================================================================
    // SESSION ACTIONS
    // =========================================================================

    public static function send_invitations(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));

        // Check minimum 1 TOP exists
        $topic_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d AND status IN ('planned','accepted')",
            $id
        ));
        if ($topic_count < 1) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Mindestens ein Tagesordnungspunkt (TOP) ist erforderlich, bevor Einladungen versendet werden können.',
            ], 400);
        }

        $result = Isidor_Consilium_Mail::send_invitation($id);

        return new \WP_REST_Response([
            'success' => $result['sent'] > 0,
            'data'    => $result,
        ]);
    }

    public static function complete_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $table = Isidor_Consilium_Database::get_sessions_table();

        $session = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden.'], 404);
        }

        if ($session['status'] !== 'active') {
            return new \WP_REST_Response(['success' => false, 'message' => 'Nur aktive Sitzungen können abgeschlossen werden.'], 400);
        }

        // Update status to completed, protocol to draft (can still be edited)
        $wpdb->update($table, [
            'status'          => 'completed',
            'protocol_status' => 'draft',
            'updated_at'      => current_time('mysql'),
        ], ['id' => $id], ['%s', '%s', '%s'], ['%d']);

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Sitzung abgeschlossen. Protokoll kann jetzt weiter bearbeitet, zwischengespeichert oder endgültig abgelegt werden.',
        ]);
    }

    // =========================================================================
    // ARCHIVE ACCESS
    // =========================================================================

    public static function get_archive_access(\WP_REST_Request $request): \WP_REST_Response {
        $user_id = intval($request->get_param('user_id'));
        $access = Isidor_Consilium_Database::get_user_archive_access($user_id);

        return new \WP_REST_Response(['success' => true, 'data' => $access]);
    }

    public static function set_archive_access(\WP_REST_Request $request): \WP_REST_Response {
        $user_id = intval($request->get_param('user_id'));
        $gremiums = $request->get_param('gremiums');

        if (!is_array($gremiums)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'gremiums muss ein Array sein.'], 400);
        }

        Isidor_Consilium_Database::set_user_archive_access($user_id, $gremiums, get_current_user_id());

        return new \WP_REST_Response(['success' => true, 'message' => 'Archivzugriff aktualisiert.']);
    }

    // =========================================================================
    // USER SEARCH
    // =========================================================================

    public static function search_users(\WP_REST_Request $request): \WP_REST_Response {
        $search = sanitize_text_field($request->get_param('search') ?: '');

        $args = [
            'number'  => 20,
            'orderby' => 'display_name',
            'order'   => 'ASC',
        ];

        if (!empty($search)) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = ['display_name', 'user_email', 'user_login'];
        }

        $user_query = new \WP_User_Query($args);
        $users = [];

        foreach ($user_query->get_results() as $user) {
            $users[] = [
                'id'    => $user->ID,
                'name'  => $user->display_name,
                'email' => $user->user_email,
            ];
        }

        return new \WP_REST_Response(['success' => true, 'data' => $users]);
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private static function build_vote_results(int $vote_id, array $vote): array {
        global $wpdb;
        $ballots_table = Isidor_Consilium_Database::get_ballots_table();

        $options = json_decode($vote['options'], true) ?: [];
        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$ballots_table} WHERE vote_id = %d",
            $vote_id
        ));

        $results = [];
        foreach ($options as $option) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$ballots_table} WHERE vote_id = %d AND choice = %s",
                $vote_id,
                $option
            ));
            $results[] = [
                'option'  => $option,
                'count'   => $count,
                'percent' => $total > 0 ? round(($count / $total) * 100, 1) : 0,
            ];
        }

        $data = [
            'vote_id' => $vote_id,
            'title'   => $vote['title'],
            'mode'    => $vote['mode'],
            'total'   => $total,
            'results' => $results,
        ];

        if ($vote['mode'] === 'open') {
            $ballots = $wpdb->get_results($wpdb->prepare(
                "SELECT user_id, choice, voted_at FROM {$ballots_table} WHERE vote_id = %d ORDER BY voted_at ASC",
                $vote_id
            ), ARRAY_A);

            $individual = [];
            foreach ($ballots as $ballot) {
                $user = get_userdata($ballot['user_id']);
                $individual[] = [
                    'user_id'  => (int) $ballot['user_id'],
                    'name'     => $user ? $user->display_name : 'Unbekannt',
                    'choice'   => $ballot['choice'],
                    'voted_at' => $ballot['voted_at'],
                ];
            }
            $data['individual'] = $individual;
        }

        $html = '<div class="consilium-vote-result">';
        $html .= '<h4>Abstimmung: ' . esc_html($vote['title']) . '</h4>';
        $html .= '<p><em>' . ($vote['mode'] === 'secret' ? 'Geheime Abstimmung' : 'Offene Abstimmung') . ' — ' . $total . ' Stimmen</em></p>';
        $html .= '<table><thead><tr><th>Option</th><th>Stimmen</th><th>%</th></tr></thead><tbody>';
        foreach ($results as $r) {
            $html .= '<tr><td>' . esc_html($r['option']) . '</td><td>' . $r['count'] . '</td><td>' . $r['percent'] . '%</td></tr>';
        }
        $html .= '</tbody></table></div>';
        $data['protocol_html'] = $html;

        return $data;
    }

    // =========================================================================
    // RSVP
    // =========================================================================

    public static function set_rsvp(\WP_REST_Request $request): \WP_REST_Response {
        $session_id = (int) $request['id'];
        $user_id = get_current_user_id();
        $rsvp = sanitize_text_field($request->get_param('rsvp'));

        if (!in_array($rsvp, Isidor_Consilium_Database::get_valid_rsvp_statuses(), true)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Ungültiger RSVP-Status'], 400);
        }

        // Check user is participant
        global $wpdb;
        $is_participant = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d AND user_id = %d",
            $session_id, $user_id
        ));

        if (!$is_participant) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sie sind kein Teilnehmer dieser Sitzung'], 403);
        }

        Isidor_Consilium_Database::set_rsvp($session_id, $user_id, $rsvp);
        return new \WP_REST_Response(['success' => true, 'rsvp' => $rsvp, 'label' => Isidor_Consilium_Database::get_rsvp_label($rsvp)]);
    }

    public static function get_rsvp_summary(\WP_REST_Request $request): \WP_REST_Response {
        $session_id = (int) $request['id'];
        $summary = Isidor_Consilium_Database::get_rsvp_summary($session_id);

        // Also get individual RSVP statuses
        global $wpdb;
        $participants = $wpdb->get_results($wpdb->prepare(
            "SELECT p.user_id, p.rsvp, p.rsvp_at, u.display_name 
             FROM " . Isidor_Consilium_Database::get_participants_table() . " p
             LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
             WHERE p.session_id = %d ORDER BY u.display_name",
            $session_id
        ), ARRAY_A);

        return new \WP_REST_Response(['success' => true, 'summary' => $summary, 'participants' => $participants]);
    }

    // =========================================================================
    // TOPIC SUBMISSIONS
    // =========================================================================

    public static function submit_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = (int) $request['id'];
        $user_id = get_current_user_id();
        $title = sanitize_text_field($request->get_param('title'));
        $description = sanitize_textarea_field($request->get_param('description') ?: '');

        if (empty($title)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Titel erforderlich'], 400);
        }

        // Check user is participant
        $is_participant = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_participants_table() . " WHERE session_id = %d AND user_id = %d",
            $session_id, $user_id
        ));
        if (!$is_participant) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Nur Teilnehmer können Themen einreichen'], 403);
        }

        // Check deadline
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT topic_deadline FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $session_id
        ), ARRAY_A);

        if ($session && $session['topic_deadline'] && $session['topic_deadline'] < current_time('Y-m-d')) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Die Frist für Themenvorschläge ist abgelaufen'], 400);
        }

        // Get max sort_order
        $max_order = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(sort_order) FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d",
            $session_id
        ));

        $wpdb->insert(Isidor_Consilium_Database::get_topics_table(), [
            'session_id'   => $session_id,
            'sort_order'   => $max_order + 1,
            'title'        => $title,
            'description'  => $description,
            'status'       => 'submitted',
            'submitted_by' => $user_id,
            'submitted_at' => current_time('mysql'),
        ]);

        return new \WP_REST_Response(['success' => true, 'id' => $wpdb->insert_id, 'message' => 'Thema eingereicht']);
    }

    public static function accept_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $topic_id = (int) $request['id'];
        $wpdb->update(
            Isidor_Consilium_Database::get_topics_table(),
            ['status' => 'accepted'],
            ['id' => $topic_id],
            ['%s'], ['%d']
        );
        return new \WP_REST_Response(['success' => true]);
    }

    public static function reject_topic(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $topic_id = (int) $request['id'];
        $wpdb->update(
            Isidor_Consilium_Database::get_topics_table(),
            ['status' => 'rejected'],
            ['id' => $topic_id],
            ['%s'], ['%d']
        );
        return new \WP_REST_Response(['success' => true]);
    }

    // =========================================================================
    // LIVE SESSION
    // =========================================================================

    public static function start_session(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = (int) $request['id'];

        $wpdb->update(
            Isidor_Consilium_Database::get_sessions_table(),
            ['status' => 'active', 'updated_at' => current_time('mysql')],
            ['id' => $session_id],
            ['%s', '%s'], ['%d']
        );

        // Pre-set attendance from accepted RSVPs
        $wpdb->query($wpdb->prepare(
            "UPDATE " . Isidor_Consilium_Database::get_participants_table() . " SET attended = 1 WHERE session_id = %d AND rsvp = 'accepted'",
            $session_id
        ));

        return new \WP_REST_Response(['success' => true]);
    }

    public static function get_live_state(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $session_id = (int) $request['id'];

        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_sessions_table() . " WHERE id = %d",
            $session_id
        ), ARRAY_A);

        if (!$session) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Sitzung nicht gefunden'], 404);
        }

        // Topics
        $topics = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_topics_table() . " WHERE session_id = %d AND status IN ('planned','accepted','submitted') ORDER BY sort_order",
            $session_id
        ), ARRAY_A);

        // Participants with attendance
        $participants = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, u.display_name FROM " . Isidor_Consilium_Database::get_participants_table() . " p LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID WHERE p.session_id = %d ORDER BY u.display_name",
            $session_id
        ), ARRAY_A);

        // Votes
        $votes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_votes_table() . " WHERE session_id = %d ORDER BY created_at",
            $session_id
        ), ARRAY_A);

        foreach ($votes as &$v) {
            $v['options'] = json_decode($v['options'], true) ?: [];
            if ($v['status'] === 'closed') {
                $v['results'] = self::build_vote_results((int) $v['id'], $v);
            }
            // Count ballots for active votes
            $v['ballot_count'] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM " . Isidor_Consilium_Database::get_ballots_table() . " WHERE vote_id = %d",
                $v['id']
            ));
        }

        // Protocols
        $protocols = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . Isidor_Consilium_Database::get_protocols_table() . " WHERE session_id = %d",
            $session_id
        ), ARRAY_A);
        $protocol_map = [];
        foreach ($protocols as $p) {
            $protocol_map[$p['topic_id']] = $p['content'];
        }

        // RSVP summary
        $rsvp = Isidor_Consilium_Database::get_rsvp_summary($session_id);

        return new \WP_REST_Response([
            'success'      => true,
            'session'      => $session,
            'topics'       => $topics,
            'participants' => $participants,
            'votes'        => $votes,
            'protocols'    => $protocol_map,
            'rsvp_summary' => $rsvp,
        ]);
    }

    // =========================================================================
    // REMINDERS & PROTOCOL MAIL
    // =========================================================================

    public static function send_reminder(\WP_REST_Request $request): \WP_REST_Response {
        $session_id = (int) $request['id'];
        $result = Isidor_Consilium_Mail::send_reminder($session_id);
        return new \WP_REST_Response(['success' => true, 'result' => $result]);
    }

    public static function send_protocol_mail(\WP_REST_Request $request): \WP_REST_Response {
        $session_id = (int) $request['id'];

        // Generate protocol PDF
        $pdf_path = Isidor_Consilium_PDF::generate_protocol($session_id);
        if (!$pdf_path) {
            return new \WP_REST_Response(['success' => false, 'message' => 'PDF-Generierung fehlgeschlagen'], 500);
        }

        $result = Isidor_Consilium_Mail::send_finalized_protocol($session_id, $pdf_path);

        // Clean up temp PDF
        if (file_exists($pdf_path)) {
            @unlink($pdf_path);
        }

        return new \WP_REST_Response(['success' => true, 'result' => $result]);
    }

    public static function get_invitation_pdf(\WP_REST_Request $request): \WP_REST_Response {
        $session_id = (int) $request['id'];

        $pdf_path = Isidor_Consilium_PDF::generate_invitation($session_id);
        if (!$pdf_path || !file_exists($pdf_path)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'PDF-Generierung fehlgeschlagen'], 500);
        }

        // Return as download URL (using WP upload)
        $upload_dir = wp_upload_dir();
        $dest = $upload_dir['basedir'] . '/consilium/' . basename($pdf_path);
        wp_mkdir_p(dirname($dest));
        copy($pdf_path, $dest);
        @unlink($pdf_path);

        $url = $upload_dir['baseurl'] . '/consilium/' . basename($pdf_path);
        return new \WP_REST_Response(['success' => true, 'url' => $url]);
    }
}
