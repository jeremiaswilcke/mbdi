<?php
/**
 * Isidor Consilium - Shortcodes
 *
 * [isidor_consilium_app]   – Hauptansicht (Sitzungsliste + Detail + RSVP + Topic Submit)
 * [isidor_consilium_vote]  – Abstimmungsseite (Teilnehmer)
 * [isidor_consilium_live]  – Live-Dashboard (Vorsitzender)
 */

if (!defined('ABSPATH')) exit;

class Isidor_Consilium_Shortcodes {

    public static function init(): void {
        add_shortcode('isidor_consilium_app', [self::class, 'render_app']);
        add_shortcode('isidor_consilium_vote', [self::class, 'render_vote']);
        add_shortcode('isidor_consilium_live', [self::class, 'render_live_dashboard']);
    }

    // =========================================================================
    // MAIN APP — Sitzungsübersicht, Detail, RSVP, Topic Submit
    // =========================================================================

    public static function render_app(array $atts = []): string {
        if (!is_user_logged_in()) return self::render_login_required();
        if (!current_user_can('isidor_consilium_view')) return self::render_access_denied();

        $can_manage = current_user_can('isidor_consilium_manage');
        $can_admin  = current_user_can('isidor_consilium_admin');
        $user_id    = get_current_user_id();

        ob_start();
        ?>
        <div id="isidor-consilium-app" class="consilium-app"
             data-can-manage="<?php echo $can_manage ? '1' : '0'; ?>"
             data-can-admin="<?php echo $can_admin ? '1' : '0'; ?>"
             data-user-id="<?php echo esc_attr($user_id); ?>"
             data-rest-url="<?php echo esc_url(rest_url('isidor/v1/consilium/')); ?>"
             data-nonce="<?php echo wp_create_nonce('wp_rest'); ?>">

            <!-- Filter Bar -->
            <div class="consilium-app__filters">
                <select id="consilium-filter-gremium" class="consilium-select">
                    <option value="">Alle Gremien</option>
                    <?php foreach (Isidor_Consilium_Database::get_valid_gremiums() as $g): ?>
                        <option value="<?php echo esc_attr($g); ?>"><?php echo esc_html(Isidor_Consilium_Database::get_gremium_short_label($g)); ?></option>
                    <?php endforeach; ?>
                </select>
                <select id="consilium-filter-status" class="consilium-select">
                    <option value="">Alle Status</option>
                    <?php foreach (Isidor_Consilium_Database::get_valid_statuses() as $s): ?>
                        <option value="<?php echo esc_attr($s); ?>"><?php echo esc_html(Isidor_Consilium_Database::get_status_label($s)); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if ($can_manage): ?>
                    <button type="button" class="consilium-btn consilium-btn--primary" id="consilium-create-session">+ Neue Sitzung</button>
                <?php endif; ?>
            </div>

            <!-- Session List -->
            <div id="consilium-sessions-list" class="consilium-sessions-list">
                <p class="consilium-loading">Sitzungen werden geladen...</p>
            </div>

            <!-- Session Detail -->
            <div id="consilium-session-detail" class="consilium-session-detail" style="display:none;">
                <button type="button" class="consilium-btn consilium-btn--back" id="consilium-back-to-list">
                    &larr; Zurück zur Übersicht
                </button>
                <div id="consilium-detail-content"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // VOTE PAGE — Abstimmungsseite für Teilnehmer
    // =========================================================================

    public static function render_vote(array $atts = []): string {
        if (!is_user_logged_in()) return self::render_login_required();
        if (!current_user_can('isidor_consilium_vote')) return self::render_access_denied();

        $session_id = intval($_GET['session_id'] ?? 0);
        $user_id = get_current_user_id();

        ob_start();
        ?>
        <div id="isidor-consilium-vote" class="consilium-vote-page"
             data-user-id="<?php echo esc_attr($user_id); ?>"
             data-session-id="<?php echo esc_attr($session_id); ?>"
             data-rest-url="<?php echo esc_url(rest_url('isidor/v1/consilium/')); ?>"
             data-nonce="<?php echo wp_create_nonce('wp_rest'); ?>">

            <div class="consilium-vote-page__header">
                <h2>🗳️ Abstimmungen</h2>
            </div>

            <?php if (!$session_id): ?>
                <div class="consilium-vote-page__select">
                    <p>Wählen Sie eine Sitzung:</p>
                    <div id="consilium-vote-session-list">
                        <p class="consilium-loading">Laden...</p>
                    </div>
                </div>
            <?php else: ?>
                <div id="consilium-vote-content">
                    <div class="consilium-vote-page__loading">
                        <div class="consilium-spinner"></div>
                        <p>Abstimmungen werden geladen...</p>
                    </div>
                </div>
                <div id="consilium-vote-refresh" style="text-align:center;margin-top:16px;">
                    <small style="color:#9ca3af;">Automatische Aktualisierung alle 5 Sekunden</small>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // LIVE DASHBOARD — Vorsitzender steuert die Sitzung
    // =========================================================================

    public static function render_live_dashboard(array $atts = []): string {
        if (!is_user_logged_in()) return self::render_login_required();
        if (!current_user_can('isidor_consilium_manage')) return self::render_access_denied();

        $session_id = intval($_GET['session_id'] ?? 0);
        if (!$session_id) {
            return '<div class="consilium-notice consilium-notice--warning"><p>Keine Sitzung ausgewählt. Bitte öffnen Sie das Live-Dashboard über die Sitzungsverwaltung.</p></div>';
        }

        $user_id = get_current_user_id();

        ob_start();
        ?>
        <div id="isidor-consilium-live" class="consilium-live"
             data-session-id="<?php echo esc_attr($session_id); ?>"
             data-user-id="<?php echo esc_attr($user_id); ?>"
             data-rest-url="<?php echo esc_url(rest_url('isidor/v1/consilium/')); ?>"
             data-nonce="<?php echo wp_create_nonce('wp_rest'); ?>">

            <!-- Live Header -->
            <div class="consilium-live__header">
                <h2>🔴 Live-Sitzung</h2>
                <div class="consilium-live__actions">
                    <button type="button" class="consilium-btn consilium-btn--danger" id="consilium-live-end">
                        Sitzung beenden
                    </button>
                </div>
            </div>

            <!-- Session Info -->
            <div id="consilium-live-info" class="consilium-live__info">
                <p class="consilium-loading">Lade Sitzungsdaten...</p>
            </div>

            <!-- Two-Column Layout -->
            <div class="consilium-live__grid">
                <!-- Left: TOPs + Protokoll -->
                <div class="consilium-live__main">
                    <h3>Tagesordnung</h3>
                    <div id="consilium-live-topics"></div>

                    <h3 style="margin-top:20px;">Protokoll</h3>
                    <div id="consilium-live-protocol"></div>
                </div>

                <!-- Right: Attendance + Votes -->
                <div class="consilium-live__sidebar">
                    <h3>Anwesenheit</h3>
                    <div id="consilium-live-attendance"></div>

                    <h3 style="margin-top:20px;">Abstimmungen</h3>
                    <div id="consilium-live-votes"></div>

                    <div style="margin-top:16px;">
                        <button type="button" class="consilium-btn consilium-btn--primary" id="consilium-live-new-vote">
                            + Neue Abstimmung
                        </button>
                    </div>

                    <h3 style="margin-top:20px;">RSVP-Übersicht</h3>
                    <div id="consilium-live-rsvp"></div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private static function render_login_required(): string {
        return '<div class="consilium-notice consilium-notice--info">'
            . '<p>Bitte melden Sie sich an, um auf die Sitzungsverwaltung zuzugreifen.</p>'
            . '<a href="' . esc_url(wp_login_url(get_permalink())) . '" class="consilium-btn consilium-btn--primary">Anmelden</a>'
            . '</div>';
    }

    private static function render_access_denied(): string {
        return '<div class="consilium-notice consilium-notice--warning">'
            . '<p>Sie haben keine Berechtigung für die Sitzungsverwaltung.</p>'
            . '</div>';
    }
}
