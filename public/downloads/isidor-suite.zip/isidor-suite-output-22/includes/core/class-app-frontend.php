<?php
/**
 * Isidor App Frontend
 *
 * Unified responsive frontend for Consilium + Liturgia modules.
 * Shortcode: [isidor_app]
 *
 * @package IsidorSuite
 * @since 11.0.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_App_Frontend {

    public static function init(): void {
        add_shortcode('isidor_app', [self::class, 'render_app']);
        add_action('wp_enqueue_scripts', [self::class, 'maybe_enqueue_assets']);
    }

    /**
     * Enqueue assets only on pages with [isidor_app]
     */
    public static function maybe_enqueue_assets(): void {
        global $post;
        if (!is_a($post, 'WP_Post')) return;

        $has = has_shortcode($post->post_content, 'isidor_app');
        if (!$has) return;

        // Google Fonts
        wp_enqueue_style(
            'isidor-app-fonts',
            'https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=DM+Sans:wght@400;500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'isidor-app-frontend',
            ISIDOR_SUITE_URL . 'assets/css/isidor-app-frontend.css',
            [],
            ISIDOR_SUITE_VERSION
        );

        wp_enqueue_script(
            'isidor-app-frontend',
            ISIDOR_SUITE_URL . 'assets/js/isidor-app-frontend.js',
            ['jquery'],
            ISIDOR_SUITE_VERSION,
            true
        );

        // Determine which modules are active
        $modules = [];
        if (defined('ISIDOR_CONSILIUM_VERSION')) $modules[] = 'consilium';
        if (defined('ISIDOR_LITURGIA_VERSION'))   $modules[] = 'liturgia';

        // User permissions
        $user_perms = [
            'consilium_view'   => current_user_can('isidor_consilium_view'),
            'consilium_manage' => current_user_can('isidor_consilium_manage'),
            'consilium_vote'   => current_user_can('isidor_consilium_vote'),
            'consilium_admin'  => current_user_can('isidor_consilium_admin'),
            'liturgia_view'    => current_user_can('isidor_liturgia_view') || current_user_can('manage_options'),
            'liturgia_manage'  => current_user_can('isidor_liturgia_manage') || current_user_can('manage_options'),
        ];

        // Parish info
        $parish_name = get_bloginfo('name');
        if (class_exists('Isidor_Parish_Settings')) {
            $settings = get_option('isidor_parish_settings', []);
            $parish_name = $settings['name'] ?? $parish_name;
        }

        wp_localize_script('isidor-app-frontend', 'isidorApp', [
            'restUrl'       => rest_url('isidor/v1/'),
            'restNonce'     => wp_create_nonce('wp_rest'),
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'ajaxNonce'     => wp_create_nonce('liturgia_frontend_nonce'),
            'pollInterval'  => 3000,
            'modules'       => $modules,
            'parishName'    => $parish_name,
            'userId'        => get_current_user_id(),
            'permissions'   => $user_perms,
            'today'         => current_time('Y-m-d'),
        ]);
    }

    /**
     * [isidor_app] shortcode
     */
    public static function render_app(array $atts = []): string {
        if (!is_user_logged_in()) {
            return self::render_login_required();
        }

        $can_consilium = current_user_can('isidor_consilium_view');
        $can_liturgia  = current_user_can('isidor_liturgia_view') || current_user_can('manage_options');

        if (!$can_consilium && !$can_liturgia) {
            return self::render_access_denied();
        }

        ob_start();
        ?>
        <div id="isidor-app" class="ia"
             data-modules="<?php echo esc_attr(implode(',', array_filter([
                 $can_consilium ? 'consilium' : '',
                 $can_liturgia ? 'liturgia' : '',
             ]))); ?>">

            <!-- HEADER -->
            <header class="ia-header" id="ia-header">
                <div class="ia-header__row">
                    <button class="ia-header__back" id="ia-back" style="display:none;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </button>
                    <div class="ia-header__title" id="ia-header-title">Isidor</div>
                    <div class="ia-header__sub" id="ia-header-sub"><?php echo esc_html(get_bloginfo('name')); ?></div>
                </div>
            </header>

            <!-- PAGES -->
            <main class="ia-main" id="ia-main">
                <!-- Dynamically rendered by JS -->
                <div class="ia-loading">Wird geladen…</div>
            </main>

            <!-- BOTTOM NAV -->
            <nav class="ia-nav" id="ia-nav">
                <button class="ia-nav__item ia-nav__item--active" data-page="home">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    <span>Übersicht</span>
                </button>
                <?php if ($can_consilium): ?>
                <button class="ia-nav__item" data-page="consilium">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4-4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                    <span>Consilium</span>
                </button>
                <?php endif; ?>
                <?php if ($can_liturgia): ?>
                <button class="ia-nav__item" data-page="liturgia">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
                    <span>Liturgia</span>
                </button>
                <?php endif; ?>
            </nav>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function render_login_required(): string {
        return '<div class="ia-notice ia-notice--info">'
            . '<p>Bitte melden Sie sich an.</p>'
            . '<a href="' . esc_url(wp_login_url(get_permalink())) . '" class="ia-btn ia-btn--primary">Anmelden</a>'
            . '</div>';
    }

    private static function render_access_denied(): string {
        return '<div class="ia-notice ia-notice--warning">'
            . '<p>Keine Berechtigung für die Isidor App.</p>'
            . '</div>';
    }
}
