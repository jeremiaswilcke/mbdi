<?php
/**
 * Isidor Suite — PWA App Link Bridge
 * 
 * Provides a redirect endpoint that attempts to open links in the installed PWA.
 * - Android: Automatically opens in PWA if installed (via manifest scope)
 * - iOS: Shows an "Open in App" button since iOS doesn't auto-redirect to PWAs from links
 *
 * Usage in emails: Instead of linking directly to /dienste/, link to /app-link/?to=dienste
 *
 * @package IsidorSuite
 * @since 2.3.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_App_Link {

    public static function init(): void {
        add_action('init', [self::class, 'register_rewrite']);
        add_action('template_redirect', [self::class, 'handle_redirect']);
        add_filter('query_vars', [self::class, 'add_query_vars']);
    }

    /**
     * Register /app-link/ rewrite rule
     */
    public static function register_rewrite(): void {
        add_rewrite_rule(
            '^app-link/?$',
            'index.php?isidor_app_link=1',
            'top'
        );
    }

    public static function add_query_vars(array $vars): array {
        $vars[] = 'isidor_app_link';
        return $vars;
    }

    /**
     * Handle the redirect
     */
    public static function handle_redirect(): void {
        if (!get_query_var('isidor_app_link')) return;

        $to = isset($_GET['to']) ? sanitize_text_field($_GET['to']) : '';
        $target_url = self::resolve_target($to);
        $site_name = get_bloginfo('name');
        $site_icon = get_site_icon_url(180) ?: '';

        // Output the bridge page
        self::render_bridge_page($target_url, $site_name, $site_icon);
        exit;
    }

    /**
     * Resolve short path to full URL
     */
    private static function resolve_target(string $to): string {
        if (!$to) return home_url('/');

        // Allow full URLs within our domain
        if (str_starts_with($to, 'http')) {
            $parsed = parse_url($to);
            $home = parse_url(home_url());
            if (($parsed['host'] ?? '') === ($home['host'] ?? '')) {
                return $to;
            }
            return home_url('/');
        }

        // Known shortcuts
        $shortcuts = [
            'dienste'     => liturgus_get_dashboard_url(),
            'startseite'  => home_url('/'),
            'lieder'      => home_url('/lieder/'),
            'termine'     => home_url('/termine/'),
            'finanzen'    => home_url('/finanzen/'),
            'sakristei'   => home_url('/sakristei/'),
            'liturgia'    => home_url('/liturgia/'),
            'sitzungen'   => home_url('/sitzungen/'),
            'verwaltung'  => home_url('/verwaltung/'),
            'tagesplan'   => home_url('/tagesplan/'),
            'nachrichten' => home_url('/nachrichten/'),
        ];

        return $shortcuts[$to] ?? home_url('/' . ltrim($to, '/') . '/');
    }

    /**
     * Render the bridge page
     */
    private static function render_bridge_page(string $target_url, string $site_name, string $icon_url): void {
        $escaped_url = esc_url($target_url);
        $escaped_name = esc_html($site_name);
        $escaped_icon = esc_url($icon_url);

        header('Content-Type: text/html; charset=utf-8');
        ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title><?php echo $escaped_name; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #155277 0%, #1a6d9e 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: #fff;
        }
        .bridge-card {
            background: rgba(255,255,255,0.12);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 48px 32px;
            text-align: center;
            max-width: 380px;
            width: 100%;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .bridge-icon {
            width: 80px;
            height: 80px;
            border-radius: 18px;
            margin: 0 auto 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.2);
        }
        .bridge-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .bridge-subtitle {
            font-size: 15px;
            opacity: 0.8;
            margin-bottom: 32px;
            line-height: 1.4;
        }
        .bridge-btn {
            display: block;
            width: 100%;
            padding: 16px 24px;
            border: none;
            border-radius: 14px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: transform 0.15s, box-shadow 0.15s;
            margin-bottom: 12px;
        }
        .bridge-btn:active { transform: scale(0.97); }
        .bridge-btn--primary {
            background: #fff;
            color: #155277;
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }
        .bridge-btn--secondary {
            background: rgba(255,255,255,0.15);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.3);
        }
        .bridge-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin-bottom: 16px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .bridge-status {
            font-size: 14px;
            opacity: 0.7;
            margin-top: 16px;
            min-height: 20px;
        }
        .bridge-ios-hint { display: none; }
        /* Show iOS hint only on iOS */
        @supports (-webkit-touch-callout: none) {
            .bridge-ios-hint { display: block; }
            .bridge-auto-hint { display: none; }
        }
    </style>
</head>
<body>
    <div class="bridge-card">
        <?php if ($escaped_icon): ?>
            <img src="<?php echo $escaped_icon; ?>" alt="" class="bridge-icon">
        <?php endif; ?>
        
        <div class="bridge-title"><?php echo $escaped_name; ?></div>
        
        <div class="bridge-subtitle bridge-auto-hint">
            <div class="bridge-spinner"></div><br>
            Du wirst weitergeleitet…
        </div>
        
        <div class="bridge-subtitle bridge-ios-hint">
            Tippe auf den Button um die App zu öffnen.
        </div>

        <a href="<?php echo $escaped_url; ?>" class="bridge-btn bridge-btn--primary" id="open-btn">
            In der App öffnen
        </a>
        
        <a href="<?php echo $escaped_url; ?>" class="bridge-btn bridge-btn--secondary">
            Im Browser öffnen
        </a>
        
        <div class="bridge-status" id="status"></div>
    </div>

    <script>
    (function() {
        var targetUrl = <?php echo json_encode($target_url); ?>;
        var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
                    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
        var isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                           window.navigator.standalone === true;

        // If already in PWA, redirect immediately
        if (isStandalone) {
            window.location.href = targetUrl;
            return;
        }

        // On Android: auto-redirect after short delay (PWA scope handles the rest)
        if (!isIOS) {
            setTimeout(function() {
                window.location.href = targetUrl;
            }, 1200);
        }
        
        // On iOS: just show the button (no auto-redirect, it would open Safari)
        // The "In der App öffnen" button is already visible
    })();
    </script>
</body>
</html>
        <?php
    }
}
