<?php
/**
 * Isidor App Permissions System
 * 
 * Modulares Berechtigungssystem: User können pro App hinzugefügt werden
 * mit verschiedenen Berechtigungsstufen.
 *
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) exit;

class Isidor_App_Permissions {
    
    private static $instance = null;
    
    /**
     * Mapping: WP-Capability → [app_slug, permission]
     *
     * Verbindet die Legacy-WordPress-Capabilities die im Frontend/AJAX geprüft werden
     * mit dem neuen App-Permission-System (Custom Table wp_isidor_app_permissions).
     *
     * Wenn eine WP-Capability geprüft wird (current_user_can / user_can), schlägt der
     * user_has_cap Filter in dieser Map nach und prüft die Custom Table.
     */
    private const CAP_BRIDGE = [
        // === Liturgus ===
        'liturgus_signup'         => ['liturgus', 'signup'],
        'liturgus_view'           => ['liturgus', 'view'],
        'liturgus_manage'         => ['liturgus', 'manage'],
        'liturgus_assign_others'  => ['liturgus', 'manage'],
        'liturgus_remind'         => ['liturgus', 'remind'],
        'liturgus_admin'          => ['liturgus', 'admin'],

        // === Cantus ===
        'isidor_cantus_view'      => ['cantus', 'view'],
        'isidor_cantus_edit'      => ['cantus', 'plan'],
        'isidor_cantus_export'    => ['cantus', 'export'],
        'isidor_cantus_admin'     => ['cantus', 'admin'],

        // === Cellerar ===
        'isidor_cellerar_read'             => ['cellerar', 'view'],
        'isidor_cellerar_add_income'       => ['cellerar', 'income'],
        'isidor_cellerar_add_expense'      => ['cellerar', 'expense'],
        'isidor_cellerar_approve_expense'  => ['cellerar', 'approve'],
        'isidor_cellerar_export'           => ['cellerar', 'export'],
        'isidor_cellerar_view_stats'       => ['cellerar', 'view'],
        'isidor_cellerar_manage_settings'  => ['cellerar', 'admin'],

        // === Sakristan ===
        'isidor_sakristan_view'            => ['sakristan', 'view'],
        'isidor_sakristan_edit'            => ['sakristan', 'edit'],
        'isidor_sakristan_check'           => ['sakristan', 'edit'],
        'isidor_sakristan_todo_create'     => ['sakristan', 'edit'],
        'isidor_sakristan_timelog'          => ['sakristan', 'edit'],
        'isidor_sakristan_timelog_view'     => ['sakristan', 'view'],
        'isidor_sakristan_admin'           => ['sakristan', 'admin'],

        // === Agenda ===
        'isidor_agenda_view'       => ['agenda', 'view'],
        'isidor_agenda_request'    => ['agenda', 'request'],
        'isidor_agenda_approve'    => ['agenda', 'approve'],
        'isidor_agenda_rooms'      => ['agenda', 'rooms'],
        'isidor_agenda_export'     => ['agenda', 'export'],
        'isidor_agenda_admin'      => ['agenda', 'admin'],

        // === Tagesplan ===
        'isidor_tagesplan_view'    => ['tagesplan', 'view'],
        'isidor_tagesplan_edit'    => ['tagesplan', 'edit'],
        'isidor_tagesplan_export'  => ['tagesplan', 'export'],
        'isidor_tagesplan_display' => ['tagesplan', 'display'],
        'isidor_tagesplan_admin'   => ['tagesplan', 'admin'],

        // === Liturgia ===
        'isidor_liturgia_view'     => ['liturgia', 'view'],
        'isidor_liturgia_plan'     => ['liturgia', 'plan'],
        'isidor_liturgia_manage'   => ['liturgia', 'manage'],
        'isidor_liturgia_admin'    => ['liturgia', 'admin'],

        // === Communicator (kein eigener App-Eintrag, aber Caps existieren) ===
        'isidor_comm_view'         => ['communicator', 'view'],
        'isidor_comm_send'         => ['communicator', 'send'],
        'isidor_comm_create_group' => ['communicator', 'create'],
        'isidor_comm_admin'        => ['communicator', 'admin'],

        // === Consilium ===
        'isidor_consilium_view'    => ['consilium', 'view'],
        'isidor_consilium_manage'  => ['consilium', 'manage'],
        'isidor_consilium_vote'    => ['consilium', 'vote'],
        'isidor_consilium_admin'   => ['consilium', 'admin'],
    ];

    /**
     * Per-Request Cache für User-Permissions (vermeidet wiederholte DB-Queries)
     * @var array<int, array<string, string[]>>
     */
    private $permission_cache = [];

    /**
     * Alle verfügbaren Apps mit ihren Berechtigungen
     */
    private const APPS = [
        'core' => [
            'name' => 'Isidor Core',
            'icon' => '⛪',
            'description' => 'Messen-Verwaltung, Vorlagen, Generator',
            'permissions' => [
                'view'    => 'Ansehen',
                'edit'    => 'Bearbeiten',
                'create'  => 'Erstellen',
                'delete'  => 'Löschen',
                'admin'   => 'Administrieren',
            ],
        ],
        'liturgus' => [
            'name' => 'Liturgus',
            'icon' => '📅',
            'description' => 'Dienstplanung für Gottesdienste',
            'permissions' => [
                'view'      => 'Dienste ansehen',
                'signup'    => 'Sich eintragen',
                'manage'    => 'Dienste verwalten',
                'remind'    => 'Erinnerungen senden',
                'admin'     => 'Administrieren',
            ],
        ],
        'cellerar' => [
            'name' => 'Cellerar',
            'icon' => '💰',
            'description' => 'Finanzverwaltung',
            'permissions' => [
                'view'      => 'Ansehen',
                'income'    => 'Einnahmen erfassen',
                'expense'   => 'Ausgaben erfassen',
                'approve'   => 'Genehmigen',
                'export'    => 'Exportieren',
                'admin'     => 'Administrieren',
            ],
        ],
        'sakristan' => [
            'name' => 'Sakristan',
            'icon' => '🕯️',
            'description' => 'Sakristei-Verwaltung',
            'permissions' => [
                'view'    => 'Ansehen',
                'edit'    => 'Bearbeiten',
                'admin'   => 'Administrieren',
            ],
        ],
        'agenda' => [
            'name' => 'Agenda',
            'icon' => '📆',
            'description' => 'Termine & Raumverwaltung',
            'permissions' => [
                'view'      => 'Kalender ansehen',
                'request'   => 'Termine anfragen',
                'approve'   => 'Termine genehmigen',
                'rooms'     => 'Räume verwalten',
                'export'    => 'Exportieren',
                'admin'     => 'Administrieren',
            ],
        ],
        'cantus' => [
            'name' => 'Cantus',
            'icon' => '🎵',
            'description' => 'Liedplanung',
            'permissions' => [
                'view'    => 'Lieder ansehen',
                'plan'    => 'Lieder planen',
                'manage'  => 'Liederbuch verwalten',
                'export'  => 'PDF exportieren',
                'admin'   => 'Administrieren',
            ],
        ],
        'tagesplan' => [
            'name' => 'Tagesplan',
            'icon' => '📋',
            'description' => 'Tagesplan-Ansicht & Export',
            'permissions' => [
                'view'    => 'Tagesplan ansehen',
                'edit'    => 'Template bearbeiten',
                'export'  => 'PDF/JSON exportieren',
                'display' => 'Display-Ansicht nutzen',
                'admin'   => 'Administrieren',
            ],
        ],
        'liturgia' => [
            'name' => 'Liturgia',
            'icon' => '📖',
            'description' => 'Gottesdienst-Detailplanung',
            'permissions' => [
                'view'    => 'Planung ansehen',
                'plan'    => 'Planung bearbeiten',
                'manage'  => 'Events verwalten',
                'admin'   => 'Administrieren',
            ],
        ],
        'consilium' => [
            'name' => 'Consilium',
            'icon' => '🏛️',
            'description' => 'PGR/VVR-Sitzungsverwaltung',
            'permissions' => [
                'view'   => 'Sitzungen ansehen',
                'manage' => 'Sitzungen verwalten',
                'vote'   => 'Abstimmen',
                'admin'  => 'Administrieren',
            ],
        ],
    ];

    /**
     * Vordefinierte Rollen-Templates
     */
    private const ROLE_TEMPLATES = [
        'pfarrer' => [
            'label' => 'Pfarrer',
            'apps' => [
                'core'      => ['view', 'edit', 'create', 'delete', 'admin'],
                'liturgus'  => ['view', 'signup', 'manage', 'remind', 'admin'],
                'cellerar'  => ['view', 'income', 'expense', 'approve', 'export', 'admin'],
                'sakristan' => ['view', 'edit', 'admin'],
                'agenda'    => ['view', 'request', 'approve', 'rooms', 'export', 'admin'],
                'cantus'    => ['view', 'plan', 'manage', 'export', 'admin'],
                'tagesplan' => ['view', 'edit', 'export', 'display', 'admin'],
                'liturgia'   => ['view', 'plan', 'manage', 'admin'],
                'consilium'  => ['view', 'manage', 'vote', 'admin'],
            ],
        ],
        'sekretariat' => [
            'label' => 'Sekretariat',
            'apps' => [
                'core'      => ['view', 'edit', 'create'],
                'liturgus'  => ['view', 'manage', 'remind'],
                'cellerar'  => ['view', 'income', 'expense', 'export'],
                'agenda'    => ['view', 'request', 'approve', 'rooms', 'export'],
                'cantus'    => ['view', 'export'],
                'tagesplan' => ['view', 'edit', 'export', 'display'],
                'liturgia'   => ['view', 'plan', 'manage'],
                'consilium'  => ['view', 'manage'],
            ],
        ],
        'mesner' => [
            'label' => 'Mesner',
            'apps' => [
                'core'      => ['view'],
                'liturgus'  => ['view', 'signup'],
                'sakristan' => ['view', 'edit'],
                'cantus'    => ['view'],
                'tagesplan' => ['view', 'display'],
                'liturgia'  => ['view'],
            ],
        ],
        'kantor' => [
            'label' => 'Kantor/Organist',
            'apps' => [
                'core'      => ['view'],
                'liturgus'  => ['view', 'signup'],
                'cantus'    => ['view', 'plan', 'manage', 'export'],
                'tagesplan' => ['view', 'export', 'display'],
                'liturgia'  => ['view', 'plan'],
            ],
        ],
        'ministrant' => [
            'label' => 'Ministrant',
            'apps' => [
                'core'     => ['view'],
                'liturgus' => ['view', 'signup'],
                'tagesplan'=> ['view'],
            ],
        ],
        'lektor' => [
            'label' => 'Lektor',
            'apps' => [
                'core'     => ['view'],
                'liturgus' => ['view', 'signup'],
                'tagesplan'=> ['view'],
                'liturgia' => ['view'],
            ],
        ],
        'vvr' => [
            'label' => 'Vermögensverwaltungsrat',
            'apps' => [
                'cellerar'  => ['view', 'approve', 'export'],
                'consilium' => ['view', 'vote'],
            ],
        ],
        'pgr' => [
            'label' => 'Pfarrgemeinderat',
            'apps' => [
                'core'      => ['view'],
                'agenda'    => ['view', 'request'],
                'consilium' => ['view', 'vote'],
            ],
        ],
    ];
    
    /**
     * DB Tabelle
     */
    private $table_name;
    
    /**
     * Singleton
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'isidor_app_permissions';

        // Bridge: App-Permissions → WP-Capabilities
        add_filter('user_has_cap', [$this, 'bridge_capabilities'], 10, 4);

        add_action('admin_menu', [$this, 'add_admin_menu'], 15);
        add_action('admin_init', [$this, 'handle_permission_actions']);
        add_action('wp_ajax_isidor_save_user_permissions', [$this, 'ajax_save_permissions']);
        add_action('wp_ajax_isidor_get_user_permissions', [$this, 'ajax_get_permissions']);
        add_action('show_user_profile', [$this, 'show_user_permissions']);
        add_action('edit_user_profile', [$this, 'show_user_permissions']);
    }
    
    /**
     * Tabelle erstellen
     */
    public static function create_table(): void {
        global $wpdb;
        $table_name = $wpdb->prefix . 'isidor_app_permissions';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            app_slug varchar(50) NOT NULL,
            permission varchar(50) NOT NULL,
            granted_by bigint(20) UNSIGNED DEFAULT NULL,
            granted_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_app_perm (user_id, app_slug, permission),
            KEY user_id (user_id),
            KEY app_slug (app_slug)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
    
    /**
     * Prüfen ob User eine Berechtigung hat
     */
    public function user_can(int $user_id, string $app, string $permission): bool {
        // Admins können alles
        if (user_can($user_id, 'manage_options')) {
            return true;
        }

        $perms = $this->get_cached_permissions($user_id);
        return isset($perms[$app]) && in_array($permission, $perms[$app], true);
    }
    
    /**
     * Aktueller User kann?
     */
    public function current_user_can(string $app, string $permission): bool {
        return $this->user_can(get_current_user_id(), $app, $permission);
    }

    /**
     * Bridge: App-Permissions → WordPress Capabilities
     *
     * Dieser Filter wird bei jeder current_user_can() / user_can() Prüfung aufgerufen.
     * Wenn die geprüfte Capability in CAP_BRIDGE steht, wird die Custom Table abgefragt
     * und bei Treffer die Capability dynamisch gewährt.
     *
     * @param array    $allcaps  Alle Capabilities des Users
     * @param array    $caps     Benötigte primitive Capabilities
     * @param array    $args     [0] = angeforderte Capability, [1] = User-ID, ...
     * @param WP_User  $user     User-Objekt
     * @return array
     */
    public function bridge_capabilities(array $allcaps, array $caps, array $args, $user): array {
        $requested_cap = $args[0] ?? '';

        // Nur weiterarbeiten wenn diese Cap in unserer Bridge-Map steht
        if (!isset(self::CAP_BRIDGE[$requested_cap])) {
            return $allcaps;
        }

        // User hat die Cap schon (z.B. durch WP-Rolle) → nichts tun
        if (!empty($allcaps[$requested_cap])) {
            return $allcaps;
        }

        $user_id = (int) ($args[1] ?? 0);
        if ($user_id <= 0) {
            return $allcaps;
        }

        // Admins können alles – das prüft user_can() bereits, aber als Sicherheit:
        if (!empty($allcaps['manage_options'])) {
            $allcaps[$requested_cap] = true;
            return $allcaps;
        }

        // Permissions aus Cache oder DB laden
        $user_perms = $this->get_cached_permissions($user_id);

        [$app, $perm] = self::CAP_BRIDGE[$requested_cap];

        if (isset($user_perms[$app]) && in_array($perm, $user_perms[$app], true)) {
            $allcaps[$requested_cap] = true;
        }

        // admin-Permission einer App gewährt auch alle anderen Caps dieser App
        if (empty($allcaps[$requested_cap]) && isset($user_perms[$app]) && in_array('admin', $user_perms[$app], true)) {
            $allcaps[$requested_cap] = true;
        }

        return $allcaps;
    }

    /**
     * Cached Permissions pro Request laden
     *
     * Lädt alle Permissions eines Users einmalig pro Request und cached sie.
     * Verhindert n+1 Queries bei mehreren current_user_can() Aufrufen.
     */
    private function get_cached_permissions(int $user_id): array {
        if (isset($this->permission_cache[$user_id])) {
            return $this->permission_cache[$user_id];
        }

        $this->permission_cache[$user_id] = $this->get_user_all_permissions($user_id);
        return $this->permission_cache[$user_id];
    }

    /**
     * Cache leeren (z.B. nach Berechtigungsänderung)
     */
    public function clear_permission_cache(int $user_id = 0): void {
        if ($user_id > 0) {
            unset($this->permission_cache[$user_id]);
        } else {
            $this->permission_cache = [];
        }
    }

    /**
     * Berechtigung gewähren
     */
    public function grant_permission(int $user_id, string $app, string $permission): bool {
        global $wpdb;
        
        // Prüfen ob App und Permission existieren
        if (!isset(self::APPS[$app]) || !isset(self::APPS[$app]['permissions'][$permission])) {
            return false;
        }
        
        $result = $wpdb->replace(
            $this->table_name,
            [
                'user_id'    => $user_id,
                'app_slug'   => $app,
                'permission' => $permission,
                'granted_by' => get_current_user_id(),
                'granted_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%d', '%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Berechtigung entziehen
     */
    public function revoke_permission(int $user_id, string $app, string $permission): bool {
        global $wpdb;
        
        $result = $wpdb->delete(
            $this->table_name,
            [
                'user_id'    => $user_id,
                'app_slug'   => $app,
                'permission' => $permission,
            ],
            ['%d', '%s', '%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Alle Berechtigungen eines Users für eine App
     */
    public function get_user_app_permissions(int $user_id, string $app): array {
        global $wpdb;
        
        $results = $wpdb->get_col($wpdb->prepare(
            "SELECT permission FROM {$this->table_name} 
             WHERE user_id = %d AND app_slug = %s",
            $user_id, $app
        ));
        
        return $results ?: [];
    }
    
    /**
     * Alle Berechtigungen eines Users
     */
    public function get_user_all_permissions(int $user_id): array {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT app_slug, permission FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ), ARRAY_A);
        
        $permissions = [];
        foreach ($results as $row) {
            if (!isset($permissions[$row['app_slug']])) {
                $permissions[$row['app_slug']] = [];
            }
            $permissions[$row['app_slug']][] = $row['permission'];
        }
        
        return $permissions;
    }
    
    /**
     * Alle User mit Zugriff auf eine App
     */
    public function get_app_users(string $app): array {
        global $wpdb;
        
        $user_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT user_id FROM {$this->table_name} WHERE app_slug = %s",
            $app
        ));
        
        if (empty($user_ids)) {
            return [];
        }
        
        $users = [];
        foreach ($user_ids as $user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                $users[] = [
                    'id'          => $user->ID,
                    'name'        => $user->display_name,
                    'email'       => $user->user_email,
                    'permissions' => $this->get_user_app_permissions($user_id, $app),
                ];
            }
        }
        
        return $users;
    }
    
    /**
     * Rollen-Template anwenden
     */
    public function apply_role_template(int $user_id, string $template): bool {
        if (!isset(self::ROLE_TEMPLATES[$template])) {
            return false;
        }
        
        // Erst alle Berechtigungen entfernen
        global $wpdb;
        $wpdb->delete($this->table_name, ['user_id' => $user_id], ['%d']);
        
        // Neue Berechtigungen setzen
        foreach (self::ROLE_TEMPLATES[$template]['apps'] as $app => $permissions) {
            foreach ($permissions as $permission) {
                $this->grant_permission($user_id, $app, $permission);
            }
        }
        
        return true;
    }
    
    /**
     * Verfügbare Apps holen
     */
    public static function get_apps(): array {
        return self::APPS;
    }
    
    /**
     * Verfügbare Rollen-Templates holen
     */
    public static function get_role_templates(): array {
        return self::ROLE_TEMPLATES;
    }
    
    /**
     * Admin-Menü hinzufügen
     */
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Benutzer & Berechtigungen',
            '👥 Berechtigungen',
            'manage_options',
            'isidor-permissions',
            [$this, 'render_admin_page']
        );
    }
    
    /**
     * Admin-Seite rendern
     */
    public function render_admin_page(): void {
        $current_tab = $_GET['tab'] ?? 'users';
        ?>
        <div class="wrap">
            <h1>👥 Isidor Berechtigungen</h1>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=isidor-permissions&tab=users" 
                   class="nav-tab <?php echo $current_tab === 'users' ? 'nav-tab-active' : ''; ?>">
                    Benutzer verwalten
                </a>
                <a href="?page=isidor-permissions&tab=apps" 
                   class="nav-tab <?php echo $current_tab === 'apps' ? 'nav-tab-active' : ''; ?>">
                    Nach Apps
                </a>
                <a href="?page=isidor-permissions&tab=templates" 
                   class="nav-tab <?php echo $current_tab === 'templates' ? 'nav-tab-active' : ''; ?>">
                    Rollen-Vorlagen
                </a>
            </nav>
            
            <div class="tab-content" style="margin-top:20px;">
                <?php
                switch ($current_tab) {
                    case 'apps':
                        $this->render_apps_tab();
                        break;
                    case 'templates':
                        $this->render_templates_tab();
                        break;
                    default:
                        $this->render_users_tab();
                }
                ?>
            </div>
        </div>
        
        <style>
            .isidor-card { background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px; }
            .isidor-card h3 { margin-top:0; }
            .isidor-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:20px; }
            .permission-checkbox { margin:5px 0; }
            .permission-checkbox label { cursor:pointer; }
            .user-permissions-form { margin-top:15px; padding-top:15px; border-top:1px solid #eee; }
            .app-icon { font-size:2em; margin-bottom:10px; }
            .app-users { margin-top:15px; }
            .app-users .user-badge { display:inline-block; background:#f0f0f0; padding:3px 10px; border-radius:15px; margin:3px; font-size:0.9em; }
        </style>
        <?php
    }
    
    /**
     * Benutzer-Tab
     */
    private function render_users_tab(): void {
        $users = get_users(['orderby' => 'display_name']);
        ?>
        <div class="isidor-card">
            <h3>Benutzer auswählen</h3>
            <select id="isidor-user-select" style="min-width:300px;">
                <option value="">-- Benutzer wählen --</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?php echo esc_attr($user->ID); ?>">
                        <?php echo esc_html($user->display_name); ?> (<?php echo esc_html($user->user_email); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            
            <select id="isidor-template-select" style="margin-left:10px;">
                <option value="">-- Vorlage anwenden --</option>
                <?php
                // Use new template system if available
                if (class_exists('Isidor_Permissions')) {
                    $new_templates = Isidor_Permissions::get_templates();
                    foreach ($new_templates as $tpl) {
                        echo '<option value="new_' . esc_attr($tpl['id']) . '">' . esc_html(($tpl['icon'] ? $tpl['icon'] . ' ' : '') . $tpl['name']) . '</option>';
                    }
                }
                // Fallback to old presets if no new templates exist
                if (empty($new_templates)) {
                    foreach (self::ROLE_TEMPLATES as $key => $template) {
                        echo '<option value="' . esc_attr($key) . '">' . esc_html($template['label']) . '</option>';
                    }
                }
                ?>
            </select>
            
            <button type="button" class="button" id="isidor-apply-template">Vorlage anwenden</button>
        </div>
        
        <div id="isidor-user-permissions" style="display:none;">
            <h2 id="isidor-user-name"></h2>
            
            <div class="isidor-grid">
                <?php foreach (self::APPS as $app_slug => $app): ?>
                    <div class="isidor-card">
                        <div class="app-icon"><?php echo esc_html($app['icon']); ?></div>
                        <h3><?php echo esc_html($app['name']); ?></h3>
                        <p style="opacity:0.7;"><?php echo esc_html($app['description']); ?></p>
                        
                        <div class="app-permissions">
                            <?php foreach ($app['permissions'] as $perm_key => $perm_label): ?>
                                <div class="permission-checkbox">
                                    <label>
                                        <input type="checkbox" 
                                               class="isidor-perm-checkbox"
                                               data-app="<?php echo esc_attr($app_slug); ?>"
                                               data-perm="<?php echo esc_attr($perm_key); ?>">
                                        <?php echo esc_html($perm_label); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="isidor-card">
                <button type="button" class="button button-primary button-large" id="isidor-save-permissions">
                    💾 Berechtigungen speichern
                </button>
                <span id="isidor-save-status" style="margin-left:15px;"></span>
            </div>
        </div>
        
        <script>
        jQuery(function($) {
            var currentUserId = 0;
            
            $('#isidor-user-select').on('change', function() {
                var userId = $(this).val();
                if (!userId) {
                    $('#isidor-user-permissions').hide();
                    return;
                }
                
                currentUserId = userId;
                
                // Berechtigungen laden
                $.post(ajaxurl, {
                    action: 'isidor_get_user_permissions',
                    user_id: userId,
                    _wpnonce: '<?php echo wp_create_nonce('isidor_permissions'); ?>'
                }, function(response) {
                    if (response.success) {
                        $('#isidor-user-name').text('Berechtigungen für: ' + response.data.user_name);
                        
                        // Alle Checkboxen zurücksetzen
                        $('.isidor-perm-checkbox').prop('checked', false);
                        
                        // Gesetzte Berechtigungen aktivieren
                        $.each(response.data.permissions, function(app, perms) {
                            $.each(perms, function(i, perm) {
                                $('.isidor-perm-checkbox[data-app="' + app + '"][data-perm="' + perm + '"]')
                                    .prop('checked', true);
                            });
                        });
                        
                        $('#isidor-user-permissions').show();
                    }
                });
            });
            
            $('#isidor-apply-template').on('click', function() {
                var userId = $('#isidor-user-select').val();
                var template = $('#isidor-template-select').val();
                
                if (!userId || !template) {
                    alert('Bitte Benutzer und Vorlage auswählen.');
                    return;
                }
                
                if (!confirm('Alle bisherigen Berechtigungen werden überschrieben. Fortfahren?')) {
                    return;
                }
                
                $.post(ajaxurl, {
                    action: 'isidor_save_user_permissions',
                    user_id: userId,
                    template: template,
                    _wpnonce: '<?php echo wp_create_nonce('isidor_permissions'); ?>'
                }, function(response) {
                    if (response.success) {
                        $('#isidor-user-select').trigger('change');
                        alert('Vorlage angewendet!');
                    }
                });
            });
            
            $('#isidor-save-permissions').on('click', function() {
                if (!currentUserId) return;
                
                var permissions = {};
                $('.isidor-perm-checkbox:checked').each(function() {
                    var app = $(this).data('app');
                    var perm = $(this).data('perm');
                    
                    if (!permissions[app]) permissions[app] = [];
                    permissions[app].push(perm);
                });
                
                $.post(ajaxurl, {
                    action: 'isidor_save_user_permissions',
                    user_id: currentUserId,
                    permissions: permissions,
                    _wpnonce: '<?php echo wp_create_nonce('isidor_permissions'); ?>'
                }, function(response) {
                    if (response.success) {
                        $('#isidor-save-status').html('<span style="color:green;">✓ Gespeichert!</span>');
                        setTimeout(function() {
                            $('#isidor-save-status').html('');
                        }, 3000);
                    } else {
                        $('#isidor-save-status').html('<span style="color:red;">✗ Fehler!</span>');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Apps-Tab
     */
    private function render_apps_tab(): void {
        ?>
        <div class="isidor-grid">
            <?php foreach (self::APPS as $app_slug => $app): 
                $users = $this->get_app_users($app_slug);
            ?>
                <div class="isidor-card">
                    <div class="app-icon"><?php echo esc_html($app['icon']); ?></div>
                    <h3><?php echo esc_html($app['name']); ?></h3>
                    <p style="opacity:0.7;"><?php echo esc_html($app['description']); ?></p>
                    
                    <div class="app-users">
                        <strong><?php echo count($users); ?> Benutzer mit Zugriff:</strong>
                        <div style="margin-top:10px;">
                            <?php if (empty($users)): ?>
                                <em style="opacity:0.5;">Keine Benutzer</em>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                    <span class="user-badge" title="<?php echo esc_attr(implode(', ', $user['permissions'])); ?>">
                                        <?php echo esc_html($user['name']); ?>
                                    </span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div style="margin-top:15px;">
                        <strong>Verfügbare Berechtigungen:</strong>
                        <ul style="margin:5px 0 0 20px;">
                            <?php foreach ($app['permissions'] as $perm_key => $perm_label): ?>
                                <li><code><?php echo esc_html($perm_key); ?></code> - <?php echo esc_html($perm_label); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
    
    /**
     * Templates-Tab
     */
    private function render_templates_tab(): void {
        ?>
        <div class="isidor-grid">
            <?php foreach (self::ROLE_TEMPLATES as $template_key => $template): ?>
                <div class="isidor-card">
                    <h3><?php echo esc_html($template['label']); ?></h3>
                    <code style="font-size:0.9em;"><?php echo esc_html($template_key); ?></code>
                    
                    <div style="margin-top:15px;">
                        <?php foreach ($template['apps'] as $app_slug => $permissions): 
                            $app = self::APPS[$app_slug] ?? null;
                            if (!$app) continue;
                        ?>
                            <div style="margin-bottom:10px;">
                                <strong><?php echo esc_html($app['icon'] . ' ' . $app['name']); ?>:</strong>
                                <br>
                                <?php foreach ($permissions as $perm): ?>
                                    <span style="display:inline-block; background:#e0f0e0; padding:2px 8px; border-radius:10px; margin:2px; font-size:0.85em;">
                                        <?php echo esc_html($app['permissions'][$perm] ?? $perm); ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="isidor-card">
            <h3>Templates verwalten</h3>
            <p>Templates können im Frontend unter <strong>Verwaltung → Templates</strong> erstellt und bearbeitet werden. Die dort angelegten Templates erscheinen automatisch in der Vorlagen-Auswahl oben.</p>
        </div>
        <?php
    }
    
    /**
     * AJAX: Berechtigungen speichern
     */
    public function ajax_save_permissions(): void {
        check_ajax_referer('isidor_permissions', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        if (!$user_id) {
            wp_send_json_error(['message' => 'Kein Benutzer']);
        }
        
        // Template anwenden?
        if (!empty($_POST['template'])) {
            $tpl_key = sanitize_text_field($_POST['template']);
            
            // New template system (ID prefixed with "new_")
            if (str_starts_with($tpl_key, 'new_') && class_exists('Isidor_Permissions')) {
                $tpl_id = (int) substr($tpl_key, 4);
                $tpl = Isidor_Permissions::get_template($tpl_id);
                if ($tpl) {
                    // Apply permissions from new template to old table (bridge)
                    global $wpdb;
                    $wpdb->delete($this->table_name, ['user_id' => $user_id], ['%d']);
                    foreach ($tpl['permissions'] as $p) {
                        $wpdb->insert($this->table_name, [
                            'user_id'    => $user_id,
                            'app_slug'   => $p['module'],
                            'permission' => $p['permission'],
                        ]);
                    }
                    // Also assign the new template
                    Isidor_Permissions::assign_template($user_id, $tpl_id);
                }
                $this->clear_permission_cache($user_id);
                if (class_exists('Isidor_Permissions')) {
                    Isidor_Permissions::get_instance()->clear_cache($user_id);
                }
                wp_send_json_success(['message' => 'Vorlage angewendet: ' . ($tpl['name'] ?? $tpl_key)]);
            }
            
            // Old template system (fallback)
            $this->apply_role_template($user_id, $tpl_key);
            $this->clear_permission_cache($user_id);
            wp_send_json_success(['message' => 'Vorlage angewendet']);
        }

        // Manuelle Berechtigungen
        global $wpdb;

        // Alle löschen
        $wpdb->delete($this->table_name, ['user_id' => $user_id], ['%d']);

        // Neue setzen
        $permissions = $_POST['permissions'] ?? [];
        foreach ($permissions as $app => $perms) {
            foreach ($perms as $perm) {
                $this->grant_permission($user_id, sanitize_text_field($app), sanitize_text_field($perm));
            }
        }

        $this->clear_permission_cache($user_id);
        wp_send_json_success(['message' => 'Gespeichert']);
    }
    
    /**
     * AJAX: Berechtigungen laden
     */
    public function ajax_get_permissions(): void {
        check_ajax_referer('isidor_permissions', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        if (!$user_id) {
            wp_send_json_error(['message' => 'Kein Benutzer']);
        }
        
        $user = get_userdata($user_id);
        $permissions = $this->get_user_all_permissions($user_id);
        
        wp_send_json_success([
            'user_name'   => $user->display_name,
            'permissions' => $permissions,
        ]);
    }
    
    /**
     * Berechtigungen auf User-Profil anzeigen
     */
    public function show_user_permissions($user): void {
        if (!current_user_can('manage_options')) return;
        
        $permissions = $this->get_user_all_permissions($user->ID);
        ?>
        <h3>Isidor Berechtigungen</h3>
        <table class="form-table">
            <tr>
                <th>Apps</th>
                <td>
                    <?php if (empty($permissions)): ?>
                        <em>Keine Isidor-Berechtigungen</em>
                    <?php else: ?>
                        <?php foreach ($permissions as $app => $perms): 
                            $app_data = self::APPS[$app] ?? null;
                            if (!$app_data) continue;
                        ?>
                            <div style="margin-bottom:10px;">
                                <strong><?php echo esc_html($app_data['icon'] . ' ' . $app_data['name']); ?>:</strong>
                                <?php echo esc_html(implode(', ', $perms)); ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <p class="description">
                        <a href="<?php echo admin_url('admin.php?page=isidor-permissions'); ?>">
                            Berechtigungen verwalten →
                        </a>
                    </p>
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Handle form actions
     */
    public function handle_permission_actions(): void {
        // Hier können weitere Form-Actions verarbeitet werden
    }
}
