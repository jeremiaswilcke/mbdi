<?php
/**
 * Isidor App Shell
 * 
 * Übernimmt das gesamte Frontend-Rendering auf Isidor-Seiten:
 * - Erkennt Seiten mit Isidor-Shortcodes
 * - Injiziert App-Shell (Navigation, Header, Footer)
 * - Lädt alle nötigen CSS/JS Assets
 * - Login-Gate für geschützte Seiten
 * - Theme-Override für konsistentes Aussehen
 */

if (!defined('ABSPATH')) exit;

class Isidor_App_Shell {
    
    private static $instance = null;
    
    /**
     * Alle Isidor-Shortcodes die eine App-Shell bekommen
     */
    private const ISIDOR_SHORTCODES = [
        'liturgus_dashboard', 'liturgus_my_services', 'liturgus_schedule',
        'isidor_cellerar_app', 'isidor_cellerar_my_submissions', 'isidor_cellerar_submit_expense',
        'isidor_agenda_calendar', 'isidor_agenda_rooms', 'isidor_agenda_request_form', 'isidor_agenda_my_requests',
        'cantus_planner', 'cantus_songbook', 'cantus_search',
        'isidor_sakristan_dashboard',
        'isidor_tagesplan', 'isidor_tagesplan_heute', 'isidor_tagesplan_display',
        'isidor_poster',
        'isidor_user_manager', 'isidor_user_add',
        'isidor_permission_templates', 'isidor_permission_user', 'isidor_permission_services',
        'isidor_parish_settings',
        'isidor_communicator',
        'liturgia_planner',
        'isidor_consilium_app', 'isidor_consilium_vote',
    ];
    
    /**
     * App-Definitionen für Navigation
     * Icons: Moderne SVG-Icons (inline für Kontrolle)
     * Colors: Isidor Brand Palette
     */
    private const APPS = [
        'tagesplan' => [
            'label' => 'Tagesplan',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
            'shortcode' => 'isidor_tagesplan_heute',
            'color' => '#68b9b2',
        ],
        'liturgus' => [
            'label' => 'Dienste',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
            'shortcode' => 'liturgus_dashboard',
            'color' => '#68b9b2',
        ],
        'cantus' => [
            'label' => 'Lieder',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
            'shortcode' => 'cantus_planner',
            'color' => '#d97055',
        ],
        'agenda' => [
            'label' => 'Termine',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
            'shortcode' => 'isidor_agenda_calendar',
            'color' => '#68b9b2',
        ],
        'cellerar' => [
            'label' => 'Finanzen',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
            'shortcode' => 'isidor_cellerar_app',
            'color' => '#d97055',
        ],
        'sakristan' => [
            'label' => 'Sakristei',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>',
            'shortcode' => 'isidor_sakristan_dashboard',
            'color' => '#505050',
        ],
        'communicator' => [
            'label' => 'Nachrichten',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
            'shortcode' => 'isidor_communicator',
            'color' => '#68b9b2',
        ],
        'liturgia' => [
            'label' => 'Liturgia',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><line x1="12" y1="6" x2="12" y2="14"/><line x1="8" y1="10" x2="16" y2="10"/></svg>',
            'shortcode' => 'liturgia_planner',
            'color' => '#16a34a',
        ],
        'consilium' => [
            'label' => 'Sitzungen',
            'icon' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/><path d="M6 8h.01"/><path d="M10 8h.01"/><path d="M14 8h.01"/><path d="M18 8h.01"/><path d="M6 12h.01"/><path d="M10 12h.01"/><path d="M14 12h.01"/><path d="M18 12h.01"/></svg>',
            'shortcode' => 'isidor_consilium_app',
            'color' => '#16a34a',
        ],
        'parish' => [
            'label' => 'Pfarrei',
            'icon' => '⛪',
            'shortcode' => 'isidor_parish_settings',
            'color' => '#0891b2',
            'admin_only' => true,
        ],
        'verwaltung' => [
            'label' => 'Verwaltung',
            'icon' => '👥',
            'shortcode' => 'isidor_user_manager',
            'color' => '#6366f1',
            'admin_only' => true,
        ],
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue_assets']);
        add_filter('the_content', [$this, 'maybe_wrap_content'], 5);
        add_action('wp_head', [$this, 'maybe_add_meta']);
        add_shortcode('isidor_app_home', [$this, 'shortcode_app_home']);
        add_shortcode('isidor_login', [$this, 'shortcode_login']);
        
        // Eigenes Template für Isidor-Seiten – umgeht Theme-Chrome komplett
        add_filter('template_include', [$this, 'maybe_override_template'], 999);
        
        // Body-Class als Fallback für CSS-Targeting
        add_filter('body_class', [$this, 'add_body_class']);
        
        // wp-login.php → Isidor Login-Seite umleiten
        add_action('login_init', [$this, 'redirect_wp_login']);
        add_filter('login_url', [$this, 'filter_login_url'], 10, 2);
        add_filter('logout_redirect', [$this, 'filter_logout_redirect']);
        
        // Eingeloggte User von der Login-Seite wegleiten (vor Output!)
        // Priority 1 = before PVC (priority 10)
        add_action('template_redirect', [$this, 'redirect_logged_in_from_login'], 1);
        
        // Global loop breaker — stop PVC from blocking login page
        add_action('template_redirect', [$this, 'protect_login_page'], 0);
    }
    
    /**
     * wp-login.php → /app/anmelden/ umleiten
     * Lässt Admin-Zugriff und POST-Requests (echten Login) durch.
     */
    public function redirect_wp_login(): void {
        // POST-Requests durchlassen (der Login-Submit geht an wp-login.php)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') return;
        
        // Admin-spezifische Aktionen durchlassen (Passwort-Reset, Registrierung etc.)
        $action = sanitize_text_field($_GET['action'] ?? '');
        if (in_array($action, ['lostpassword', 'resetpass', 'rp', 'register', 'confirmaction', 'logout'], true)) {
            return;
        }
        
        // Prüfen ob Isidor-Login-Seite existiert
        $login_page = get_page_by_path('app/anmelden');
        if (!$login_page) return;
        
        $login_url = get_permalink($login_page);
        if (!$login_url) return;
        
        // redirect_to Parameter weiterleiten
        $redirect_to = !empty($_GET['redirect_to']) ? $_GET['redirect_to'] : '';
        
        // Prevent redirect loop: don't redirect_to the login page itself
        if ($redirect_to) {
            $login_path = wp_parse_url($login_url, PHP_URL_PATH);
            $redir_path = wp_parse_url($redirect_to, PHP_URL_PATH);
            if ($login_path && $redir_path && trailingslashit($login_path) === trailingslashit($redir_path)) {
                $redirect_to = ''; // Clear to avoid loop
            }
        }
        
        if ($redirect_to) {
            $login_url = add_query_arg('redirect_to', urlencode($redirect_to), $login_url);
        }
        
        wp_safe_redirect($login_url, 302);
        exit;
    }
    
    /**
     * login_url Filter → Isidor-Login statt wp-login.php
     */
    public function filter_login_url(string $login_url, string $redirect = ''): string {
        $login_page = get_page_by_path('app/anmelden');
        if (!$login_page) return $login_url;
        
        $url = get_permalink($login_page);
        if ($redirect) {
            $url = add_query_arg('redirect_to', urlencode($redirect), $url);
        }
        return $url;
    }
    
    /**
     * Nach Logout → Isidor Login-Seite statt wp-login.php?loggedout
     */
    public function filter_logout_redirect(): string {
        $login_page = get_page_by_path('app/anmelden');
        if ($login_page) {
            return add_query_arg('loggedout', '1', get_permalink($login_page));
        }
        return home_url('/');
    }
    
    /**
     * Global loop breaker — runs at priority 0 (before everything).
     * If we're on the login page and user is NOT logged in, remove PVC
     * access checks to prevent redirect loops. The login page must ALWAYS load.
     */
    public function protect_login_page(): void {
        if (!is_page()) return;
        
        $post = get_post();
        if (!$post) return;
        
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $slug = $post->post_name ?? '';
        $content = $post->post_content ?? '';
        
        $is_login = (
            has_shortcode($content, 'isidor_login') ||
            $slug === 'anmelden' ||
            str_contains($uri, '/anmelden')
        );
        
        if ($is_login && !is_user_logged_in()) {
            // Remove ALL template_redirect at priority 10 (where PVC runs)
            // This is safe: user is not logged in on login page, no other redirects needed
            remove_all_actions('template_redirect');
        }
    }

    /**
     * Eingeloggte User sofort von der Login-Seite wegleiten.
     * Läuft im template_redirect-Hook, also BEVOR irgendein Output gesendet wird.
     * Verhindert den weißen Flash nach dem Login.
     */
    public function redirect_logged_in_from_login(): void {
        if (!is_user_logged_in()) return;
        
        $post = get_post();
        if (!$post || !has_shortcode($post->post_content ?? '', 'isidor_login')) return;
        
        // Redirect-Ziel bestimmen
        $target = '';
        if (!empty($_GET['redirect_to'])) {
            $target = esc_url_raw(urldecode($_GET['redirect_to']));
        }
        
        // Prevent loop: don't redirect to login page
        $current_url = trailingslashit(get_permalink($post->ID));
        if ($target && trailingslashit($target) === $current_url) {
            $target = ''; // Would loop
        }
        
        if (!$target) {
            $home = $this->find_page_by_shortcode('isidor_app_home');
            $target = $home ? get_permalink($home->ID) : home_url('/app/');
        }
        
        // Final safety: if target is still the login page, go home
        if (trailingslashit($target) === $current_url) {
            $target = home_url('/');
        }
        
        wp_safe_redirect($target, 302);
        exit;
    }
    
    /**
     * Body-Class hinzufügen auf Isidor-Seiten
     */
    public function add_body_class(array $classes): array {
        if ($this->is_isidor_page()) {
            $classes[] = 'isidor-app';
            $classes[] = 'isidor-app--' . ($this->get_current_app() ?: 'home');
        }
        return $classes;
    }
    
    /**
     * Eigenes minimales Template laden auf Isidor-Seiten
     * Umgeht Theme-Header/Footer/Sidebar komplett
     */
    public function maybe_override_template(string $template): string {
        if (!$this->is_isidor_page() || is_admin()) {
            return $template;
        }
        
        // Display-Modus: Kein Shell, eigenes Minimal-Template
        $post = get_post();
        if ($post && has_shortcode($post->post_content, 'isidor_tagesplan_display')) {
            return $template; // Kein Override für Beamer-Display
        }
        
        // Prüfe ob unser Template existiert
        $isidor_template = ISIDOR_SUITE_PATH . 'templates/app-shell.php';
        if (file_exists($isidor_template)) {
            return $isidor_template;
        }
        
        return $template;
    }
    
    /**
     * Prüfe ob aktuelle Seite Isidor-Shortcodes enthält
     */
    private function is_isidor_page(): bool {
        if (!is_singular('page')) {
            return false;
        }
        
        $post = get_post();
        if (!$post) return false;
        
        foreach (self::ISIDOR_SHORTCODES as $sc) {
            if (has_shortcode($post->post_content, $sc)) {
                return true;
            }
        }
        
        // Auch App-Home und Login
        if (has_shortcode($post->post_content, 'isidor_app_home') ||
            has_shortcode($post->post_content, 'isidor_login')) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Aktuellen App-Key erkennen
     */
    private function get_current_app(): string {
        $post = get_post();
        if (!$post) return '';
        
        foreach (self::APPS as $key => $app) {
            if (has_shortcode($post->post_content, $app['shortcode'])) {
                return $key;
            }
        }
        
        // Auch Sub-Shortcodes checken
        $content = $post->post_content;
        if (str_contains($content, 'liturgus_')) return 'liturgus';
        if (str_contains($content, 'cellerar_') || str_contains($content, 'isidor_cellerar')) return 'cellerar';
        if (str_contains($content, 'agenda_') || str_contains($content, 'isidor_agenda')) return 'agenda';
        if (str_contains($content, 'cantus_')) return 'cantus';
        if (str_contains($content, 'liturgia_')) return 'liturgia';
        if (str_contains($content, 'sakristan')) return 'sakristan';
        if (str_contains($content, 'tagesplan')) return 'tagesplan';
        if (str_contains($content, 'isidor_user_') || str_contains($content, 'isidor_permission_')) return 'verwaltung';
        
        // Check by parent page (for sub-pages of verwaltung etc.)
        if ($post->post_parent) {
            $parent = get_post($post->post_parent);
            if ($parent) {
                foreach (self::APPS as $key => $app) {
                    if (has_shortcode($parent->post_content, $app['shortcode'])) {
                        return $key;
                    }
                }
            }
        }
        
        return '';
    }
    
    /**
     * Assets laden auf Isidor-Seiten
     */
    public function maybe_enqueue_assets(): void {
        if (!$this->is_isidor_page()) return;
        
        // Google Fonts – dynamisch aus Parish Settings
        $font_url = 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap';
        if (class_exists('Isidor_Parish_Settings')) {
            $theme = Isidor_Parish_Settings::css_custom_properties();
            if (!empty($theme['font_url'])) {
                $font_url = $theme['font_url'];
            }
        }
        
        wp_enqueue_style(
            'isidor-fonts',
            $font_url,
            [],
            null
        );
        
        // App Shell CSS
        wp_enqueue_style(
            'isidor-shell',
            ISIDOR_SUITE_URL . 'assets/css/isidor-shell.css',
            ['isidor-fonts'],
            ISIDOR_SUITE_VERSION
        );
        
        // Custom Color Properties (inline CSS override)
        if (class_exists('Isidor_Parish_Settings')) {
            $theme = Isidor_Parish_Settings::css_custom_properties();
            wp_add_inline_style('isidor-shell', $theme['css']);
        }
        
        // App Shell JS
        wp_enqueue_script(
            'isidor-shell',
            ISIDOR_SUITE_URL . 'assets/js/isidor-shell.js',
            [],
            ISIDOR_SUITE_VERSION,
            true
        );
        
        wp_localize_script('isidor-shell', 'isidorShell', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'homeUrl' => home_url('/'),
            'logoutUrl' => wp_logout_url(home_url('/')),
            'currentApp' => $this->get_current_app(),
            'user' => is_user_logged_in() ? [
                'name' => wp_get_current_user()->display_name,
                'initials' => $this->get_user_initials(),
            ] : null,
        ]);
    }
    
    /**
     * Meta-Tags für App-UX
     */
    public function maybe_add_meta(): void {
        if (!$this->is_isidor_page()) return;
        
        // Viewport – essentiell für responsive Verhalten
        echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' . "\n";
        
        $parish = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_bloginfo('name');
        echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
        echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr($parish) . '">' . "\n";
        $nav_bg = class_exists('Isidor_Parish_Settings') 
            ? (Isidor_Parish_Settings::get('color_nav_bg') ?: '#0f172a')
            : '#0f172a';
        echo '<meta name="theme-color" content="' . esc_attr($nav_bg) . '">' . "\n";
    }
    
    /**
     * Content in App-Shell wrappen
     */
    public function maybe_wrap_content(string $content): string {
        if (!$this->is_isidor_page() || is_admin()) {
            return $content;
        }
        
        // Display-Modus: Kein Shell, nur Content
        $post = get_post();
        if ($post && has_shortcode($post->post_content, 'isidor_tagesplan_display')) {
            return $content;
        }
        
        $current_app = $this->get_current_app();
        $nav_html = $this->render_navigation($current_app);
        $header_html = $this->render_header($current_app);
        $footer_html = $this->render_footer();
        $sub_nav_html = $this->render_sub_navigation($current_app);
        
        // Login-Gate
        if (!is_user_logged_in() && !has_shortcode($post->post_content ?? '', 'isidor_login')) {
            // redirect_to auf die aktuelle Seite setzen, damit der User
            // nach dem Login hierher zurückkommt (nicht zur Login-Seite)
            $_GET['redirect_to'] = $_GET['redirect_to'] ?? get_permalink();
            $content = $this->render_login_form();
            $sub_nav_html = ''; // Keine Sub-Nav bei Login
        }
        
        return '<div class="isidor-shell" data-app="' . esc_attr($current_app) . '">'
             . $header_html
             . '<div class="isidor-shell-body">'
             . $nav_html
             . '<main class="isidor-shell-main">' . $sub_nav_html . $content . $footer_html . '</main>'
             . '</div>'
             . $this->render_bottom_nav($current_app)
             . '</div>';
    }
    
    /**
     * Sub-Seiten Definitionen pro App (Shortcode → Label)
     * Wird für die Tab-Navigation im Frontend verwendet.
     */
    private const SUB_PAGES = [
        'agenda' => [
            ['shortcode' => 'isidor_agenda_calendar',     'label' => 'Kalender',       'icon' => '📅'],
            ['shortcode' => 'isidor_agenda_rooms',         'label' => 'Räume',          'icon' => '🏠'],
            ['shortcode' => 'isidor_agenda_request_form',  'label' => 'Termin anfragen','icon' => '➕'],
            ['shortcode' => 'isidor_agenda_my_requests',   'label' => 'Meine Anfragen', 'icon' => '📋'],
            ['shortcode' => 'isidor_poster',               'label' => 'Plakat',         'icon' => '🖼️'],
        ],
        'liturgus' => [
            ['shortcode' => 'liturgus_dashboard',     'label' => 'Übersicht',      'icon' => '⛪'],
            ['shortcode' => 'liturgus_my_services',   'label' => 'Meine Dienste',  'icon' => '👤'],
            ['shortcode' => 'liturgus_schedule',      'label' => 'Dienstplan',     'icon' => '📋'],
        ],
        'cellerar' => [
            ['shortcode' => 'isidor_cellerar_app',             'label' => 'Übersicht',          'icon' => '💰'],
            ['shortcode' => 'isidor_cellerar_submit_expense',  'label' => 'Ausgabe einreichen', 'icon' => '➕'],
            ['shortcode' => 'isidor_cellerar_my_submissions',  'label' => 'Meine Einreichungen','icon' => '📋'],
        ],
        'cantus' => [
            ['shortcode' => 'cantus_planner',  'label' => 'Lied-Planer', 'icon' => '🎵'],
            ['shortcode' => 'cantus_songbook', 'label' => 'Liederbuch',  'icon' => '📖'],
            ['shortcode' => 'cantus_search',   'label' => 'Suche',       'icon' => '🔍'],
        ],
        'verwaltung' => [
            ['shortcode' => 'isidor_user_manager', 'label' => 'Benutzer',        'icon' => '👥'],
            ['shortcode' => 'isidor_user_add',     'label' => 'Benutzer anlegen', 'icon' => '➕'],
            ['shortcode' => 'isidor_permission_templates', 'label' => 'Templates', 'icon' => '🔑'],
            ['shortcode' => 'isidor_permission_services',  'label' => 'Dienste',   'icon' => '⛪'],
        ],
    ];
    
    /**
     * Sub-Navigation (Tabs) rendern für die aktuelle App
     */
    private function render_sub_navigation(string $current_app): string {
        if (!isset(self::SUB_PAGES[$current_app])) {
            return '';
        }
        
        $tabs = self::SUB_PAGES[$current_app];
        $current_post = get_post();
        $current_content = $current_post ? $current_post->post_content : '';
        
        $html = '<nav class="isidor-sub-nav">';
        
        foreach ($tabs as $tab) {
            $page_id = $this->find_page_by_shortcode($tab['shortcode']);
            if (!$page_id) continue;
            
            $is_active = has_shortcode($current_content, $tab['shortcode']);
            
            $html .= '<a href="' . get_permalink($page_id) . '" class="isidor-sub-nav-item' . ($is_active ? ' active' : '') . '">';
            $html .= '<span class="isidor-sub-nav-icon">' . $tab['icon'] . '</span>';
            $html .= '<span class="isidor-sub-nav-label">' . esc_html($tab['label']) . '</span>';
            $html .= '</a>';
        }
        
        $html .= '</nav>';
        return $html;
    }
    
    /**
     * Header rendern
     */
    private function render_header(string $current_app): string {
        $parish_name = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_option('isidor_tagesplan_parish_name', get_bloginfo('name'));
        $logo_url = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::get('logo_url') 
            : get_option('isidor_tagesplan_logo_url', '');
        $user = wp_get_current_user();
        $app_info = self::APPS[$current_app] ?? null;
        
        $html = '<header class="isidor-shell-header">';
        $html .= '<div class="isidor-shell-header-inner">';
        
        // Left: Menu + Logo + Title
        $html .= '<div class="isidor-header-left">';
        $html .= '<button type="button" class="isidor-menu-toggle" id="isidor-menu-toggle" aria-label="Menü öffnen">';
        $html .= '<span></span><span></span><span></span>';
        $html .= '</button>';
        
        if ($logo_url) {
            $html .= '<img src="' . esc_url($logo_url) . '" alt="" class="isidor-header-logo">';
        }
        
        // Title: App-Name wenn in einer App, sonst Pfarrname
        if ($app_info) {
            $html .= '<h1 class="isidor-header-title"><span class="isidor-header-icon">' . $app_info['icon'] . '</span>' . esc_html($app_info['label']) . '</h1>';
        } else {
            $html .= '<h1 class="isidor-header-title">' . esc_html($parish_name) . '</h1>';
        }
        $html .= '</div>';
        
        // Right: User
        if (is_user_logged_in()) {
            $html .= '<div class="isidor-header-right">';
            $html .= '<span class="isidor-header-user-name">' . esc_html($user->display_name) . '</span>';
            $html .= '<div class="isidor-avatar" title="' . esc_attr($user->display_name) . '">';
            $html .= esc_html($this->get_user_initials());
            $html .= '</div>';
            $html .= '<a href="' . esc_url(wp_logout_url(home_url('/'))) . '" class="isidor-header-logout" title="Abmelden">⏻</a>';
            $html .= '</div>';
        }
        
        $html .= '</div></header>';
        
        return $html;
    }
    
    /**
     * Sidebar Navigation rendern
     */
    private function render_navigation(string $current_app): string {
        $suite = Isidor_Suite::get_instance();
        
        $html = '<nav class="isidor-shell-nav" id="isidor-shell-nav">';
        $html .= '<div class="isidor-nav-overlay" id="isidor-nav-overlay"></div>';
        $html .= '<div class="isidor-nav-panel">';
        
        // Parish name
        $parish = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_option('isidor_tagesplan_parish_name', get_bloginfo('name'));
        $logo_url = class_exists('Isidor_Parish_Settings')
            ? Isidor_Parish_Settings::get('logo_url')
            : '';
        $html .= '<div class="isidor-nav-brand">';
        if ($logo_url) {
            $html .= '<img src="' . esc_url($logo_url) . '" alt="" class="isidor-nav-brand-logo">';
        } else {
            $html .= '<span class="isidor-nav-brand-icon">⛪</span>';
        }
        $html .= '<span class="isidor-nav-brand-name">' . esc_html($parish) . '</span>';
        $html .= '</div>';
        
        $html .= '<div class="isidor-nav-items">';
        
        // Home
        $home_page = $this->find_page_by_shortcode('isidor_app_home');
        if ($home_page) {
            $html .= '<a href="' . get_permalink($home_page) . '" class="isidor-nav-item' . ($current_app === '' ? ' active' : '') . '">';
            $html .= '<span class="isidor-nav-icon">🏠</span>';
            $html .= '<span class="isidor-nav-label">Startseite</span>';
            $html .= '</a>';
        }
        
        foreach (self::APPS as $key => $app) {
            // Check ob Modul aktiv
            if (!$suite->is_module_active($key) && $key !== 'tagesplan' && $key !== 'verwaltung') {
                continue;
            }
            
            // Admin-only Apps nur für Berechtigte anzeigen
            if (!empty($app['admin_only']) && !$this->user_can_manage()) {
                continue;
            }
            
            $page_id = $this->find_page_by_shortcode($app['shortcode']);
            if (!$page_id) continue;
            
            $is_active = ($key === $current_app);
            
            $html .= '<a href="' . get_permalink($page_id) . '" class="isidor-nav-item' . ($is_active ? ' active' : '') . '" style="--nav-color: ' . $app['color'] . '">';
            $html .= '<span class="isidor-nav-icon">' . $app['icon'] . '</span>';
            $html .= '<span class="isidor-nav-label">' . esc_html($app['label']) . '</span>';
            $html .= '</a>';
        }
        
        $html .= '</div>';
        
        // Footer
        if (is_user_logged_in() && current_user_can('manage_options')) {
            $html .= '<div class="isidor-nav-footer">';
            $html .= '<a href="' . admin_url('admin.php?page=isidor-os') . '" class="isidor-nav-item isidor-nav-admin">';
            $html .= '<span class="isidor-nav-icon">⚙️</span>';
            $html .= '<span class="isidor-nav-label">Administration</span>';
            $html .= '</a>';
            $html .= '</div>';
        }
        
        $html .= '</div></nav>';
        
        return $html;
    }
    
    /**
     * Bottom Navigation für Mobile
     */
    private function render_bottom_nav(string $current_app): string {
        $suite = Isidor_Suite::get_instance();
        $html = '<nav class="isidor-bottom-nav">';
        
        // Home
        $home_page = $this->find_page_by_shortcode('isidor_app_home');
        if ($home_page) {
            $html .= '<a href="' . get_permalink($home_page) . '" class="isidor-bottom-item' . ($current_app === '' ? ' active' : '') . '">';
            $html .= '<span class="isidor-bottom-icon">🏠</span>';
            $html .= '<span class="isidor-bottom-label">Home</span>';
            $html .= '</a>';
        }
        
        // Max 4 Apps in Bottom-Nav
        $count = 0;
        foreach (self::APPS as $key => $app) {
            if ($count >= 4) break;
            if (!$suite->is_module_active($key) && $key !== 'tagesplan') continue;
            // Admin-only Apps nicht in Bottom-Nav (Platz ist begrenzt)
            if (!empty($app['admin_only'])) continue;
            
            $page_id = $this->find_page_by_shortcode($app['shortcode']);
            if (!$page_id) continue;
            
            $is_active = ($key === $current_app);
            
            $html .= '<a href="' . get_permalink($page_id) . '" class="isidor-bottom-item' . ($is_active ? ' active' : '') . '">';
            $html .= '<span class="isidor-bottom-icon">' . $app['icon'] . '</span>';
            $html .= '<span class="isidor-bottom-label">' . esc_html($app['label']) . '</span>';
            $html .= '</a>';
            
            $count++;
        }
        
        $html .= '</nav>';
        return $html;
    }
    
    /**
     * Footer rendern – zeigt Pfarrkontaktdaten
     */
    private function render_footer(): string {
        if (!class_exists('Isidor_Parish_Settings')) {
            return '';
        }
        
        $p = Isidor_Parish_Settings::get_all();
        
        // Nur rendern wenn mindestens IRGENDWAS ausgefüllt ist
        $has_data = $p['phone'] || $p['email'] || $p['street'] || $p['office_hours'] || $p['footer_text'];
        if (!$has_data) return '';
        
        $html = '<footer class="isidor-shell-footer">';
        $html .= '<div class="isidor-footer-inner">';
        
        // Spalte 1: Kontakt
        $has_contact = $p['street'] || $p['phone'] || $p['email'];
        if ($has_contact) {
            $html .= '<div class="isidor-footer-col">';
            $html .= '<div class="isidor-footer-heading">' . esc_html(Isidor_Parish_Settings::name()) . '</div>';
            
            if ($p['subtitle']) {
                $html .= '<div class="isidor-footer-subtitle">' . esc_html($p['subtitle']) . '</div>';
            }
            
            $addr = Isidor_Parish_Settings::address_oneline();
            if ($addr) {
                $html .= '<div class="isidor-footer-row">📍 ' . esc_html($addr) . '</div>';
            }
            if ($p['phone']) {
                $html .= '<div class="isidor-footer-row">📞 <a href="tel:' . esc_attr(preg_replace('/\s+/', '', $p['phone'])) . '">' . esc_html($p['phone']) . '</a></div>';
            }
            if ($p['email']) {
                $html .= '<div class="isidor-footer-row">✉️ <a href="mailto:' . esc_attr($p['email']) . '">' . esc_html($p['email']) . '</a></div>';
            }
            
            $html .= '</div>';
        }
        
        // Spalte 2: Öffnungszeiten
        if ($p['office_hours']) {
            $html .= '<div class="isidor-footer-col">';
            $html .= '<div class="isidor-footer-heading">Pfarrkanzlei</div>';
            $html .= '<div class="isidor-footer-row">' . nl2br(esc_html($p['office_hours'])) . '</div>';
            
            if ($p['pastor_name']) {
                $html .= '<div class="isidor-footer-row" style="margin-top: 8px;">';
                $html .= esc_html(($p['pastor_title'] ? $p['pastor_title'] . ': ' : '') . $p['pastor_name']);
                $html .= '</div>';
            }
            
            $html .= '</div>';
        }
        
        // Spalte 3: Bankdaten (nur wenn IBAN da)
        if ($p['iban']) {
            $html .= '<div class="isidor-footer-col">';
            $html .= '<div class="isidor-footer-heading">Bankverbindung</div>';
            if ($p['account_holder']) {
                $html .= '<div class="isidor-footer-row">' . esc_html($p['account_holder']) . '</div>';
            }
            $html .= '<div class="isidor-footer-row isidor-footer-mono">IBAN: ' . esc_html(Isidor_Parish_Settings::iban_formatted()) . '</div>';
            if ($p['bic']) {
                $html .= '<div class="isidor-footer-row isidor-footer-mono">BIC: ' . esc_html($p['bic']) . '</div>';
            }
            $html .= '</div>';
        }
        
        $html .= '</div>';
        
        // Custom Footer-Text
        if ($p['footer_text']) {
            $html .= '<div class="isidor-footer-custom">' . esc_html($p['footer_text']) . '</div>';
        }
        
        // Copyright
        $html .= '<div class="isidor-footer-copy">© ' . date('Y') . ' ' . esc_html(Isidor_Parish_Settings::name());
        if ($p['dvr_number']) {
            $html .= ' · DVR: ' . esc_html($p['dvr_number']);
        }
        $html .= '</div>';
        
        $html .= '</footer>';
        
        return $html;
    }
    
    /**
     * Login-Formular
     */
    private function render_login_form(): string {
        $parish = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_option('isidor_tagesplan_parish_name', get_bloginfo('name'));
        $logo_url = class_exists('Isidor_Parish_Settings')
            ? Isidor_Parish_Settings::get('logo_url')
            : '';
        
        // Redirect-Ziel: URL-Parameter > App-Startseite > Home
        $redirect = '';
        if (!empty($_GET['redirect_to'])) {
            $redirect = esc_url_raw(urldecode($_GET['redirect_to']));
        } else {
            // Immer zur App-Startseite, nie zur Login-Seite zurück
            $home_page = $this->find_page_by_shortcode('isidor_app_home');
            $redirect = $home_page ? get_permalink($home_page->ID) : home_url('/app/');
        }
        
        $html = '<div class="isidor-login-gate">';
        $html .= '<div class="isidor-login-card">';
        
        if ($logo_url) {
            $html .= '<img src="' . esc_url($logo_url) . '" alt="" class="isidor-login-logo">';
        } else {
            $html .= '<div class="isidor-login-brand">⛪</div>';
        }
        
        $html .= '<h2>' . esc_html($parish) . '</h2>';
        
        // Abmeldungs-Nachricht
        if (!empty($_GET['loggedout'])) {
            $html .= '<p class="isidor-login-notice">Sie wurden erfolgreich abgemeldet.</p>';
        } else {
            $html .= '<p>Bitte melden Sie sich an, um fortzufahren.</p>';
        }
        
        $html .= wp_login_form([
            'echo' => false,
            'redirect' => $redirect,
            'label_username' => 'Benutzername',
            'label_password' => 'Passwort',
            'label_remember' => 'Angemeldet bleiben',
            'label_log_in' => 'Anmelden',
        ]);
        
        $html .= '</div></div>';
        
        return $html;
    }
    
    /**
     * Shortcode: App-Startseite mit Kacheln
     */
    public function shortcode_app_home($atts): string {
        if (!is_user_logged_in()) {
            return ''; // Login-Gate greift über wrap
        }
        
        $user = wp_get_current_user();
        $parish = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_bloginfo('name');
        $suite = Isidor_Suite::get_instance();
        $hour = (int) current_time('G');
        
        if ($hour < 12) $greeting = 'Guten Morgen';
        elseif ($hour < 18) $greeting = 'Grüß Gott';
        else $greeting = 'Guten Abend';
        
        $html = '<div class="isidor-home">';
        
        // Welcome
        $html .= '<div class="isidor-home-welcome">';
        $html .= '<h2>' . $greeting . ', ' . esc_html($user->display_name) . '</h2>';
        $html .= '<p>' . esc_html(wp_date('l, j. F Y')) . '</p>';
        $html .= '</div>';
        
        // App Grid
        $html .= '<div class="isidor-home-grid">';
        
        foreach (self::APPS as $key => $app) {
            if (!$suite->is_module_active($key) && $key !== 'tagesplan' && $key !== 'verwaltung' && $key !== 'parish') continue;
            
            // Admin-only Apps nur für Berechtigte
            if (!empty($app['admin_only']) && !$this->user_can_manage()) continue;
            
            $page_id = $this->find_page_by_shortcode($app['shortcode']);
            if (!$page_id) continue;
            
            $html .= '<a href="' . get_permalink($page_id) . '" class="isidor-home-tile" style="--tile-color: ' . $app['color'] . '">';
            $html .= '<span class="isidor-tile-icon">' . $app['icon'] . '</span>';
            $html .= '<span class="isidor-tile-label">' . esc_html($app['label']) . '</span>';
            $html .= '</a>';
        }
        
        $html .= '</div>';
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * Shortcode: Login-Seite
     */
    public function shortcode_login($atts): string {
        // Wenn eingeloggt: Redirect wurde bereits in template_redirect erledigt,
        // hier nur Fallback-Text
        if (is_user_logged_in()) {
            return '<p>Sie sind bereits angemeldet. <a href="' . esc_url(home_url('/app/')) . '">Zur Startseite</a></p>';
        }
        
        return $this->render_login_form();
    }
    
    /**
     * Seite anhand eines Shortcodes finden
     */
    private function find_page_by_shortcode(string $shortcode){
        // Cache pro Request
        static $cache = [];
        if (isset($cache[$shortcode])) return $cache[$shortcode];
        
        global $wpdb;
        $page_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE %s 
             ORDER BY ID ASC LIMIT 1",
            '%[' . $shortcode . '%'
        ));
        
        $cache[$shortcode] = $page_id ? (int) $page_id : null;
        return $cache[$shortcode];
    }
    
    /**
     * User-Initialen berechnen
     */
    private function get_user_initials(): string {
        $user = wp_get_current_user();
        $name = $user->display_name;
        $parts = explode(' ', trim($name));
        
        if (count($parts) >= 2) {
            return mb_strtoupper(mb_substr($parts[0], 0, 1) . mb_substr(end($parts), 0, 1));
        }
        
        return mb_strtoupper(mb_substr($name, 0, 2));
    }
    
    /**
     * Prüft ob der aktuelle User Verwaltungs-Rechte hat
     * (Admin, Pfarrer Godmode, Sekretär, oder core:admin)
     */
    private function user_can_manage(): bool {
        if (!is_user_logged_in()) return false;
        if (current_user_can('manage_options')) return true;
        
        $user = wp_get_current_user();
        if (in_array('isidor_pfarrer_godmode', $user->roles, true)) return true;
        if (in_array('isidor_sekretaer', $user->roles, true)) return true;
        
        if (class_exists('Isidor_App_Permissions')) {
            return Isidor_App_Permissions::get_instance()->current_user_can('core', 'admin');
        }
        
        return false;
    }
}
