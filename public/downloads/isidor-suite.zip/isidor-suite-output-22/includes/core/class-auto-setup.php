<?php
/**
 * Isidor Auto Setup
 * 
 * Automatisches Anlegen aller benötigten Seiten für jede App.
 * Erstellt Hauptseiten und Unterseiten mit den richtigen Shortcodes.
 *
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) exit;

class Isidor_Auto_Setup {
    
    private static $instance = null;
    
    /**
     * Definition aller benötigten Seiten pro App
     */
    private const APP_PAGES = [
        'home' => [
            'parent' => [
                'title' => 'Startseite',
                'slug'  => 'app',
                'content' => '[isidor_app_home]',
                'menu_order' => 1,
            ],
            'children' => [
                [
                    'title' => 'Anmelden',
                    'slug'  => 'anmelden',
                    'content' => '[isidor_login]',
                ],
                [
                    'title' => 'Pfarrei-Einstellungen',
                    'slug'  => 'pfarrei',
                    'content' => '[isidor_parish_settings]',
                ],
            ],
        ],
        'liturgus' => [
            'parent' => [
                'title' => 'Dienste',
                'slug'  => 'dienste',
                'content' => '[liturgus_dashboard]',
                'menu_order' => 10,
            ],
            'children' => [
                [
                    'title' => 'Meine Dienste',
                    'slug'  => 'meine-dienste',
                    'content' => '[liturgus_my_services]',
                ],
                [
                    'title' => 'Dienstplan',
                    'slug'  => 'dienstplan',
                    'content' => '[liturgus_schedule]',
                ],
            ],
        ],
        'cellerar' => [
            'parent' => [
                'title' => 'Finanzen',
                'slug'  => 'finanzen',
                'content' => '[isidor_cellerar_app]',
                'menu_order' => 20,
            ],
            'children' => [
                [
                    'title' => 'Meine Einreichungen',
                    'slug'  => 'meine-einreichungen',
                    'content' => '[isidor_cellerar_my_submissions]',
                ],
                [
                    'title' => 'Ausgabe einreichen',
                    'slug'  => 'ausgabe-einreichen',
                    'content' => '[isidor_cellerar_submit_expense]',
                ],
            ],
        ],
        'agenda' => [
            'parent' => [
                'title' => 'Termine & Räume',
                'slug'  => 'termine',
                'content' => '[isidor_agenda_calendar]',
                'menu_order' => 30,
            ],
            'children' => [
                [
                    'title' => 'Raumübersicht',
                    'slug'  => 'raeume',
                    'content' => '[isidor_agenda_rooms]',
                ],
                [
                    'title' => 'Termin anfragen',
                    'slug'  => 'termin-anfragen',
                    'content' => '[isidor_agenda_request_form]',
                ],
                [
                    'title' => 'Meine Anfragen',
                    'slug'  => 'meine-anfragen',
                    'content' => '[isidor_agenda_my_requests]',
                ],
                [
                    'title' => 'Plakat-Designer',
                    'slug'  => 'plakat-generator',
                    'content' => '[isidor_poster]',
                ],
            ],
        ],
        'cantus' => [
            'parent' => [
                'title' => 'Liedplanung',
                'slug'  => 'liedplanung',
                'content' => '[cantus_planner]',
                'menu_order' => 40,
            ],
            'children' => [
                [
                    'title' => 'Liederbuch',
                    'slug'  => 'liederbuch',
                    'content' => '[cantus_songbook]',
                ],
                [
                    'title' => 'Liedsuche',
                    'slug'  => 'liedsuche',
                    'content' => '[cantus_search]',
                ],
            ],
        ],
        'sakristan' => [
            'parent' => [
                'title' => 'Sakristei',
                'slug'  => 'sakristei',
                'content' => '[isidor_sakristan_dashboard]',
                'menu_order' => 50,
            ],
            'children' => [],
        ],
        'tagesplan' => [
            'parent' => [
                'title' => 'Tagesplan',
                'slug'  => 'tagesplan',
                'content' => '[isidor_tagesplan_heute]',
                'menu_order' => 5,
            ],
            'children' => [
                [
                    'title' => 'Tagesplan Display',
                    'slug'  => 'tagesplan-display',
                    'content' => '[isidor_tagesplan_display]',
                ],
            ],
        ],
        'verwaltung' => [
            'parent' => [
                'title' => 'Verwaltung',
                'slug'  => 'verwaltung',
                'content' => '[isidor_user_manager]',
                'menu_order' => 90,
            ],
            'children' => [
                [
                    'title' => 'Benutzer anlegen',
                    'slug'  => 'benutzer-anlegen',
                    'content' => '[isidor_user_add]',
                ],
                [
                    'title' => 'Templates',
                    'slug'  => 'templates',
                    'content' => '[isidor_permission_templates]',
                ],
                [
                    'title' => 'Dienste',
                    'slug'  => 'dienste-verwaltung',
                    'content' => '[isidor_permission_services]',
                ],
            ],
        ],
        'communicator' => [
            'parent' => [
                'title' => 'Nachrichten',
                'slug'  => 'nachrichten',
                'content' => '[isidor_communicator]',
                'menu_order' => 85,
            ],
            'children' => [],
        ],
        'liturgia' => [
            'parent' => [
                'title' => 'Liturgia',
                'slug'  => 'liturgia',
                'content' => '[liturgia_planner]',
                'menu_order' => 55,
            ],
            'children' => [],
        ],
        'consilium' => [
            'parent' => [
                'title' => 'Sitzungen',
                'slug'  => 'sitzungen',
                'content' => '[isidor_consilium_app]',
                'menu_order' => 60,
            ],
            'children' => [
                [
                    'title' => 'Abstimmung',
                    'slug'  => 'abstimmung',
                    'content' => '[isidor_consilium_vote]',
                ],
            ],
        ],
    ];
    
    /**
     * Singleton
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu'], 90);
        add_action('admin_notices', [$this, 'show_setup_notice']);
        add_action('wp_ajax_isidor_auto_setup', [$this, 'ajax_run_setup']);
        add_action('wp_ajax_isidor_check_pages', [$this, 'ajax_check_pages']);
    }
    
    /**
     * Admin-Menü hinzufügen
     */
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Auto Setup',
            '🚀 Auto Setup',
            'manage_options',
            'isidor-setup',
            [$this, 'render_setup_page']
        );
    }
    
    /**
     * Setup-Hinweis anzeigen
     */
    public function show_setup_notice(): void {
        if (!isset($_GET['page']) || strpos($_GET['page'], 'isidor') === false) {
            return;
        }
        
        if ($_GET['page'] === 'isidor-setup') {
            return;
        }
        
        if (get_option('isidor_setup_completed')) {
            return;
        }
        
        $missing = $this->get_missing_pages();
        if (empty($missing)) {
            update_option('isidor_setup_completed', true);
            return;
        }
        
        ?>
        <div class="notice notice-info">
            <p>
                <strong>🚀 Isidor Auto Setup:</strong> 
                Es fehlen noch <?php echo count($missing); ?> Seiten für die volle Funktionalität.
                <a href="<?php echo admin_url('admin.php?page=isidor-setup'); ?>" class="button button-primary" style="margin-left:10px;">
                    Jetzt einrichten
                </a>
            </p>
        </div>
        <?php
    }
    
    /**
     * Setup-Seite rendern
     */
    public function render_setup_page(): void {
        $missing_pages = $this->get_missing_pages();
        $existing_pages = $this->get_existing_pages();
        $nonce = wp_create_nonce('isidor_setup');
        ?>
        <div class="wrap">
            <h1>🚀 Isidor Auto Setup</h1>
            
            <div style="background: linear-gradient(135deg, #1a365d 0%, #2d3748 100%); color:#fff; padding:30px; border-radius:12px; margin:20px 0;">
                <h2 style="color:#fff; margin-top:0;">Willkommen bei Isidor Suite!</h2>
                <p style="font-size:1.1em; opacity:0.9;">
                    Das Auto Setup erstellt alle benötigten Seiten mit den richtigen Shortcodes automatisch.
                    Sie können danach in Ihr Menü eingebunden werden.
                </p>
            </div>
            
            <?php if (empty($missing_pages)): ?>
                <div class="notice notice-success" style="margin:20px 0;">
                    <p>✓ Alle Seiten sind bereits eingerichtet!</p>
                </div>
            <?php else: ?>
                <div class="notice notice-warning" style="margin:20px 0;">
                    <p><strong><?php echo count($missing_pages); ?> Seiten müssen noch erstellt werden.</strong></p>
                </div>
            <?php endif; ?>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:20px;">
                
                <!-- Fehlende Seiten -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top:0;">📋 Zu erstellende Seiten</h3>
                    
                    <?php if (empty($missing_pages)): ?>
                        <p style="opacity:0.7;">Alle Seiten sind vorhanden.</p>
                    <?php else: ?>
                        <table class="widefat" style="margin-top:15px;">
                            <thead>
                                <tr>
                                    <th>App</th>
                                    <th>Seite</th>
                                    <th>Shortcode</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($missing_pages as $page): ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($page['app']); ?></strong></td>
                                        <td>
                                            <?php echo esc_html($page['title']); ?>
                                            <?php if ($page['is_child']): ?>
                                                <small>(Unterseite)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><code><?php echo esc_html($page['shortcode']); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div style="margin-top:20px;">
                            <button type="button" class="button button-primary button-large" id="isidor-run-setup">
                                🚀 Alle Seiten jetzt erstellen
                            </button>
                            <span id="setup-status" style="margin-left:15px;"></span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Bestehende Seiten -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top:0;">✓ Vorhandene Seiten</h3>
                    
                    <?php if (empty($existing_pages)): ?>
                        <p style="opacity:0.7;">Noch keine Isidor-Seiten vorhanden.</p>
                    <?php else: ?>
                        <table class="widefat" style="margin-top:15px;">
                            <thead>
                                <tr>
                                    <th>Seite</th>
                                    <th>Aktionen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($existing_pages as $page): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html($page['title']); ?></strong>
                                            <br>
                                            <small><?php echo esc_url($page['url']); ?></small>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url($page['url']); ?>" target="_blank" class="button button-small">Ansehen</a>
                                            <a href="<?php echo esc_url($page['edit_url']); ?>" class="button button-small">Bearbeiten</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Menü-Hinweis -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-top:20px;">
                <h3 style="margin-top:0;">📌 Nächste Schritte</h3>
                <ol>
                    <li>Erstellen Sie alle fehlenden Seiten mit dem Button oben</li>
                    <li>Gehen Sie zu <a href="<?php echo admin_url('nav-menus.php'); ?>">Design → Menüs</a></li>
                    <li>Fügen Sie die Isidor-Seiten zu Ihrem Menü hinzu</li>
                    <li>Optional: Nutzen Sie <strong>Page Visibility Control</strong> um Seiten nur für bestimmte Rollen sichtbar zu machen</li>
                </ol>
            </div>
        </div>
        
        <script>
        jQuery(function($) {
            $('#isidor-run-setup').on('click', function() {
                var $btn = $(this);
                var $status = $('#setup-status');
                
                $btn.prop('disabled', true).text('Erstelle Seiten...');
                $status.html('<span style="color:#666;">⏳ Bitte warten...</span>');
                
                $.post(ajaxurl, {
                    action: 'isidor_auto_setup',
                    _wpnonce: '<?php echo $nonce; ?>'
                }, function(response) {
                    if (response.success) {
                        $status.html('<span style="color:green;">✓ ' + response.data.message + '</span>');
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        $status.html('<span style="color:red;">✗ ' + response.data.message + '</span>');
                        $btn.prop('disabled', false).text('🚀 Alle Seiten jetzt erstellen');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Fehlende Seiten ermitteln
     */
    private function get_missing_pages(): array {
        $missing = [];
        
        foreach (self::APP_PAGES as $app => $config) {
            if (!$this->page_exists_by_shortcode($config['parent']['content'])) {
                $missing[] = [
                    'app'       => ucfirst($app),
                    'title'     => $config['parent']['title'],
                    'slug'      => $config['parent']['slug'],
                    'shortcode' => $config['parent']['content'],
                    'is_child'  => false,
                ];
            }
            
            foreach ($config['children'] as $child) {
                if (!$this->page_exists_by_shortcode($child['content'])) {
                    $missing[] = [
                        'app'       => ucfirst($app),
                        'title'     => $child['title'],
                        'slug'      => $child['slug'],
                        'shortcode' => $child['content'],
                        'is_child'  => true,
                        'parent'    => $config['parent']['slug'],
                    ];
                }
            }
        }
        
        return $missing;
    }
    
    /**
     * Bestehende Seiten ermitteln
     */
    private function get_existing_pages(): array {
        $existing = [];
        
        foreach (self::APP_PAGES as $app => $config) {
            $shortcodes = [$config['parent']['content']];
            foreach ($config['children'] as $child) {
                $shortcodes[] = $child['content'];
            }
            
            foreach ($shortcodes as $shortcode) {
                $page = $this->find_page_by_shortcode($shortcode);
                if ($page) {
                    $existing[] = [
                        'id'       => $page->ID,
                        'title'    => $page->post_title,
                        'url'      => get_permalink($page->ID),
                        'edit_url' => get_edit_post_link($page->ID, 'raw'),
                    ];
                }
            }
        }
        
        return $existing;
    }
    
    /**
     * Prüfen ob Seite mit Shortcode existiert
     */
    private function page_exists_by_shortcode(string $shortcode): bool {
        return $this->find_page_by_shortcode($shortcode) !== null;
    }
    
    /**
     * Seite nach Shortcode finden
     */
    private function find_page_by_shortcode(string $shortcode): ?WP_Post {
        global $wpdb;
        
        preg_match('/\[(\w+)/', $shortcode, $matches);
        $shortcode_name = $matches[1] ?? '';
        
        if (empty($shortcode_name)) {
            return null;
        }
        
        $page = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE %s 
             LIMIT 1",
            '%[' . $wpdb->esc_like($shortcode_name) . '%'
        ));
        
        return $page ? new WP_Post($page) : null;
    }
    
    /**
     * AJAX: Setup ausführen
     */
    public function ajax_run_setup(): void {
        check_ajax_referer('isidor_setup', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $created = 0;
        $errors = [];
        
        foreach (self::APP_PAGES as $app => $config) {
            $parent_id = $this->create_page_if_missing(
                $config['parent']['title'],
                $config['parent']['slug'],
                $config['parent']['content'],
                0,
                $config['parent']['menu_order'] ?? 0
            );
            
            if (is_wp_error($parent_id)) {
                $errors[] = $parent_id->get_error_message();
            } elseif ($parent_id) {
                $created++;
            }
            
            foreach ($config['children'] as $child) {
                $actual_parent_id = 0;
                if ($parent_id && !is_wp_error($parent_id)) {
                    $actual_parent_id = $parent_id;
                } else {
                    $existing_parent = $this->find_page_by_shortcode($config['parent']['content']);
                    if ($existing_parent) {
                        $actual_parent_id = $existing_parent->ID;
                    }
                }
                
                $child_id = $this->create_page_if_missing(
                    $child['title'],
                    $child['slug'],
                    $child['content'],
                    $actual_parent_id
                );
                
                if (is_wp_error($child_id)) {
                    $errors[] = $child_id->get_error_message();
                } elseif ($child_id) {
                    $created++;
                }
            }
        }
        
        if (!empty($errors)) {
            wp_send_json_error(['message' => implode(', ', $errors)]);
        }
        
        update_option('isidor_setup_completed', true);
        
        wp_send_json_success([
            'message' => sprintf('%d Seiten wurden erstellt!', $created),
            'created' => $created,
        ]);
    }
    
    /**
     * Seite erstellen falls nicht vorhanden
     */
    private function create_page_if_missing(
        string $title, 
        string $slug, 
        string $content, 
        int $parent_id = 0,
        int $menu_order = 0
    ) {
        if ($this->page_exists_by_shortcode($content)) {
            return null;
        }
        
        $page_id = wp_insert_post([
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_parent'  => $parent_id,
            'menu_order'   => $menu_order,
            'post_author'  => get_current_user_id(),
        ], true);
        
        return $page_id;
    }
    
    /**
     * AJAX: Seiten-Status prüfen
     */
    public function ajax_check_pages(): void {
        check_ajax_referer('isidor_setup', '_wpnonce');
        
        $missing = $this->get_missing_pages();
        $existing = $this->get_existing_pages();
        
        wp_send_json_success([
            'missing_count'  => count($missing),
            'existing_count' => count($existing),
            'missing'        => $missing,
            'existing'       => $existing,
        ]);
    }
    
    /**
     * Einzelne App-Seiten erstellen
     */
    public function setup_app(string $app): array {
        if (!isset(self::APP_PAGES[$app])) {
            return ['error' => 'Unbekannte App'];
        }
        
        $config = self::APP_PAGES[$app];
        $created = [];
        
        $parent_id = $this->create_page_if_missing(
            $config['parent']['title'],
            $config['parent']['slug'],
            $config['parent']['content'],
            0,
            $config['parent']['menu_order'] ?? 0
        );
        
        if ($parent_id && !is_wp_error($parent_id)) {
            $created[] = $config['parent']['title'];
        }
        
        $actual_parent_id = $parent_id ?: 0;
        if (!$actual_parent_id) {
            $existing = $this->find_page_by_shortcode($config['parent']['content']);
            if ($existing) {
                $actual_parent_id = $existing->ID;
            }
        }
        
        foreach ($config['children'] as $child) {
            $child_id = $this->create_page_if_missing(
                $child['title'],
                $child['slug'],
                $child['content'],
                $actual_parent_id
            );
            
            if ($child_id && !is_wp_error($child_id)) {
                $created[] = $child['title'];
            }
        }
        
        return ['created' => $created];
    }
    
    /**
     * Alle App-Seiten-Definitionen holen
     */
    public static function get_app_pages(): array {
        return self::APP_PAGES;
    }
}
