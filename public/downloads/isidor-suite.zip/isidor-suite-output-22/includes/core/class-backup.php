<?php


/**
 * Isidor Backup & Restore System
 * 
 * Features:
 * - Vollständiger Export aller Isidor-Daten
 * - Automatische Backups via WP-Cron
 * - Import/Restore-Funktion
 * - Migrations-Tool
 * - Backup-Rotation (alte Backups löschen)
 */

if (!defined('ABSPATH')) exit;

class Isidor_Backup {
    
    private static $instance = null;
    
    /** Alle Isidor-Tabellen (ohne Prefix) */
    private const TABLES = [
        'liturgus_slots',
        'liturgus_assignments',
        'liturgus_swaps',
        'isidor_cellerar_entries',
        'isidor_cellerar_expenses',
        'isidor_cellerar_files',
        'isidor_cellerar_audit',
        'cantus_songs',
        'cantus_catalog',
        'isidor_comm_rooms',
        'isidor_comm_participants',
        'isidor_comm_messages',
        'isidor_comm_read',
        'isidor_matrikel_cases',
        'isidor_matrikel_appointments',
        'isidor_matrikel_documents',
        'isidor_matrikel_fees',
        'isidor_agenda_series',
        'isidor_agenda_slots',
    ];
    
    /** Options die gesichert werden */
    private const OPTIONS = [
        'isidor_parish',
        'isidor_suite_modules',
        'isidor_suite_version',
        'isidor_messe_template',
        'isidor_tagesplan_template',
        'isidor_security_settings',
        'isidor_gdpr_settings',
        'isidor_backup_settings',
    ];
    
    private $backup_dir;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $upload_dir = wp_upload_dir();
        $this->backup_dir = $upload_dir['basedir'] . '/isidor-backups/';
        
        // Backup-Verzeichnis erstellen
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
            // .htaccess zum Schutz
            file_put_contents($this->backup_dir . '.htaccess', "Deny from all\n");
            file_put_contents($this->backup_dir . 'index.php', "<?php // Silence is golden");
        }
        
        add_action('admin_menu', [$this, 'add_admin_menu'], 30);
        add_action('admin_init', [$this, 'handle_actions']);
        
        // Cron für automatische Backups
        add_action('isidor_scheduled_backup', [$this, 'run_scheduled_backup']);
        
        if (!wp_next_scheduled('isidor_scheduled_backup')) {
            $settings = get_option('isidor_backup_settings', []);
            $schedule = $settings['schedule'] ?? 'daily';
            if ($schedule !== 'disabled') {
                wp_schedule_event(time(), $schedule, 'isidor_scheduled_backup');
            }
        }
    }
    
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Backup & Restore',
            '💾 Backup',
            'manage_options',
            'isidor-backup',
            [$this, 'render_admin_page']
        );
    }
    
    public function handle_actions(): void {
        if (!current_user_can('manage_options')) return;
        
        // Manuelles Backup erstellen
        if (isset($_POST['isidor_create_backup']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_backup')) {
            $result = $this->create_backup();
            if ($result['success']) {
                $filename = $result['filename'];
                add_action('admin_notices', function() use ($filename) {
                    printf('<div class="notice notice-success"><p>✓ Backup erstellt: %s</p></div>', esc_html($filename));
                });
            } else {
                $error = $result['error'];
                add_action('admin_notices', function() use ($error) {
                    printf('<div class="notice notice-error"><p>Fehler: %s</p></div>', esc_html($error));
                });
            }
        }
        
        // Backup herunterladen
        if (isset($_GET['isidor_download_backup']) && wp_verify_nonce($_GET['_wpnonce'], 'isidor_download')) {
            $this->download_backup(sanitize_file_name($_GET['isidor_download_backup']));
        }
        
        // Backup löschen
        if (isset($_POST['isidor_delete_backup']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_delete_backup')) {
            $filename = sanitize_file_name($_POST['backup_file']);
            $this->delete_backup($filename);
        }
        
        // Backup wiederherstellen
        if (isset($_POST['isidor_restore_backup']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_restore')) {
            $filename = sanitize_file_name($_POST['backup_file']);
            $result = $this->restore_backup($filename);
            if ($result['success']) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-success"><p>✓ Backup erfolgreich wiederhergestellt!</p></div>';
                });
            } else {
                $error = $result['error'];
                add_action('admin_notices', function() use ($error) {
                    printf('<div class="notice notice-error"><p>Fehler: %s</p></div>', esc_html($error));
                });
            }
        }
        
        // Import von Datei
        if (isset($_POST['isidor_import_backup']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_import')) {
            if (!empty($_FILES['backup_file']['tmp_name'])) {
                $result = $this->import_backup($_FILES['backup_file']['tmp_name']);
                if ($result['success']) {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-success"><p>✓ Import erfolgreich!</p></div>';
                    });
                }
            }
        }
        
        // Einstellungen speichern
        if (isset($_POST['isidor_save_backup_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_backup_settings')) {
            $settings = [
                'schedule' => sanitize_key($_POST['schedule'] ?? 'daily'),
                'retention' => (int)($_POST['retention'] ?? 7),
                'include_uploads' => !empty($_POST['include_uploads']),
                'encrypt' => !empty($_POST['encrypt']),
                'email_notify' => sanitize_email($_POST['email_notify'] ?? ''),
            ];
            update_option('isidor_backup_settings', $settings);
            
            // Cron neu planen
            wp_clear_scheduled_hook('isidor_scheduled_backup');
            if ($settings['schedule'] !== 'disabled') {
                wp_schedule_event(time(), $settings['schedule'], 'isidor_scheduled_backup');
            }
            
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success"><p>✓ Einstellungen gespeichert!</p></div>';
            });
        }
    }
    
    /**
     * Backup erstellen
     */
    public function create_backup(bool $scheduled = false): array {
        global $wpdb;
        
        $timestamp = current_time('Y-m-d_H-i-s');
        $filename = 'isidor-backup_' . $timestamp . '.json';
        $filepath = $this->backup_dir . $filename;
        
        $backup_data = [
            'version' => ISIDOR_SUITE_VERSION,
            'created_at' => current_time('mysql'),
            'site_url' => get_site_url(),
            'scheduled' => $scheduled,
            'tables' => [],
            'options' => [],
            'posts' => [],
            'postmeta' => [],
            'users' => [],
            'usermeta' => [],
        ];
        
        // 1. Custom Tables
        foreach (self::TABLES as $table) {
            $full_table = $wpdb->prefix . $table;
            if ($wpdb->get_var("SHOW TABLES LIKE '$full_table'") === $full_table) {
                $backup_data['tables'][$table] = $wpdb->get_results("SELECT * FROM $full_table", ARRAY_A);
            }
        }
        
        // 2. Options
        foreach (self::OPTIONS as $option) {
            $backup_data['options'][$option] = get_option($option);
        }
        
        // 3. Messen (CPT)
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'any',
        ]);
        foreach ($messen as $messe) {
            $backup_data['posts'][] = (array) $messe;
            $meta = get_post_meta($messe->ID);
            foreach ($meta as $key => $values) {
                foreach ($values as $value) {
                    $backup_data['postmeta'][] = [
                        'post_id' => $messe->ID,
                        'meta_key' => $key,
                        'meta_value' => $value,
                    ];
                }
            }
        }
        
        // 4. Agenda Events (CPT)
        $events = get_posts([
            'post_type' => 'isidor_agenda_event',
            'posts_per_page' => -1,
            'post_status' => 'any',
        ]);
        foreach ($events as $event) {
            $backup_data['posts'][] = (array) $event;
            $meta = get_post_meta($event->ID);
            foreach ($meta as $key => $values) {
                foreach ($values as $value) {
                    $backup_data['postmeta'][] = [
                        'post_id' => $event->ID,
                        'meta_key' => $key,
                        'meta_value' => $value,
                    ];
                }
            }
        }
        
        // 5. User-Meta (Isidor-relevante)
        $users = get_users(['fields' => 'ID']);
        foreach ($users as $user_id) {
            $permissions = get_user_meta($user_id, 'isidor_app_permissions', true);
            if ($permissions) {
                $backup_data['usermeta'][] = [
                    'user_id' => $user_id,
                    'meta_key' => 'isidor_app_permissions',
                    'meta_value' => $permissions,
                ];
            }
        }
        
        // Speichern
        $settings = get_option('isidor_backup_settings', []);
        $json = json_encode($backup_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        
        // Optional: Verschlüsselung
        if (!empty($settings['encrypt'])) {
            $json = $this->encrypt($json);
            $filename = str_replace('.json', '.enc', $filename);
            $filepath = $this->backup_dir . $filename;
        }
        
        if (file_put_contents($filepath, $json) === false) {
            return ['success' => false, 'error' => 'Konnte Datei nicht schreiben'];
        }
        
        // Rotation: Alte Backups löschen
        $this->rotate_backups();
        
        // E-Mail-Benachrichtigung
        if ($scheduled && !empty($settings['email_notify'])) {
            $parish_name = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : 'Isidor Suite';
            wp_mail(
                $settings['email_notify'],
                "[{$parish_name}] Backup erstellt",
                "Ein automatisches Backup wurde erstellt:\n\nDatei: {$filename}\nGröße: " . size_format(filesize($filepath)) . "\nZeit: " . current_time('d.m.Y H:i'),
                ['Content-Type: text/plain; charset=UTF-8']
            );
        }
        
        // Audit-Log
        $this->log_action('backup_created', ['filename' => $filename, 'scheduled' => $scheduled]);
        
        return ['success' => true, 'filename' => $filename, 'filepath' => $filepath];
    }
    
    /**
     * Backup wiederherstellen
     */
    public function restore_backup(string $filename): array {
        global $wpdb;
        
        $filepath = $this->backup_dir . $filename;
        if (!file_exists($filepath)) {
            return ['success' => false, 'error' => 'Datei nicht gefunden'];
        }
        
        $content = file_get_contents($filepath);
        
        // Entschlüsseln wenn nötig
        if (str_ends_with($filename, '.enc')) {
            $content = $this->decrypt($content);
            if ($content === false) {
                return ['success' => false, 'error' => 'Entschlüsselung fehlgeschlagen'];
            }
        }
        
        $data = json_decode($content, true);
        if (!$data) {
            return ['success' => false, 'error' => 'Ungültiges Backup-Format'];
        }
        
        // Vor Restore: Aktuelles Backup erstellen
        $this->create_backup();
        
        // 1. Tabellen leeren und neu befüllen
        foreach ($data['tables'] ?? [] as $table => $rows) {
            $full_table = $wpdb->prefix . $table;
            if ($wpdb->get_var("SHOW TABLES LIKE '$full_table'") === $full_table) {
                $wpdb->query("TRUNCATE TABLE $full_table");
                foreach ($rows as $row) {
                    $wpdb->insert($full_table, $row);
                }
            }
        }
        
        // 2. Options wiederherstellen
        foreach ($data['options'] ?? [] as $key => $value) {
            update_option($key, $value);
        }
        
        // 3. Posts (Messen, Events) - komplexer wegen ID-Mapping
        $id_map = [];
        foreach ($data['posts'] ?? [] as $post_data) {
            $old_id = $post_data['ID'];
            unset($post_data['ID']);
            
            // Prüfen ob Post existiert
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_title = %s AND post_date = %s",
                $post_data['post_type'], $post_data['post_title'], $post_data['post_date']
            ));
            
            if ($existing) {
                $new_id = (int) $existing;
                wp_update_post(array_merge($post_data, ['ID' => $new_id]));
            } else {
                $new_id = wp_insert_post($post_data);
            }
            
            $id_map[$old_id] = $new_id;
        }
        
        // 4. Post-Meta
        foreach ($data['postmeta'] ?? [] as $meta) {
            $new_post_id = $id_map[$meta['post_id']] ?? $meta['post_id'];
            update_post_meta($new_post_id, $meta['meta_key'], maybe_unserialize($meta['meta_value']));
        }
        
        // 5. User-Meta
        foreach ($data['usermeta'] ?? [] as $meta) {
            update_user_meta($meta['user_id'], $meta['meta_key'], maybe_unserialize($meta['meta_value']));
        }
        
        // Audit-Log
        $this->log_action('backup_restored', ['filename' => $filename]);
        
        // Cache leeren
        wp_cache_flush();
        
        return ['success' => true];
    }
    
    /**
     * Backup von Upload importieren
     */
    public function import_backup(string $tmp_file): array {
        $filename = 'isidor-import_' . current_time('Y-m-d_H-i-s') . '.json';
        $filepath = $this->backup_dir . $filename;
        
        if (!move_uploaded_file($tmp_file, $filepath)) {
            return ['success' => false, 'error' => 'Upload fehlgeschlagen'];
        }
        
        return $this->restore_backup($filename);
    }
    
    /**
     * Backup herunterladen
     */
    public function download_backup(string $filename): void {
        $filepath = $this->backup_dir . $filename;
        if (!file_exists($filepath)) {
            wp_die('Datei nicht gefunden');
        }
        
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }
    
    /**
     * Backup löschen
     */
    public function delete_backup(string $filename): bool {
        $filepath = $this->backup_dir . $filename;
        if (file_exists($filepath) && strpos($filename, 'isidor-backup') === 0) {
            $this->log_action('backup_deleted', ['filename' => $filename]);
            return unlink($filepath);
        }
        return false;
    }
    
    /**
     * Alte Backups rotieren
     */
    private function rotate_backups(): void {
        $settings = get_option('isidor_backup_settings', []);
        $retention = $settings['retention'] ?? 7;
        
        $files = glob($this->backup_dir . 'isidor-backup_*');
        if (count($files) <= $retention) return;
        
        // Nach Datum sortieren (älteste zuerst)
        usort($files, function($a, $b) { return filemtime($a) - filemtime($b); });
        
        // Überzählige löschen
        $to_delete = count($files) - $retention;
        for ($i = 0; $i < $to_delete; $i++) {
            unlink($files[$i]);
        }
    }
    
    /**
     * Geplantes Backup ausführen
     */
    public function run_scheduled_backup(): void {
        $this->create_backup(true);
    }
    
    /**
     * Verfügbare Backups auflisten
     */
    public function get_backups(): array {
        $files = glob($this->backup_dir . 'isidor-backup_*');
        $backups = [];
        
        foreach ($files as $file) {
            $filename = basename($file);
            $backups[] = [
                'filename' => $filename,
                'size' => filesize($file),
                'created' => filemtime($file),
                'encrypted' => str_ends_with($filename, '.enc'),
            ];
        }
        
        // Neueste zuerst
        usort($backups, function($a, $b) { return $b['created'] - $a['created']; });
        
        return $backups;
    }
    
    /**
     * Einfache Verschlüsselung (für echte Sicherheit: externes Modul nutzen)
     */
    private function encrypt(string $data): string {
        $key = wp_salt('auth');
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . '::' . $encrypted);
    }
    
    private function decrypt(string $data) {
        $key = wp_salt('auth');
        $parts = explode('::', base64_decode($data), 2);
        if (count($parts) !== 2) return false;
        return openssl_decrypt($parts[1], 'AES-256-CBC', $key, 0, $parts[0]);
    }
    
    /**
     * Aktion protokollieren
     */
    private function log_action(string $action, array $data = []): void {
        global $wpdb;
        
        // In Cellerar Audit-Log wenn verfügbar
        $audit_table = $wpdb->prefix . 'isidor_cellerar_audit';
        if ($wpdb->get_var("SHOW TABLES LIKE '$audit_table'") === $audit_table) {
            $wpdb->insert($audit_table, [
                'user_id' => get_current_user_id(),
                'action' => 'backup_' . $action,
                'object_type' => 'system',
                'object_id' => 0,
                'details' => json_encode($data),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'created_at' => current_time('mysql'),
            ]);
        }
    }
    
    /**
     * Admin-Seite rendern
     */
    public function render_admin_page(): void {
        $backups = $this->get_backups();
        $settings = get_option('isidor_backup_settings', [
            'schedule' => 'daily',
            'retention' => 7,
            'include_uploads' => false,
            'encrypt' => false,
            'email_notify' => '',
        ]);
        $next_scheduled = wp_next_scheduled('isidor_scheduled_backup');
        ?>
        <div class="wrap">
            <h1>💾 Backup & Restore</h1>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:20px;">
                <!-- Linke Spalte: Backups -->
                <div>
                    <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                        <h2 style="margin-top:0;">🔄 Jetzt sichern</h2>
                        <p>Erstellt ein vollständiges Backup aller Isidor-Daten.</p>
                        <form method="post">
                            <?php wp_nonce_field('isidor_backup'); ?>
                            <button type="submit" name="isidor_create_backup" class="button button-primary button-large">
                                💾 Backup jetzt erstellen
                            </button>
                        </form>
                    </div>
                    
                    <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                        <h2 style="margin-top:0;">📁 Vorhandene Backups</h2>
                        
                        <?php if (empty($backups)): ?>
                            <p style="opacity:0.7;">Noch keine Backups vorhanden.</p>
                        <?php else: ?>
                            <table class="widefat striped">
                                <thead>
                                    <tr>
                                        <th>Datei</th>
                                        <th>Größe</th>
                                        <th>Erstellt</th>
                                        <th>Aktionen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $backup): ?>
                                        <tr>
                                            <td>
                                                <?php echo esc_html($backup['filename']); ?>
                                                <?php if ($backup['encrypted']): ?>
                                                    <span title="Verschlüsselt">🔐</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo size_format($backup['size']); ?></td>
                                            <td><?php echo date('d.m.Y H:i', $backup['created']); ?></td>
                                            <td>
                                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=isidor-backup&isidor_download_backup=' . urlencode($backup['filename'])), 'isidor_download'); ?>" 
                                                   class="button button-small">⬇️ Download</a>
                                                
                                                <form method="post" style="display:inline;" onsubmit="return confirm('Backup wiederherstellen? Aktuelle Daten werden überschrieben!');">
                                                    <?php wp_nonce_field('isidor_restore'); ?>
                                                    <input type="hidden" name="backup_file" value="<?php echo esc_attr($backup['filename']); ?>">
                                                    <button type="submit" name="isidor_restore_backup" class="button button-small">🔄 Restore</button>
                                                </form>
                                                
                                                <form method="post" style="display:inline;" onsubmit="return confirm('Backup wirklich löschen?');">
                                                    <?php wp_nonce_field('isidor_delete_backup'); ?>
                                                    <input type="hidden" name="backup_file" value="<?php echo esc_attr($backup['filename']); ?>">
                                                    <button type="submit" name="isidor_delete_backup" class="button button-small" style="color:#dc2626;">🗑️</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        
                        <h3 style="margin-top:20px;">📤 Backup importieren</h3>
                        <form method="post" enctype="multipart/form-data">
                            <?php wp_nonce_field('isidor_import'); ?>
                            <input type="file" name="backup_file" accept=".json,.enc" required>
                            <button type="submit" name="isidor_import_backup" class="button">Importieren</button>
                        </form>
                    </div>
                </div>
                
                <!-- Rechte Spalte: Einstellungen -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h2 style="margin-top:0;">⚙️ Automatische Backups</h2>
                    
                    <?php if ($next_scheduled): ?>
                        <p style="background:#d1fae5; padding:10px; border-radius:6px;">
                            ✓ Nächstes Backup: <strong><?php echo date('d.m.Y H:i', $next_scheduled); ?></strong>
                        </p>
                    <?php endif; ?>
                    
                    <form method="post">
                        <?php wp_nonce_field('isidor_backup_settings'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th>Zeitplan</th>
                                <td>
                                    <select name="schedule">
                                        <option value="disabled" <?php selected($settings['schedule'], 'disabled'); ?>>Deaktiviert</option>
                                        <option value="hourly" <?php selected($settings['schedule'], 'hourly'); ?>>Stündlich</option>
                                        <option value="twicedaily" <?php selected($settings['schedule'], 'twicedaily'); ?>>2x täglich</option>
                                        <option value="daily" <?php selected($settings['schedule'], 'daily'); ?>>Täglich</option>
                                        <option value="weekly" <?php selected($settings['schedule'], 'weekly'); ?>>Wöchentlich</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>Aufbewahrung</th>
                                <td>
                                    <input type="number" name="retention" value="<?php echo esc_attr($settings['retention']); ?>" min="1" max="365" style="width:80px;">
                                    <span>Backups behalten</span>
                                </td>
                            </tr>
                            <tr>
                                <th>Verschlüsselung</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="encrypt" value="1" <?php checked($settings['encrypt']); ?>>
                                        Backups verschlüsseln (AES-256)
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th>E-Mail-Benachrichtigung</th>
                                <td>
                                    <input type="email" name="email_notify" value="<?php echo esc_attr($settings['email_notify']); ?>" placeholder="admin@pfarrei.at" style="width:250px;">
                                    <p class="description">Bei automatischen Backups benachrichtigen</p>
                                </td>
                            </tr>
                        </table>
                        
                        <p>
                            <button type="submit" name="isidor_save_backup_settings" class="button button-primary">
                                Einstellungen speichern
                            </button>
                        </p>
                    </form>
                    
                    <hr style="margin:20px 0;">
                    
                    <h3>📊 Backup-Inhalt</h3>
                    <ul style="list-style:disc; margin-left:20px;">
                        <li>Alle Messen & Termine</li>
                        <li>Dienstpläne & Zuweisungen</li>
                        <li>Finanzdaten (Cellerar)</li>
                        <li>Liedpläne & Liederbuch</li>
                        <li>Sakristei-Daten</li>
                        <li>Sakramentsfälle (Matrikel)</li>
                        <li>Chat-Nachrichten</li>
                        <li>Benutzerberechtigungen</li>
                        <li>Alle Einstellungen</li>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }
}
