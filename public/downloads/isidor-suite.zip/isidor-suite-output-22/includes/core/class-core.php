<?php
/**
 * Plugin Name: Pfarr Companion Core (Isidor Core OS)
 * Description: Messzentrierte Steuerungsapp (Core): Rollen (ohne Doppelrollen), CPT (isidor_messe), Wochen-Vorlage, Generator, Messen-Übersicht.
 * Version: 1.1.0
 * Author: Wilcke Worte & Visionen / Mariabrunn Digital
 */

if (!defined('ABSPATH')) exit;

final class Isidor_Core {
    const VERSION = '1.1.0';
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'register_isidor_post_types']);
        add_action('init', [$this, 'register_caps_for_admin']);
        add_action('admin_menu', [$this, 'isidor_main_menu']);
        add_action('admin_init', [$this, 'handle_isidor_logic']);
    }

    /* =========================================================
     *  ROLES & CAPS (ohne Doppelrollen)
     * ========================================================= */

    /** @return array<string, array{label:string, caps:array<string,bool>}> */
    private static function roles_spec(): array {
        return [
            'isidor_pfarrer' => [
                'label' => 'Pfarrer',
                'caps'  => array_merge(self::caps_all(), [
                    'create_users'            => true,
                    'edit_users'              => true,
                    'list_users'              => true,
                    'isidor_manage_templates' => true,
                    'isidor_assign_templates' => true,
                    'isidor_manage_users'     => true,
                ]),
            ],
            'isidor_sekretaer' => [
                'label' => 'Sekretär(in)',
                'caps'  => array_merge(self::caps_secretary(), [
                    'create_users'            => true,
                    'edit_users'              => true,
                    'list_users'              => true,
                    'isidor_manage_templates' => true,
                    'isidor_assign_templates' => true,
                    'isidor_manage_users'     => true,
                ]),
            ],
            'isidor_mitglied' => [
                'label' => 'Mitglied',
                'caps'  => [
                    'read' => true,
                ],
            ],
        ];
    }

    private static function caps_viewer(): array {
        return [
            'read' => true,
            'isidor_view' => true,
            'isidor_view_messes' => true,
        ];
    }

    private static function caps_viewer_plus(): array {
        return array_merge(self::caps_viewer(), [
            'isidor_view_reports' => true,
        ]);
    }

    private static function caps_secretary(): array {
        return array_merge(self::caps_viewer_plus(), [
            'isidor_manage_templates' => true,
            'isidor_generate_messes'  => true,
            'isidor_add_special_messe'=> true,
            'isidor_manage_messes'    => true,
        ]);
    }

    private static function caps_all(): array {
        return array_merge(self::caps_secretary(), [
            'isidor_admin' => true,
        ]);
    }

    /** Legacy Rollen, die wir loswerden wollen (WP-Core-Rollen nie anfassen). */
    private static function legacy_roles_to_remove(): array {
        return [
            'ministrant', 'mesner', 'diakon', 'pfarrer',
            'liturgen', 'liturg', 'kantor',
            'orgel', 'technik', 'orgel_technik', 'orgel/technik',
            'pfarrsekretaer', 'pfarrsekretär', 'sekretaer', 'sekretär',
            'pgr', 'vvr',
            'mitarbeiter',
            'isidor_pfarrer', 'isidor_liturg', 'isidor_mini',
            // v11 Rollen, die in v12 durch Templates ersetzt werden:
            'isidor_pfarrer_godmode',
            'isidor_diakon', 'isidor_liturg_kantor', 'isidor_mesner',
            'isidor_ministrant', 'isidor_mitarbeiter', 'isidor_ag_leiter',
            'isidor_pgr', 'isidor_vvr', 'isidor_orgel', 'isidor_technik',
        ];
    }

    /** Migration alt -> neu. */
    private static function legacy_role_map(): array {
        return [
            // v11 → v12
            'isidor_pfarrer_godmode' => 'isidor_pfarrer',
            // isidor_sekretaer bleibt isidor_sekretaer
            'isidor_diakon'          => 'isidor_mitglied',
            'isidor_liturg_kantor'   => 'isidor_mitglied',
            'isidor_mesner'          => 'isidor_mitglied',
            'isidor_ministrant'      => 'isidor_mitglied',
            'isidor_mitarbeiter'     => 'isidor_mitglied',
            'isidor_ag_leiter'       => 'isidor_mitglied',
            'isidor_pgr'             => 'isidor_mitglied',
            'isidor_vvr'             => 'isidor_mitglied',
            'isidor_orgel'           => 'isidor_mitglied',
            'isidor_technik'         => 'isidor_mitglied',

            // Alte Isidor-Varianten
            'isidor_pfarrer'     => 'isidor_pfarrer',
            'isidor_liturg'      => 'isidor_mitglied',
            'isidor_mini'        => 'isidor_mitglied',

            // Generische Rollen
            'pfarrer'            => 'isidor_pfarrer',
            'diakon'             => 'isidor_mitglied',
            'liturgen'           => 'isidor_mitglied',
            'liturg'             => 'isidor_mitglied',
            'kantor'             => 'isidor_mitglied',
            'mesner'             => 'isidor_mitglied',
            'ministrant'         => 'isidor_mitglied',
            'pfarrsekretaer'     => 'isidor_sekretaer',
            'pfarrsekretär'      => 'isidor_sekretaer',
            'sekretaer'          => 'isidor_sekretaer',
            'sekretär'           => 'isidor_sekretaer',
            'pgr'                => 'isidor_mitglied',
            'vvr'                => 'isidor_mitglied',
            'mitarbeiter'        => 'isidor_mitglied',
            'orgel'              => 'isidor_mitglied',
            'technik'            => 'isidor_mitglied',
            'orgel_technik'      => 'isidor_mitglied',
            'orgel/technik'      => 'isidor_mitglied',
            'orgel/technik'      => 'isidor_mitarbeiter',
        ];
    }

    public static function activate(): void {
        self::ensure_isidor_roles();
        self::migrate_users_from_legacy_roles();
        self::remove_legacy_roles();

        // CPT aktivieren + Rewrite
        self::get_instance()->register_isidor_post_types();
        flush_rewrite_rules();

        // Default Wochen-Vorlage (wie in deinem alten Core)
        if (!get_option('isidor_templates')) {
            $default_tpl = [
                'Sunday' => [
                    ['t' => 'Hochamt',   'z' => '10:00'],
                    ['t' => 'Frühmesse', 'z' => '08:00'],
                ],
                'Tuesday' => [
                    ['t' => 'Abendmesse', 'z' => '18:30'],
                ],
            ];
            update_option('isidor_templates', $default_tpl, false);
        }

        update_option('isidor_core_version', self::VERSION, false);
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    private static function ensure_isidor_roles(): void {
        $spec = self::roles_spec();
        foreach ($spec as $slug => $data) {
            if (get_role($slug)) remove_role($slug);
            add_role($slug, $data['label'], $data['caps']);
        }
    }

    private static function migrate_users_from_legacy_roles(): void {
        if (!function_exists('get_users')) return;

        $map = self::legacy_role_map();

        foreach ($map as $old_role => $new_role) {
            if (!get_role($old_role)) continue;
            if (!get_role($new_role)) continue;

            $users = get_users([
                'role'   => $old_role,
                'fields' => ['ID'],
                'number' => 9999,
            ]);

            foreach ($users as $u) {
                $user = new WP_User((int)$u->ID);

                // Admin bleibt Admin (und bekommt Caps ohnehin)
                if (in_array('administrator', (array)$user->roles, true)) continue;

                // exakt eine Rolle -> keine Doppelrollen
                $user->set_role($new_role);
            }
        }
    }

    private static function remove_legacy_roles(): void {
        $protected = ['administrator', 'editor', 'author', 'contributor', 'subscriber'];

        foreach (self::legacy_roles_to_remove() as $role_slug) {
            if (in_array($role_slug, $protected, true)) continue;
            if (!get_role($role_slug)) continue;

            // Nur löschen, wenn niemand mehr dran hängt
            $users = get_users([
                'role'   => $role_slug,
                'fields' => ['ID'],
                'number' => 1,
            ]);
            if (!empty($users)) continue;

            remove_role($role_slug);
        }
    }

    /**
     * Administrator kann immer alles Isidor-relevante tun (auch wenn er keine Isidor-Rolle hat)
     */
    public function register_caps_for_admin(): void {
        $admin = get_role('administrator');
        if (!$admin) return;

        $caps = [
            'isidor_view',
            'isidor_view_messes',
            'isidor_view_reports',
            'isidor_manage_templates',
            'isidor_generate_messes',
            'isidor_add_special_messe',
            'isidor_manage_messes',
            'isidor_admin',
        ];

        foreach ($caps as $cap) {
            if (!$admin->has_cap($cap)) $admin->add_cap($cap, true);
        }
    }

    /* =========================================================
     *  CPT (aus deinem alten Core übernommen)
     * ========================================================= */

    public function register_isidor_post_types(): void {
        register_post_type('isidor_messe', [
            'labels' => [
                'name'          => 'Gottesdienste',
                'singular_name' => 'Messe',
                'add_new_item'  => 'Neue Messe hinzufügen',
                'edit_item'     => 'Messe bearbeiten',
                'view_item'     => 'Messe ansehen',
            ],
            'public'       => true,
            'show_in_menu' => 'isidor-os',
            'supports'     => ['title', 'editor', 'custom-fields'],
            'menu_icon'    => 'dashicons-church',
        ]);
    }

    /* =========================================================
     *  Permissions-Helper
     * ========================================================= */

    private function can_manage_templates_and_generate(): bool {
        return current_user_can('isidor_manage_templates')
            || current_user_can('isidor_generate_messes')
            || current_user_can('isidor_admin')
            || current_user_can('manage_options');
    }

    private function can_add_special_messe(): bool {
        return current_user_can('isidor_add_special_messe')
            || current_user_can('isidor_admin')
            || current_user_can('manage_options');
    }

    /* =========================================================
     *  UI Helpers (Header)
     * ========================================================= */

    private function ui_header($title): void {
        ?>
        <div style="background:#fff; padding:20px; border-radius:12px; margin:20px 0; display:flex; align-items:center; gap:25px; border-left:6px solid #1a365d; box-shadow:0 4px 10px rgba(0,0,0,0.05);">
            <div style="background:#f0f4f8; padding:10px; border-radius:8px;">
                <svg width="50" height="50" viewBox="0 0 400 400">
                    <g fill="none" stroke="#1a365d" stroke-width="10" stroke-linecap="round">
                        <line x1="200" y1="80" x2="200" y2="260" />
                        <line x1="120" y1="150" x2="280" y2="150" />
                        <circle cx="200" cy="80" r="5" fill="#1a365d" stroke="none"/>
                        <circle cx="200" cy="260" r="5" fill="#1a365d" stroke="none"/>
                        <circle cx="120" cy="150" r="5" fill="#1a365d" stroke="none"/>
                        <circle cx="280" cy="150" r="5" fill="#1a365d" stroke="none"/>
                    </g>
                    <text x="200" y="340" font-family="Arial" font-size="50" font-weight="bold" fill="#1a365d" text-anchor="middle">ISIDOR</text>
                </svg>
            </div>
            <div>
                <h1 style="margin:0; color:#1a365d; font-size:2em;"><?php echo esc_html($title); ?></h1>
                <p style="margin:0; opacity:0.6;">Messzentrierte Pfarradministration – Core</p>
            </div>
        </div>
        <?php
    }

    /* =========================================================
     *  ZENTRALE LOGIK (Form-Posts)
     * ========================================================= */

    /* =========================================================
     *  LESUNGEN-IMPORT (eucharistiefeier.de API)
     * ========================================================= */
    
    /**
     * Holt Lesungen für einen Zeitraum von eucharistiefeier.de API.
     * Macht einen Request pro Monat (Fair-Use-konform).
     * 
     * @return array<string, array{L1:string,AP:string,L2:string,EV:string,Farbe:string,Datei:string}>
     *         Key = Datum (Y-m-d)
     */
    private function fetch_readings_for_range(string $from, string $to): array {
        // Diözese aus Parish Settings (leer = Deutscher Sprachraum allgemein)
        $diocese = '';
        if (class_exists('Isidor_Parish_Settings')) {
            $diocese = Isidor_Parish_Settings::get('diocese_calendar') ?: '';
        }
        
        $readings_map = [];
        
        // Monats-basierte Requests (Fair Use: ein Request pro menschlicher Aktion)
        $start = new DateTime($from);
        $end   = new DateTime($to);
        
        // Sammle alle benötigten Monate
        $months = [];
        $current = clone $start;
        while ($current <= $end) {
            $key = $current->format('Y-m');
            if (!isset($months[$key])) {
                $months[$key] = [
                    'year'  => (int) $current->format('Y'),
                    'month' => (int) $current->format('m'),
                ];
            }
            $current->modify('+1 day');
        }
        
        foreach ($months as $m) {
            $url = sprintf(
                'https://www.eucharistiefeier.de/lk/api.php?format=json&info=dtrlf&kal=%s&jahr=%d&monat=%d',
                rawurlencode($diocese),
                $m['year'],
                $m['month']
            );
            
            $response = wp_remote_get($url, [
                'timeout'   => 15,
                'sslverify' => true,
                'headers'   => [
                    'User-Agent' => 'IsidorSuite/2.0 (WordPress-Plugin; +https://isidor.at)',
                    'Accept'     => 'application/json',
                ],
            ]);
            
            if (is_wp_error($response)) {
                // Stille Fehlerbehandlung — Lesungen sind optional
                continue;
            }
            
            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200) continue;
            
            $body = wp_remote_retrieve_body($response);
            $json = json_decode($body, true);
            
            if (!is_array($json) || !isset($json['Zelebrationen'])) continue;
            
            foreach ($json['Zelebrationen'] as $entry) {
                $datum = $entry['Datum'] ?? '';
                if (!$datum) continue;
                
                // Nur Tage im angefragten Zeitraum übernehmen
                if ($datum < $from || $datum > $to) continue;
                
                // Wenn mehrere Zelebrationen pro Tag: die mit höchstem Rang gewinnt
                // (API liefert sie in Rang-Reihenfolge, erste ist die wichtigste)
                if (isset($readings_map[$datum])) continue;
                
                $readings_map[$datum] = [
                    'L1'    => $entry['L1'] ?? '',
                    'AP'    => $entry['AP'] ?? '',
                    'L2'    => $entry['L2'] ?? '',
                    'EV'    => $entry['EV'] ?? '',
                    'Farbe' => $entry['Farbe'] ?? '',
                    'Datei' => $entry['Datei'] ?? '',  // Schott-Link-Fragment
                    'Titel' => $entry['Tl'] ?? '',
                    'Rang'  => $entry['Rang'] ?? '',
                ];
            }
            
            // Kleine Pause zwischen Requests (Fair Use)
            if (count($months) > 1) {
                usleep(300000); // 300ms
            }
        }
        
        return $readings_map;
    }
    
    /**
     * Speichert Lesungs-Daten als Post-Meta für eine Messe.
     */
    private function save_readings_to_messe(int $post_id, array $readings): void {
        if (!empty($readings['L1'])) {
            update_post_meta($post_id, '_is_lesung1', sanitize_text_field($readings['L1']));
        }
        if (!empty($readings['AP'])) {
            update_post_meta($post_id, '_is_antwortpsalm', sanitize_text_field($readings['AP']));
        }
        if (!empty($readings['L2'])) {
            update_post_meta($post_id, '_is_lesung2', sanitize_text_field($readings['L2']));
        }
        if (!empty($readings['EV'])) {
            update_post_meta($post_id, '_is_evangelium', sanitize_text_field($readings['EV']));
        }
        if (!empty($readings['Farbe'])) {
            update_post_meta($post_id, '_is_lit_farbe', sanitize_text_field($readings['Farbe']));
        }
        if (!empty($readings['Datei'])) {
            $schott_url = 'https://www.erzabtei-beuron.de/schott/' . ltrim($readings['Datei'], '/');
            update_post_meta($post_id, '_is_schott_url', esc_url_raw($schott_url));
        }
    }

    /* =========================================================
     *  HANDLER – POST-Logik
     * ========================================================= */

    public function handle_isidor_logic(): void {
        if (!is_admin()) return;
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        if (!isset($_POST['isidor_nonce']) || !wp_verify_nonce($_POST['isidor_nonce'], 'isidor_action_nonce')) {
            return;
        }

        if (!current_user_can('read')) return;

        // A) Vorlage speichern
        if (isset($_POST['isidor_save_tpl'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');

            $raw_data = (isset($_POST['tpl']) && is_array($_POST['tpl'])) ? $_POST['tpl'] : [];
            $clean_tpl = [];

            $valid_days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

            foreach ($raw_data as $day => $entries) {
                $day = sanitize_text_field($day);
                if (!in_array($day, $valid_days, true)) continue;
                if (!is_array($entries)) continue;

                foreach ($entries as $entry) {
                    if (!is_array($entry)) continue;

                    $title = isset($entry['t']) ? sanitize_text_field($entry['t']) : '';
                    $time  = isset($entry['z']) ? sanitize_text_field($entry['z']) : '';

                    if ($title === '') continue;
                    if (!preg_match('/^\d{2}:\d{2}$/', $time)) $time = '';

                    $clean_tpl[$day][] = ['t' => $title, 'z' => $time];
                }
            }

            update_option('isidor_templates', $clean_tpl, false);
            wp_safe_redirect(admin_url('admin.php?page=isidor-template&status=saved'));
            exit;
        }

        // B) Zeitraum-Generator (mit automatischer liturgischer Benennung + Lesungen)
        if (isset($_POST['isidor_execute_gen_range'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');

            $from = isset($_POST['gen_from']) ? sanitize_text_field($_POST['gen_from']) : '';
            $to   = isset($_POST['gen_to']) ? sanitize_text_field($_POST['gen_to']) : '';
            $auto_name = !empty($_POST['gen_auto_liturgical']);
            $import_readings = !empty($_POST['gen_import_readings']);

            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
                wp_die('Ungültiger Zeitraum.');
            }

            try {
                $start = new DateTime($from);
                $end   = new DateTime($to);
            } catch (Exception $e) {
                wp_die('Datum konnte nicht verarbeitet werden.');
            }

            if ($end < $start) wp_die('Enddatum muss nach dem Startdatum liegen.');

            $templates = get_option('isidor_templates');
            if (!is_array($templates)) $templates = [];

            // Lesungen vorab für den gesamten Zeitraum holen (effizient: ein API-Call pro Monat)
            $readings_map = [];
            if ($import_readings) {
                $readings_map = $this->fetch_readings_for_range($from, $to);
            }

            $count = 0;
            $readings_count = 0;

            $end_inclusive = clone $end;
            $end_inclusive->modify('+1 day');

            foreach (new DatePeriod($start, new DateInterval('P1D'), $end_inclusive) as $date) {
                $day_of_week = $date->format('l');

                if (!isset($templates[$day_of_week]) || !is_array($templates[$day_of_week])) {
                    continue;
                }

                foreach ($templates[$day_of_week] as $tpl) {
                    $title = isset($tpl['t']) ? sanitize_text_field($tpl['t']) : '';
                    $time  = isset($tpl['z']) ? sanitize_text_field($tpl['z']) : '';

                    if ($title === '') continue;
                    if (!preg_match('/^\d{2}:\d{2}$/', $time)) $time = '';

                    $date_val = $date->format('Y-m-d');
                    
                    // Liturgischer Name
                    $liturgical = '';
                    if ($auto_name && class_exists('Isidor_Liturgical_Calendar')) {
                        $liturgical = Isidor_Liturgical_Calendar::short_name($date_val);
                    }
                    
                    // Titel zusammenbauen
                    if ($liturgical) {
                        $post_title = $liturgical . ' – ' . $title . ' (' . $date->format('d.m.') . ')';
                    } else {
                        $post_title = $title . ' (' . $date->format('d.m.') . ')';
                    }

                    // Duplikat-Check
                    $exists = new WP_Query([
                        'post_type'      => 'isidor_messe',
                        'posts_per_page' => 1,
                        'fields'         => 'ids',
                        'no_found_rows'  => true,
                        'meta_query'     => [
                            ['key' => '_is_date', 'value' => $date_val],
                            ['key' => '_is_time', 'value' => $time],
                        ],
                    ]);

                    if ($exists->have_posts()) continue;

                    $new_id = wp_insert_post([
                        'post_title'  => $post_title,
                        'post_type'   => 'isidor_messe',
                        'post_status' => 'publish',
                        'meta_input'  => [
                            '_is_date'       => $date_val,
                            '_is_time'       => $time,
                            '_is_template'   => 1,
                            '_is_liturgical' => $liturgical,
                            '_is_lektionar'  => class_exists('Isidor_Liturgical_Calendar') 
                                ? 'Lesejahr ' . Isidor_Liturgical_Calendar::reading_cycle((int)$date->format('Y'))
                                : '',
                        ],
                    ], true);

                    if (!is_wp_error($new_id) && $new_id) {
                        $count++;
                        
                        // Lesungen speichern wenn vorhanden
                        if ($import_readings && isset($readings_map[$date_val])) {
                            $this->save_readings_to_messe($new_id, $readings_map[$date_val]);
                            $readings_count++;
                        }
                    }
                }
            }

            $url = admin_url('admin.php?page=isidor-messen&status=gen_ok&count=' . intval($count) . '&readings=' . intval($readings_count) . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to));
            wp_safe_redirect($url);
            exit;
        }
        
        // C) Sondermessen erstellen (direkt aus Generator)
        if (isset($_POST['isidor_add_sondermessen'])) {
            if (!$this->can_add_special_messe()) wp_die('Keine Berechtigung.');
            
            $sonder = isset($_POST['sonder']) && is_array($_POST['sonder']) ? $_POST['sonder'] : [];
            $count = 0;
            
            foreach ($sonder as $entry) {
                $title = isset($entry['title']) ? sanitize_text_field($entry['title']) : '';
                $date  = isset($entry['date']) ? sanitize_text_field($entry['date']) : '';
                $time  = isset($entry['time']) ? sanitize_text_field($entry['time']) : '';
                
                if ($title === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) continue;
                if ($time && !preg_match('/^\d{2}:\d{2}$/', $time)) $time = '';
                
                $dt = new DateTime($date);
                $post_title = $title . ' (' . $dt->format('d.m.') . ')';
                
                $new_id = wp_insert_post([
                    'post_title'  => $post_title,
                    'post_type'   => 'isidor_messe',
                    'post_status' => 'publish',
                    'meta_input'  => [
                        '_is_date'     => $date,
                        '_is_time'     => $time,
                        '_is_template' => 0,
                        '_is_special'  => 1,
                    ],
                ], true);
                
                if (!is_wp_error($new_id) && $new_id) $count++;
            }
            
            wp_safe_redirect(admin_url('admin.php?page=isidor-messen&status=sonder_ok&count=' . $count));
            exit;
        }
        
        // D) Messen umbenennen (Inline)
        if (isset($_POST['isidor_rename_messen'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');
            
            $renames = isset($_POST['rename']) && is_array($_POST['rename']) ? $_POST['rename'] : [];
            $count = 0;
            
            foreach ($renames as $post_id => $new_title) {
                $post_id = (int) $post_id;
                $new_title = sanitize_text_field($new_title);
                if ($post_id <= 0 || $new_title === '') continue;
                
                $post = get_post($post_id);
                if (!$post || $post->post_type !== 'isidor_messe') continue;
                
                if ($post->post_title !== $new_title) {
                    wp_update_post(['ID' => $post_id, 'post_title' => $new_title]);
                    $count++;
                }
            }
            
            $redirect = admin_url('admin.php?page=isidor-messen&status=renamed&count=' . $count);
            if (!empty($_POST['filter_from'])) $redirect .= '&from=' . rawurlencode(sanitize_text_field($_POST['filter_from']));
            if (!empty($_POST['filter_to'])) $redirect .= '&to=' . rawurlencode(sanitize_text_field($_POST['filter_to']));
            wp_safe_redirect($redirect);
            exit;
        }
        
        // E) Auto-Benennung für bestehende Messen
        if (isset($_POST['isidor_auto_rename'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');
            if (!class_exists('Isidor_Liturgical_Calendar')) wp_die('Liturgischer Kalender nicht verfügbar.');
            
            $from = isset($_POST['auto_from']) ? sanitize_text_field($_POST['auto_from']) : '';
            $to   = isset($_POST['auto_to']) ? sanitize_text_field($_POST['auto_to']) : '';
            
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-01');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = date('Y-m-t');
            
            $q = new WP_Query([
                'post_type'      => 'isidor_messe',
                'posts_per_page' => 500,
                'fields'         => 'ids',
                'meta_query'     => [
                    ['key' => '_is_date', 'value' => [$from, $to], 'compare' => 'BETWEEN', 'type' => 'DATE'],
                ],
            ]);
            
            $count = 0;
            foreach ($q->posts as $post_id) {
                $date_val = get_post_meta($post_id, '_is_date', true);
                $liturgical = Isidor_Liturgical_Calendar::short_name($date_val);
                
                if (!$liturgical) continue;
                
                // Aktuellen Titel holen
                $current = get_the_title($post_id);
                
                // Schon korrekt benannt?
                if (str_starts_with($current, $liturgical)) continue;
                
                // Alten liturgischen Namen entfernen wenn vorhanden
                $clean_title = preg_replace('/^.*?\s–\s/', '', $current);
                $new_title = $liturgical . ' – ' . $clean_title;
                
                wp_update_post(['ID' => $post_id, 'post_title' => $new_title]);
                update_post_meta($post_id, '_is_liturgical', $liturgical);
                $count++;
            }
            
            wp_safe_redirect(admin_url('admin.php?page=isidor-messen&status=auto_ok&count=' . $count . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to)));
            exit;
        }
        
        // F) Ausgewählte Messen löschen (Checkbox-Auswahl)
        if (isset($_POST['isidor_delete_selected'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');
            
            $ids = isset($_POST['delete_ids']) && is_array($_POST['delete_ids']) ? $_POST['delete_ids'] : [];
            $count = 0;
            
            foreach ($ids as $post_id) {
                $post_id = (int) $post_id;
                if ($post_id <= 0) continue;
                
                $post = get_post($post_id);
                if (!$post || $post->post_type !== 'isidor_messe') continue;
                
                wp_delete_post($post_id, true); // true = force delete (kein Papierkorb)
                $count++;
            }
            
            $redirect = admin_url('admin.php?page=isidor-messen&status=deleted&count=' . $count);
            if (!empty($_POST['filter_from'])) $redirect .= '&from=' . rawurlencode(sanitize_text_field($_POST['filter_from']));
            if (!empty($_POST['filter_to'])) $redirect .= '&to=' . rawurlencode(sanitize_text_field($_POST['filter_to']));
            wp_safe_redirect($redirect);
            exit;
        }
        
        // G) Alle Messen im Zeitraum löschen
        if (isset($_POST['isidor_delete_range'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');
            
            $from = isset($_POST['del_from']) ? sanitize_text_field($_POST['del_from']) : '';
            $to   = isset($_POST['del_to']) ? sanitize_text_field($_POST['del_to']) : '';
            
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
                wp_die('Ungültiger Zeitraum.');
            }
            
            $q = new WP_Query([
                'post_type'      => 'isidor_messe',
                'posts_per_page' => 1000,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => [
                    ['key' => '_is_date', 'value' => [$from, $to], 'compare' => 'BETWEEN', 'type' => 'DATE'],
                ],
            ]);
            
            $count = 0;
            foreach ($q->posts as $post_id) {
                wp_delete_post($post_id, true);
                $count++;
            }
            
            wp_safe_redirect(admin_url('admin.php?page=isidor-messen&status=deleted&count=' . $count . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to)));
            exit;
        }
        
        // H) Lesungen nachträglich importieren (für bestehende Messen)
        if (isset($_POST['isidor_import_readings'])) {
            if (!$this->can_manage_templates_and_generate()) wp_die('Keine Berechtigung.');
            
            $from = isset($_POST['readings_from']) ? sanitize_text_field($_POST['readings_from']) : '';
            $to   = isset($_POST['readings_to']) ? sanitize_text_field($_POST['readings_to']) : '';
            $overwrite = !empty($_POST['readings_overwrite']);
            
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-01');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = date('Y-m-t');
            
            // Lesungen von API holen
            $readings_map = $this->fetch_readings_for_range($from, $to);
            
            if (empty($readings_map)) {
                wp_safe_redirect(admin_url('admin.php?page=isidor-messen&status=readings_ok&count=0&from=' . rawurlencode($from) . '&to=' . rawurlencode($to)));
                exit;
            }
            
            // Alle Messen im Zeitraum
            $q = new WP_Query([
                'post_type'      => 'isidor_messe',
                'posts_per_page' => 500,
                'fields'         => 'ids',
                'meta_query'     => [
                    ['key' => '_is_date', 'value' => [$from, $to], 'compare' => 'BETWEEN', 'type' => 'DATE'],
                ],
            ]);
            
            $count = 0;
            foreach ($q->posts as $post_id) {
                $date_val = get_post_meta($post_id, '_is_date', true);
                if (!$date_val || !isset($readings_map[$date_val])) continue;
                
                // Nicht überschreiben wenn Lesungen schon vorhanden (außer Checkbox gesetzt)
                if (!$overwrite) {
                    $existing_ev = get_post_meta($post_id, '_is_evangelium', true);
                    if (!empty($existing_ev)) continue;
                }
                
                $this->save_readings_to_messe($post_id, $readings_map[$date_val]);
                $count++;
            }
            
            wp_safe_redirect(admin_url('admin.php?page=isidor-messen&status=readings_ok&count=' . $count . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to)));
            exit;
        }
    }

    /* =========================================================
     *  MENÜS / UI
     * ========================================================= */

    public function isidor_main_menu(): void {
        add_menu_page(
            'Isidor OS',
            'Isidor OS',
            'read',
            'isidor-os',
            [$this, 'render_dashboard'],
            'dashicons-shield-alt',
            3
        );

        add_submenu_page(
            'isidor-os',
            'Wochen-Vorlage',
            '⚙️ Vorlage',
            'isidor_manage_templates',
            'isidor-template',
            [$this, 'render_template_view']
        );

        add_submenu_page(
            'isidor-os',
            'Generator',
            '📅 Generator',
            'isidor_generate_messes',
            'isidor-generator',
            [$this, 'render_generator_view']
        );

        add_submenu_page(
            'isidor-os',
            'Messen',
            '🗓️ Messen',
            'read',
            'isidor-messen',
            [$this, 'render_messen_view']
        );

        add_submenu_page(
            'isidor-os',
            'Rollen',
            '👥 Rollen-Check',
            'manage_options',
            'isidor-roles',
            [$this, 'render_roles_view']
        );
    }

    public function render_dashboard(): void {
        echo '<div class="wrap">';
        $this->ui_header("Zentrale");
        ?>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:16px;">

            <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
                <h3 style="margin-top:0;">⚙️ Wochen-Vorlage</h3>
                <p style="margin:0 0 10px 0; opacity:0.75;">Standardmäßig festlegen, an welchen Wochentagen welche Messen stattfinden (0..n).</p>
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=isidor-template')); ?>">Vorlage bearbeiten</a>
            </div>

            <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
                <h3 style="margin-top:0;">📅 Generator</h3>
                <p style="margin:0 0 10px 0; opacity:0.75;">Zeitraum auswählen und Messen nach der Vorlage generieren.</p>
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=isidor-generator')); ?>">Zum Generator</a>
            </div>

            <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
                <h3 style="margin-top:0;">🗓️ Messen</h3>
                <p style="margin:0 0 10px 0; opacity:0.75;">Alle erzeugten und manuell hinzugefügten Messen ansehen und filtern.</p>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=isidor-messen')); ?>">Messen ansehen</a>
                <?php if ($this->can_add_special_messe()): ?>
                    <a class="button" style="margin-left:8px;" href="<?php echo esc_url(admin_url('post-new.php?post_type=isidor_messe')); ?>">Sondermesse hinzufügen</a>
                <?php endif; ?>
            </div>

        </div>
        </div>
        <?php
    }

    public function render_template_view(): void {
        if (!$this->can_manage_templates_and_generate()) {
            wp_die('Keine Berechtigung.');
        }

        $tpls = get_option('isidor_templates');
        if (!is_array($tpls)) $tpls = [];

        $days = [
            'Monday'=>'Montag','Tuesday'=>'Dienstag','Wednesday'=>'Mittwoch',
            'Thursday'=>'Donnerstag','Friday'=>'Freitag','Saturday'=>'Samstag','Sunday'=>'Sonntag'
        ];

        echo '<div class="wrap">';
        $this->ui_header("Wochen-Vorlage (Standard)");

        if (isset($_GET['status']) && $_GET['status'] === 'saved') {
            echo "<div class='notice notice-success'><p><b>Vorlage gespeichert.</b> Künftige Generierungen verwenden diese Vorlage.</p></div>";
        }
        ?>
        <form method="post">
            <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
            <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap:20px;">
                <?php foreach ($days as $key => $label): ?>
                <div style="background:#fff; padding:15px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
                    <h3 style="border-bottom:2px solid #f0f4f8; padding-bottom:10px;"><?php echo esc_html($label); ?></h3>

                    <?php
                    if (isset($tpls[$key]) && is_array($tpls[$key])) {
                        foreach ($tpls[$key] as $i => $m) {
                            $t = isset($m['t']) ? esc_attr($m['t']) : '';
                            $z = isset($m['z']) ? esc_attr($m['z']) : '';
                            echo "<div style='margin-bottom:8px;'>
                                    <input name='tpl[".esc_attr($key)."][".esc_attr($i)."][t]' value='{$t}' placeholder='Titel' style='width:65%'>
                                    <input name='tpl[".esc_attr($key)."][".esc_attr($i)."][z]' value='{$z}' type='time' style='width:30%'>
                                  </div>";
                        }
                    } else {
                        echo "<p style='opacity:0.6; margin:0 0 10px 0;'>Keine Standardmesse an diesem Tag.</p>";
                    }
                    ?>

                    <div style="margin-top:15px; background:#f9f9f9; padding:10px; border-radius:5px;">
                        <input name="tpl[<?php echo esc_attr($key); ?>][new][t]" placeholder="+ Name" style="width:65%">
                        <input name="tpl[<?php echo esc_attr($key); ?>][new][z]" type="time" style="width:30%">
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top:30px; background:#1a365d; padding:20px; border-radius:12px; text-align:right;">
                <button type="submit" name="isidor_save_tpl" class="button button-primary button-large" style="background:#fff; color:#1a365d; border:none; font-weight:bold;">Wochen-Vorlage dauerhaft sichern</button>
            </div>
        </form>
        </div>
        <?php
    }

    public function render_generator_view(): void {
        if (!$this->can_manage_templates_and_generate()) {
            wp_die('Keine Berechtigung.');
        }

        echo '<div class="wrap">';
        $this->ui_header("Generator (Zeitraum)");

        $today = date('Y-m-d');
        $default_to = date('Y-m-d', strtotime('+2 months'));
        
        // Lesejahr
        $cycle = class_exists('Isidor_Liturgical_Calendar') 
            ? Isidor_Liturgical_Calendar::reading_cycle((int)date('Y')) : '?';
        ?>
        
        <!-- Batch-Generator -->
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:20px;">
        
        <div style="background:#fff; padding:22px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
            <h3 style="margin-top:0;">📅 Messen aus Vorlage generieren</h3>
            <p style="opacity:0.75; margin-top:0;">
                Zeitraum wählen → Isidor erzeugt alle Standardmessen aus der Wochen-Vorlage.
                Duplikate werden automatisch verhindert.
            </p>

            <form method="post">
                <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>

                <div style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:12px;">
                    <div style="flex:1; min-width:180px;">
                        <label><b>Von</b></label><br>
                        <input type="date" name="gen_from" value="<?php echo esc_attr($today); ?>" style="width:100%; padding:8px;">
                    </div>
                    <div style="flex:1; min-width:180px;">
                        <label><b>Bis</b></label><br>
                        <input type="date" name="gen_to" value="<?php echo esc_attr($default_to); ?>" style="width:100%; padding:8px;">
                    </div>
                </div>
                
                <label style="display:flex; align-items:center; gap:8px; padding:10px; background:#f0fdf4; border-radius:8px; margin-bottom:14px; cursor:pointer; border:1px solid #bbf7d0;">
                    <input type="checkbox" name="gen_auto_liturgical" value="1" checked style="width:18px; height:18px;">
                    <span>
                        <b>⛪ Automatisch liturgisch benennen</b><br>
                        <span style="font-size:0.85em; opacity:0.7;">Sonntage, Hochfeste, Feiertage werden automatisch erkannt (Lesejahr <?php echo esc_html($cycle); ?>)</span>
                    </span>
                </label>
                
                <label style="display:flex; align-items:center; gap:8px; padding:10px; background:#eff6ff; border-radius:8px; margin-bottom:14px; cursor:pointer; border:1px solid #bfdbfe;">
                    <input type="checkbox" name="gen_import_readings" value="1" checked style="width:18px; height:18px;">
                    <span>
                        <b>📖 Lesungen automatisch importieren</b><br>
                        <span style="font-size:0.85em; opacity:0.7;">1.&nbsp;Lesung, Antwortpsalm, 2.&nbsp;Lesung, Evangelium aus dem Lektionar
                        (<?php 
                            $diocese_labels = [
                                ''              => 'Deutscher Sprachraum',
                                'edw'           => 'Erzdiözese Wien',
                                'eds'           => 'Erzdiözese Salzburg',
                                'grazseckau'    => 'Diözese Graz-Seckau',
                                'linz'          => 'Diözese Linz',
                                'deutschland'   => 'Deutschland',
                                'koeln'         => 'Erzbistum Köln',
                                'muenchenfreising' => 'Erzbistum München-Freising',
                                'burger'        => 'Erzdiözese Freiburg',
                            ];
                            $d = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::get('diocese_calendar') : '';
                            echo esc_html($diocese_labels[$d] ?? ucfirst($d ?: 'Deutscher Sprachraum'));
                        ?>)</span>
                    </span>
                </label>

                <button type="submit" name="isidor_execute_gen_range" class="button button-primary button-large" style="height:44px; font-size:1.05em;">
                    🚀 Messen generieren
                </button>
            </form>
        </div>
        
        <!-- Sondermessen -->
        <div style="background:#fff; padding:22px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
            <h3 style="margin-top:0;">✨ Sondermessen hinzufügen</h3>
            <p style="opacity:0.75; margin-top:0;">
                Einzelne Messen direkt erstellen – z.B. Osternacht, Firmung, Patrozinium, Requiem.
            </p>
            
            <form method="post" id="sondermessen-form">
                <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
                
                <div id="sonder-entries">
                    <div class="sonder-row" style="display:flex; gap:8px; margin-bottom:8px; flex-wrap:wrap;">
                        <input type="text" name="sonder[0][title]" placeholder="Titel (z.B. Osternacht)" style="flex:2; min-width:200px; padding:8px;">
                        <input type="date" name="sonder[0][date]" value="<?php echo esc_attr($today); ?>" style="flex:1; min-width:140px; padding:8px;">
                        <input type="time" name="sonder[0][time]" style="width:100px; padding:8px;">
                    </div>
                </div>
                
                <div style="display:flex; gap:8px; margin-top:10px;">
                    <button type="button" onclick="isidorAddSonder()" class="button" style="height:36px;">
                        ➕ Weitere Messe
                    </button>
                    <button type="submit" name="isidor_add_sondermessen" class="button button-primary" style="height:36px;">
                        ✨ Sondermessen erstellen
                    </button>
                </div>
            </form>
            
            <div style="margin-top:14px; padding:10px; background:#fffbeb; border-radius:8px; border:1px solid #fde68a; font-size:0.88em;">
                <b>💡 Tipp:</b> Häufige Sondermessen: Osternacht, Christmette, Patrozinium, Firmung, Erstkommunion, Fronleichnamsprozession, Requiem, Maiandacht, Adventkranzsegnung
            </div>
        </div>
        
        </div>
        
        <!-- Auto-Rename bestehende Messen -->
        <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
            <h3 style="margin-top:0;">🔄 Bestehende Messen automatisch umbenennen</h3>
            <p style="opacity:0.75; margin-top:0; margin-bottom:12px;">
                Benennt bestehende Messen im gewählten Zeitraum mit dem korrekten liturgischen Namen.
                Bereits korrekt benannte Messen werden übersprungen.
            </p>
            <form method="post" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
                <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
                <div>
                    <label><b>Von</b></label><br>
                    <input type="date" name="auto_from" value="<?php echo esc_attr($today); ?>" style="padding:7px;">
                </div>
                <div>
                    <label><b>Bis</b></label><br>
                    <input type="date" name="auto_to" value="<?php echo esc_attr($default_to); ?>" style="padding:7px;">
                </div>
                <button type="submit" name="isidor_auto_rename" class="button" style="height:38px;">
                    🔄 Auto-Benennung starten
                </button>
            </form>
        </div>
        
        <!-- Lesungen nachträglich importieren -->
        <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05); margin-top:16px;">
            <h3 style="margin-top:0;">📖 Lesungen nachträglich importieren</h3>
            <p style="opacity:0.75; margin-top:0; margin-bottom:12px;">
                Importiert 1.&thinsp;Lesung, Antwortpsalm, 2.&thinsp;Lesung und Evangelium für bestehende Messen
                von <a href="https://www.eucharistiefeier.de/lk/" target="_blank">eucharistiefeier.de</a>.
                Messen, die bereits Lesungen haben, werden übersprungen (außer „Überschreiben" ist aktiviert).
            </p>
            <form method="post" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
                <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
                <div>
                    <label><b>Von</b></label><br>
                    <input type="date" name="readings_from" value="<?php echo esc_attr($today); ?>" style="padding:7px;">
                </div>
                <div>
                    <label><b>Bis</b></label><br>
                    <input type="date" name="readings_to" value="<?php echo esc_attr($default_to); ?>" style="padding:7px;">
                </div>
                <label style="display:flex; align-items:center; gap:5px; padding:7px 10px; background:#fef3c7; border-radius:6px; cursor:pointer; font-size:0.9em; height:38px; box-sizing:border-box;">
                    <input type="checkbox" name="readings_overwrite" value="1">
                    Bestehende überschreiben
                </label>
                <button type="submit" name="isidor_import_readings" class="button" style="height:38px;">
                    📖 Lesungen importieren
                </button>
            </form>
        </div>
        
        <script>
        var sonderIdx = 1;
        function isidorAddSonder() {
            var html = '<div class="sonder-row" style="display:flex; gap:8px; margin-bottom:8px; flex-wrap:wrap;">'
                + '<input type="text" name="sonder[' + sonderIdx + '][title]" placeholder="Titel" style="flex:2; min-width:200px; padding:8px;">'
                + '<input type="date" name="sonder[' + sonderIdx + '][date]" value="<?php echo esc_attr($today); ?>" style="flex:1; min-width:140px; padding:8px;">'
                + '<input type="time" name="sonder[' + sonderIdx + '][time]" style="width:100px; padding:8px;">'
                + '<button type="button" onclick="this.parentNode.remove()" class="button" style="color:#dc2626;" title="Entfernen">✕</button>'
                + '</div>';
            document.getElementById('sonder-entries').insertAdjacentHTML('beforeend', html);
            sonderIdx++;
        }
        </script>
        
        </div>
        <?php
    }

    public function render_messen_view(): void {
        echo '<div class="wrap">';
        $this->ui_header("Messen (Datenbank)");

        // Status-Meldungen
        if (isset($_GET['status'])) {
            $count = isset($_GET['count']) ? intval($_GET['count']) : 0;
            $readings_imported = isset($_GET['readings']) ? intval($_GET['readings']) : 0;
            
            $gen_msg = "✅ <b>Generiert:</b> {$count} neue Messen wurden angelegt.";
            if ($readings_imported > 0) {
                $gen_msg .= " 📖 Lesungen für {$readings_imported} Messen importiert.";
            }
            
            $msgs = [
                'gen_ok'    => $gen_msg,
                'sonder_ok' => "✨ <b>{$count} Sondermesse(n)</b> erfolgreich erstellt.",
                'renamed'   => "✏️ <b>{$count} Messe(n)</b> umbenannt.",
                'auto_ok'   => "🔄 <b>{$count} Messe(n)</b> automatisch liturgisch benannt.",
                'deleted'   => "🗑️ <b>{$count} Messe(n)</b> gelöscht.",
                'readings_ok' => "📖 Lesungen für <b>{$count} Messe(n)</b> importiert.",
            ];
            $key = sanitize_text_field($_GET['status']);
            if (isset($msgs[$key])) {
                echo "<div class='notice notice-success is-dismissible'><p>{$msgs[$key]}</p></div>";
            }
        }

        $from = isset($_GET['from']) ? sanitize_text_field($_GET['from']) : '';
        $to   = isset($_GET['to']) ? sanitize_text_field($_GET['to']) : '';

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-01');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = date('Y-m-t');

        $q = new WP_Query([
            'post_type'      => 'isidor_messe',
            'posts_per_page' => 200,
            'orderby'        => 'meta_value',
            'meta_key'       => '_is_date',
            'order'          => 'ASC',
            'meta_query'     => [
                [
                    'key'     => '_is_date',
                    'value'   => [$from, $to],
                    'compare' => 'BETWEEN',
                    'type'    => 'DATE',
                ],
            ],
        ]);
        
        $can_edit = $this->can_manage_templates_and_generate();
        $can_add = $this->can_add_special_messe();
        ?>
        
        <!-- Filter -->
        <div style="background:#fff; padding:18px; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05); margin-bottom:14px;">
            <form method="get" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
                <input type="hidden" name="page" value="isidor-messen">
                <div>
                    <label><b>Von</b></label><br>
                    <input type="date" name="from" value="<?php echo esc_attr($from); ?>" style="padding:7px;">
                </div>
                <div>
                    <label><b>Bis</b></label><br>
                    <input type="date" name="to" value="<?php echo esc_attr($to); ?>" style="padding:7px;">
                </div>
                <button class="button button-primary" type="submit" style="height:38px;">Filtern</button>
                
                <?php if ($can_add): ?>
                    <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=isidor-generator')); ?>" style="height:38px; display:inline-flex; align-items:center;">
                        ✨ Sondermesse / Generator
                    </a>
                <?php endif; ?>
                
                <span style="margin-left:auto; opacity:0.6; font-size:0.9em;">
                    <?php echo $q->found_posts; ?> Messen im Zeitraum
                    <?php if (class_exists('Isidor_Liturgical_Calendar')): ?>
                        · Lesejahr <?php echo Isidor_Liturgical_Calendar::reading_cycle((int)date('Y', strtotime($from))); ?>
                    <?php endif; ?>
                </span>
            </form>
        </div>

        <!-- Messen-Tabelle mit Inline-Edit -->
        <form method="post">
        <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
        <input type="hidden" name="filter_from" value="<?php echo esc_attr($from); ?>">
        <input type="hidden" name="filter_to" value="<?php echo esc_attr($to); ?>">
        
        <div style="background:#fff; padding:0; border-radius:12px; overflow:hidden; box-shadow:0 2px 15px rgba(0,0,0,0.05);">
            <table class="widefat fixed striped" style="margin:0;">
                <thead>
                    <tr>
                        <?php if ($can_edit): ?>
                        <th style="width:36px; text-align:center;">
                            <input type="checkbox" id="isidor-check-all" title="Alle auswählen" style="width:16px; height:16px;">
                        </th>
                        <?php endif; ?>
                        <th style="width:110px;">Datum</th>
                        <th style="width:55px;">Tag</th>
                        <th style="width:70px;">Zeit</th>
                        <th>Titel <?php if ($can_edit): ?><span style="font-weight:normal; opacity:0.5;">(klicken zum Bearbeiten)</span><?php endif; ?></th>
                        <th style="width:160px;">Liturgie</th>
                        <th style="width:100px;">Quelle</th>
                        <th style="width:80px;">Aktion</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if (!$q->have_posts()) {
                    echo '<tr><td colspan="' . ($can_edit ? 8 : 7) . '" style="padding:14px; opacity:0.7;">Keine Messen im gewählten Zeitraum.</td></tr>';
                } else {
                    $last_date = '';
                    $day_names_de = ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'];
                    
                    while ($q->have_posts()) {
                        $q->the_post();
                        $id = get_the_ID();

                        $d = get_post_meta($id, '_is_date', true);
                        $t = get_post_meta($id, '_is_time', true);
                        $is_tpl = get_post_meta($id, '_is_template', true);
                        $is_special = get_post_meta($id, '_is_special', true);
                        $liturgical = get_post_meta($id, '_is_liturgical', true);
                        $title = get_the_title($id);
                        
                        // Tag der Woche
                        $dt = new DateTime($d);
                        $dow = $day_names_de[(int)$dt->format('w')];
                        $is_sunday = ((int)$dt->format('w') === 0);
                        
                        // Liturgischer Name (live berechnen wenn nicht gespeichert)
                        if (!$liturgical && class_exists('Isidor_Liturgical_Calendar')) {
                            $liturgical = Isidor_Liturgical_Calendar::short_name($d);
                        }
                        
                        // Separator bei neuem Datum
                        $show_sep = ($d !== $last_date && $last_date !== '');
                        $last_date = $d;
                        
                        if ($show_sep) {
                            echo '<tr><td colspan="' . ($can_edit ? 8 : 7) . '" style="height:1px; padding:0; background:#e5e7eb;"></td></tr>';
                        }
                        
                        $row_bg = $is_sunday ? 'background:#f0f9ff;' : '';
                        $row_bg .= $is_special ? 'background:#fffbeb;' : '';

                        $edit_link = get_edit_post_link($id, '');

                        echo '<tr style="' . $row_bg . '">';
                        
                        // Checkbox
                        if ($can_edit) {
                            echo '<td style="padding:8px 4px; text-align:center;">';
                            echo '<input type="checkbox" name="delete_ids[]" value="' . $id . '" class="isidor-row-check" style="width:15px; height:15px;">';
                            echo '</td>';
                        }
                        
                        echo '<td style="padding:8px 10px; font-weight:500;">' . esc_html(date_i18n('d.m.Y', strtotime($d))) . '</td>';
                        echo '<td style="padding:8px 10px; font-size:0.88em; opacity:0.7;">' . esc_html(mb_substr($dow, 0, 2)) . '</td>';
                        echo '<td style="padding:8px 10px; font-family:monospace;">' . esc_html($t) . '</td>';
                        
                        // Titel (editierbar)
                        echo '<td style="padding:8px 10px;">';
                        if ($can_edit) {
                            echo '<input type="text" name="rename[' . $id . ']" value="' . esc_attr($title) . '" 
                                    style="width:100%; border:1px solid transparent; padding:4px 8px; border-radius:4px; background:transparent; font-size:0.92em;"
                                    onfocus="this.style.borderColor=\'#3b82f6\'; this.style.background=\'#fff\';"
                                    onblur="this.style.borderColor=\'transparent\'; this.style.background=\'transparent\';">';
                        } else {
                            echo '<b>' . esc_html($title) . '</b>';
                        }
                        echo '</td>';
                        
                        // Liturgie-Badge
                        echo '<td style="padding:8px 10px;">';
                        if ($liturgical) {
                            $badge_color = $is_sunday ? '#2563eb' : '#059669';
                            echo '<span style="display:inline-block; padding:2px 8px; border-radius:9999px; font-size:0.75em; font-weight:600; background:' . $badge_color . '15; color:' . $badge_color . ';">';
                            echo esc_html(mb_strimwidth($liturgical, 0, 28, '…'));
                            echo '</span>';
                        }
                        echo '</td>';
                        
                        // Quelle
                        echo '<td style="padding:8px 10px; font-size:0.85em;">';
                        if ($is_special) {
                            echo '<span style="color:#d97706;">✨ Sonder</span>';
                        } elseif ($is_tpl) {
                            echo '<span style="opacity:0.6;">📋 Vorlage</span>';
                        } else {
                            echo '<span style="opacity:0.4;">—</span>';
                        }
                        // Lesungs-Indikator
                        $has_readings = get_post_meta($post_id, '_is_evangelium', true);
                        if ($has_readings) {
                            echo ' <span title="Lesungen importiert" style="cursor:help;">📖</span>';
                        }
                        echo '</td>';
                        
                        echo '<td style="padding:8px 10px;"><a class="button" href="' . esc_url($edit_link) . '" style="font-size:0.85em;">Öffnen</a></td>';
                        echo '</tr>';
                    }
                    wp_reset_postdata();
                }
                ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($can_edit && $q->have_posts()): ?>
        <div style="margin-top:14px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <button type="submit" name="isidor_rename_messen" class="button button-primary" style="height:40px;">
                💾 Änderungen speichern
            </button>
            
            <button type="submit" name="isidor_delete_selected" class="button" 
                style="height:40px; color:#dc2626; border-color:#fca5a5;"
                onclick="var c=document.querySelectorAll('.isidor-row-check:checked'); if(!c.length){alert('Bitte zuerst Messen ankreuzen.');return false;} return confirm('Wirklich '+c.length+' Messe(n) unwiderruflich löschen?');">
                🗑️ Ausgewählte löschen <span id="isidor-delete-count"></span>
            </button>
            
            <span style="margin-left:auto; opacity:0.5; font-size:0.85em;">
                Tipp: Checkbox links anklicken um Messen zum Löschen auszuwählen
            </span>
        </div>
        <?php endif; ?>
        
        </form>
        
        <?php if ($can_edit): ?>
        <!-- Zeitraum löschen -->
        <details style="margin-top:16px;">
            <summary style="cursor:pointer; padding:12px 18px; background:#fff; border-radius:12px; box-shadow:0 2px 15px rgba(0,0,0,0.05); font-weight:600; color:#dc2626;">
                🗑️ Zeitraum komplett löschen…
            </summary>
            <div style="background:#fef2f2; padding:18px; border-radius:0 0 12px 12px; border:1px solid #fecaca; border-top:none;">
                <p style="margin:0 0 12px; color:#991b1b; font-size:0.92em;">
                    <b>⚠️ Achtung:</b> Löscht <b>alle</b> Messen im gewählten Zeitraum unwiderruflich (Vorlage + Sondermessen).
                </p>
                <form method="post" onsubmit="return confirm('ACHTUNG: Alle Messen zwischen den gewählten Daten werden unwiderruflich gelöscht. Fortfahren?');">
                    <?php wp_nonce_field('isidor_action_nonce', 'isidor_nonce'); ?>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
                        <div>
                            <label><b>Von</b></label><br>
                            <input type="date" name="del_from" value="<?php echo esc_attr($from); ?>" style="padding:7px;">
                        </div>
                        <div>
                            <label><b>Bis</b></label><br>
                            <input type="date" name="del_to" value="<?php echo esc_attr($to); ?>" style="padding:7px;">
                        </div>
                        <button type="submit" name="isidor_delete_range" class="button" style="height:38px; color:#dc2626; border-color:#fca5a5;">
                            🗑️ Zeitraum löschen
                        </button>
                    </div>
                </form>
            </div>
        </details>
        <?php endif; ?>
        
        <script>
        (function(){
            // Select all / deselect all
            var checkAll = document.getElementById('isidor-check-all');
            if (checkAll) {
                checkAll.addEventListener('change', function() {
                    var boxes = document.querySelectorAll('.isidor-row-check');
                    boxes.forEach(function(b){ b.checked = checkAll.checked; });
                    updateDeleteCount();
                });
            }
            
            // Count selected
            function updateDeleteCount() {
                var count = document.querySelectorAll('.isidor-row-check:checked').length;
                var el = document.getElementById('isidor-delete-count');
                if (el) el.textContent = count > 0 ? '(' + count + ')' : '';
            }
            
            document.querySelectorAll('.isidor-row-check').forEach(function(box) {
                box.addEventListener('change', updateDeleteCount);
            });
        })();
        </script>
        
        </div>
        <?php
    }

    public function render_roles_view(): void {
        echo '<div class="wrap">';
        $this->ui_header("Rollen-Matrix (Isidor)");

        $roles = wp_roles();
        $spec  = self::roles_spec();

        echo '<div style="background:#fff; padding:20px; border-radius:10px;">';
        echo '<p style="opacity:.75; margin-top:0;">Nur die <b>Isidor-*</b> Rollen sind relevant für den Core. Doppelrollen wurden entfernt.</p>';

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Rolle</th><th>Slug</th><th>Caps (Auszug)</th></tr></thead><tbody>';

        foreach ($spec as $slug => $data) {
            $caps = array_keys(array_filter($data['caps']));
            $caps_preview = esc_html(implode(', ', array_slice($caps, 0, 8)) . (count($caps) > 8 ? ' …' : ''));
            echo '<tr>';
            echo '<td><b>' . esc_html($data['label']) . '</b></td>';
            echo '<td><code>' . esc_html($slug) . '</code></td>';
            echo '<td style="opacity:.85;">' . $caps_preview . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        echo '<hr style="margin:18px 0;">';
        echo '<p style="margin:0;"><b>Hinweis:</b> Administrator hat alle Isidor-Caps automatisch (auch ohne Isidor-Rolle).</p>';
        echo '</div></div>';
    }
}


// Bootstrap wird von der Hauptdatei übernommen
