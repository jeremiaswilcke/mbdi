<?php


/**
 * Isidor DSGVO/GDPR Compliance Module
 * 
 * Features:
 * - Datenauskunft (Art. 15 DSGVO)
 * - Datenlöschung (Art. 17 DSGVO)
 * - Datenportabilität (Art. 20 DSGVO)
 * - Einwilligungsverwaltung
 * - Verarbeitungsverzeichnis
 * - Aufbewahrungsfristen & Auto-Löschung
 * - Audit-Log für alle Verarbeitungen
 */

if (!defined('ABSPATH')) exit;

class Isidor_GDPR {
    
    private static $instance = null;
    
    /** Daten-Kategorien mit Aufbewahrungsfristen (in Tagen) */
    public const DATA_CATEGORIES = [
        'messen' => [
            'label' => 'Messen & Gottesdienste',
            'retention' => 365 * 7, // 7 Jahre (Buchführungspflicht)
            'legal_basis' => 'Kirchliche Verwaltungspflicht',
        ],
        'dienste' => [
            'label' => 'Dienstpläne & Zuweisungen',
            'retention' => 365 * 2, // 2 Jahre
            'legal_basis' => 'Berechtigtes Interesse (Planung)',
        ],
        'finanzen' => [
            'label' => 'Finanzdaten',
            'retention' => 365 * 10, // 10 Jahre (Steuerrecht)
            'legal_basis' => 'Rechtliche Verpflichtung (BAO)',
        ],
        'matrikel' => [
            'label' => 'Sakramentsdaten',
            'retention' => 0, // Unbegrenzt (Kirchenrecht)
            'legal_basis' => 'Kirchenrechtliche Pflicht (CIC)',
        ],
        'kommunikation' => [
            'label' => 'Chat-Nachrichten',
            'retention' => 365, // 1 Jahr
            'legal_basis' => 'Einwilligung',
        ],
        'audit' => [
            'label' => 'Protokolldaten',
            'retention' => 365 * 3, // 3 Jahre
            'legal_basis' => 'Berechtigtes Interesse (Sicherheit)',
        ],
    ];
    
    /** Einwilligungstypen */
    public const CONSENT_TYPES = [
        'kommunikation' => [
            'label' => 'Kommunikation via Pfarr-Messenger',
            'description' => 'Ich willige ein, dass meine Nachrichten im internen Pfarr-Messenger verarbeitet werden.',
            'required' => false,
        ],
        'fotos' => [
            'label' => 'Fotos in Pfarrmedien',
            'description' => 'Ich willige ein, dass Fotos von mir in Pfarrblatt, Website und sozialen Medien veröffentlicht werden dürfen.',
            'required' => false,
        ],
        'email' => [
            'label' => 'E-Mail-Benachrichtigungen',
            'description' => 'Ich möchte per E-Mail über Dienstpläne, Termine und Pfarraktivitäten informiert werden.',
            'required' => false,
        ],
        'datenweitergabe' => [
            'label' => 'Datenweitergabe an Diözese',
            'description' => 'Ich willige ein, dass meine Kontaktdaten für kirchliche Zwecke an die Diözese weitergegeben werden.',
            'required' => false,
        ],
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu'], 31);
        add_action('admin_init', [$this, 'handle_actions']);
        
        // User-Seite für Datenauskunft
        add_shortcode('isidor_my_data', [$this, 'shortcode_my_data']);
        
        // WordPress Privacy Tools Integration
        add_filter('wp_privacy_personal_data_exporters', [$this, 'register_data_exporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'register_data_eraser']);
        
        // Cron für Auto-Löschung
        add_action('isidor_gdpr_cleanup', [$this, 'run_retention_cleanup']);
        if (!wp_next_scheduled('isidor_gdpr_cleanup')) {
            wp_schedule_event(time(), 'daily', 'isidor_gdpr_cleanup');
        }
    }
    
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Datenschutz',
            '🔒 Datenschutz',
            'manage_options',
            'isidor-gdpr',
            [$this, 'render_admin_page']
        );
    }
    
    public function handle_actions(): void {
        if (!current_user_can('manage_options')) return;
        
        // User-Daten exportieren
        if (isset($_POST['isidor_export_user_data']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_gdpr_export')) {
            $user_id = (int) $_POST['user_id'];
            $this->export_user_data($user_id);
        }
        
        // User-Daten löschen
        if (isset($_POST['isidor_delete_user_data']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_gdpr_delete')) {
            $user_id = (int) $_POST['user_id'];
            $categories = $_POST['categories'] ?? [];
            $result = $this->delete_user_data($user_id, $categories);
            $deleted_count = $result['deleted'];
            add_action('admin_notices', function() use ($deleted_count) {
                printf('<div class="notice notice-success"><p>%d Datensätze gelöscht.</p></div>', $deleted_count);
            });
        }
        
        // Einstellungen speichern
        if (isset($_POST['isidor_save_gdpr_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_gdpr_settings')) {
            $settings = [
                'dpo_name' => sanitize_text_field($_POST['dpo_name'] ?? ''),
                'dpo_email' => sanitize_email($_POST['dpo_email'] ?? ''),
                'privacy_page' => (int) ($_POST['privacy_page'] ?? 0),
                'auto_cleanup' => !empty($_POST['auto_cleanup']),
                'consent_required' => !empty($_POST['consent_required']),
            ];
            update_option('isidor_gdpr_settings', $settings);
            
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success"><p>✓ Datenschutz-Einstellungen gespeichert!</p></div>';
            });
        }
    }
    
    /**
     * Alle Daten eines Users sammeln
     */
    public function get_user_data(int $user_id): array {
        global $wpdb;
        $user = get_userdata($user_id);
        if (!$user) return [];
        
        $data = [
            'user' => [
                'id' => $user->ID,
                'email' => $user->user_email,
                'name' => $user->display_name,
                'registered' => $user->user_registered,
                'roles' => $user->roles,
            ],
            'permissions' => get_user_meta($user_id, 'isidor_app_permissions', true) ?: [],
            'consents' => get_user_meta($user_id, 'isidor_gdpr_consents', true) ?: [],
            'dienste' => [],
            'finanzen' => [],
            'kommunikation' => [],
            'matrikel' => [],
        ];
        
        // Liturgus Zuweisungen
        $assignments_table = $wpdb->prefix . 'liturgus_assignments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$assignments_table'") === $assignments_table) {
            $data['dienste'] = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $assignments_table WHERE user_id = %d", $user_id
            ), ARRAY_A);
        }
        
        // Cellerar Einträge
        $entries_table = $wpdb->prefix . 'isidor_cellerar_entries';
        if ($wpdb->get_var("SHOW TABLES LIKE '$entries_table'") === $entries_table) {
            $data['finanzen'] = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $entries_table WHERE created_by = %d", $user_id
            ), ARRAY_A);
        }
        
        // Communicator Nachrichten
        $messages_table = $wpdb->prefix . 'isidor_comm_messages';
        if ($wpdb->get_var("SHOW TABLES LIKE '$messages_table'") === $messages_table) {
            $data['kommunikation'] = $wpdb->get_results($wpdb->prepare(
                "SELECT id, room_id, message, created_at FROM $messages_table WHERE user_id = %d", $user_id
            ), ARRAY_A);
        }
        
        // Matrikel (als Ersteller)
        $matrikel_table = $wpdb->prefix . 'isidor_matrikel_cases';
        if ($wpdb->get_var("SHOW TABLES LIKE '$matrikel_table'") === $matrikel_table) {
            $data['matrikel'] = $wpdb->get_results($wpdb->prepare(
                "SELECT id, type, person_name, ceremony_date, created_at FROM $matrikel_table WHERE created_by = %d", $user_id
            ), ARRAY_A);
        }
        
        return $data;
    }
    
    /**
     * User-Daten als JSON exportieren
     */
    public function export_user_data(int $user_id): void {
        $data = $this->get_user_data($user_id);
        $user = get_userdata($user_id);
        
        $export = [
            'export_date' => current_time('mysql'),
            'exported_by' => wp_get_current_user()->display_name,
            'data_subject' => $user ? $user->display_name : "User #$user_id",
            'data' => $data,
        ];
        
        // Audit-Log
        $this->log_action('data_export', $user_id, ['exported_by' => get_current_user_id()]);
        
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="isidor-datenauskunft-' . $user_id . '-' . date('Y-m-d') . '.json"');
        echo json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * User-Daten löschen
     */
    public function delete_user_data(int $user_id, array $categories): array {
        global $wpdb;
        $deleted = 0;
        
        foreach ($categories as $category) {
            switch ($category) {
                case 'dienste':
                    $table = $wpdb->prefix . 'liturgus_assignments';
                    $deleted += $wpdb->delete($table, ['user_id' => $user_id]);
                    break;
                    
                case 'finanzen':
                    // Anonymisieren statt löschen (wegen Buchführungspflicht)
                    $table = $wpdb->prefix . 'isidor_cellerar_entries';
                    $wpdb->update($table, 
                        ['created_by' => 0, 'notes' => '[Anonymisiert auf Wunsch des Betroffenen]'],
                        ['created_by' => $user_id]
                    );
                    $deleted += $wpdb->rows_affected;
                    break;
                    
                case 'kommunikation':
                    $table = $wpdb->prefix . 'isidor_comm_messages';
                    // Soft-Delete
                    $deleted += $wpdb->update($table,
                        ['message' => '[Gelöscht]', 'deleted_at' => current_time('mysql')],
                        ['user_id' => $user_id]
                    );
                    break;
                    
                case 'permissions':
                    delete_user_meta($user_id, 'isidor_app_permissions');
                    $deleted++;
                    break;
                    
                case 'consents':
                    delete_user_meta($user_id, 'isidor_gdpr_consents');
                    $deleted++;
                    break;
            }
        }
        
        // Audit-Log
        $this->log_action('data_deletion', $user_id, ['categories' => $categories, 'deleted' => $deleted]);
        
        return ['deleted' => $deleted];
    }
    
    /**
     * Aufbewahrungsfristen prüfen und alte Daten löschen
     */
    public function run_retention_cleanup(): void {
        global $wpdb;
        $settings = get_option('isidor_gdpr_settings', []);
        
        if (empty($settings['auto_cleanup'])) return;
        
        $deleted_total = 0;
        
        // Chat-Nachrichten älter als 1 Jahr
        $messages_table = $wpdb->prefix . 'isidor_comm_messages';
        if ($wpdb->get_var("SHOW TABLES LIKE '$messages_table'") === $messages_table) {
            $retention = self::DATA_CATEGORIES['kommunikation']['retention'];
            $cutoff = date('Y-m-d H:i:s', strtotime("-{$retention} days"));
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM $messages_table WHERE created_at < %s AND deleted_at IS NOT NULL", $cutoff
            ));
            $deleted_total += $deleted;
        }
        
        // Alte Dienstplan-Zuweisungen (2 Jahre)
        $assignments_table = $wpdb->prefix . 'liturgus_assignments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$assignments_table'") === $assignments_table) {
            $retention = self::DATA_CATEGORIES['dienste']['retention'];
            $cutoff = date('Y-m-d', strtotime("-{$retention} days"));
            // Nur wenn Messe-Datum bekannt ist
            // (komplexere Logik nötig, hier vereinfacht)
        }
        
        // Audit-Log
        if ($deleted_total > 0) {
            $this->log_action('retention_cleanup', 0, ['deleted' => $deleted_total]);
        }
    }
    
    /**
     * Einwilligung speichern
     */
    public function save_consent(int $user_id, string $type, bool $granted): void {
        $consents = get_user_meta($user_id, 'isidor_gdpr_consents', true) ?: [];
        $consents[$type] = [
            'granted' => $granted,
            'date' => current_time('mysql'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ];
        update_user_meta($user_id, 'isidor_gdpr_consents', $consents);
        
        $this->log_action('consent_' . ($granted ? 'granted' : 'withdrawn'), $user_id, ['type' => $type]);
    }
    
    /**
     * Einwilligung prüfen
     */
    public function has_consent(int $user_id, string $type): bool {
        $consents = get_user_meta($user_id, 'isidor_gdpr_consents', true) ?: [];
        return !empty($consents[$type]['granted']);
    }
    
    /**
     * WordPress Privacy Tools: Exporter registrieren
     */
    public function register_data_exporter(array $exporters): array {
        $exporters['isidor-suite'] = [
            'exporter_friendly_name' => 'Isidor Suite',
            'callback' => [$this, 'wp_privacy_exporter'],
        ];
        return $exporters;
    }
    
    public function wp_privacy_exporter(string $email, int $page = 1): array {
        $user = get_user_by('email', $email);
        if (!$user) {
            return ['data' => [], 'done' => true];
        }
        
        $data = $this->get_user_data($user->ID);
        $export_items = [];
        
        // Berechtigungen
        if (!empty($data['permissions'])) {
            $export_items[] = [
                'group_id' => 'isidor_permissions',
                'group_label' => 'Isidor Berechtigungen',
                'item_id' => 'permissions-' . $user->ID,
                'data' => [
                    ['name' => 'Berechtigungen', 'value' => json_encode($data['permissions'])],
                ],
            ];
        }
        
        // Dienste
        foreach ($data['dienste'] as $dienst) {
            $export_items[] = [
                'group_id' => 'isidor_dienste',
                'group_label' => 'Isidor Dienste',
                'item_id' => 'dienst-' . $dienst['id'],
                'data' => [
                    ['name' => 'Dienst-ID', 'value' => $dienst['id']],
                    ['name' => 'Status', 'value' => $dienst['status'] ?? ''],
                ],
            ];
        }
        
        return [
            'data' => $export_items,
            'done' => true,
        ];
    }
    
    /**
     * WordPress Privacy Tools: Eraser registrieren
     */
    public function register_data_eraser(array $erasers): array {
        $erasers['isidor-suite'] = [
            'eraser_friendly_name' => 'Isidor Suite',
            'callback' => [$this, 'wp_privacy_eraser'],
        ];
        return $erasers;
    }
    
    public function wp_privacy_eraser(string $email, int $page = 1): array {
        $user = get_user_by('email', $email);
        if (!$user) {
            return ['items_removed' => 0, 'items_retained' => 0, 'messages' => [], 'done' => true];
        }
        
        $result = $this->delete_user_data($user->ID, ['dienste', 'kommunikation', 'permissions', 'consents']);
        
        return [
            'items_removed' => $result['deleted'],
            'items_retained' => 0,
            'messages' => ['Finanzdaten wurden anonymisiert statt gelöscht (gesetzliche Aufbewahrungspflicht).'],
            'done' => true,
        ];
    }
    
    /**
     * Aktion protokollieren
     */
    private function log_action(string $action, int $user_id, array $data = []): void {
        global $wpdb;
        
        $audit_table = $wpdb->prefix . 'isidor_cellerar_audit';
        if ($wpdb->get_var("SHOW TABLES LIKE '$audit_table'") === $audit_table) {
            $wpdb->insert($audit_table, [
                'user_id' => get_current_user_id(),
                'action' => 'gdpr_' . $action,
                'object_type' => 'user',
                'object_id' => $user_id,
                'details' => json_encode($data),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'created_at' => current_time('mysql'),
            ]);
        }
    }
    
    /**
     * Shortcode: Meine Daten (für User-Seite)
     */
    public function shortcode_my_data($atts): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte anmelden um Ihre Daten einzusehen.</p>';
        }
        
        $user_id = get_current_user_id();
        $user = wp_get_current_user();
        $data = $this->get_user_data($user_id);
        $consents = get_user_meta($user_id, 'isidor_gdpr_consents', true) ?: [];
        
        // Consent-Update verarbeiten
        if (isset($_POST['isidor_update_consents']) && wp_verify_nonce($_POST['_wpnonce'], 'isidor_my_consents')) {
            foreach (self::CONSENT_TYPES as $key => $type) {
                $granted = !empty($_POST['consent_' . $key]);
                $this->save_consent($user_id, $key, $granted);
            }
            $consents = get_user_meta($user_id, 'isidor_gdpr_consents', true) ?: [];
            echo '<div class="is-notice is-success">✓ Einstellungen gespeichert!</div>';
        }
        
        ob_start();
        ?>
        <div class="isidor-gdpr-my-data">
            <h2>🔒 Meine Daten</h2>
            
            <!-- Übersicht -->
            <div class="gdpr-section">
                <h3>Ihre gespeicherten Daten</h3>
                <table class="gdpr-data-table">
                    <tr>
                        <td>👤 Name</td>
                        <td><?php echo esc_html($user->display_name); ?></td>
                    </tr>
                    <tr>
                        <td>📧 E-Mail</td>
                        <td><?php echo esc_html($user->user_email); ?></td>
                    </tr>
                    <tr>
                        <td>📅 Registriert seit</td>
                        <td><?php echo date('d.m.Y', strtotime($user->user_registered)); ?></td>
                    </tr>
                    <tr>
                        <td>⛪ Dienste</td>
                        <td><?php echo count($data['dienste']); ?> Einsätze</td>
                    </tr>
                    <tr>
                        <td>💬 Nachrichten</td>
                        <td><?php echo count($data['kommunikation']); ?> Nachrichten</td>
                    </tr>
                </table>
            </div>
            
            <!-- Einwilligungen -->
            <div class="gdpr-section">
                <h3>Meine Einwilligungen</h3>
                <form method="post">
                    <?php wp_nonce_field('isidor_my_consents'); ?>
                    
                    <?php foreach (self::CONSENT_TYPES as $key => $type): ?>
                        <div class="gdpr-consent-item">
                            <label>
                                <input type="checkbox" name="consent_<?php echo $key; ?>" value="1" 
                                       <?php checked(!empty($consents[$key]['granted'])); ?>>
                                <strong><?php echo esc_html($type['label']); ?></strong>
                            </label>
                            <p class="description"><?php echo esc_html($type['description']); ?></p>
                            <?php if (!empty($consents[$key]['date'])): ?>
                                <small>
                                    <?php echo $consents[$key]['granted'] ? '✓ Erteilt' : '✗ Widerrufen'; ?> am 
                                    <?php echo date('d.m.Y', strtotime($consents[$key]['date'])); ?>
                                </small>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <button type="submit" name="isidor_update_consents" class="btn btn-primary">
                        Einstellungen speichern
                    </button>
                </form>
            </div>
            
            <!-- Datenexport -->
            <div class="gdpr-section">
                <h3>Daten exportieren</h3>
                <p>Sie können eine Kopie aller Ihrer in Isidor gespeicherten Daten anfordern.</p>
                <a href="<?php echo esc_url(admin_url('export-personal-data.php')); ?>" class="btn btn-outline" target="_blank">
                    📥 Datenexport anfordern
                </a>
            </div>
            
            <!-- Löschanfrage -->
            <div class="gdpr-section">
                <h3>Daten löschen</h3>
                <p>Sie können die Löschung Ihrer personenbezogenen Daten beantragen. Beachten Sie, dass einige Daten aufgrund gesetzlicher Aufbewahrungspflichten nicht gelöscht werden können.</p>
                <a href="<?php echo esc_url(admin_url('erase-personal-data.php')); ?>" class="btn btn-outline" target="_blank">
                    🗑️ Löschung beantragen
                </a>
            </div>
        </div>
        
        <style>
        .isidor-gdpr-my-data { max-width: 700px; }
        .gdpr-section { background: #fff; padding: 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .gdpr-section h3 { margin-top: 0; }
        .gdpr-data-table { width: 100%; border-collapse: collapse; }
        .gdpr-data-table td { padding: 10px; border-bottom: 1px solid #e5e7eb; }
        .gdpr-data-table td:first-child { width: 150px; color: #64748b; }
        .gdpr-consent-item { padding: 12px; border: 1px solid #e5e7eb; border-radius: 8px; margin-bottom: 12px; }
        .gdpr-consent-item .description { margin: 8px 0 4px; color: #64748b; font-size: 0.9rem; }
        .gdpr-consent-item small { color: #94a3b8; }
        .btn { display: inline-block; padding: 10px 20px; border-radius: 8px; text-decoration: none; cursor: pointer; border: none; font-size: 0.95rem; }
        .btn-primary { background: var(--is-primary, #2563eb); color: #fff; }
        .btn-outline { background: #fff; border: 1px solid #e5e7eb; color: #334155; }
        .is-notice { padding: 12px; border-radius: 8px; margin-bottom: 16px; }
        .is-notice.is-success { background: #d1fae5; color: #065f46; }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Admin-Seite rendern
     */
    public function render_admin_page(): void {
        $settings = get_option('isidor_gdpr_settings', [
            'dpo_name' => '',
            'dpo_email' => '',
            'privacy_page' => 0,
            'auto_cleanup' => false,
            'consent_required' => false,
        ]);
        
        $users = get_users(['fields' => ['ID', 'display_name', 'user_email']]);
        ?>
        <div class="wrap">
            <h1>🔒 Datenschutz (DSGVO)</h1>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:20px;">
                <!-- Einstellungen -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h2 style="margin-top:0;">⚙️ Datenschutz-Einstellungen</h2>
                    
                    <form method="post">
                        <?php wp_nonce_field('isidor_gdpr_settings'); ?>
                        
                        <table class="form-table">
                            <tr>
                                <th>Datenschutzbeauftragter</th>
                                <td>
                                    <input type="text" name="dpo_name" value="<?php echo esc_attr($settings['dpo_name']); ?>" placeholder="Name" style="width:100%; margin-bottom:8px;">
                                    <input type="email" name="dpo_email" value="<?php echo esc_attr($settings['dpo_email']); ?>" placeholder="E-Mail" style="width:100%;">
                                </td>
                            </tr>
                            <tr>
                                <th>Datenschutzseite</th>
                                <td>
                                    <?php wp_dropdown_pages([
                                        'name' => 'privacy_page',
                                        'selected' => $settings['privacy_page'],
                                        'show_option_none' => '— Seite wählen —',
                                    ]); ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Auto-Bereinigung</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="auto_cleanup" value="1" <?php checked($settings['auto_cleanup']); ?>>
                                        Alte Daten automatisch löschen (gemäß Aufbewahrungsfristen)
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th>Einwilligung</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="consent_required" value="1" <?php checked($settings['consent_required']); ?>>
                                        Einwilligung vor erster Nutzung erforderlich
                                    </label>
                                </td>
                            </tr>
                        </table>
                        
                        <p>
                            <button type="submit" name="isidor_save_gdpr_settings" class="button button-primary">
                                Einstellungen speichern
                            </button>
                        </p>
                    </form>
                </div>
                
                <!-- Benutzer-Daten -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h2 style="margin-top:0;">👤 Benutzer-Datenauskunft</h2>
                    
                    <form method="post">
                        <?php wp_nonce_field('isidor_gdpr_export'); ?>
                        <p>
                            <select name="user_id" style="width:100%;">
                                <option value="">— Benutzer wählen —</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo $u->ID; ?>"><?php echo esc_html($u->display_name . ' (' . $u->user_email . ')'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                        <p>
                            <button type="submit" name="isidor_export_user_data" class="button">
                                📥 Daten exportieren (JSON)
                            </button>
                        </p>
                    </form>
                    
                    <hr style="margin:20px 0;">
                    
                    <h3>🗑️ Daten löschen</h3>
                    <form method="post" onsubmit="return confirm('Daten wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden!');">
                        <?php wp_nonce_field('isidor_gdpr_delete'); ?>
                        <p>
                            <select name="user_id" style="width:100%;">
                                <option value="">— Benutzer wählen —</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo $u->ID; ?>"><?php echo esc_html($u->display_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                        <p>
                            <label><input type="checkbox" name="categories[]" value="dienste"> Dienstpläne</label><br>
                            <label><input type="checkbox" name="categories[]" value="finanzen"> Finanzdaten (anonymisieren)</label><br>
                            <label><input type="checkbox" name="categories[]" value="kommunikation"> Chat-Nachrichten</label><br>
                            <label><input type="checkbox" name="categories[]" value="permissions"> Berechtigungen</label><br>
                            <label><input type="checkbox" name="categories[]" value="consents"> Einwilligungen</label>
                        </p>
                        <p>
                            <button type="submit" name="isidor_delete_user_data" class="button" style="color:#dc2626;">
                                🗑️ Ausgewählte Daten löschen
                            </button>
                        </p>
                    </form>
                </div>
            </div>
            
            <!-- Verarbeitungsverzeichnis -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-top:20px;">
                <h2 style="margin-top:0;">📋 Verarbeitungsverzeichnis</h2>
                <p>Übersicht der in Isidor Suite verarbeiteten personenbezogenen Daten gemäß Art. 30 DSGVO.</p>
                
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Kategorie</th>
                            <th>Rechtsgrundlage</th>
                            <th>Aufbewahrung</th>
                            <th>Betroffene</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (self::DATA_CATEGORIES as $key => $cat): ?>
                            <tr>
                                <td><strong><?php echo esc_html($cat['label']); ?></strong></td>
                                <td><?php echo esc_html($cat['legal_basis']); ?></td>
                                <td>
                                    <?php 
                                    if ($cat['retention'] === 0) {
                                        echo 'Unbegrenzt';
                                    } else {
                                        $years = floor($cat['retention'] / 365);
                                        echo $years . ' Jahr' . ($years > 1 ? 'e' : '');
                                    }
                                    ?>
                                </td>
                                <td>Mitarbeiter, Ehrenamtliche</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}
