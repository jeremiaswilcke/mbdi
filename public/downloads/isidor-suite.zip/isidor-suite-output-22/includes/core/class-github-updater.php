<?php
/**
 * Isidor Suite — GitHub Auto-Updater
 * 
 * Checks for new releases on GitHub and integrates with WordPress update system.
 * Updates appear in Dashboard → Updates and Plugins page just like any other plugin.
 *
 * Usage:
 * 1. Create a GitHub Release with tag matching plugin version (e.g. "12.0.0")
 * 2. Attach the plugin ZIP as release asset
 * 3. WordPress will detect the update automatically
 *
 * @package IsidorSuite
 * @since 12.0.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_GitHub_Updater {

    /** @var string GitHub username/org */
    private string $github_user = '';

    /** @var string GitHub repository name */
    private string $github_repo = '';

    /** @var string Full path to main plugin file */
    private string $plugin_file = '';

    /** @var string Plugin slug (e.g. "isidor-suite/isidor-suite.php") */
    private string $plugin_slug = '';

    /** @var string Current plugin version */
    private string $current_version = '';

    /** @var string|null Personal Access Token for private repos */
    private ?string $access_token = null;

    /** @var int Cache duration in seconds (default: 6 hours) */
    private int $cache_duration = 21600;

    /** @var string Transient key for caching */
    private string $cache_key = 'isidor_github_update';

    /**
     * Initialize the updater.
     *
     * @param string      $plugin_file   Full path to main plugin file
     * @param string      $github_user   GitHub username or organization
     * @param string      $github_repo   GitHub repository name
     * @param string|null $access_token  Personal Access Token (required for private repos)
     */
    public function __construct(string $plugin_file, string $github_user, string $github_repo, ?string $access_token = null) {
        $this->plugin_file    = $plugin_file;
        $this->github_user    = $github_user;
        $this->github_repo    = $github_repo;
        $this->access_token   = $access_token;
        $this->plugin_slug    = plugin_basename($plugin_file);
        $this->current_version = $this->get_plugin_version();

        // Hook into WordPress update system
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
        add_filter('upgrader_post_install', [$this, 'after_install'], 10, 3);

        // Allow manual cache clearing
        add_action('admin_init', [$this, 'maybe_clear_cache']);
    }

    /**
     * Get the current plugin version from file header.
     */
    private function get_plugin_version(): string {
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $data = get_plugin_data($this->plugin_file, false, false);
        return $data['Version'] ?? '0.0.0';
    }

    /**
     * Fetch latest release info from GitHub API (with caching).
     */
    private function get_github_release(): ?array {
        $cached = get_transient($this->cache_key);
        if ($cached !== false) {
            return $cached ?: null;
        }

        $url = sprintf(
            'https://api.github.com/repos/%s/%s/releases/latest',
            $this->github_user,
            $this->github_repo
        );

        $args = [
            'headers' => [
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'Isidor-Suite-Updater/' . $this->current_version,
            ],
            'timeout' => 10,
        ];

        if ($this->access_token) {
            $args['headers']['Authorization'] = 'Bearer ' . $this->access_token;
        }

        $response = wp_remote_get($url, $args);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            // Cache the failure briefly (30 min) to avoid hammering GitHub
            set_transient($this->cache_key, '', 1800);
            return null;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!$body || empty($body['tag_name'])) {
            set_transient($this->cache_key, '', 1800);
            return null;
        }

        // Extract version from tag (strip "v" prefix if present)
        $version = ltrim($body['tag_name'], 'vV');

        // Find ZIP asset (prefer .zip attachment, fallback to source zipball)
        $download_url = $body['zipball_url'] ?? '';
        if (!empty($body['assets'])) {
            foreach ($body['assets'] as $asset) {
                if (str_ends_with($asset['name'], '.zip')) {
                    $download_url = $asset['browser_download_url'];
                    break;
                }
            }
        }

        // For private repos, use authenticated download URL
        if ($this->access_token && $download_url) {
            $download_url = add_query_arg('access_token', $this->access_token, $download_url);
        }

        $release = [
            'version'      => $version,
            'download_url' => $download_url,
            'name'         => $body['name'] ?? ('Version ' . $version),
            'body'         => $body['body'] ?? '',
            'published_at' => $body['published_at'] ?? '',
            'html_url'     => $body['html_url'] ?? '',
        ];

        set_transient($this->cache_key, $release, $this->cache_duration);

        return $release;
    }

    /**
     * Check for updates and inject into WordPress update transient.
     */
    public function check_for_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $release = $this->get_github_release();
        if (!$release) {
            return $transient;
        }

        // Compare versions
        if (version_compare($release['version'], $this->current_version, '>')) {
            $plugin_data = [
                'slug'        => dirname($this->plugin_slug),
                'plugin'      => $this->plugin_slug,
                'new_version' => $release['version'],
                'url'         => $release['html_url'],
                'package'     => $release['download_url'],
                'icons'       => [],
                'banners'     => [],
                'tested'      => '',
                'requires_php'=> '8.0',
            ];

            $transient->response[$this->plugin_slug] = (object) $plugin_data;
        } else {
            // No update, but tell WP we checked
            $transient->no_update[$this->plugin_slug] = (object) [
                'slug'        => dirname($this->plugin_slug),
                'plugin'      => $this->plugin_slug,
                'new_version' => $this->current_version,
                'url'         => '',
                'package'     => '',
            ];
        }

        return $transient;
    }

    /**
     * Provide plugin info for the "View Details" popup in Plugins page.
     */
    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (!isset($args->slug) || $args->slug !== dirname($this->plugin_slug)) return $result;

        $release = $this->get_github_release();
        if (!$release) return $result;

        $info = new \stdClass();
        $info->name          = 'Isidor Suite';
        $info->slug          = dirname($this->plugin_slug);
        $info->version       = $release['version'];
        $info->author        = '<a href="https://wilcke-wuv.at">Wilcke Worte & Visionen</a>';
        $info->homepage      = 'https://github.com/' . $this->github_user . '/' . $this->github_repo;
        $info->download_link = $release['download_url'];
        $info->requires_php  = '8.0';
        $info->last_updated  = $release['published_at'];
        $info->tested        = get_bloginfo('version');

        // Convert Markdown changelog to HTML (basic)
        $changelog = $release['body'];
        $changelog = esc_html($changelog);
        $changelog = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $changelog);
        $changelog = preg_replace('/\n- /', "\n• ", $changelog);
        $changelog = nl2br($changelog);

        $info->sections = [
            'description' => 'Isidor OS — Umfassende Pfarr-Management-Suite für WordPress. Liturgus, Cantus, Consilium, Cellerar, Agenda und mehr.',
            'changelog'   => '<h4>' . esc_html($release['name']) . '</h4>' . $changelog,
        ];

        return $info;
    }

    /**
     * After install: rename extracted folder to match expected plugin directory.
     */
    public function after_install($response, $hook_extra, $result) {
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_slug) {
            return $result;
        }

        global $wp_filesystem;

        $plugin_dir = WP_PLUGIN_DIR . '/' . dirname($this->plugin_slug);
        $installed_dir = $result['destination'];

        // GitHub ZIP extracts to "repo-name-hash/" — rename to our plugin dir
        if ($installed_dir !== $plugin_dir) {
            $wp_filesystem->move($installed_dir, $plugin_dir);
            $result['destination'] = $plugin_dir;
        }

        // Re-activate plugin
        activate_plugin($this->plugin_slug);

        // Clear cache
        delete_transient($this->cache_key);

        return $result;
    }

    /**
     * Allow manual cache clearing via ?isidor_clear_update_cache=1
     */
    public function maybe_clear_cache(): void {
        if (isset($_GET['isidor_clear_update_cache']) && current_user_can('manage_options')) {
            delete_transient($this->cache_key);
            delete_site_transient('update_plugins');
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>Isidor Suite Update-Cache geleert.</p></div>';
            });
        }
    }
}
