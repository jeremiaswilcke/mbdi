<?php
/**
 * Isidor Impressum & Datenschutz
 * 
 * Generiert rechtlich konforme Seiten aus Parish Settings:
 * - Impressum (ECG §5, Mediengesetz §24/25)
 * - Datenschutzerklärung (DSGVO Art. 13/14)
 * - Cookie-Hinweis
 * 
 * Shortcodes:
 * - [isidor_impressum]
 * - [isidor_datenschutz]
 * - [isidor_cookie_banner]
 */

if (!defined('ABSPATH')) exit;

class Isidor_Impressum {
    
    /** @var Isidor_Impressum|null */
    private static $instance = null;
    
    /** Zusätzliche Impressum-Felder */
    private const EXTRA_FIELDS = [
        'legal_form' => 'Körperschaft öffentlichen Rechts',
        'diocese' => '',
        'diocese_address' => '',
        'responsible_person' => '',
        'responsible_role' => 'Pfarrer',
        'uid_number' => '',
        'editorial_responsibility' => '',
        'editorial_direction' => 'Information über das Pfarrleben und religiöse Inhalte',
        'hosting_provider' => '',
        'hosting_address' => '',
    ];
    
    /**
     * @return Isidor_Impressum
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Admin
        add_action('admin_menu', [$this, 'add_admin_menu'], 32);
        add_action('admin_init', [$this, 'handle_save']);
        
        // Shortcodes
        add_shortcode('isidor_impressum', [$this, 'render_impressum']);
        add_shortcode('isidor_datenschutz', [$this, 'render_datenschutz']);
        add_shortcode('isidor_cookie_banner', [$this, 'render_cookie_banner']);
        
        // Footer-Links automatisch einfügen
        add_action('wp_footer', [$this, 'maybe_add_footer_links']);
        
        // Cookie-Banner
        add_action('wp_footer', [$this, 'maybe_show_cookie_banner']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }
    
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Impressum & Datenschutz',
            '⚖️ Impressum',
            'manage_options',
            'isidor-impressum',
            [$this, 'render_admin_page']
        );
    }
    
    /**
     * Alle Impressum-Daten abrufen (kombiniert mit Parish Settings)
     */
    public static function get_data(): array {
        $parish = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::get_all() : [];
        $extra = get_option('isidor_impressum_data', []);
        
        return array_merge(self::EXTRA_FIELDS, $parish, $extra);
    }
    
    /**
     * Einzelnes Feld abrufen
     */
    public static function get(string $key, string $fallback = ''): string {
        $data = self::get_data();
        return !empty($data[$key]) ? $data[$key] : $fallback;
    }
    
    public function handle_save(): void {
        if (!isset($_POST['isidor_save_impressum'])) return;
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'isidor_impressum')) return;
        if (!current_user_can('manage_options')) return;
        
        $fields = [
            'legal_form', 'diocese', 'diocese_address', 
            'responsible_person', 'responsible_role',
            'uid_number', 'editorial_responsibility', 'editorial_direction',
            'hosting_provider', 'hosting_address',
            'show_footer_links', 'show_cookie_banner',
            'impressum_page_id', 'datenschutz_page_id',
        ];
        
        $data = [];
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                $data[$field] = sanitize_textarea_field($_POST[$field]);
            }
        }
        
        update_option('isidor_impressum_data', $data);
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success"><p>✓ Einstellungen gespeichert!</p></div>';
        });
    }
    
    /* ================================================================
       SHORTCODE: IMPRESSUM
       ================================================================ */
    
    public function render_impressum(): string {
        $d = self::get_data();
        
        ob_start();
        ?>
        <div class="isidor-legal-page isidor-impressum">
            <h1>Impressum</h1>
            
            <section class="legal-section">
                <h2>Medieninhaber und Herausgeber</h2>
                <p>
                    <strong><?php echo esc_html($d['name'] ?? 'Pfarre'); ?></strong><br>
                    <?php if (!empty($d['subtitle'])): ?>
                        <?php echo esc_html($d['subtitle']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($d['legal_form'])): ?>
                        <?php echo esc_html($d['legal_form']); ?><br>
                    <?php endif; ?>
                </p>
                
                <p>
                    <?php echo esc_html($d['street'] ?? ''); ?><br>
                    <?php echo esc_html(($d['zip'] ?? '') . ' ' . ($d['city'] ?? '')); ?><br>
                    <?php echo esc_html($d['country'] ?? 'Österreich'); ?>
                </p>
                
                <?php if (!empty($d['phone']) || !empty($d['email'])): ?>
                <p>
                    <?php if (!empty($d['phone'])): ?>
                        Tel: <?php echo esc_html($d['phone']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($d['fax'])): ?>
                        Fax: <?php echo esc_html($d['fax']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($d['email'])): ?>
                        E-Mail: <a href="mailto:<?php echo esc_attr($d['email']); ?>"><?php echo esc_html($d['email']); ?></a><br>
                    <?php endif; ?>
                    <?php if (!empty($d['website'])): ?>
                        Web: <a href="<?php echo esc_url($d['website']); ?>" target="_blank"><?php echo esc_html($d['website']); ?></a>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
            </section>
            
            <?php if (!empty($d['responsible_person'])): ?>
            <section class="legal-section">
                <h2>Vertretungsbefugte Person</h2>
                <p>
                    <?php echo esc_html($d['responsible_role'] ?? 'Pfarrer'); ?>: 
                    <strong><?php echo esc_html($d['responsible_person']); ?></strong>
                </p>
            </section>
            <?php endif; ?>
            
            <?php if (!empty($d['diocese'])): ?>
            <section class="legal-section">
                <h2>Aufsichtsbehörde</h2>
                <p>
                    <?php echo esc_html($d['diocese']); ?><br>
                    <?php if (!empty($d['diocese_address'])): ?>
                        <?php echo nl2br(esc_html($d['diocese_address'])); ?>
                    <?php endif; ?>
                </p>
            </section>
            <?php endif; ?>
            
            <?php if (!empty($d['uid_number']) || !empty($d['dvr_number'])): ?>
            <section class="legal-section">
                <h2>Registernummern</h2>
                <p>
                    <?php if (!empty($d['uid_number'])): ?>
                        UID-Nummer: <?php echo esc_html($d['uid_number']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($d['dvr_number'])): ?>
                        DVR-Nummer: <?php echo esc_html($d['dvr_number']); ?>
                    <?php endif; ?>
                </p>
            </section>
            <?php endif; ?>
            
            <?php if (!empty($d['iban'])): ?>
            <section class="legal-section">
                <h2>Bankverbindung</h2>
                <p>
                    <?php if (!empty($d['account_holder'])): ?>
                        Kontoinhaber: <?php echo esc_html($d['account_holder']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($d['bank_name'])): ?>
                        Bank: <?php echo esc_html($d['bank_name']); ?><br>
                    <?php endif; ?>
                    IBAN: <?php echo esc_html($d['iban']); ?><br>
                    <?php if (!empty($d['bic'])): ?>
                        BIC: <?php echo esc_html($d['bic']); ?>
                    <?php endif; ?>
                </p>
            </section>
            <?php endif; ?>
            
            <section class="legal-section">
                <h2>Grundlegende Richtung (Blattlinie)</h2>
                <p>
                    <?php echo esc_html($d['editorial_direction'] ?? 'Information über das Pfarrleben und religiöse Inhalte'); ?>
                </p>
                <?php if (!empty($d['editorial_responsibility'])): ?>
                <p>
                    Redaktionelle Verantwortung: <?php echo esc_html($d['editorial_responsibility']); ?>
                </p>
                <?php endif; ?>
            </section>
            
            <?php if (!empty($d['hosting_provider'])): ?>
            <section class="legal-section">
                <h2>Hosting</h2>
                <p>
                    <?php echo esc_html($d['hosting_provider']); ?><br>
                    <?php if (!empty($d['hosting_address'])): ?>
                        <?php echo nl2br(esc_html($d['hosting_address'])); ?>
                    <?php endif; ?>
                </p>
            </section>
            <?php endif; ?>
            
            <section class="legal-section">
                <h2>Haftungsausschluss</h2>
                <p>
                    Die Inhalte dieser Website wurden mit größtmöglicher Sorgfalt erstellt. 
                    Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte können wir 
                    jedoch keine Gewähr übernehmen.
                </p>
                <p>
                    Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für 
                    die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind 
                    ausschließlich deren Betreiber verantwortlich.
                </p>
            </section>
            
            <section class="legal-section">
                <h2>Urheberrecht</h2>
                <p>
                    Die durch den Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten 
                    unterliegen dem österreichischen Urheberrecht. Die Vervielfältigung, 
                    Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen 
                    des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen 
                    Autors bzw. Erstellers.
                </p>
            </section>
            
            <p class="legal-footer">
                <small>Stand: <?php echo date('F Y'); ?></small>
            </p>
        </div>
        
        <style>
        .isidor-legal-page {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            font-size: 16px;
            line-height: 1.7;
        }
        .isidor-legal-page h1 {
            color: var(--is-primary, #2563eb);
            border-bottom: 3px solid var(--is-primary, #2563eb);
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .isidor-legal-page h2 {
            color: #333;
            font-size: 1.2em;
            margin-top: 30px;
            margin-bottom: 10px;
        }
        .legal-section {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .legal-section:last-of-type {
            border-bottom: none;
        }
        .legal-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #eee;
            color: #666;
        }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /* ================================================================
       SHORTCODE: DATENSCHUTZ
       ================================================================ */
    
    public function render_datenschutz(): string {
        $d = self::get_data();
        $parish_name = $d['name'] ?? 'Die Pfarre';
        
        ob_start();
        ?>
        <div class="isidor-legal-page isidor-datenschutz">
            <h1>Datenschutzerklärung</h1>
            
            <section class="legal-section">
                <h2>1. Verantwortlicher</h2>
                <p>
                    Verantwortlich für die Datenverarbeitung auf dieser Website ist:<br><br>
                    <strong><?php echo esc_html($parish_name); ?></strong><br>
                    <?php echo esc_html($d['street'] ?? ''); ?><br>
                    <?php echo esc_html(($d['zip'] ?? '') . ' ' . ($d['city'] ?? '')); ?><br>
                    <?php if (!empty($d['email'])): ?>
                        E-Mail: <a href="mailto:<?php echo esc_attr($d['email']); ?>"><?php echo esc_html($d['email']); ?></a><br>
                    <?php endif; ?>
                    <?php if (!empty($d['phone'])): ?>
                        Tel: <?php echo esc_html($d['phone']); ?>
                    <?php endif; ?>
                </p>
            </section>
            
            <section class="legal-section">
                <h2>2. Ihre Rechte</h2>
                <p>Sie haben folgende Rechte bezüglich Ihrer personenbezogenen Daten:</p>
                <ul>
                    <li><strong>Auskunftsrecht</strong> (Art. 15 DSGVO): Sie können Auskunft über Ihre gespeicherten Daten verlangen.</li>
                    <li><strong>Berichtigungsrecht</strong> (Art. 16 DSGVO): Sie können die Berichtigung unrichtiger Daten verlangen.</li>
                    <li><strong>Löschungsrecht</strong> (Art. 17 DSGVO): Sie können die Löschung Ihrer Daten verlangen.</li>
                    <li><strong>Einschränkung</strong> (Art. 18 DSGVO): Sie können die Einschränkung der Verarbeitung verlangen.</li>
                    <li><strong>Datenübertragbarkeit</strong> (Art. 20 DSGVO): Sie können Ihre Daten in einem gängigen Format erhalten.</li>
                    <li><strong>Widerspruchsrecht</strong> (Art. 21 DSGVO): Sie können der Verarbeitung widersprechen.</li>
                </ul>
                <p>
                    Zur Ausübung Ihrer Rechte wenden Sie sich bitte an: 
                    <a href="mailto:<?php echo esc_attr($d['email'] ?? ''); ?>"><?php echo esc_html($d['email'] ?? 'die Pfarrkanzlei'); ?></a>
                </p>
            </section>
            
            <section class="legal-section">
                <h2>3. Beschwerderecht</h2>
                <p>
                    Sie haben das Recht, sich bei der österreichischen Datenschutzbehörde zu beschweren:
                </p>
                <p>
                    Österreichische Datenschutzbehörde<br>
                    Barichgasse 40-42<br>
                    1030 Wien<br>
                    Tel: +43 1 52 152-0<br>
                    E-Mail: dsb@dsb.gv.at<br>
                    Web: <a href="https://www.dsb.gv.at" target="_blank">www.dsb.gv.at</a>
                </p>
            </section>
            
            <section class="legal-section">
                <h2>4. Server-Logfiles</h2>
                <p>
                    Der Provider dieser Website erhebt automatisch Informationen in sogenannten Server-Logfiles, 
                    die Ihr Browser automatisch übermittelt. Dies sind:
                </p>
                <ul>
                    <li>Browsertyp und -version</li>
                    <li>Verwendetes Betriebssystem</li>
                    <li>Referrer URL (zuvor besuchte Seite)</li>
                    <li>IP-Adresse des zugreifenden Rechners</li>
                    <li>Uhrzeit der Serveranfrage</li>
                </ul>
                <p>
                    Diese Daten sind nicht bestimmten Personen zuordenbar. Eine Zusammenführung mit 
                    anderen Datenquellen wird nicht vorgenommen. Die Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO 
                    (berechtigtes Interesse an der Sicherheit und Optimierung der Website).
                </p>
            </section>
            
            <section class="legal-section">
                <h2>5. Cookies</h2>
                <p>
                    Diese Website verwendet Cookies. Cookies sind kleine Textdateien, die auf Ihrem 
                    Endgerät gespeichert werden. Sie richten keinen Schaden an.
                </p>
                <p>
                    Wir verwenden folgende Arten von Cookies:
                </p>
                <ul>
                    <li><strong>Technisch notwendige Cookies:</strong> Diese sind für den Betrieb der Website erforderlich 
                        (z.B. Login-Session). Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO.</li>
                </ul>
                <p>
                    Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden 
                    und Cookies nur im Einzelfall erlauben.
                </p>
            </section>
            
            <section class="legal-section">
                <h2>6. Kontaktformular / E-Mail</h2>
                <p>
                    Wenn Sie uns per E-Mail oder Kontaktformular kontaktieren, werden Ihre Angaben 
                    zur Bearbeitung Ihrer Anfrage gespeichert. Die Daten werden gelöscht, sobald 
                    sie nicht mehr benötigt werden. Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO 
                    (Vertragsanbahnung) oder Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse).
                </p>
            </section>
            
            <section class="legal-section">
                <h2>7. Registrierung / Benutzerkonten</h2>
                <p>
                    Für bestimmte Funktionen (z.B. Dienstplanung, Liedplanung) ist eine Registrierung erforderlich. 
                    Dabei werden folgende Daten gespeichert:
                </p>
                <ul>
                    <li>Name</li>
                    <li>E-Mail-Adresse</li>
                    <li>Ggf. Telefonnummer</li>
                    <li>Zugewiesene Dienste und Rollen</li>
                </ul>
                <p>
                    Die Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO (Erfüllung eines Vertrags) sowie 
                    das berechtigte Interesse der Pfarrgemeinde an der Organisation des Gemeindelebens 
                    (Art. 6 Abs. 1 lit. f DSGVO).
                </p>
            </section>
            
            <section class="legal-section">
                <h2>8. Kirchliche Datenverarbeitung</h2>
                <p>
                    Als katholische Pfarre unterliegen wir neben der DSGVO auch dem kirchlichen Datenschutzrecht. 
                    Die Verarbeitung von Daten im Zusammenhang mit Sakramenten (Taufe, Firmung, Trauung, etc.) 
                    erfolgt auf Grundlage kirchenrechtlicher Bestimmungen (CIC).
                </p>
                <p>
                    Für Fragen zum kirchlichen Datenschutz können Sie sich an die Datenschutzstelle der 
                    <?php echo esc_html($d['diocese'] ?? 'Diözese'); ?> wenden.
                </p>
            </section>
            
            <section class="legal-section">
                <h2>9. Speicherdauer</h2>
                <p>
                    Personenbezogene Daten werden nur so lange gespeichert, wie es für die Zwecke, 
                    für die sie verarbeitet werden, erforderlich ist:
                </p>
                <ul>
                    <li>Kontaktanfragen: Nach Abschluss der Anfrage</li>
                    <li>Benutzerkonten: Bis zur Löschung des Kontos</li>
                    <li>Dienstpläne: 2 Jahre</li>
                    <li>Finanzdaten: 10 Jahre (gesetzliche Aufbewahrungspflicht)</li>
                    <li>Sakramentsdaten: Unbegrenzt (Kirchenrecht)</li>
                </ul>
            </section>
            
            <section class="legal-section">
                <h2>10. Datensicherheit</h2>
                <p>
                    Wir setzen technische und organisatorische Sicherheitsmaßnahmen ein, um Ihre Daten 
                    gegen Manipulation, Verlust, Zerstörung oder unbefugten Zugriff zu schützen. 
                    Unsere Sicherheitsmaßnahmen werden regelmäßig überprüft und an den technischen 
                    Fortschritt angepasst.
                </p>
            </section>
            
            <p class="legal-footer">
                <small>Stand: <?php echo date('F Y'); ?></small>
            </p>
        </div>
        
        <style>
        .isidor-datenschutz ul {
            margin-left: 20px;
            margin-bottom: 15px;
        }
        .isidor-datenschutz li {
            margin-bottom: 8px;
        }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /* ================================================================
       COOKIE BANNER
       ================================================================ */
    
    public function render_cookie_banner(): string {
        return ''; // Wird via Footer eingebunden
    }
    
    public function enqueue_scripts(): void {
        $data = get_option('isidor_impressum_data', []);
        if (empty($data['show_cookie_banner'])) return;
        
        wp_add_inline_script('jquery', $this->get_cookie_js());
    }
    
    public function maybe_show_cookie_banner(): void {
        $data = get_option('isidor_impressum_data', []);
        if (empty($data['show_cookie_banner'])) return;
        
        $datenschutz_url = !empty($data['datenschutz_page_id']) 
            ? get_permalink($data['datenschutz_page_id']) 
            : '#';
        
        ?>
        <div id="isidor-cookie-banner" style="display:none; position:fixed; bottom:0; left:0; right:0; background:#1e293b; color:#fff; padding:15px 20px; z-index:99999; box-shadow:0 -2px 10px rgba(0,0,0,0.2);">
            <div style="max-width:1200px; margin:0 auto; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:15px;">
                <p style="margin:0; flex:1;">
                    🍪 Diese Website verwendet technisch notwendige Cookies für den Betrieb. 
                    <a href="<?php echo esc_url($datenschutz_url); ?>" style="color:#60a5fa;">Mehr erfahren</a>
                </p>
                <button onclick="isidorAcceptCookies()" style="background:#2563eb; color:#fff; border:none; padding:10px 25px; border-radius:6px; cursor:pointer; font-weight:600;">
                    Verstanden
                </button>
            </div>
        </div>
        <script>
        function isidorAcceptCookies() {
            document.cookie = "isidor_cookies_accepted=1; path=/; max-age=" + (365*24*60*60);
            document.getElementById('isidor-cookie-banner').style.display = 'none';
        }
        if (!document.cookie.includes('isidor_cookies_accepted=1')) {
            document.getElementById('isidor-cookie-banner').style.display = 'block';
        }
        </script>
        <?php
    }
    
    private function get_cookie_js(): string {
        return '';
    }
    
    /* ================================================================
       FOOTER LINKS
       ================================================================ */
    
    public function maybe_add_footer_links(): void {
        $data = get_option('isidor_impressum_data', []);
        if (empty($data['show_footer_links'])) return;
        
        $impressum_url = !empty($data['impressum_page_id']) 
            ? get_permalink($data['impressum_page_id']) 
            : '#';
        $datenschutz_url = !empty($data['datenschutz_page_id']) 
            ? get_permalink($data['datenschutz_page_id']) 
            : '#';
        
        ?>
        <div id="isidor-legal-footer" style="text-align:center; padding:15px; background:#f8fafc; border-top:1px solid #e2e8f0; font-size:14px;">
            <a href="<?php echo esc_url($impressum_url); ?>" style="color:#64748b; margin:0 10px;">Impressum</a>
            <span style="color:#cbd5e1;">|</span>
            <a href="<?php echo esc_url($datenschutz_url); ?>" style="color:#64748b; margin:0 10px;">Datenschutz</a>
        </div>
        <?php
    }
    
    /* ================================================================
       ADMIN PAGE
       ================================================================ */
    
    public function render_admin_page(): void {
        $data = get_option('isidor_impressum_data', []);
        $data = array_merge(self::EXTRA_FIELDS, $data);
        
        // Seiten für Dropdown
        $pages = get_pages(['post_status' => 'publish']);
        ?>
        <div class="wrap">
            <h1>⚖️ Impressum & Datenschutz</h1>
            
            <p>Konfigurieren Sie hier die rechtlich erforderlichen Angaben für Ihre Pfarr-Website.</p>
            
            <form method="post">
                <?php wp_nonce_field('isidor_impressum'); ?>
                
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:20px;">
                    
                    <!-- Linke Spalte -->
                    <div>
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                            <h2 style="margin-top:0;">📋 Rechtliche Angaben</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Rechtsform</th>
                                    <td>
                                        <input type="text" name="legal_form" value="<?php echo esc_attr($data['legal_form']); ?>" class="regular-text">
                                        <p class="description">z.B. "Körperschaft öffentlichen Rechts"</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Vertretungsbefugte Person</th>
                                    <td>
                                        <input type="text" name="responsible_person" value="<?php echo esc_attr($data['responsible_person']); ?>" class="regular-text" placeholder="Mag. Max Mustermann">
                                    </td>
                                </tr>
                                <tr>
                                    <th>Rolle/Funktion</th>
                                    <td>
                                        <input type="text" name="responsible_role" value="<?php echo esc_attr($data['responsible_role']); ?>" class="regular-text" placeholder="Pfarrer">
                                    </td>
                                </tr>
                                <tr>
                                    <th>UID-Nummer</th>
                                    <td>
                                        <input type="text" name="uid_number" value="<?php echo esc_attr($data['uid_number']); ?>" placeholder="ATU12345678">
                                        <p class="description">Falls vorhanden</p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                            <h2 style="margin-top:0;">⛪ Aufsichtsbehörde (Diözese)</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Diözese</th>
                                    <td>
                                        <input type="text" name="diocese" value="<?php echo esc_attr($data['diocese']); ?>" class="regular-text" placeholder="Erzdiözese Wien">
                                    </td>
                                </tr>
                                <tr>
                                    <th>Adresse</th>
                                    <td>
                                        <textarea name="diocese_address" rows="3" class="large-text"><?php echo esc_textarea($data['diocese_address']); ?></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                            <h2 style="margin-top:0;">📰 Mediengesetz (Blattlinie)</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Grundlegende Richtung</th>
                                    <td>
                                        <textarea name="editorial_direction" rows="2" class="large-text"><?php echo esc_textarea($data['editorial_direction']); ?></textarea>
                                        <p class="description">z.B. "Information über das Pfarrleben und religiöse Inhalte"</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Redaktionelle Verantwortung</th>
                                    <td>
                                        <input type="text" name="editorial_responsibility" value="<?php echo esc_attr($data['editorial_responsibility']); ?>" class="regular-text">
                                        <p class="description">Falls abweichend vom Pfarrer</p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Rechte Spalte -->
                    <div>
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                            <h2 style="margin-top:0;">🌐 Hosting</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Hosting-Anbieter</th>
                                    <td>
                                        <input type="text" name="hosting_provider" value="<?php echo esc_attr($data['hosting_provider']); ?>" class="regular-text" placeholder="z.B. World4You, All-Inkl">
                                    </td>
                                </tr>
                                <tr>
                                    <th>Adresse</th>
                                    <td>
                                        <textarea name="hosting_address" rows="3" class="large-text"><?php echo esc_textarea($data['hosting_address']); ?></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                            <h2 style="margin-top:0;">📄 Seiten zuweisen</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Impressum-Seite</th>
                                    <td>
                                        <select name="impressum_page_id">
                                            <option value="">-- Seite wählen --</option>
                                            <?php foreach ($pages as $page): ?>
                                                <option value="<?php echo $page->ID; ?>" <?php selected($data['impressum_page_id'] ?? '', $page->ID); ?>>
                                                    <?php echo esc_html($page->post_title); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description">Seite mit Shortcode <code>[isidor_impressum]</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Datenschutz-Seite</th>
                                    <td>
                                        <select name="datenschutz_page_id">
                                            <option value="">-- Seite wählen --</option>
                                            <?php foreach ($pages as $page): ?>
                                                <option value="<?php echo $page->ID; ?>" <?php selected($data['datenschutz_page_id'] ?? '', $page->ID); ?>>
                                                    <?php echo esc_html($page->post_title); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description">Seite mit Shortcode <code>[isidor_datenschutz]</code></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                            <h2 style="margin-top:0;">⚙️ Optionen</h2>
                            
                            <table class="form-table">
                                <tr>
                                    <th>Footer-Links</th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="show_footer_links" value="1" <?php checked(!empty($data['show_footer_links'])); ?>>
                                            Impressum & Datenschutz automatisch im Footer anzeigen
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Cookie-Banner</th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="show_cookie_banner" value="1" <?php checked(!empty($data['show_cookie_banner'])); ?>>
                                            Cookie-Hinweis anzeigen (einmalig pro Besucher)
                                        </label>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="background:#dbeafe; padding:20px; border-radius:8px; border-left:4px solid #2563eb;">
                            <h3 style="margin-top:0;">💡 Tipp: Seiten erstellen</h3>
                            <p>Erstellen Sie zwei neue Seiten:</p>
                            <ol>
                                <li><strong>Impressum</strong> mit Inhalt: <code>[isidor_impressum]</code></li>
                                <li><strong>Datenschutz</strong> mit Inhalt: <code>[isidor_datenschutz]</code></li>
                            </ol>
                            <p>Die restlichen Daten werden aus den Pfarrei-Einstellungen übernommen.</p>
                        </div>
                    </div>
                </div>
                
                <p style="margin-top:20px;">
                    <button type="submit" name="isidor_save_impressum" class="button button-primary button-large">
                        💾 Einstellungen speichern
                    </button>
                </p>
            </form>
        </div>
        <?php
    }
}
