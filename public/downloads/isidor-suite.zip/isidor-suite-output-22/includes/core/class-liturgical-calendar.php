<?php
/**
 * Isidor Liturgischer Kalender
 * 
 * Automatische Benennung von Sonntagen und Feiertagen nach dem
 * römisch-katholischen Kirchenjahr.
 * 
 * Berechnet:
 * - Ostern (Gauss-Algorithmus)
 * - Alle beweglichen Feste relativ zu Ostern
 * - Sonntage im Jahreskreis (Ordinalzählung)
 * - Advent, Weihnachtszeit, Fastenzeit
 * - Hochfeste mit festem Datum
 * - Heiligenfeste / Gedenktage (wichtigste)
 */

if (!defined('ABSPATH')) exit;

class Isidor_Liturgical_Calendar {
    
    /**
     * Feste Feiertage (Monat-Tag => Name)
     * Priorität: Hochfest > Fest > Gedenktag
     */
    private const FIXED_FEASTS = [
        '01-01' => ['name' => 'Hochfest der Gottesmutter Maria', 'rank' => 'hochfest'],
        '01-06' => ['name' => 'Erscheinung des Herrn (Dreikönig)', 'rank' => 'hochfest'],
        '02-02' => ['name' => 'Darstellung des Herrn (Mariä Lichtmess)', 'rank' => 'fest'],
        '02-14' => ['name' => 'Hl. Cyrill u. Methodius', 'rank' => 'gedenktag'],
        '03-19' => ['name' => 'Hl. Josef, Bräutigam der Gottesmutter', 'rank' => 'hochfest'],
        '03-25' => ['name' => 'Verkündigung des Herrn', 'rank' => 'hochfest'],
        '04-25' => ['name' => 'Hl. Markus, Evangelist', 'rank' => 'fest'],
        '05-01' => ['name' => 'Hl. Josef der Arbeiter', 'rank' => 'gedenktag'],
        '05-31' => ['name' => 'Mariä Heimsuchung', 'rank' => 'fest'],
        '06-24' => ['name' => 'Geburt des Hl. Johannes des Täufers', 'rank' => 'hochfest'],
        '06-29' => ['name' => 'Hl. Petrus und Paulus', 'rank' => 'hochfest'],
        '08-06' => ['name' => 'Verklärung des Herrn', 'rank' => 'fest'],
        '08-15' => ['name' => 'Mariä Aufnahme in den Himmel', 'rank' => 'hochfest'],
        '09-08' => ['name' => 'Mariä Geburt', 'rank' => 'fest'],
        '09-14' => ['name' => 'Kreuzerhöhung', 'rank' => 'fest'],
        '09-29' => ['name' => 'Hl. Michael, Gabriel u. Raphael', 'rank' => 'fest'],
        '10-04' => ['name' => 'Hl. Franz von Assisi', 'rank' => 'gedenktag'],
        '10-07' => ['name' => 'Unsere Liebe Frau vom Rosenkranz', 'rank' => 'gedenktag'],
        '10-15' => ['name' => 'Hl. Teresa von Ávila', 'rank' => 'gedenktag'],
        '11-01' => ['name' => 'Allerheiligen', 'rank' => 'hochfest'],
        '11-02' => ['name' => 'Allerseelen', 'rank' => 'gedenktag'],
        '11-09' => ['name' => 'Weihe der Lateranbasilika', 'rank' => 'fest'],
        '11-11' => ['name' => 'Hl. Martin von Tours', 'rank' => 'gedenktag'],
        '11-21' => ['name' => 'Unsere Liebe Frau in Jerusalem', 'rank' => 'gedenktag'],
        '12-06' => ['name' => 'Hl. Nikolaus von Myra', 'rank' => 'gedenktag'],
        '12-08' => ['name' => 'Hochfest der ohne Erbsünde empfangenen Jungfrau Maria', 'rank' => 'hochfest'],
        '12-24' => ['name' => 'Heiliger Abend', 'rank' => 'fest'],
        '12-25' => ['name' => 'Hochfest der Geburt des Herrn (Weihnachten)', 'rank' => 'hochfest'],
        '12-26' => ['name' => 'Hl. Stephanus, erster Märtyrer', 'rank' => 'fest'],
        '12-31' => ['name' => 'Hl. Silvester', 'rank' => 'gedenktag'],
    ];
    
    /** Cache für Oster-Berechnung pro Jahr */
    private static array $easter_cache = [];
    
    /**
     * Osterdatum berechnen (Gauss/Meeus)
     */
    public static function easter(int $year): DateTime {
        if (isset(self::$easter_cache[$year])) {
            return clone self::$easter_cache[$year];
        }
        
        // PHP easter_date ist limitiert – wir nutzen den Algorithmus direkt
        $a = $year % 19;
        $b = intdiv($year, 100);
        $c = $year % 100;
        $d = intdiv($b, 4);
        $e = $b % 4;
        $f = intdiv($b + 8, 25);
        $g = intdiv($b - $f + 1, 3);
        $h = (19 * $a + $b - $d - $g + 15) % 30;
        $i = intdiv($c, 4);
        $k = $c % 4;
        $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
        $m = intdiv($a + 11 * $h + 22 * $l, 451);
        $month = intdiv($h + $l - 7 * $m + 114, 31);
        $day = (($h + $l - 7 * $m + 114) % 31) + 1;
        
        $dt = new DateTime("$year-$month-$day");
        self::$easter_cache[$year] = clone $dt;
        return $dt;
    }
    
    /**
     * Alle beweglichen Feste für ein Jahr berechnen
     * Gibt Array [Y-m-d => [name, rank]] zurück
     */
    public static function moveable_feasts(int $year): array {
        $easter = self::easter($year);
        $feasts = [];
        
        $add = function(int $days, string $name, string $rank) use ($easter, &$feasts) {
            $dt = clone $easter;
            $dt->modify(($days >= 0 ? '+' : '') . $days . ' days');
            $feasts[$dt->format('Y-m-d')] = ['name' => $name, 'rank' => $rank];
        };
        
        // Vor Ostern
        $add(-46, 'Aschermittwoch', 'fest');
        $add(-7, 'Palmsonntag (Beginn der Karwoche)', 'hochfest');
        $add(-3, 'Gründonnerstag', 'hochfest');
        $add(-2, 'Karfreitag', 'hochfest');
        $add(-1, 'Karsamstag (Osternacht)', 'hochfest');
        
        // Ostern
        $add(0, 'Hochfest der Auferstehung des Herrn (Ostersonntag)', 'hochfest');
        $add(1, 'Ostermontag', 'hochfest');
        
        // Nach Ostern
        $add(7, '2. Sonntag der Osterzeit (Weißer Sonntag)', 'hochfest');
        $add(39, 'Christi Himmelfahrt', 'hochfest');
        $add(49, 'Pfingstsonntag', 'hochfest');
        $add(50, 'Pfingstmontag', 'hochfest');
        $add(56, 'Dreifaltigkeitssonntag', 'hochfest');
        $add(60, 'Fronleichnam', 'hochfest');
        $add(68, 'Heiligstes Herz Jesu', 'hochfest');
        
        // Christkönig = letzter Sonntag vor 1. Advent
        // 1. Advent = Sonntag >= 27.11. bzw. der 4. Sonntag vor Weihnachten
        $dec25 = new DateTime("$year-12-25");
        $dow_dec25 = (int) $dec25->format('w'); // 0=So
        $advent1 = clone $dec25;
        $advent1->modify('-' . (($dow_dec25 + 21) % 7 + 21) . ' days');
        
        $christkoenig = clone $advent1;
        $christkoenig->modify('-7 days');
        $feasts[$christkoenig->format('Y-m-d')] = ['name' => 'Christkönigssonntag', 'rank' => 'hochfest'];
        
        // Adventssonntage
        for ($i = 0; $i < 4; $i++) {
            $adv = clone $advent1;
            $adv->modify('+' . ($i * 7) . ' days');
            $feasts[$adv->format('Y-m-d')] = [
                'name' => ($i + 1) . '. Adventsonntag',
                'rank' => 'zeit',
            ];
        }
        
        return $feasts;
    }
    
    /**
     * Sonntag im Jahreskreis bestimmen
     * Zählung: Nach Taufe des Herrn beginnen die Sonntage im Jahreskreis.
     * Unterbrechung durch Fastenzeit/Osterzeit.
     * Wiederaufnahme nach Pfingsten.
     */
    public static function ordinary_sunday(DateTime $date, int $year){
        $easter = self::easter($year);
        
        // Taufe des Herrn = Sonntag nach 6. Januar
        $jan6 = new DateTime("$year-01-06");
        $dow_jan6 = (int) $jan6->format('w');
        $baptism = clone $jan6;
        if ($dow_jan6 === 0) {
            $baptism->modify('+7 days');
        } else {
            $baptism->modify('+' . (7 - $dow_jan6) . ' days');
        }
        
        // Aschermittwoch
        $ash = clone $easter;
        $ash->modify('-46 days');
        
        // Pfingstsonntag
        $pentecost = clone $easter;
        $pentecost->modify('+49 days');
        
        // Dreifaltigkeitssonntag
        $trinity = clone $easter;
        $trinity->modify('+56 days');
        
        // Christkönig
        $dec25 = new DateTime("$year-12-25");
        $dow_dec25 = (int) $dec25->format('w');
        $advent1 = clone $dec25;
        $advent1->modify('-' . (($dow_dec25 + 21) % 7 + 21) . ' days');
        $christkoenig = clone $advent1;
        $christkoenig->modify('-7 days');
        
        $date_str = $date->format('Y-m-d');
        
        // Phase 1: Taufe des Herrn bis Aschermittwoch
        if ($date > $baptism && $date < $ash) {
            $week_after_baptism = (int) ceil($baptism->diff($date)->days / 7);
            // Zählung beginnt bei 2 (1. Sonntag JK = Taufe des Herrn = Sonderfall)
            $n = $week_after_baptism + 1;
            return self::format_sunday_number($n);
        }
        
        // Phase 2: Nach Pfingsten bis Christkönig
        if ($date > $trinity && $date < $advent1 && $date_str !== $christkoenig->format('Y-m-d')) {
            // Rückwärts rechnen von Christkönig (= 34. Sonntag im JK)
            $weeks_before_ck = (int) round($date->diff($christkoenig)->days / 7);
            $n = 34 - $weeks_before_ck;
            if ($n >= 2 && $n <= 34) {
                return self::format_sunday_number($n);
            }
        }
        
        return null;
    }
    
    /**
     * Sonntags-Nummer formatieren
     */
    private static function format_sunday_number(int $n): string {
        return $n . '. Sonntag im Jahreskreis';
    }
    
    /**
     * Weihnachtszeit-Sonntage
     */
    private static function christmas_season_name(DateTime $date, int $year){
        $md = $date->format('m-d');
        $dow = (int) $date->format('w');
        
        // Hl. Familie = Sonntag in der Weihnachtsoktav (26.12. - 31.12.)
        if ($md >= '12-26' && $md <= '12-31' && $dow === 0) {
            return 'Fest der Heiligen Familie';
        }
        
        // 2. Sonntag nach Weihnachten (falls vor 6.1.)
        $next_year = $year + 1;
        if ($date->format('m') === '01') {
            // Sonntag zwischen 2.1. und 5.1.
            if ($md >= '01-02' && $md <= '01-05' && $dow === 0) {
                return '2. Sonntag nach Weihnachten';
            }
        }
        
        return null;
    }
    
    /**
     * Fastenzeit-Sonntage
     */
    private static function lent_sunday_name(DateTime $date, int $year){
        $easter = self::easter($year);
        $ash = clone $easter;
        $ash->modify('-46 days');
        
        if ($date <= $ash || $date >= $easter) return null;
        if ((int) $date->format('w') !== 0) return null;
        
        $days_after_ash = (int) $ash->diff($date)->days;
        $week = (int) ceil($days_after_ash / 7);
        
        $names = [
            1 => '1. Fastensonntag',
            2 => '2. Fastensonntag',
            3 => '3. Fastensonntag',
            4 => '4. Fastensonntag (Laetare)',
            5 => '5. Fastensonntag',
            // 6 = Palmsonntag (im moveable_feasts)
        ];
        
        return $names[$week] ?? null;
    }
    
    /**
     * Osterzeit-Sonntage
     */
    private static function easter_season_name(DateTime $date, int $year){
        $easter = self::easter($year);
        $pentecost = clone $easter;
        $pentecost->modify('+49 days');
        
        if ($date <= $easter || $date > $pentecost) return null;
        if ((int) $date->format('w') !== 0) return null;
        
        $days_after_easter = (int) $easter->diff($date)->days;
        $week = (int) ($days_after_easter / 7) + 1;
        
        // Sonntag 2 = Weißer Sonntag, 7 = Pfingsten (in moveable_feasts)
        $names = [
            3 => '3. Sonntag der Osterzeit',
            4 => '4. Sonntag der Osterzeit (Guter Hirte)',
            5 => '5. Sonntag der Osterzeit',
            6 => '6. Sonntag der Osterzeit',
        ];
        
        return $names[$week] ?? null;
    }
    
    /* ================================================================
       HAUPT-API
       ================================================================ */
    
    /**
     * Liturgischen Namen für ein Datum ermitteln
     * 
     * @return array{name: string, rank: string, source: string}|null
     *   rank: hochfest, fest, gedenktag, zeit
     *   source: fixed, moveable, season, ordinary
     */
    public static function get_name(string $date_str){
        try {
            $dt = new DateTime($date_str);
        } catch (\Exception $e) {
            return null;
        }
        
        $year = (int) $dt->format('Y');
        $md = $dt->format('m-d');
        $dow = (int) $dt->format('w');
        
        // 1. Bewegliche Hochfeste (höchste Priorität)
        $moveable = self::moveable_feasts($year);
        if (isset($moveable[$date_str]) && $moveable[$date_str]['rank'] === 'hochfest') {
            return array_merge($moveable[$date_str], ['source' => 'moveable']);
        }
        
        // 2. Feste Hochfeste
        if (isset(self::FIXED_FEASTS[$md]) && self::FIXED_FEASTS[$md]['rank'] === 'hochfest') {
            return array_merge(self::FIXED_FEASTS[$md], ['source' => 'fixed']);
        }
        
        // 3. Bewegliche Feste/Zeiten
        if (isset($moveable[$date_str])) {
            return array_merge($moveable[$date_str], ['source' => 'moveable']);
        }
        
        // 4. Sonntags-Logik
        if ($dow === 0) {
            // Adventssonntage (schon in moveable)
            // Weihnachtszeit
            $xmas = self::christmas_season_name($dt, $year);
            if ($xmas) return ['name' => $xmas, 'rank' => 'fest', 'source' => 'season'];
            
            // Fastenzeit
            $lent = self::lent_sunday_name($dt, $year);
            if ($lent) return ['name' => $lent, 'rank' => 'zeit', 'source' => 'season'];
            
            // Osterzeit
            $easter_s = self::easter_season_name($dt, $year);
            if ($easter_s) return ['name' => $easter_s, 'rank' => 'zeit', 'source' => 'season'];
            
            // Sonntag im Jahreskreis
            $ordinary = self::ordinary_sunday($dt, $year);
            if ($ordinary) return ['name' => $ordinary, 'rank' => 'zeit', 'source' => 'ordinary'];
        }
        
        // 5. Feste Feste/Gedenktage (nur Werktage, Sonntag hat Vorrang)
        if (isset(self::FIXED_FEASTS[$md])) {
            return array_merge(self::FIXED_FEASTS[$md], ['source' => 'fixed']);
        }
        
        return null;
    }
    
    /**
     * Kurzer liturgischer Name (für Messen-Titel)
     * z.B. "4. Sonntag im Jahreskreis" oder "Mariä Aufnahme"
     */
    public static function short_name(string $date_str): string {
        $info = self::get_name($date_str);
        if (!$info) return '';
        
        // Kürze lange Namen
        $name = $info['name'];
        $name = str_replace('Hochfest der Geburt des Herrn (', '', $name);
        $name = str_replace('Hochfest der Auferstehung des Herrn (', '', $name);
        $name = str_replace('Hochfest der ohne Erbsünde empfangenen Jungfrau Maria', 'Mariä Empfängnis', $name);
        $name = str_replace('Hochfest der Gottesmutter Maria', 'Gottesmutter Maria', $name);
        $name = str_replace('Erscheinung des Herrn (Dreikönig)', 'Dreikönig', $name);
        $name = str_replace('Darstellung des Herrn (Mariä Lichtmess)', 'Mariä Lichtmess', $name);
        $name = str_replace('Mariä Aufnahme in den Himmel', 'Mariä Himmelfahrt', $name);
        $name = rtrim($name, ')');
        
        return $name;
    }
    
    /**
     * Lesejahr berechnen (A/B/C für Sonntage)
     */
    public static function reading_cycle(int $year): string {
        $cycles = ['A', 'B', 'C'];
        return $cycles[$year % 3];
    }
    
    /**
     * Lesereihe (I/II für Werktage)
     */
    public static function weekday_cycle(int $year): string {
        return ($year % 2 === 1) ? 'I' : 'II';
    }
}
