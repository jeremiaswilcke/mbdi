<?php
/**
 * Isidor Parish Settings
 * 
 * Zentrale Pfarrei-Daten:
 * Name, Adresse, Kontakt, Bankverbindung, Logo, Öffnungszeiten
 * 
 * Admin-Formular unter Isidor → ⛪ Pfarrei
 * Daten werden global in allen Modulen verwendet (Header, Footer, PDF, etc.)
 */

if (!defined('ABSPATH')) exit;

class Isidor_Parish_Settings {
    
    private static $instance = null;
    
    /** Option key in wp_options */
    private const OPTION_KEY = 'isidor_parish';
    
    /** Alle Felder mit Defaults */
    private const DEFAULTS = [
        // Grunddaten
        'name'          => '',
        'subtitle'      => '',   // z.B. "Röm.-kath. Pfarre" oder "Diözese Wien"
        'logo_url'      => '',
        
        // Adresse
        'street'        => '',
        'zip'           => '',
        'city'          => '',
        'country'       => 'Österreich',
        
        // Kontakt
        'phone'         => '',
        'fax'           => '',
        'email'         => '',
        'website'       => '',
        
        // Bankverbindung
        'bank_name'     => '',
        'iban'          => '',
        'bic'           => '',
        'account_holder'=> '',
        
        // Seelsorge / Pfarrer
        'pastor_name'   => '',
        'pastor_title'  => '',   // z.B. "Pfarrer", "Pfarradministrator"
        
        // Öffnungszeiten Pfarrkanzlei
        'office_hours'  => '',   // Freitext, z.B. "Mo-Fr 9-12 Uhr, Do 15-18 Uhr"
        
        // Liturgischer Kalender
        'diocese_calendar' => '',  // Teilkirche für eucharistiefeier.de API (leer = Deutscher Sprachraum allgemein)
        
        // Sonstiges
        'footer_text'   => '',   // Custom Footer-Text
        'dvr_number'    => '',   // Datenverarbeitungsregister (AT)
        
        // Plakat-Generator E-Mail-Schnellwahl
        'poster_emails' => 'ana.topitsch@katholischekirche.at',  // Komma-getrennt
        
        // Erscheinungsbild / Farben
        'color_primary' => '#2563eb',  // Haupt-Akzentfarbe
        'color_nav_bg'  => '#0f172a',  // Navigation/Header Hintergrund
        'color_nav_text'=> '#e2e8f0',  // Navigation Text
        'font_family'   => 'DM Sans',  // Schriftart
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_page'], 11);
        add_action('admin_init', [$this, 'register_settings']);
        
        // Frontend Shortcode
        add_shortcode('isidor_parish_settings', [$this, 'render_frontend']);
    }
    
    /* ================================================================
       PUBLIC API – Daten abrufen
       ================================================================ */
    
    /**
     * Alle Pfarrei-Daten als Array
     */
    public static function get_all(): array {
        $saved = get_option(self::OPTION_KEY, []);
        return wp_parse_args($saved, self::DEFAULTS);
    }
    
    /**
     * Einzelnes Feld abrufen
     */
    public static function get(string $key, string $fallback = ''): string {
        $data = self::get_all();
        $value = $data[$key] ?? '';
        return $value !== '' ? $value : $fallback;
    }
    
    /**
     * Pfarrname (mit Fallback auf Blog-Name)
     */
    public static function name(): string {
        return self::get('name', get_bloginfo('name'));
    }
    
    /**
     * Formatierte Adresse (mehrzeilig)
     */
    public static function address_lines(): array {
        $data = self::get_all();
        $lines = [];
        
        if ($data['street']) $lines[] = $data['street'];
        
        $city_line = trim(($data['zip'] ? $data['zip'] . ' ' : '') . $data['city']);
        if ($city_line) $lines[] = $city_line;
        
        if ($data['country'] && $data['country'] !== 'Österreich' && $data['country'] !== 'Deutschland') {
            $lines[] = $data['country'];
        }
        
        return $lines;
    }
    
    /**
     * Einzeilige Adresse
     */
    public static function address_oneline(): string {
        return implode(', ', self::address_lines());
    }
    
    /**
     * IBAN formatiert (DE/AT Stil mit Leerzeichen alle 4 Zeichen)
     */
    public static function iban_formatted(): string {
        $iban = preg_replace('/\s+/', '', self::get('iban'));
        return trim(chunk_split(strtoupper($iban), 4, ' '));
    }
    
    /**
     * CSS Custom Properties als inline style-Block
     * Wird von App Shell im <head> ausgegeben
     */
    public static function css_custom_properties(): array {
        $data = self::get_all();
        
        $primary = $data['color_primary'] ?: '#2563eb';
        $nav_bg = $data['color_nav_bg'] ?: '#0f172a';
        $nav_text = $data['color_nav_text'] ?: '#e2e8f0';
        
        // Automatisch abgeleitete Farben
        $primary_hover = self::darken_hex($primary, 15);
        $primary_subtle = self::lighten_hex($primary, 92);
        $primary_text = self::darken_hex($primary, 25);
        
        $font = $data['font_family'] ?: 'DM Sans';
        if ($font === 'System') {
            $font_stack = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
            $font_url = '';
        } else {
            $font_stack = "'{$font}', sans-serif";
            $font_url = 'https://fonts.googleapis.com/css2?family=' . urlencode($font) . ':wght@300;400;500;600;700&display=swap';
        }
        
        $css = ":root {\n";
        $css .= "  --is-primary: {$primary};\n";
        $css .= "  --is-primary-hover: {$primary_hover};\n";
        $css .= "  --is-primary-subtle: {$primary_subtle};\n";
        $css .= "  --is-primary-text: {$primary_text};\n";
        $css .= "  --is-bg-dark: {$nav_bg};\n";
        $css .= "  --is-nav-text: {$nav_text};\n";
        $css .= "  --is-text: {$nav_bg};\n";
        $css .= "  --is-font: {$font_stack};\n";
        $css .= "}\n";
        
        return ['css' => $css, 'font_url' => $font_url, 'font_stack' => $font_stack];
    }
    
    /**
     * Hex-Farbe abdunkeln
     */
    private static function darken_hex(string $hex, int $percent): string {
        $hex = ltrim($hex, '#');
        $r = max(0, hexdec(substr($hex, 0, 2)) - (int)(255 * $percent / 100));
        $g = max(0, hexdec(substr($hex, 2, 2)) - (int)(255 * $percent / 100));
        $b = max(0, hexdec(substr($hex, 4, 2)) - (int)(255 * $percent / 100));
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
    
    /**
     * Hex-Farbe aufhellen (Richtung Weiß, als Hintergrund-Tint)
     */
    private static function lighten_hex(string $hex, int $percent): string {
        $hex = ltrim($hex, '#');
        $factor = $percent / 100;
        $r = (int)(hexdec(substr($hex, 0, 2)) + (255 - hexdec(substr($hex, 0, 2))) * $factor);
        $g = (int)(hexdec(substr($hex, 2, 2)) + (255 - hexdec(substr($hex, 2, 2))) * $factor);
        $b = (int)(hexdec(substr($hex, 4, 2)) + (255 - hexdec(substr($hex, 4, 2))) * $factor);
        return sprintf('#%02x%02x%02x', min(255, $r), min(255, $g), min(255, $b));
    }
    
    /* ================================================================
       ADMIN
       ================================================================ */
    
    public function add_admin_page(): void {
        add_submenu_page(
            'isidor-os',
            'Pfarrei-Einstellungen',
            '⛪ Pfarrei',
            'manage_options',
            'isidor-parish',
            [$this, 'render_admin_page']
        );
    }
    
    public function register_settings(): void {
        register_setting('isidor_parish_settings', self::OPTION_KEY, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize'],
        ]);
    }
    
    public function sanitize(array $input): array {
        $clean = [];
        
        foreach (self::DEFAULTS as $key => $default) {
            if (!isset($input[$key])) {
                $clean[$key] = $default;
                continue;
            }
            
            $val = $input[$key];
            
            switch ($key) {
                case 'email':
                    $clean[$key] = sanitize_email($val);
                    break;
                case 'website':
                case 'logo_url':
                    $clean[$key] = esc_url_raw($val);
                    break;
                case 'iban':
                    $clean[$key] = strtoupper(preg_replace('/\s+/', '', sanitize_text_field($val)));
                    break;
                case 'bic':
                    $clean[$key] = strtoupper(sanitize_text_field($val));
                    break;
                case 'office_hours':
                case 'footer_text':
                    $clean[$key] = sanitize_textarea_field($val);
                    break;
                case 'color_primary':
                case 'color_nav_bg':
                case 'color_nav_text':
                    // Hex-Color validieren
                    $val = sanitize_text_field($val);
                    $clean[$key] = preg_match('/^#[0-9a-fA-F]{6}$/', $val) ? $val : $default;
                    break;
                case 'font_family':
                    $allowed_fonts = ['DM Sans', 'Inter', 'Source Sans 3', 'Lato', 'Open Sans', 'Nunito', 'System'];
                    $val = sanitize_text_field($val);
                    $clean[$key] = in_array($val, $allowed_fonts) ? $val : 'DM Sans';
                    break;
                default:
                    $clean[$key] = sanitize_text_field($val);
            }
        }
        
        // Sync mit Legacy-Option (für Tagesplan-Template Kompatibilität)
        if (!empty($clean['name'])) {
            update_option('isidor_tagesplan_parish_name', $clean['name']);
        }
        if (!empty($clean['logo_url'])) {
            update_option('isidor_tagesplan_logo_url', $clean['logo_url']);
        }
        
        return $clean;
    }
    
    /* ================================================================
       ADMIN-SEITE RENDERN
       ================================================================ */
    
    public function render_admin_page(): void {
        $data = self::get_all();
        $saved = isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true';
        ?>
        <div class="wrap isidor-parish-admin">
            
            <?php if ($saved): ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>✅ Pfarrei-Daten gespeichert!</strong></p>
            </div>
            <?php endif; ?>
            
            <div class="isidor-parish-header">
                <h1>⛪ Pfarrei-Einstellungen</h1>
                <p>Zentrale Daten Ihrer Pfarre – werden in Header, Footer, PDFs und allen Modulen verwendet.</p>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('isidor_parish_settings'); ?>
                
                <div class="isidor-parish-grid">
                    
                    <!-- Linke Spalte: Formulare -->
                    <div class="isidor-parish-forms">
                    
                        <!-- Grunddaten -->
                        <div class="isidor-parish-section">
                            <h2>🏛️ Grunddaten</h2>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_name">Pfarrname *</label></th>
                                    <td>
                                        <input type="text" id="parish_name" name="<?php echo self::OPTION_KEY; ?>[name]" 
                                            value="<?php echo esc_attr($data['name']); ?>" class="regular-text" 
                                            placeholder="z.B. Pfarre Maria Brunn">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_subtitle">Untertitel</label></th>
                                    <td>
                                        <input type="text" id="parish_subtitle" name="<?php echo self::OPTION_KEY; ?>[subtitle]" 
                                            value="<?php echo esc_attr($data['subtitle']); ?>" class="regular-text"
                                            placeholder="z.B. Röm.-kath. Pfarre · Diözese Wien">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_logo">Logo-URL</label></th>
                                    <td>
                                        <input type="url" id="parish_logo" name="<?php echo self::OPTION_KEY; ?>[logo_url]" 
                                            value="<?php echo esc_url($data['logo_url']); ?>" class="regular-text"
                                            placeholder="https://...">
                                        <button type="button" class="button isidor-upload-logo" id="upload-logo-btn">Bild wählen</button>
                                        <?php if ($data['logo_url']): ?>
                                            <div style="margin-top: 10px;">
                                                <img src="<?php echo esc_url($data['logo_url']); ?>" style="max-height: 60px; border-radius: 4px;">
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_pastor_title">Titel Seelsorger</label></th>
                                    <td>
                                        <input type="text" id="parish_pastor_title" name="<?php echo self::OPTION_KEY; ?>[pastor_title]" 
                                            value="<?php echo esc_attr($data['pastor_title']); ?>" class="regular-text"
                                            placeholder="z.B. Pfarrer, Pfarradministrator">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_pastor_name">Name Seelsorger</label></th>
                                    <td>
                                        <input type="text" id="parish_pastor_name" name="<?php echo self::OPTION_KEY; ?>[pastor_name]" 
                                            value="<?php echo esc_attr($data['pastor_name']); ?>" class="regular-text"
                                            placeholder="z.B. Mag. Johann Müller">
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Adresse -->
                        <div class="isidor-parish-section">
                            <h2>📍 Adresse</h2>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_street">Straße / Nr.</label></th>
                                    <td>
                                        <input type="text" id="parish_street" name="<?php echo self::OPTION_KEY; ?>[street]" 
                                            value="<?php echo esc_attr($data['street']); ?>" class="regular-text"
                                            placeholder="z.B. Kirchenplatz 1">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_zip">PLZ</label></th>
                                    <td>
                                        <input type="text" id="parish_zip" name="<?php echo self::OPTION_KEY; ?>[zip]" 
                                            value="<?php echo esc_attr($data['zip']); ?>" style="width: 100px;"
                                            placeholder="1140">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_city">Ort</label></th>
                                    <td>
                                        <input type="text" id="parish_city" name="<?php echo self::OPTION_KEY; ?>[city]" 
                                            value="<?php echo esc_attr($data['city']); ?>" class="regular-text"
                                            placeholder="Wien">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_country">Land</label></th>
                                    <td>
                                        <input type="text" id="parish_country" name="<?php echo self::OPTION_KEY; ?>[country]" 
                                            value="<?php echo esc_attr($data['country']); ?>" class="regular-text">
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Kontakt -->
                        <div class="isidor-parish-section">
                            <h2>📞 Kontakt</h2>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_phone">Telefon</label></th>
                                    <td>
                                        <input type="text" id="parish_phone" name="<?php echo self::OPTION_KEY; ?>[phone]" 
                                            value="<?php echo esc_attr($data['phone']); ?>" class="regular-text"
                                            placeholder="+43 1 1234567">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_fax">Fax</label></th>
                                    <td>
                                        <input type="text" id="parish_fax" name="<?php echo self::OPTION_KEY; ?>[fax]" 
                                            value="<?php echo esc_attr($data['fax']); ?>" class="regular-text">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_email">E-Mail</label></th>
                                    <td>
                                        <input type="email" id="parish_email" name="<?php echo self::OPTION_KEY; ?>[email]" 
                                            value="<?php echo esc_attr($data['email']); ?>" class="regular-text"
                                            placeholder="pfarramt@example.at">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_website">Website</label></th>
                                    <td>
                                        <input type="url" id="parish_website" name="<?php echo self::OPTION_KEY; ?>[website]" 
                                            value="<?php echo esc_url($data['website']); ?>" class="regular-text"
                                            placeholder="https://www.pfarre-beispiel.at">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_office_hours">Öffnungszeiten Kanzlei</label></th>
                                    <td>
                                        <textarea id="parish_office_hours" name="<?php echo self::OPTION_KEY; ?>[office_hours]" 
                                            rows="3" class="large-text"
                                            placeholder="Mo-Fr 9-12 Uhr&#10;Do auch 15-18 Uhr"><?php echo esc_textarea($data['office_hours']); ?></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Bankverbindung -->
                        <div class="isidor-parish-section">
                            <h2>🏦 Bankverbindung</h2>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_account_holder">Kontoinhaber</label></th>
                                    <td>
                                        <input type="text" id="parish_account_holder" name="<?php echo self::OPTION_KEY; ?>[account_holder]" 
                                            value="<?php echo esc_attr($data['account_holder']); ?>" class="regular-text"
                                            placeholder="Röm.-kath. Pfarramt Maria Brunn">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_iban">IBAN</label></th>
                                    <td>
                                        <input type="text" id="parish_iban" name="<?php echo self::OPTION_KEY; ?>[iban]" 
                                            value="<?php echo esc_attr($data['iban']); ?>" class="regular-text"
                                            placeholder="AT12 3456 7890 1234 5678" style="font-family: monospace;">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_bic">BIC/SWIFT</label></th>
                                    <td>
                                        <input type="text" id="parish_bic" name="<?php echo self::OPTION_KEY; ?>[bic]" 
                                            value="<?php echo esc_attr($data['bic']); ?>" style="width: 200px; font-family: monospace;"
                                            placeholder="BKAUATWW">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_bank_name">Bankinstitut</label></th>
                                    <td>
                                        <input type="text" id="parish_bank_name" name="<?php echo self::OPTION_KEY; ?>[bank_name]" 
                                            value="<?php echo esc_attr($data['bank_name']); ?>" class="regular-text"
                                            placeholder="Erste Bank">
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Erscheinungsbild -->
                        <div class="isidor-parish-section">
                            <h2>🎨 Erscheinungsbild</h2>
                            <p style="margin:-2px 0 14px; font-size:0.9em; opacity:0.7;">
                                Farben und Schrift für die gesamte Isidor App. Wird sofort auf allen Seiten übernommen.
                            </p>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_color_primary">Akzentfarbe</label></th>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:10px;">
                                            <input type="color" id="parish_color_primary" name="<?php echo self::OPTION_KEY; ?>[color_primary]" 
                                                value="<?php echo esc_attr($data['color_primary'] ?: '#2563eb'); ?>"
                                                style="width:50px; height:38px; border:1px solid #ccc; border-radius:6px; cursor:pointer;">
                                            <input type="text" value="<?php echo esc_attr($data['color_primary'] ?: '#2563eb'); ?>" 
                                                style="width:90px; font-family:monospace;" readonly
                                                id="color_primary_hex">
                                            <span style="font-size:0.85em; opacity:0.6;">Links, Buttons, aktive Elemente</span>
                                        </div>
                                        <div style="margin-top:8px; display:flex; gap:6px;">
                                            <?php 
                                            $presets = [
                                                '#2563eb' => 'Blau', '#16a34a' => 'Violett', '#059669' => 'Grün',
                                                '#dc2626' => 'Rot', '#d97706' => 'Gold', '#0891b2' => 'Cyan',
                                                '#4f46e5' => 'Indigo', '#db2777' => 'Pink',
                                            ];
                                            foreach ($presets as $hex => $label): ?>
                                                <button type="button" class="isidor-color-preset" 
                                                    data-color="<?php echo $hex; ?>"
                                                    title="<?php echo $label; ?>"
                                                    style="width:28px; height:28px; border-radius:50%; border:2px solid #e2e8f0; background:<?php echo $hex; ?>; cursor:pointer; transition:transform 0.15s;">
                                                </button>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_color_nav_bg">Navigation Hintergrund</label></th>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:10px;">
                                            <input type="color" id="parish_color_nav_bg" name="<?php echo self::OPTION_KEY; ?>[color_nav_bg]" 
                                                value="<?php echo esc_attr($data['color_nav_bg'] ?: '#0f172a'); ?>"
                                                style="width:50px; height:38px; border:1px solid #ccc; border-radius:6px; cursor:pointer;">
                                            <input type="text" value="<?php echo esc_attr($data['color_nav_bg'] ?: '#0f172a'); ?>" 
                                                style="width:90px; font-family:monospace;" readonly
                                                id="color_nav_bg_hex">
                                            <span style="font-size:0.85em; opacity:0.6;">Header, Sidebar, Dark-Theme</span>
                                        </div>
                                        <div style="margin-top:8px; display:flex; gap:6px;">
                                            <?php 
                                            $nav_presets = [
                                                '#0f172a' => 'Slate', '#1e1b4b' => 'Navy', '#1c1917' => 'Warm',
                                                '#14532d' => 'Forest', '#450a0a' => 'Bordeaux', '#172554' => 'Blau',
                                                '#27272a' => 'Zink', '#292524' => 'Stone',
                                            ];
                                            foreach ($nav_presets as $hex => $label): ?>
                                                <button type="button" class="isidor-color-preset" 
                                                    data-target="parish_color_nav_bg"
                                                    data-color="<?php echo $hex; ?>"
                                                    title="<?php echo $label; ?>"
                                                    style="width:28px; height:28px; border-radius:50%; border:2px solid #e2e8f0; background:<?php echo $hex; ?>; cursor:pointer; transition:transform 0.15s;">
                                                </button>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_font">Schriftart</label></th>
                                    <td>
                                        <select id="parish_font" name="<?php echo self::OPTION_KEY; ?>[font_family]" style="padding:6px 10px;">
                                            <?php 
                                            $fonts = [
                                                'DM Sans' => 'DM Sans (modern, clean)',
                                                'Inter' => 'Inter (neutral, technisch)',
                                                'Source Sans 3' => 'Source Sans (klassisch)',
                                                'Lato' => 'Lato (warm, freundlich)',
                                                'Open Sans' => 'Open Sans (neutral)',
                                                'Nunito' => 'Nunito (rund, weich)',
                                                'System' => 'System-Schrift (schnellste)',
                                            ];
                                            foreach ($fonts as $val => $label): ?>
                                                <option value="<?php echo esc_attr($val); ?>" <?php selected($data['font_family'] ?: 'DM Sans', $val); ?>>
                                                    <?php echo esc_html($label); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Sonstiges -->
                        <div class="isidor-parish-section">
                            <h2>📝 Sonstiges</h2>
                            <table class="form-table">
                                <tr>
                                    <th><label for="parish_diocese_calendar">Diözese (Liturgischer Kalender)</label></th>
                                    <td>
                                        <?php
                                        // Werte müssen exakt den Kalender-IDs auf eucharistiefeier.de entsprechen!
                                        $diocese_options = [
                                            ''              => '🌍 Deutscher Sprachraum (Allgemein)',
                                            'edw'           => '🇦🇹 Erzdiözese Wien',
                                            'eds'           => '🇦🇹 Erzdiözese Salzburg',
                                            'grazseckau'    => '🇦🇹 Diözese Graz-Seckau',
                                            'linz'          => '🇦🇹 Diözese Linz',
                                            'deutschland'   => '🇩🇪 Deutschland (Allgemein)',
                                            'koeln'         => '🇩🇪 Erzbistum Köln',
                                            'muenchenfreising' => '🇩🇪 Erzbistum München-Freising',
                                            'burger'        => '🇩🇪 Erzdiözese Freiburg',
                                            'rottenburg'    => '🇩🇪 Diözese Rottenburg-Stuttgart',
                                            'mainz'         => '🇩🇪 Bistum Mainz',
                                            'trier'         => '🇩🇪 Bistum Trier',
                                            'regensburg'    => '🇩🇪 Bistum Regensburg',
                                            'augsburg'      => '🇩🇪 Bistum Augsburg',
                                            'bistumpassau'  => '🇩🇪 Bistum Passau',
                                            'lausannegenffreiburg' => '🇨🇭 Bistum Lausanne-Genf-Freiburg',
                                        ];
                                        ?>
                                        <select id="parish_diocese_calendar" name="<?php echo self::OPTION_KEY; ?>[diocese_calendar]" style="width: 350px;">
                                            <?php foreach ($diocese_options as $val => $label): ?>
                                                <option value="<?php echo esc_attr($val); ?>" <?php selected($data['diocese_calendar'], $val); ?>>
                                                    <?php echo esc_html($label); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description">
                                            Wird für den automatischen Import der Lesungen beim Generieren verwendet.
                                            Quelle: <a href="https://www.eucharistiefeier.de/lk/" target="_blank">eucharistiefeier.de</a>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_footer_text">Footer-Text</label></th>
                                    <td>
                                        <textarea id="parish_footer_text" name="<?php echo self::OPTION_KEY; ?>[footer_text]" 
                                            rows="2" class="large-text"
                                            placeholder="Wird im App-Footer angezeigt"><?php echo esc_textarea($data['footer_text']); ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_dvr">DVR-Nummer</label></th>
                                    <td>
                                        <input type="text" id="parish_dvr" name="<?php echo self::OPTION_KEY; ?>[dvr_number]" 
                                            value="<?php echo esc_attr($data['dvr_number']); ?>" style="width: 200px;">
                                    </td>
                                </tr>
                                <tr>
                                    <th><label for="parish_poster_emails">📧 Plakat E-Mail-Verteiler</label></th>
                                    <td>
                                        <textarea id="parish_poster_emails" name="<?php echo self::OPTION_KEY; ?>[poster_emails]" 
                                            rows="3" style="width: 100%;"
                                            placeholder="ana.topitsch@katholischekirche.at"><?php echo esc_textarea($data['poster_emails'] ?? ''); ?></textarea>
                                        <p class="description">
                                            E-Mail-Adressen für Plakat-Schnellversand (eine pro Zeile oder komma-getrennt).<br>
                                            Diese erscheinen im Plakat-Generator als Schnellauswahl.
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <?php submit_button('Pfarrei-Daten speichern', 'primary large'); ?>
                    
                    </div>
                    
                    <!-- Rechte Spalte: Vorschau-Karte -->
                    <div class="isidor-parish-preview">
                        <div class="isidor-parish-card">
                            <h3>Vorschau</h3>
                            <div class="isidor-parish-card-inner" id="parish-preview">
                                <?php $this->render_preview_card($data); ?>
                            </div>
                            <p class="description" style="margin-top: 12px;">
                                Diese Daten erscheinen automatisch im App-Header, Footer, auf PDFs und in allen Modulen.
                            </p>
                        </div>
                        
                        <div class="isidor-parish-card" style="margin-top: 20px;">
                            <h3>🎨 Aktuelles Farbschema</h3>
                            <div style="display:flex; gap:8px; margin-bottom:12px;">
                                <div style="flex:1; height:40px; border-radius:8px; background:<?php echo esc_attr($data['color_primary'] ?: '#2563eb'); ?>;" title="Akzent"></div>
                                <div style="flex:1; height:40px; border-radius:8px; background:<?php echo esc_attr($data['color_nav_bg'] ?: '#0f172a'); ?>;" title="Navigation"></div>
                                <div style="flex:1; height:40px; border-radius:8px; background:#f8fafc; border:1px solid #e2e8f0;" title="Hintergrund"></div>
                            </div>
                            <div style="font-size:12px; opacity:0.6; line-height:1.6;">
                                Akzent: <?php echo esc_html($data['color_primary'] ?: '#2563eb'); ?><br>
                                Navigation: <?php echo esc_html($data['color_nav_bg'] ?: '#0f172a'); ?><br>
                                Font: <?php echo esc_html($data['font_family'] ?: 'DM Sans'); ?>
                            </div>
                        </div>
                        
                        <div class="isidor-parish-card" style="margin-top: 20px;">
                            <h3>💡 Verwendung</h3>
                            <ul style="margin: 10px 0 0 16px; line-height: 1.8; font-size: 13px;">
                                <li><strong>App-Header:</strong> Logo + Pfarrname</li>
                                <li><strong>App-Footer:</strong> Adresse, Telefon, Kanzlei-Zeiten</li>
                                <li><strong>Tagesplan PDFs:</strong> Briefkopf mit Logo</li>
                                <li><strong>Login-Seite:</strong> Pfarrname als Willkommen</li>
                                <li><strong>Cellerar Exports:</strong> Kontodaten auf Rechnungen</li>
                                <li><strong>Startseite:</strong> Begrüßungstext</li>
                            </ul>
                        </div>
                        
                        <div class="isidor-parish-card" style="margin-top: 20px;">
                            <h3>🔧 Für Entwickler</h3>
                            <code style="display: block; padding: 12px; background: #f0f0f1; border-radius: 6px; font-size: 12px; line-height: 1.6;">
                                Isidor_Parish_Settings::name();<br>
                                Isidor_Parish_Settings::get('phone');<br>
                                Isidor_Parish_Settings::get_all();<br>
                                Isidor_Parish_Settings::address_oneline();<br>
                                Isidor_Parish_Settings::iban_formatted();
                            </code>
                        </div>
                    </div>
                    
                </div>
            </form>
            
            <style>
                .isidor-parish-header {
                    background: linear-gradient(135deg, #1a365d 0%, #2d3748 100%);
                    color: #fff;
                    padding: 28px 32px;
                    border-radius: 12px;
                    margin: 10px 0 24px;
                }
                .isidor-parish-header h1 { color: #fff; margin: 0 0 6px; font-size: 1.6em; }
                .isidor-parish-header p { margin: 0; opacity: 0.8; font-size: 1.05em; }
                
                .isidor-parish-grid {
                    display: grid;
                    grid-template-columns: 1fr 340px;
                    gap: 28px;
                    align-items: start;
                }
                @media (max-width: 1100px) {
                    .isidor-parish-grid { grid-template-columns: 1fr; }
                }
                
                .isidor-parish-section {
                    background: #fff;
                    border: 1px solid #ddd;
                    border-radius: 10px;
                    padding: 20px 24px;
                    margin-bottom: 20px;
                }
                .isidor-parish-section h2 {
                    font-size: 1.15em;
                    margin: 0 0 10px;
                    padding-bottom: 10px;
                    border-bottom: 1px solid #eee;
                }
                .isidor-parish-section .form-table th {
                    font-weight: 500;
                    padding: 10px 10px 10px 0;
                    width: 160px;
                    font-size: 13px;
                }
                .isidor-parish-section .form-table td {
                    padding: 8px 0;
                }
                
                .isidor-parish-card {
                    background: #fff;
                    border: 1px solid #ddd;
                    border-radius: 10px;
                    padding: 20px;
                    position: sticky;
                    top: 52px;
                }
                .isidor-parish-card h3 {
                    margin: 0 0 14px;
                    font-size: 1em;
                    padding-bottom: 10px;
                    border-bottom: 1px solid #eee;
                }
                
                .isidor-preview-name {
                    font-size: 1.15em;
                    font-weight: 700;
                    margin-bottom: 2px;
                }
                .isidor-preview-subtitle {
                    font-size: 0.88em;
                    color: #666;
                    margin-bottom: 12px;
                }
                .isidor-preview-row {
                    display: flex;
                    align-items: flex-start;
                    gap: 8px;
                    margin-bottom: 6px;
                    font-size: 13px;
                    color: #444;
                }
                .isidor-preview-row span:first-child {
                    flex-shrink: 0;
                    width: 20px;
                    text-align: center;
                }
                .isidor-preview-divider {
                    border-top: 1px solid #eee;
                    margin: 10px 0;
                }
                .isidor-preview-bank {
                    font-family: monospace;
                    font-size: 12px;
                    background: #f8f8f8;
                    padding: 8px 10px;
                    border-radius: 6px;
                    margin-top: 6px;
                }
            </style>
            
            <script>
            jQuery(document).ready(function($) {
                // Media Uploader für Logo
                $('#upload-logo-btn').on('click', function(e) {
                    e.preventDefault();
                    var frame = wp.media({
                        title: 'Logo auswählen',
                        button: { text: 'Logo verwenden' },
                        multiple: false,
                        library: { type: 'image' }
                    });
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        $('#parish_logo').val(attachment.url);
                    });
                    frame.open();
                });
                
                // Color picker sync
                $('#parish_color_primary').on('input', function() {
                    $('#color_primary_hex').val(this.value);
                });
                $('#parish_color_nav_bg').on('input', function() {
                    $('#color_nav_bg_hex').val(this.value);
                });
                
                // Color presets
                $('.isidor-color-preset').on('click', function() {
                    var color = $(this).data('color');
                    var target = $(this).data('target') || 'parish_color_primary';
                    $('#' + target).val(color).trigger('input');
                    // Animate
                    $(this).css('transform', 'scale(1.3)');
                    setTimeout(() => $(this).css('transform', 'scale(1)'), 200);
                });
            });
            </script>
            <?php
            wp_enqueue_media(); // Für den Logo-Upload Button
    }
    
    /**
     * Vorschau-Karte rendern
     */
    private function render_preview_card(array $data): void {
        ?>
        <?php if ($data['logo_url']): ?>
            <img src="<?php echo esc_url($data['logo_url']); ?>" style="max-height: 48px; margin-bottom: 10px; border-radius: 4px;">
        <?php endif; ?>
        
        <div class="isidor-preview-name">
            <?php echo esc_html($data['name'] ?: 'Pfarrname'); ?>
        </div>
        
        <?php if ($data['subtitle']): ?>
            <div class="isidor-preview-subtitle"><?php echo esc_html($data['subtitle']); ?></div>
        <?php endif; ?>
        
        <?php if ($data['pastor_name']): ?>
            <div class="isidor-preview-row">
                <span>👤</span>
                <span><?php echo esc_html(($data['pastor_title'] ? $data['pastor_title'] . ': ' : '') . $data['pastor_name']); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['street'] || $data['city']): ?>
            <div class="isidor-preview-row">
                <span>📍</span>
                <span>
                    <?php 
                    $addr = self::address_lines();
                    echo esc_html(implode(', ', $addr));
                    ?>
                </span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['phone']): ?>
            <div class="isidor-preview-row">
                <span>📞</span>
                <span><?php echo esc_html($data['phone']); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['email']): ?>
            <div class="isidor-preview-row">
                <span>✉️</span>
                <span><?php echo esc_html($data['email']); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['website']): ?>
            <div class="isidor-preview-row">
                <span>🌐</span>
                <span><?php echo esc_html($data['website']); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['office_hours']): ?>
            <div class="isidor-preview-divider"></div>
            <div class="isidor-preview-row">
                <span>🕐</span>
                <span><?php echo nl2br(esc_html($data['office_hours'])); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($data['iban']): ?>
            <div class="isidor-preview-divider"></div>
            <div class="isidor-preview-bank">
                <?php if ($data['account_holder']): ?>
                    <?php echo esc_html($data['account_holder']); ?><br>
                <?php endif; ?>
                IBAN: <?php echo esc_html(self::iban_formatted()); ?><br>
                <?php if ($data['bic']): ?>
                    BIC: <?php echo esc_html($data['bic']); ?>
                <?php endif; ?>
                <?php if ($data['bank_name']): ?>
                    <br><?php echo esc_html($data['bank_name']); ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php
    }
    
    /* ================================================================
       FRONTEND SHORTCODE — [isidor_parish_settings]
       Für Admins: Bearbeitungsformular
       Für andere: Nur-Lese-Ansicht der Pfarrdaten
       ================================================================ */
    
    public function render_frontend(): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte anmelden um die Pfarrei-Daten zu sehen.</p>';
        }
        
        $can_edit = current_user_can('manage_options') || current_user_can('isidor_admin');
        $data = self::get_all();
        
        // Formular-Verarbeitung (nur für Admins)
        if ($can_edit && isset($_POST['isidor_parish_frontend_save']) && wp_verify_nonce($_POST['_wpnonce'] ?? '', 'isidor_parish_frontend')) {
            $new_data = [];
            foreach (self::DEFAULTS as $key => $default) {
                if (isset($_POST['parish'][$key])) {
                    $new_data[$key] = sanitize_text_field($_POST['parish'][$key]);
                } else {
                    $new_data[$key] = $data[$key];
                }
            }
            update_option(self::OPTION_KEY, $new_data);
            $data = $new_data;
        }
        
        ob_start();
        ?>
        <div class="isidor-parish-frontend">
            <div class="isidor-parish-header">
                <h2>⛪ Pfarrei-Einstellungen</h2>
                <?php if ($can_edit): ?>
                    <p class="isidor-parish-hint">Zentrale Daten die in allen Modulen verwendet werden.</p>
                <?php endif; ?>
            </div>
            
            <?php if ($can_edit): ?>
                <!-- Bearbeitungsformular für Admins -->
                <form method="post" class="isidor-parish-form">
                    <?php wp_nonce_field('isidor_parish_frontend'); ?>
                    
                    <div class="isidor-parish-grid">
                        <!-- Grunddaten -->
                        <div class="isidor-parish-section">
                            <h3>📍 Grunddaten</h3>
                            <div class="isidor-form-row">
                                <label>Pfarrname</label>
                                <input type="text" name="parish[name]" value="<?php echo esc_attr($data['name']); ?>" placeholder="z.B. Pfarre St. Maria">
                            </div>
                            <div class="isidor-form-row">
                                <label>Untertitel</label>
                                <input type="text" name="parish[subtitle]" value="<?php echo esc_attr($data['subtitle']); ?>" placeholder="z.B. Röm.-kath. Pfarre">
                            </div>
                            <div class="isidor-form-row">
                                <label>Logo</label>
                                <div class="isidor-logo-upload">
                                    <input type="hidden" name="parish[logo_url]" id="parish_logo_url" value="<?php echo esc_attr($data['logo_url']); ?>">
                                    <div class="isidor-logo-preview" id="parish_logo_preview">
                                        <?php if ($data['logo_url']): ?>
                                            <img src="<?php echo esc_url($data['logo_url']); ?>" alt="Logo">
                                            <button type="button" class="isidor-logo-remove" onclick="isidorRemoveLogo()">✕</button>
                                        <?php else: ?>
                                            <span class="isidor-logo-placeholder">Kein Logo</span>
                                        <?php endif; ?>
                                    </div>
                                    <button type="button" class="isidor-btn isidor-btn-outline isidor-btn-small" onclick="isidorUploadLogo()">
                                        📷 Logo wählen
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Adresse -->
                        <div class="isidor-parish-section">
                            <h3>🏠 Adresse</h3>
                            <div class="isidor-form-row">
                                <label>Straße</label>
                                <input type="text" name="parish[street]" value="<?php echo esc_attr($data['street']); ?>">
                            </div>
                            <div class="isidor-form-row isidor-form-row-split">
                                <div>
                                    <label>PLZ</label>
                                    <input type="text" name="parish[zip]" value="<?php echo esc_attr($data['zip']); ?>" style="width:100px;">
                                </div>
                                <div style="flex:1;">
                                    <label>Ort</label>
                                    <input type="text" name="parish[city]" value="<?php echo esc_attr($data['city']); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Kontakt -->
                        <div class="isidor-parish-section">
                            <h3>📞 Kontakt</h3>
                            <div class="isidor-form-row">
                                <label>Telefon</label>
                                <input type="tel" name="parish[phone]" value="<?php echo esc_attr($data['phone']); ?>">
                            </div>
                            <div class="isidor-form-row">
                                <label>E-Mail</label>
                                <input type="email" name="parish[email]" value="<?php echo esc_attr($data['email']); ?>">
                            </div>
                            <div class="isidor-form-row">
                                <label>Website</label>
                                <input type="url" name="parish[website]" value="<?php echo esc_attr($data['website']); ?>">
                            </div>
                        </div>
                        
                        <!-- Seelsorge -->
                        <div class="isidor-parish-section">
                            <h3>👤 Seelsorge</h3>
                            <div class="isidor-form-row">
                                <label>Pfarrer / Leitung</label>
                                <input type="text" name="parish[pastor_name]" value="<?php echo esc_attr($data['pastor_name']); ?>">
                            </div>
                            <div class="isidor-form-row">
                                <label>Titel</label>
                                <input type="text" name="parish[pastor_title]" value="<?php echo esc_attr($data['pastor_title']); ?>" placeholder="z.B. Pfarrer, Pfarradministrator">
                            </div>
                            <div class="isidor-form-row">
                                <label>Kanzlei-Öffnungszeiten</label>
                                <input type="text" name="parish[office_hours]" value="<?php echo esc_attr($data['office_hours']); ?>" placeholder="z.B. Mo-Fr 9-12 Uhr">
                            </div>
                        </div>
                        
                        <!-- Bank -->
                        <div class="isidor-parish-section">
                            <h3>🏦 Bankverbindung</h3>
                            <div class="isidor-form-row">
                                <label>Kontoinhaber</label>
                                <input type="text" name="parish[account_holder]" value="<?php echo esc_attr($data['account_holder']); ?>">
                            </div>
                            <div class="isidor-form-row">
                                <label>IBAN</label>
                                <input type="text" name="parish[iban]" value="<?php echo esc_attr($data['iban']); ?>" placeholder="AT12 3456 7890 1234 5678">
                            </div>
                            <div class="isidor-form-row isidor-form-row-split">
                                <div>
                                    <label>BIC</label>
                                    <input type="text" name="parish[bic]" value="<?php echo esc_attr($data['bic']); ?>">
                                </div>
                                <div style="flex:1;">
                                    <label>Bank</label>
                                    <input type="text" name="parish[bank_name]" value="<?php echo esc_attr($data['bank_name']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="isidor-parish-actions">
                        <button type="submit" name="isidor_parish_frontend_save" class="isidor-btn isidor-btn-primary">
                            💾 Speichern
                        </button>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=isidor-parish')); ?>" class="isidor-btn isidor-btn-outline" target="_blank">
                            ⚙️ Erweiterte Einstellungen (Farben, Diözese)
                        </a>
                    </div>
                </form>
                
            <?php else: ?>
                <!-- Nur-Lese-Ansicht für normale User -->
                <div class="isidor-parish-readonly">
                    <div class="isidor-parish-card-display">
                        <?php if ($data['logo_url']): ?>
                            <img src="<?php echo esc_url($data['logo_url']); ?>" alt="Logo" class="isidor-parish-logo">
                        <?php endif; ?>
                        
                        <h3><?php echo esc_html(self::name()); ?></h3>
                        <?php if ($data['subtitle']): ?>
                            <p class="isidor-parish-subtitle"><?php echo esc_html($data['subtitle']); ?></p>
                        <?php endif; ?>
                        
                        <?php if ($data['street'] || $data['city']): ?>
                            <div class="isidor-parish-info">
                                <strong>📍 Adresse</strong><br>
                                <?php echo nl2br(esc_html(implode("\n", self::address_lines()))); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($data['phone'] || $data['email']): ?>
                            <div class="isidor-parish-info">
                                <strong>📞 Kontakt</strong><br>
                                <?php if ($data['phone']): ?>
                                    Tel: <?php echo esc_html($data['phone']); ?><br>
                                <?php endif; ?>
                                <?php if ($data['email']): ?>
                                    <a href="mailto:<?php echo esc_attr($data['email']); ?>"><?php echo esc_html($data['email']); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($data['pastor_name']): ?>
                            <div class="isidor-parish-info">
                                <strong>👤 <?php echo esc_html($data['pastor_title'] ?: 'Pfarrer'); ?></strong><br>
                                <?php echo esc_html($data['pastor_name']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($data['office_hours']): ?>
                            <div class="isidor-parish-info">
                                <strong>🕐 Kanzlei</strong><br>
                                <?php echo esc_html($data['office_hours']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <style>
        .isidor-parish-frontend { max-width: 900px; }
        .isidor-parish-header h2 { margin: 0 0 8px; font-size: 1.5rem; }
        .isidor-parish-hint { color: #64748b; margin: 0 0 24px; }
        
        .isidor-parish-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 24px;
        }
        .isidor-parish-section {
            background: #f8fafc;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #e2e8f0;
        }
        .isidor-parish-section h3 {
            margin: 0 0 16px;
            font-size: 1rem;
            color: #334155;
        }
        .isidor-form-row { margin-bottom: 12px; }
        .isidor-form-row label {
            display: block;
            font-size: 0.85rem;
            color: #64748b;
            margin-bottom: 4px;
        }
        .isidor-form-row input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 0.95rem;
        }
        .isidor-form-row input:focus {
            outline: none;
            border-color: var(--is-primary, #2563eb);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        .isidor-form-row-split {
            display: flex;
            gap: 12px;
        }
        
        .isidor-parish-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .isidor-btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 0.95rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }
        .isidor-btn-primary {
            background: var(--is-primary, #2563eb);
            color: white;
        }
        .isidor-btn-primary:hover { background: var(--is-primary-hover, #1d4ed8); }
        .isidor-btn-outline {
            background: white;
            color: #334155;
            border: 1px solid #cbd5e1;
        }
        .isidor-btn-outline:hover { background: #f8fafc; }
        .isidor-btn-small { padding: 6px 12px; font-size: 0.85rem; }
        
        /* Logo Upload */
        .isidor-logo-upload { display: flex; align-items: center; gap: 12px; }
        .isidor-logo-preview {
            width: 80px;
            height: 80px;
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            background: #f8fafc;
        }
        .isidor-logo-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .isidor-logo-preview .isidor-logo-placeholder {
            font-size: 0.75rem;
            color: #94a3b8;
            text-align: center;
        }
        .isidor-logo-remove {
            position: absolute;
            top: 2px;
            right: 2px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #ef4444;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 12px;
            line-height: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .isidor-logo-remove:hover { background: #dc2626; }
        
        /* Readonly Card */
        .isidor-parish-card-display {
            background: white;
            border-radius: 12px;
            padding: 24px;
            border: 1px solid #e2e8f0;
            max-width: 400px;
        }
        .isidor-parish-logo {
            max-width: 80px;
            max-height: 80px;
            margin-bottom: 16px;
        }
        .isidor-parish-card-display h3 {
            margin: 0 0 4px;
            font-size: 1.25rem;
        }
        .isidor-parish-subtitle {
            color: #64748b;
            margin: 0 0 16px;
            font-size: 0.9rem;
        }
        .isidor-parish-info {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #e2e8f0;
            font-size: 0.9rem;
        }
        .isidor-parish-info strong { color: #334155; }
        .isidor-parish-info a { color: var(--is-primary, #2563eb); }
        </style>
        
        <?php if ($can_edit): ?>
        <script>
        function isidorUploadLogo() {
            if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                alert('WordPress Media Library nicht verfügbar. Bitte die Seite neu laden.');
                return;
            }
            
            var frame = wp.media({
                title: 'Logo auswählen',
                button: { text: 'Logo verwenden' },
                multiple: false,
                library: { type: 'image' }
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                document.getElementById('parish_logo_url').value = attachment.url;
                
                var preview = document.getElementById('parish_logo_preview');
                preview.innerHTML = '<img src="' + attachment.url + '" alt="Logo">' +
                    '<button type="button" class="isidor-logo-remove" onclick="isidorRemoveLogo()">✕</button>';
            });
            
            frame.open();
        }
        
        function isidorRemoveLogo() {
            document.getElementById('parish_logo_url').value = '';
            document.getElementById('parish_logo_preview').innerHTML = 
                '<span class="isidor-logo-placeholder">Kein Logo</span>';
        }
        </script>
        <?php 
        // Media Library JS laden
        wp_enqueue_media();
        endif; 
        ?>
        <?php
        return ob_get_clean();
    }
}
