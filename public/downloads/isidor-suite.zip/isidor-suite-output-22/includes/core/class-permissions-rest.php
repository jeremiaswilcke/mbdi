<?php
/**
 * Isidor Permissions REST API
 *
 * Endpoints for managing templates, user permissions,
 * service types, and migration.
 *
 * @package IsidorSuite
 * @since 12.0.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_Permissions_REST {

    private const NS = 'isidor/v1';

    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function register_routes(): void {
        // Templates
        register_rest_route(self::NS, '/permissions/templates', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_templates'],  'permission_callback' => [self::class, 'can_assign']],
            ['methods' => 'POST', 'callback' => [self::class, 'create_template'], 'permission_callback' => [self::class, 'can_manage']],
        ]);
        register_rest_route(self::NS, '/permissions/templates/(?P<id>\d+)', [
            ['methods' => 'GET',    'callback' => [self::class, 'get_template'],    'permission_callback' => [self::class, 'can_assign']],
            ['methods' => 'PUT',    'callback' => [self::class, 'update_template'], 'permission_callback' => [self::class, 'can_manage']],
            ['methods' => 'DELETE', 'callback' => [self::class, 'delete_template'], 'permission_callback' => [self::class, 'can_manage']],
        ]);

        // User permissions
        register_rest_route(self::NS, '/permissions/users/(?P<id>\d+)', [
            ['methods' => 'GET', 'callback' => [self::class, 'get_user_perms'], 'permission_callback' => [self::class, 'can_assign']],
            ['methods' => 'PUT', 'callback' => [self::class, 'save_user_perms'], 'permission_callback' => [self::class, 'can_assign']],
        ]);

        // Modules + service types (read-only metadata)
        register_rest_route(self::NS, '/permissions/modules', [
            'methods' => 'GET', 'callback' => [self::class, 'get_modules'], 'permission_callback' => [self::class, 'can_assign'],
        ]);
        register_rest_route(self::NS, '/permissions/services', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_services'],  'permission_callback' => [self::class, 'can_assign']],
            ['methods' => 'POST', 'callback' => [self::class, 'add_service'],   'permission_callback' => [self::class, 'can_manage']],
        ]);
        register_rest_route(self::NS, '/permissions/services/(?P<id>\d+)', [
            ['methods' => 'PUT',    'callback' => [self::class, 'update_service'], 'permission_callback' => [self::class, 'can_manage']],
            ['methods' => 'DELETE', 'callback' => [self::class, 'delete_service'], 'permission_callback' => [self::class, 'can_manage']],
        ]);

        // Starter pack
        register_rest_route(self::NS, '/permissions/starter-pack', [
            ['methods' => 'GET',  'callback' => [self::class, 'get_starter_pack'], 'permission_callback' => [self::class, 'can_manage']],
            ['methods' => 'POST', 'callback' => [self::class, 'import_starter'],   'permission_callback' => [self::class, 'can_manage']],
        ]);

        // Migration
        register_rest_route(self::NS, '/permissions/migrate', [
            'methods' => 'POST', 'callback' => [self::class, 'run_migration'], 'permission_callback' => [self::class, 'is_admin'],
        ]);
    }

    // Permissions
    public static function can_assign(): bool {
        return current_user_can('isidor_assign_templates') || current_user_can('manage_options');
    }
    public static function can_manage(): bool {
        return current_user_can('isidor_manage_templates') || current_user_can('manage_options');
    }
    public static function is_admin(): bool {
        return current_user_can('manage_options');
    }

    // =========================================================================
    // TEMPLATES
    // =========================================================================

    public static function get_templates(): \WP_REST_Response {
        $templates = Isidor_Permissions::get_templates();
        // Enrich with user count
        global $wpdb;
        foreach ($templates as &$t) {
            $t['user_count'] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM " . Isidor_Permissions::t_user_templates() . " WHERE template_id = %d",
                $t['id']
            ));
        }
        return new \WP_REST_Response(['success' => true, 'data' => $templates]);
    }

    public static function get_template(\WP_REST_Request $req): \WP_REST_Response {
        $tpl = Isidor_Permissions::get_template((int) $req['id']);
        if (!$tpl) return new \WP_REST_Response(['success' => false, 'message' => 'Nicht gefunden'], 404);
        return new \WP_REST_Response(['success' => true, 'data' => $tpl]);
    }

    public static function create_template(\WP_REST_Request $req): \WP_REST_Response {
        $body = $req->get_json_params();
        if (empty($body['name'])) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Name erforderlich'], 400);
        }
        $id = Isidor_Permissions::create_template($body);
        if (!$id) return new \WP_REST_Response(['success' => false, 'message' => 'Fehler'], 500);

        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_template($id)]);
    }

    public static function update_template(\WP_REST_Request $req): \WP_REST_Response {
        $id = (int) $req['id'];
        $body = $req->get_json_params();
        Isidor_Permissions::update_template($id, $body);
        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_template($id)]);
    }

    public static function delete_template(\WP_REST_Request $req): \WP_REST_Response {
        $id = (int) $req['id'];
        $tpl = Isidor_Permissions::get_template($id);
        if (!$tpl) return new \WP_REST_Response(['success' => false, 'message' => 'Nicht gefunden'], 404);

        Isidor_Permissions::delete_template($id);
        return new \WP_REST_Response(['success' => true, 'message' => 'Template gelöscht', 'affected_users' => $tpl['user_count']]);
    }

    // =========================================================================
    // USER PERMISSIONS
    // =========================================================================

    public static function get_user_perms(\WP_REST_Request $req): \WP_REST_Response {
        $uid = (int) $req['id'];
        $user = get_userdata($uid);
        if (!$user) return new \WP_REST_Response(['success' => false, 'message' => 'User nicht gefunden'], 404);

        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_user_profile($uid)]);
    }

    public static function save_user_perms(\WP_REST_Request $req): \WP_REST_Response {
        $uid = (int) $req['id'];
        $user = get_userdata($uid);
        if (!$user) return new \WP_REST_Response(['success' => false, 'message' => 'User nicht gefunden'], 404);

        $body = $req->get_json_params();

        // Role change (only admin/pfarrer/sekretär)
        if (isset($body['role']) && current_user_can('isidor_manage_users')) {
            $allowed_roles = ['isidor_pfarrer', 'isidor_sekretaer', 'isidor_mitglied'];
            if (in_array($body['role'], $allowed_roles, true)) {
                $user->set_role($body['role']);
            }
        }

        // Templates
        if (isset($body['template_ids']) && is_array($body['template_ids'])) {
            Isidor_Permissions::set_user_templates($uid, array_map('intval', $body['template_ids']));
        }

        // Permission overrides
        if (isset($body['overrides']) && is_array($body['overrides'])) {
            Isidor_Permissions::set_all_user_overrides($uid, $body['overrides']);
        }

        // Service overrides
        if (isset($body['service_overrides']) && is_array($body['service_overrides'])) {
            Isidor_Permissions::set_all_user_service_overrides($uid, $body['service_overrides']);
        }

        // Delegate assign_templates capability
        if (isset($body['can_assign_templates']) && current_user_can('isidor_manage_users')) {
            if ($body['can_assign_templates']) {
                $user->add_cap('isidor_assign_templates');
            } else {
                $user->remove_cap('isidor_assign_templates');
            }
        }

        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_user_profile($uid)]);
    }

    // =========================================================================
    // MODULES + SERVICES
    // =========================================================================

    public static function get_modules(): \WP_REST_Response {
        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_modules()]);
    }

    public static function get_services(): \WP_REST_Response {
        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_service_types()]);
    }

    public static function add_service(\WP_REST_Request $req): \WP_REST_Response {
        $body = $req->get_json_params();
        if (empty($body['name'])) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Name erforderlich'], 400);
        }
        $id = Isidor_Permissions::add_service_type($body['name'], $body['category'] ?? 'sonstige');
        if (!$id) return new \WP_REST_Response(['success' => false, 'message' => 'Dienst existiert bereits'], 400);
        return new \WP_REST_Response(['success' => true, 'data' => ['id' => $id]]);
    }

    public static function update_service(\WP_REST_Request $req): \WP_REST_Response {
        $id = (int) $req['id'];
        $body = $req->get_json_params();
        Isidor_Permissions::update_service_type($id, $body);
        return new \WP_REST_Response(['success' => true]);
    }

    public static function delete_service(\WP_REST_Request $req): \WP_REST_Response {
        $id = (int) $req['id'];
        Isidor_Permissions::delete_service_type($id);
        return new \WP_REST_Response(['success' => true, 'message' => 'Dienst deaktiviert']);
    }

    // =========================================================================
    // STARTER PACK + MIGRATION
    // =========================================================================

    public static function get_starter_pack(): \WP_REST_Response {
        return new \WP_REST_Response(['success' => true, 'data' => Isidor_Permissions::get_starter_pack()]);
    }

    public static function import_starter(): \WP_REST_Response {
        $created = Isidor_Permissions::import_starter_pack();
        return new \WP_REST_Response([
            'success' => true,
            'message' => count($created) . ' Templates importiert',
            'created' => $created,
        ]);
    }

    public static function run_migration(): \WP_REST_Response {
        $log = Isidor_Permissions::migrate_from_v1();
        return new \WP_REST_Response(['success' => true, 'log' => $log]);
    }
}
