<?php
/**
 * Isidor Permissions Frontend Shortcodes
 *
 * [isidor_permission_templates] — Template-Verwaltung
 * [isidor_permission_user id="123"] — User-Berechtigungen bearbeiten
 *
 * @package IsidorSuite
 * @since 12.0.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_Permissions_Shortcodes {

    public static function init(): void {
        add_shortcode('isidor_permission_templates', [self::class, 'render_templates']);
        add_shortcode('isidor_permission_user', [self::class, 'render_user_perms']);
        add_shortcode('isidor_permission_services', [self::class, 'render_services']);
        add_action('wp_enqueue_scripts', [self::class, 'maybe_enqueue']);
    }

    public static function maybe_enqueue(): void {
        global $post;
        if (!$post) return;

        $needs = has_shortcode($post->post_content, 'isidor_permission_templates')
              || has_shortcode($post->post_content, 'isidor_permission_user')
              || has_shortcode($post->post_content, 'isidor_permission_services')
              || has_shortcode($post->post_content, 'isidor_app') // App Shell
              || has_shortcode($post->post_content, 'isidor_app_home')
              || has_shortcode($post->post_content, 'isidor_user_manager');

        if (!$needs) return;

        wp_enqueue_style(
            'isidor-permissions-frontend',
            ISIDOR_SUITE_URL . 'assets/css/permissions-frontend.css',
            [],
            ISIDOR_SUITE_VERSION
        );

        wp_enqueue_script(
            'isidor-permissions-frontend',
            ISIDOR_SUITE_URL . 'assets/js/permissions-frontend.js',
            ['jquery'],
            ISIDOR_SUITE_VERSION,
            true
        );

        wp_localize_script('isidor-permissions-frontend', 'isidorPerms', [
            'restUrl'   => esc_url_raw(rest_url('isidor/v1/')),
            'restNonce' => wp_create_nonce('wp_rest'),
            'iconsUrl'  => ISIDOR_SUITE_URL . 'assets/icons/templates/',
        ]);
    }

    /**
     * [isidor_permission_templates] — Template management page
     */
    public static function render_templates(): string {
        if (!current_user_can('isidor_manage_templates') && !current_user_can('manage_options')) {
            return '<p>Keine Berechtigung für die Template-Verwaltung.</p>';
        }

        return '<div id="isidor-perm-templates"></div>';
    }

    /**
     * [isidor_permission_user id="123"] — User permissions editor
     * Can also be triggered dynamically from user manager JS
     */
    public static function render_user_perms($atts): string {
        if (!current_user_can('isidor_assign_templates') && !current_user_can('manage_options')) {
            return '<p>Keine Berechtigung.</p>';
        }

        $atts = shortcode_atts(['id' => 0], $atts);
        $user_id = intval($atts['id']);

        $html = '<div id="isidor-perm-user-editor"';
        if ($user_id) {
            $html .= ' data-user-id="' . $user_id . '"';
        }
        $html .= '></div>';

        if ($user_id) {
            $html .= '<script>jQuery(function(){ if(window.IsidorUserPerms) window.IsidorUserPerms.open(' . $user_id . '); });</script>';
        }

        return $html;
    }

    /**
     * [isidor_permission_services] — Service types management
     */
    public static function render_services(): string {
        if (!current_user_can('isidor_manage_templates') && !current_user_can('manage_options')) {
            return '<p>Keine Berechtigung.</p>';
        }

        return '<div id="isidor-perm-services"></div>';
    }
}
