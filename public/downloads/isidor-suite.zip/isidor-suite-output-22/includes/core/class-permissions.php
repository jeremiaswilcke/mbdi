<?php
/**
 * Isidor Permissions Engine v2
 *
 * Template-basiertes Berechtigungssystem.
 * Ersetzt das alte flat-table System (class-app-permissions.php).
 *
 * Architektur:
 *   3 Master-Rollen (isidor_pfarrer, isidor_sekretaer, isidor_mitglied)
 *   + Templates (DB-gespeichert, per UI verwaltbar)
 *   + Individuelle Overrides (grant/revoke pro User)
 *   + Dienst-Zuordnungen (pro Template + User-Overrides)
 *
 * @package IsidorSuite
 * @since 12.0.0
 */

if (!defined('ABSPATH')) exit;

class Isidor_Permissions {

    private static $instance = null;

    /** Per-request cache */
    private $cache = [];
    private $service_cache = [];

    // =========================================================================
    // CAP BRIDGE (unchanged from v1 — maps WP capabilities to module:permission)
    // =========================================================================

    private const CAP_BRIDGE = [
        // Liturgus
        'liturgus_view'           => ['liturgus', 'view'],
        'liturgus_signup'         => ['liturgus', 'signup'],
        'liturgus_assign_others'  => ['liturgus', 'assign'],
        'liturgus_manage'         => ['liturgus', 'manage'],
        'liturgus_remind'         => ['liturgus', 'remind'],
        'liturgus_predigt'        => ['liturgus', 'predigt'],
        'liturgus_admin'          => ['liturgus', 'admin'],

        // Cantus
        'isidor_cantus_view'      => ['cantus', 'view'],
        'isidor_cantus_edit'      => ['cantus', 'plan'],
        'isidor_cantus_export'    => ['cantus', 'export'],
        'isidor_cantus_manage'    => ['cantus', 'manage'],
        'isidor_cantus_admin'     => ['cantus', 'admin'],

        // Cellerar
        'isidor_cellerar_read'             => ['cellerar', 'view'],
        'isidor_cellerar_add_income'       => ['cellerar', 'income'],
        'isidor_cellerar_add_expense'      => ['cellerar', 'expense'],
        'isidor_cellerar_approve_expense'  => ['cellerar', 'approve'],
        'isidor_cellerar_export'           => ['cellerar', 'export'],
        'isidor_cellerar_view_stats'       => ['cellerar', 'view'],
        'isidor_cellerar_manage_settings'  => ['cellerar', 'admin'],

        // Sakristan
        'isidor_sakristan_view'        => ['sakristan', 'view'],
        'isidor_sakristan_edit'        => ['sakristan', 'edit'],
        'isidor_sakristan_check'       => ['sakristan', 'edit'],
        'isidor_sakristan_todo_create' => ['sakristan', 'edit'],
        'isidor_sakristan_timelog'     => ['sakristan', 'timelog'],
        'isidor_sakristan_timelog_view'=> ['sakristan', 'view'],
        'isidor_sakristan_admin'       => ['sakristan', 'admin'],

        // Agenda
        'isidor_agenda_view'      => ['agenda', 'view'],
        'isidor_agenda_request'   => ['agenda', 'request'],
        'agenda_request_room'     => ['agenda', 'request'],
        'isidor_agenda_approve'   => ['agenda', 'approve'],
        'agenda_approve_booking'  => ['agenda', 'approve'],
        'isidor_agenda_rooms'     => ['agenda', 'rooms'],
        'agenda_manage_rooms'     => ['agenda', 'rooms'],
        'isidor_agenda_export'    => ['agenda', 'export'],
        'agenda_export'           => ['agenda', 'export'],
        'isidor_agenda_admin'     => ['agenda', 'admin'],

        // Tagesplan
        'isidor_tagesplan_view'    => ['tagesplan', 'view'],
        'isidor_tagesplan_edit'    => ['tagesplan', 'edit'],
        'isidor_tagesplan_export'  => ['tagesplan', 'export'],
        'isidor_tagesplan_display' => ['tagesplan', 'display'],
        'isidor_tagesplan_admin'   => ['tagesplan', 'admin'],

        // Liturgia
        'isidor_liturgia_view'    => ['liturgia', 'view'],
        'isidor_liturgia_plan'    => ['liturgia', 'plan'],
        'isidor_liturgia_manage'  => ['liturgia', 'manage'],
        'isidor_liturgia_admin'   => ['liturgia', 'admin'],

        // Consilium
        'isidor_consilium_view'   => ['consilium', 'view'],
        'isidor_consilium_vote'   => ['consilium', 'vote'],
        'isidor_consilium_manage' => ['consilium', 'manage'],
        'isidor_consilium_admin'  => ['consilium', 'admin'],

        // Communicator
        'isidor_communicator_view'   => ['communicator', 'view'],
        'isidor_communicator_send'   => ['communicator', 'send'],
        'isidor_communicator_admin'  => ['communicator', 'admin'],

        // Meta-Permissions
        'isidor_manage_templates'    => ['_system', 'manage_templates'],
        'isidor_assign_templates'    => ['_system', 'assign_templates'],
        'isidor_manage_users'        => ['_system', 'manage_users'],
    ];

    /**
     * All modules with their available permissions (for UI)
     */
    private const MODULES = [
        'liturgus' => [
            'name' => 'Liturgus',
            'icon' => '📋',
            'permissions' => [
                'view'    => 'Dienstplan sehen',
                'signup'  => 'Sich für Dienste eintragen',
                'assign'  => 'Andere Personen zuweisen',
                'manage'  => 'Dienstplan verwalten',
                'remind'  => 'Erinnerungen senden',
                'predigt' => 'Predigt',
                'admin'   => 'Administrieren',
            ],
        ],
        'cantus' => [
            'name' => 'Cantus',
            'icon' => '🎵',
            'permissions' => [
                'view'   => 'Liederbuch sehen',
                'plan'   => 'Lieder planen',
                'manage' => 'Liederbuch verwalten',
                'export' => 'PDF exportieren',
                'admin'  => 'Administrieren',
            ],
        ],
        'consilium' => [
            'name' => 'Consilium',
            'icon' => '🏛️',
            'permissions' => [
                'view'   => 'Sitzungen sehen',
                'vote'   => 'Abstimmen',
                'manage' => 'Sitzungen verwalten',
                'admin'  => 'Administrieren',
            ],
        ],
        'cellerar' => [
            'name' => 'Cellerar',
            'icon' => '💰',
            'permissions' => [
                'view'    => 'Finanzen sehen',
                'income'  => 'Einnahmen erfassen',
                'expense' => 'Ausgaben einreichen',
                'approve' => 'Ausgaben genehmigen',
                'export'  => 'Exportieren',
                'admin'   => 'Administrieren',
            ],
        ],
        'sakristan' => [
            'name' => 'Sakristan',
            'icon' => '⛪',
            'permissions' => [
                'view'    => 'Sakristei sehen',
                'edit'    => 'Bearbeiten & Aufgaben',
                'timelog' => 'Zeiterfassung',
                'admin'   => 'Administrieren',
            ],
        ],
        'liturgia' => [
            'name' => 'Liturgia',
            'icon' => '📖',
            'permissions' => [
                'view'   => 'Liturgie sehen',
                'plan'   => 'Liturgie planen',
                'manage' => 'Liturgia verwalten',
                'admin'  => 'Administrieren',
            ],
        ],
        'agenda' => [
            'name' => 'Agenda',
            'icon' => '📅',
            'permissions' => [
                'view'    => 'Termine sehen',
                'request' => 'Räume anfragen',
                'approve' => 'Buchungen genehmigen',
                'rooms'   => 'Räume verwalten',
                'export'  => 'Exportieren',
                'admin'   => 'Administrieren',
            ],
        ],
        'tagesplan' => [
            'name' => 'Tagesplan',
            'icon' => '📆',
            'permissions' => [
                'view'    => 'Tagesplan sehen',
                'edit'    => 'Tagesplan bearbeiten',
                'export'  => 'Exportieren',
                'display' => 'Display-Modus',
                'admin'   => 'Administrieren',
            ],
        ],
        'communicator' => [
            'name' => 'Nachrichten',
            'icon' => '💬',
            'permissions' => [
                'view' => 'Nachrichten sehen',
                'send' => 'Nachrichten senden',
                'admin'=> 'Administrieren',
            ],
        ],
    ];

    // =========================================================================
    // TABLE NAMES
    // =========================================================================

    public static function t_templates(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_permission_templates';
    }
    public static function t_template_perms(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_template_permissions';
    }
    public static function t_template_services(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_template_services';
    }
    public static function t_user_templates(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_user_templates';
    }
    public static function t_user_overrides(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_user_permission_overrides';
    }
    public static function t_user_services(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_user_services';
    }
    public static function t_service_types(): string {
        global $wpdb; return $wpdb->prefix . 'isidor_service_types';
    }

    // =========================================================================
    // SINGLETON + INIT
    // =========================================================================

    public static function get_instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_filter('user_has_cap', [$this, 'bridge_capabilities'], 10, 4);
    }

    // =========================================================================
    // DB SETUP
    // =========================================================================

    public static function create_tables(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $sqls = [];

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_service_types() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            slug VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            category VARCHAR(30) DEFAULT 'liturgisch',
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_templates() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            slug VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50) DEFAULT '',
            is_starter TINYINT(1) DEFAULT 0,
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_template_perms() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            template_id BIGINT UNSIGNED NOT NULL,
            module VARCHAR(30) NOT NULL,
            permission VARCHAR(30) NOT NULL,
            UNIQUE KEY tpl_mod_perm (template_id, module, permission)
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_template_services() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            template_id BIGINT UNSIGNED NOT NULL,
            service_slug VARCHAR(50) NOT NULL,
            UNIQUE KEY tpl_svc (template_id, service_slug)
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_user_templates() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            template_id BIGINT UNSIGNED NOT NULL,
            assigned_by BIGINT UNSIGNED DEFAULT NULL,
            assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY usr_tpl (user_id, template_id),
            KEY idx_user (user_id)
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_user_overrides() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            module VARCHAR(30) NOT NULL,
            permission VARCHAR(30) NOT NULL,
            action ENUM('grant','revoke') NOT NULL,
            UNIQUE KEY usr_mod_perm (user_id, module, permission),
            KEY idx_user (user_id)
        ) {$charset};";

        $sqls[] = "CREATE TABLE IF NOT EXISTS " . self::t_user_services() . " (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            service_slug VARCHAR(50) NOT NULL,
            action ENUM('grant','revoke') NOT NULL,
            UNIQUE KEY usr_svc (user_id, service_slug),
            KEY idx_user (user_id)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ($sqls as $sql) {
            dbDelta($sql);
        }

        self::seed_service_types();
    }

    /**
     * Standard-Diensttypen anlegen (falls leer)
     */
    private static function seed_service_types(): void {
        global $wpdb;
        $table = self::t_service_types();

        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        if ($count > 0) return;

        $services = [
            ['lesung',           'Lesung',           'liturgisch', 10],
            ['fuerbitten',       'Fürbitten',        'liturgisch', 20],
            ['kommunionhelfer',  'Kommunionhelfer',  'liturgisch', 30],
            ['ministrant',       'Ministrant',       'liturgisch', 40],
            ['mesner',           'Mesner',           'liturgisch', 50],
            ['liturg',           'Liturg',           'liturgisch', 60],
            ['diakon',           'Diakon',           'liturgisch', 70],
            ['predigt',          'Predigt',          'liturgisch', 80],
            ['wortgottesfeier',  'Wortgottesfeier',  'liturgisch', 90],
            ['kantor',           'Kantor',           'musikalisch', 100],
            ['vorsaenger',       'Vorsänger',        'musikalisch', 110],
            ['orgel',            'Orgel',            'musikalisch', 120],
            ['technik',          'Technik',          'technisch', 130],
            ['streaming',        'Streaming',        'technisch', 140],
            ['kiwogo',           'Kindergottesdienst','sonstige', 150],
            ['blumenschmuck',    'Blumenschmuck',    'sonstige', 160],
        ];

        foreach ($services as $s) {
            $wpdb->insert($table, [
                'slug'      => $s[0],
                'name'      => $s[1],
                'category'  => $s[2],
                'sort_order'=> $s[3],
            ]);
        }
    }

    // =========================================================================
    // MASTER ROLES
    // =========================================================================

    /**
     * Create the 3 master roles + set capabilities
     */
    public static function setup_roles(): void {
        // Remove all old Isidor roles
        $old_roles = [
            'isidor_pfarrer_godmode', 'isidor_diakon', 'isidor_liturg_kantor',
            'isidor_mesner', 'isidor_ministrant', 'isidor_mitarbeiter',
            'isidor_ag_leiter', 'isidor_pgr', 'isidor_vvr',
            'isidor_orgel', 'isidor_technik',
            // Legacy
            'isidor_pfarrer', 'isidor_liturg', 'isidor_mini',
            'ministrant', 'mesner', 'diakon', 'pfarrer',
            'liturgen', 'liturg', 'kantor', 'orgel', 'technik',
            'orgel_technik', 'orgel/technik',
            'pfarrsekretaer', 'sekretaer', 'pgr', 'vvr', 'mitarbeiter',
        ];

        foreach ($old_roles as $role_slug) {
            if ($role_slug === 'isidor_pfarrer' || $role_slug === 'isidor_sekretaer') {
                // These will be recreated below — only remove if they have old caps
                continue;
            }
            remove_role($role_slug);
        }

        // Pfarrer (Godmode)
        remove_role('isidor_pfarrer');
        add_role('isidor_pfarrer', 'Pfarrer', [
            'read'                    => true,
            'create_users'            => true,
            'edit_users'              => true,
            'list_users'              => true,
            'isidor_manage_templates' => true,
            'isidor_assign_templates' => true,
            'isidor_manage_users'     => true,
        ]);

        // Sekretär(in)
        remove_role('isidor_sekretaer');
        add_role('isidor_sekretaer', 'Sekretär(in)', [
            'read'                    => true,
            'create_users'            => true,
            'edit_users'              => true,
            'list_users'              => true,
            'isidor_manage_templates' => true,
            'isidor_assign_templates' => true,
            'isidor_manage_users'     => true,
        ]);

        // Mitglied (Basis)
        remove_role('isidor_mitglied');
        add_role('isidor_mitglied', 'Mitglied', [
            'read' => true,
        ]);

        // Admin gets meta-caps
        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('isidor_manage_templates');
            $admin->add_cap('isidor_assign_templates');
            $admin->add_cap('isidor_manage_users');
        }
    }

    // =========================================================================
    // CAPABILITY BRIDGE (core filter)
    // =========================================================================

    /** Recursion guard */
    private $resolving = [];

    /**
     * WordPress user_has_cap filter.
     * Maps WP capabilities to the template-based permission system.
     */
    public function bridge_capabilities(array $allcaps, array $caps, array $args, $user): array {
        $requested_cap = $args[0] ?? '';

        if (!isset(self::CAP_BRIDGE[$requested_cap])) {
            return $allcaps;
        }

        // Already granted by WP role
        if (!empty($allcaps[$requested_cap])) {
            return $allcaps;
        }

        $user_id = (int) ($args[1] ?? 0);
        if ($user_id <= 0) return $allcaps;

        // Recursion guard
        $guard_key = $user_id . ':' . $requested_cap;
        if (isset($this->resolving[$guard_key])) {
            return $allcaps;
        }
        $this->resolving[$guard_key] = true;

        // Admins can do everything
        if (!empty($allcaps['manage_options'])) {
            $allcaps[$requested_cap] = true;
            unset($this->resolving[$guard_key]);
            return $allcaps;
        }

        // Check roles from the $user object directly (no get_userdata call)
        $roles = [];
        if (is_object($user) && isset($user->roles)) {
            $roles = (array) $user->roles;
        }

        // Pfarrer can do everything in Isidor
        if (in_array('isidor_pfarrer', $roles, true) || in_array('isidor_pfarrer_godmode', $roles, true)) {
            $allcaps[$requested_cap] = true;
            unset($this->resolving[$guard_key]);
            return $allcaps;
        }

        // Sekretär can do everything except *_admin
        if (in_array('isidor_sekretaer', $roles, true)) {
            [$module, $perm] = self::CAP_BRIDGE[$requested_cap];
            if ($perm !== 'admin' && $module !== '_system') {
                $allcaps[$requested_cap] = true;
            }
            unset($this->resolving[$guard_key]);
            return $allcaps;
        }

        // Template-based resolution (only for isidor_mitglied or unknown roles)
        // Skip if tables don't exist yet (pre-migration)
        if (!$this->tables_exist()) {
            unset($this->resolving[$guard_key]);
            return $allcaps;
        }

        [$module, $perm] = self::CAP_BRIDGE[$requested_cap];

        $effective = $this->get_effective_permissions($user_id);

        if (isset($effective[$module]) && in_array($perm, $effective[$module], true)) {
            $allcaps[$requested_cap] = true;
        }

        // admin permission grants all permissions for that module
        if (empty($allcaps[$requested_cap]) && isset($effective[$module]) && in_array('admin', $effective[$module], true)) {
            $allcaps[$requested_cap] = true;
        }

        unset($this->resolving[$guard_key]);
        return $allcaps;
    }

    /** Check if new tables exist (cached) */
    private $tables_exist_cache = null;
    private function tables_exist(): bool {
        if ($this->tables_exist_cache !== null) return $this->tables_exist_cache;
        global $wpdb;
        $this->tables_exist_cache = $wpdb->get_var(
            "SHOW TABLES LIKE '" . self::t_user_templates() . "'"
        ) !== null;
        return $this->tables_exist_cache;
    }

    // =========================================================================
    // PERMISSION RESOLUTION
    // =========================================================================

    /**
     * Get effective permissions for a user (cached per request).
     * Returns: ['module' => ['perm1', 'perm2', ...], ...]
     */
    public function get_effective_permissions(int $user_id): array {
        if (isset($this->cache[$user_id])) {
            return $this->cache[$user_id];
        }

        global $wpdb;

        // 1. Collect all permissions from assigned templates
        $perms = [];
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT tp.module, tp.permission
             FROM " . self::t_user_templates() . " ut
             JOIN " . self::t_template_perms() . " tp ON tp.template_id = ut.template_id
             WHERE ut.user_id = %d",
            $user_id
        ));

        foreach ($rows as $row) {
            $perms[$row->module][] = $row->permission;
        }

        // 2. Apply overrides
        $overrides = $wpdb->get_results($wpdb->prepare(
            "SELECT module, permission, action FROM " . self::t_user_overrides() . " WHERE user_id = %d",
            $user_id
        ));

        foreach ($overrides as $o) {
            if ($o->action === 'grant') {
                $perms[$o->module][] = $o->permission;
            } elseif ($o->action === 'revoke') {
                if (isset($perms[$o->module])) {
                    $perms[$o->module] = array_diff($perms[$o->module], [$o->permission]);
                }
            }
        }

        // Deduplicate
        foreach ($perms as &$p) {
            $p = array_values(array_unique($p));
        }

        $this->cache[$user_id] = $perms;
        return $perms;
    }

    /**
     * Get effective service slugs for a user.
     */
    public function get_effective_services(int $user_id): array {
        if (isset($this->service_cache[$user_id])) {
            return $this->service_cache[$user_id];
        }

        global $wpdb;

        // 1. From templates
        $services = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT ts.service_slug
             FROM " . self::t_user_templates() . " ut
             JOIN " . self::t_template_services() . " ts ON ts.template_id = ut.template_id
             WHERE ut.user_id = %d",
            $user_id
        ));

        // 2. Apply overrides
        $overrides = $wpdb->get_results($wpdb->prepare(
            "SELECT service_slug, action FROM " . self::t_user_services() . " WHERE user_id = %d",
            $user_id
        ));

        foreach ($overrides as $o) {
            if ($o->action === 'grant' && !in_array($o->service_slug, $services, true)) {
                $services[] = $o->service_slug;
            } elseif ($o->action === 'revoke') {
                $services = array_diff($services, [$o->service_slug]);
            }
        }

        $result = array_values(array_unique($services));
        $this->service_cache[$user_id] = $result;
        return $result;
    }

    /**
     * Get all users that have a specific service assigned.
     * Used by Liturgus for email notifications.
     */
    public static function get_users_for_service(string $service_slug): array {
        global $wpdb;
        $inst = self::get_instance();

        // Users from templates
        $from_templates = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT ut.user_id
             FROM " . self::t_user_templates() . " ut
             JOIN " . self::t_template_services() . " ts ON ts.template_id = ut.template_id
             WHERE ts.service_slug = %s",
            $service_slug
        ));

        // Users with individual grant
        $granted = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM " . self::t_user_services() . " WHERE service_slug = %s AND action = 'grant'",
            $service_slug
        ));

        // Users with individual revoke
        $revoked = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM " . self::t_user_services() . " WHERE service_slug = %s AND action = 'revoke'",
            $service_slug
        ));

        $all = array_unique(array_merge($from_templates, $granted));
        $all = array_diff($all, $revoked);

        // Also include pfarrer + sekretär + admin who have liturgus:manage
        // They should always see everything but don't need service emails
        // → intentionally NOT included, they get emails based on their own services

        return array_values(array_map('intval', $all));
    }

    /**
     * Clear caches for a user.
     */
    public function clear_cache(int $user_id = 0): void {
        if ($user_id > 0) {
            unset($this->cache[$user_id], $this->service_cache[$user_id]);
        } else {
            $this->cache = [];
            $this->service_cache = [];
        }
    }

    // =========================================================================
    // TEMPLATE CRUD
    // =========================================================================

    public static function get_templates(): array {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM " . self::t_templates() . " ORDER BY sort_order, name",
            ARRAY_A
        ) ?: [];
    }

    public static function get_template(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::t_templates() . " WHERE id = %d", $id
        ), ARRAY_A);
        if (!$row) return null;

        // Load permissions
        $row['permissions'] = $wpdb->get_results($wpdb->prepare(
            "SELECT module, permission FROM " . self::t_template_perms() . " WHERE template_id = %d",
            $id
        ), ARRAY_A) ?: [];

        // Load services
        $row['services'] = $wpdb->get_col($wpdb->prepare(
            "SELECT service_slug FROM " . self::t_template_services() . " WHERE template_id = %d",
            $id
        )) ?: [];

        // Count assigned users
        $row['user_count'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::t_user_templates() . " WHERE template_id = %d",
            $id
        ));

        return $row;
    }

    public static function create_template(array $data): int {
        global $wpdb;
        $wpdb->insert(self::t_templates(), [
            'slug'        => sanitize_title($data['slug'] ?? $data['name']),
            'name'        => sanitize_text_field($data['name']),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'icon'        => sanitize_text_field($data['icon'] ?? ''),
            'sort_order'  => intval($data['sort_order'] ?? 0),
            'is_starter'  => intval($data['is_starter'] ?? 0),
        ]);
        $id = (int) $wpdb->insert_id;

        if ($id && !empty($data['permissions'])) {
            self::set_template_permissions($id, $data['permissions']);
        }
        if ($id && !empty($data['services'])) {
            self::set_template_services($id, $data['services']);
        }

        return $id;
    }

    public static function update_template(int $id, array $data): bool {
        global $wpdb;
        $update = [];
        if (isset($data['name']))        $update['name'] = sanitize_text_field($data['name']);
        if (isset($data['description'])) $update['description'] = sanitize_textarea_field($data['description']);
        if (isset($data['icon']))        $update['icon'] = sanitize_text_field($data['icon']);
        if (isset($data['sort_order']))  $update['sort_order'] = intval($data['sort_order']);

        if ($update) {
            $wpdb->update(self::t_templates(), $update, ['id' => $id]);
        }

        if (isset($data['permissions'])) {
            self::set_template_permissions($id, $data['permissions']);
        }
        if (isset($data['services'])) {
            self::set_template_services($id, $data['services']);
        }

        // Clear all caches since template change affects all assigned users
        self::get_instance()->clear_cache();

        return true;
    }

    public static function delete_template(int $id): bool {
        global $wpdb;
        // Get affected users for warning
        $affected = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM " . self::t_user_templates() . " WHERE template_id = %d", $id
        ));

        $wpdb->delete(self::t_template_perms(), ['template_id' => $id]);
        $wpdb->delete(self::t_template_services(), ['template_id' => $id]);
        $wpdb->delete(self::t_user_templates(), ['template_id' => $id]);
        $wpdb->delete(self::t_templates(), ['id' => $id]);

        self::get_instance()->clear_cache();

        return true;
    }

    private static function set_template_permissions(int $template_id, array $permissions): void {
        global $wpdb;
        $wpdb->delete(self::t_template_perms(), ['template_id' => $template_id]);
        foreach ($permissions as $p) {
            $wpdb->insert(self::t_template_perms(), [
                'template_id' => $template_id,
                'module'      => sanitize_key($p['module']),
                'permission'  => sanitize_key($p['permission']),
            ]);
        }
    }

    private static function set_template_services(int $template_id, array $services): void {
        global $wpdb;
        $wpdb->delete(self::t_template_services(), ['template_id' => $template_id]);
        foreach ($services as $slug) {
            $wpdb->insert(self::t_template_services(), [
                'template_id' => $template_id,
                'service_slug'=> sanitize_key($slug),
            ]);
        }
    }

    // =========================================================================
    // USER ↔ TEMPLATE ASSIGNMENT
    // =========================================================================

    public static function get_user_templates(int $user_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT ut.template_id, t.name, t.slug, t.icon, ut.assigned_at
             FROM " . self::t_user_templates() . " ut
             JOIN " . self::t_templates() . " t ON t.id = ut.template_id
             WHERE ut.user_id = %d
             ORDER BY t.sort_order, t.name",
            $user_id
        ), ARRAY_A) ?: [];
    }

    public static function assign_template(int $user_id, int $template_id, int $assigned_by = 0): bool {
        global $wpdb;
        $result = $wpdb->replace(self::t_user_templates(), [
            'user_id'     => $user_id,
            'template_id' => $template_id,
            'assigned_by' => $assigned_by ?: get_current_user_id(),
        ]);
        self::get_instance()->clear_cache($user_id);
        return $result !== false;
    }

    public static function remove_template(int $user_id, int $template_id): bool {
        global $wpdb;
        $result = $wpdb->delete(self::t_user_templates(), [
            'user_id'     => $user_id,
            'template_id' => $template_id,
        ]);
        self::get_instance()->clear_cache($user_id);
        return $result !== false;
    }

    public static function set_user_templates(int $user_id, array $template_ids): void {
        global $wpdb;
        $wpdb->delete(self::t_user_templates(), ['user_id' => $user_id]);
        foreach ($template_ids as $tid) {
            self::assign_template($user_id, (int) $tid);
        }
    }

    // =========================================================================
    // USER OVERRIDES
    // =========================================================================

    public static function get_user_overrides(int $user_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT module, permission, action FROM " . self::t_user_overrides() . " WHERE user_id = %d",
            $user_id
        ), ARRAY_A) ?: [];
    }

    public static function set_user_override(int $user_id, string $module, string $permission, string $action): void {
        global $wpdb;
        $wpdb->replace(self::t_user_overrides(), [
            'user_id'    => $user_id,
            'module'     => sanitize_key($module),
            'permission' => sanitize_key($permission),
            'action'     => $action === 'revoke' ? 'revoke' : 'grant',
        ]);
        self::get_instance()->clear_cache($user_id);
    }

    public static function remove_user_override(int $user_id, string $module, string $permission): void {
        global $wpdb;
        $wpdb->delete(self::t_user_overrides(), [
            'user_id'    => $user_id,
            'module'     => $module,
            'permission' => $permission,
        ]);
        self::get_instance()->clear_cache($user_id);
    }

    public static function set_all_user_overrides(int $user_id, array $overrides): void {
        global $wpdb;
        $wpdb->delete(self::t_user_overrides(), ['user_id' => $user_id]);
        foreach ($overrides as $o) {
            $wpdb->insert(self::t_user_overrides(), [
                'user_id'    => $user_id,
                'module'     => sanitize_key($o['module']),
                'permission' => sanitize_key($o['permission']),
                'action'     => ($o['action'] ?? 'grant') === 'revoke' ? 'revoke' : 'grant',
            ]);
        }
        self::get_instance()->clear_cache($user_id);
    }

    // =========================================================================
    // USER SERVICE OVERRIDES
    // =========================================================================

    public static function get_user_service_overrides(int $user_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT service_slug, action FROM " . self::t_user_services() . " WHERE user_id = %d",
            $user_id
        ), ARRAY_A) ?: [];
    }

    public static function set_all_user_service_overrides(int $user_id, array $overrides): void {
        global $wpdb;
        $wpdb->delete(self::t_user_services(), ['user_id' => $user_id]);
        foreach ($overrides as $o) {
            $wpdb->insert(self::t_user_services(), [
                'user_id'      => $user_id,
                'service_slug' => sanitize_key($o['service_slug']),
                'action'       => ($o['action'] ?? 'grant') === 'revoke' ? 'revoke' : 'grant',
            ]);
        }
        self::get_instance()->clear_cache($user_id);
    }

    // =========================================================================
    // SERVICE TYPES
    // =========================================================================

    public static function get_service_types(): array {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM " . self::t_service_types() . " WHERE is_active = 1 ORDER BY sort_order, name",
            ARRAY_A
        ) ?: [];
    }

    public static function add_service_type(string $name, string $category = 'sonstige'): int {
        global $wpdb;
        $slug = sanitize_title($name);
        // Avoid duplicate slugs
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::t_service_types() . " WHERE slug = %s", $slug
        ));
        if ($exists) return 0;

        $max = (int) $wpdb->get_var("SELECT MAX(sort_order) FROM " . self::t_service_types());
        $wpdb->insert(self::t_service_types(), [
            'slug'       => $slug,
            'name'       => sanitize_text_field($name),
            'category'   => sanitize_key($category),
            'sort_order' => $max + 10,
        ]);
        return (int) $wpdb->insert_id;
    }

    public static function update_service_type(int $id, array $data): bool {
        global $wpdb;
        $update = [];
        if (isset($data['name']))      $update['name'] = sanitize_text_field($data['name']);
        if (isset($data['category']))  $update['category'] = sanitize_key($data['category']);
        if (isset($data['sort_order']))$update['sort_order'] = intval($data['sort_order']);
        if (empty($update)) return false;
        return $wpdb->update(self::t_service_types(), $update, ['id' => $id]) !== false;
    }

    public static function delete_service_type(int $id): bool {
        global $wpdb;
        // Soft delete (deactivate) — keep for existing references
        return $wpdb->update(self::t_service_types(), ['is_active' => 0], ['id' => $id]) !== false;
    }

    public static function get_all_service_types(): array {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM " . self::t_service_types() . " ORDER BY sort_order, name",
            ARRAY_A
        ) ?: [];
    }

    // =========================================================================
    // MIGRATION from v1
    // =========================================================================

    /**
     * Migrate from old role-based system to template-based system.
     */
    public static function migrate_from_v1(): array {
        $log = [];

        // 1. Create tables
        self::create_tables();
        $log[] = 'Tabellen erstellt.';

        // 2. Setup new roles
        self::setup_roles();
        $log[] = 'Master-Rollen angelegt (Pfarrer, Sekretär, Mitglied).';

        // 3. Role → Template mapping
        $role_map = [
            'isidor_pfarrer_godmode' => 'isidor_pfarrer',
            'isidor_sekretaer'       => 'isidor_sekretaer',
            'isidor_diakon'          => 'isidor_mitglied',
            'isidor_liturg_kantor'   => 'isidor_mitglied',
            'isidor_mesner'          => 'isidor_mitglied',
            'isidor_ministrant'      => 'isidor_mitglied',
            'isidor_mitarbeiter'     => 'isidor_mitglied',
            'isidor_ag_leiter'       => 'isidor_mitglied',
            'isidor_pgr'             => 'isidor_mitglied',
            'isidor_vvr'             => 'isidor_mitglied',
            'isidor_orgel'           => 'isidor_mitglied',
            'isidor_technik'         => 'isidor_mitglied',
        ];

        // Track which template slugs we need to create based on existing users
        $needed_templates = [];
        $template_for_old_role = [
            'isidor_diakon'        => 'diakon',
            'isidor_liturg_kantor' => 'liturg', // Will get kantor too
            'isidor_mesner'        => 'mesner',
            'isidor_ministrant'    => 'ministrant',
            'isidor_mitarbeiter'   => 'mitarbeiter',
            'isidor_ag_leiter'     => 'ag-leiter',
            'isidor_pgr'           => 'pgr-mitglied',
            'isidor_vvr'           => 'vvr-mitglied',
            'isidor_orgel'         => 'organist',
            'isidor_technik'       => 'technik',
        ];

        // 4. Scan users and create needed templates
        $users = get_users(['fields' => ['ID']]);
        $user_assignments = []; // user_id => [template_slugs]

        foreach ($users as $u) {
            $user = get_userdata($u->ID);
            if (!$user) continue;

            foreach ($user->roles as $role) {
                if (isset($template_for_old_role[$role])) {
                    $tpl_slug = $template_for_old_role[$role];
                    $needed_templates[$tpl_slug] = true;
                    $user_assignments[$u->ID][] = $tpl_slug;

                    // liturg_kantor → both liturg and kantor
                    if ($role === 'isidor_liturg_kantor') {
                        $needed_templates['kantor'] = true;
                        $user_assignments[$u->ID][] = 'kantor';
                    }
                }
            }
        }

        // 5. Create the templates that are actually needed
        $starter_pack = self::get_starter_pack();
        $created_templates = [];

        foreach ($needed_templates as $slug => $_) {
            if (isset($starter_pack[$slug])) {
                $data = $starter_pack[$slug];
                $data['slug'] = $slug;
                $data['is_starter'] = 1;
                $id = self::create_template($data);
                $created_templates[$slug] = $id;
                $log[] = "Template erstellt: {$data['name']}";
            }
        }

        // 6. Migrate each user
        $migrated = 0;
        foreach ($users as $u) {
            $user = get_userdata($u->ID);
            if (!$user) continue;

            $old_roles = $user->roles;
            $new_role = null;

            foreach ($old_roles as $role) {
                if (isset($role_map[$role])) {
                    $new_role = $role_map[$role];
                    break;
                }
            }

            if (!$new_role) continue;

            // Set new role
            $user->set_role($new_role);

            // Assign templates
            if (isset($user_assignments[$u->ID])) {
                foreach (array_unique($user_assignments[$u->ID]) as $tpl_slug) {
                    if (isset($created_templates[$tpl_slug])) {
                        self::assign_template($u->ID, $created_templates[$tpl_slug]);
                    }
                }
            }

            $migrated++;
        }

        $log[] = "{$migrated} Benutzer migriert.";

        // 7. Migrate old app_permissions as overrides
        global $wpdb;
        $old_table = $wpdb->prefix . 'isidor_app_permissions';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$old_table}'")) {
            $old_perms = $wpdb->get_results("SELECT * FROM {$old_table}");
            $override_count = 0;
            foreach ($old_perms as $op) {
                // Check if this permission is already covered by templates
                $effective = self::get_instance()->get_effective_permissions((int) $op->user_id);
                if (!isset($effective[$op->app_slug]) || !in_array($op->permission, $effective[$op->app_slug], true)) {
                    self::set_user_override((int) $op->user_id, $op->app_slug, $op->permission, 'grant');
                    $override_count++;
                }
            }
            // Rename old table as backup
            $wpdb->query("RENAME TABLE {$old_table} TO {$old_table}_backup_v1");
            $log[] = "{$override_count} individuelle Overrides aus alter Tabelle übernommen.";
            $log[] = "Alte Tabelle als {$old_table}_backup_v1 archiviert.";
        }

        update_option('isidor_permissions_v2_migrated', true);
        update_option('isidor_permissions_migration_log', $log);

        return $log;
    }

    // =========================================================================
    // STARTER PACK (optional import)
    // =========================================================================

    public static function get_starter_pack(): array {
        return [
            'diakon' => [
                'name' => 'Diakon',
                'icon' => '⛪',
                'description' => 'Diakon',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'liturgus','permission'=>'assign'],
                    ['module'=>'liturgus','permission'=>'predigt'],
                    ['module'=>'cantus','permission'=>'view'],
                    ['module'=>'consilium','permission'=>'view'],
                    ['module'=>'consilium','permission'=>'vote'],
                    ['module'=>'sakristan','permission'=>'view'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'liturgia','permission'=>'plan'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'request'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['diakon','predigt','lesung','fuerbitten','kommunionhelfer','wortgottesfeier'],
            ],
            'liturg' => [
                'name' => 'Liturg',
                'icon' => '📿',
                'description' => 'Liturg für Wortgottesdienste',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'cantus','permission'=>'view'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['liturg','wortgottesfeier'],
            ],
            'kantor' => [
                'name' => 'Kantor',
                'icon' => '🎤',
                'description' => 'Kantor / Vorsänger',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'cantus','permission'=>'view'],
                    ['module'=>'cantus','permission'=>'plan'],
                    ['module'=>'cantus','permission'=>'export'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['kantor','vorsaenger'],
            ],
            'organist' => [
                'name' => 'Organist',
                'icon' => '🎹',
                'description' => 'Organist',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'cantus','permission'=>'view'],
                    ['module'=>'cantus','permission'=>'plan'],
                    ['module'=>'cantus','permission'=>'export'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['orgel'],
            ],
            'mesner' => [
                'name' => 'Mesner',
                'icon' => '🔑',
                'description' => 'Mesner / Kirchenpfleger',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'sakristan','permission'=>'view'],
                    ['module'=>'sakristan','permission'=>'edit'],
                    ['module'=>'sakristan','permission'=>'timelog'],
                    ['module'=>'tagesplan','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'edit'],
                ],
                'services' => ['mesner'],
            ],
            'ministrant' => [
                'name' => 'Ministrant',
                'icon' => '🕯️',
                'description' => 'Ministrant / Altar-Dienst',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['ministrant'],
            ],
            'lektor' => [
                'name' => 'Lektor',
                'icon' => '📖',
                'description' => 'Lektor / Lesung & Fürbitten',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['lesung','fuerbitten'],
            ],
            'kommunionhelfer' => [
                'name' => 'Kommunionhelfer',
                'icon' => '🍞',
                'description' => 'Kommunionhelfer',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['kommunionhelfer'],
            ],
            'technik' => [
                'name' => 'Technik',
                'icon' => '🎛️',
                'description' => 'Technik / Streaming',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'sakristan','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['technik','streaming'],
            ],
            'kiwogo-leiter' => [
                'name' => 'KiWoGo-Leiter',
                'icon' => '👶',
                'description' => 'Kindergottesdienst-Leiter',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'liturgus','permission'=>'signup'],
                    ['module'=>'cantus','permission'=>'view'],
                    ['module'=>'cantus','permission'=>'plan'],
                    ['module'=>'liturgia','permission'=>'view'],
                    ['module'=>'liturgia','permission'=>'plan'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'request'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => ['kiwogo'],
            ],
            'pgr-mitglied' => [
                'name' => 'PGR-Mitglied',
                'icon' => '🏛️',
                'description' => 'Pfarrgemeinderat',
                'permissions' => [
                    ['module'=>'consilium','permission'=>'view'],
                    ['module'=>'consilium','permission'=>'vote'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => [],
            ],
            'vvr-mitglied' => [
                'name' => 'VVR-Mitglied',
                'icon' => '💰',
                'description' => 'Vermögensverwaltungsrat',
                'permissions' => [
                    ['module'=>'consilium','permission'=>'view'],
                    ['module'=>'consilium','permission'=>'vote'],
                    ['module'=>'cellerar','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => [],
            ],
            'ag-leiter' => [
                'name' => 'AG-Leiter',
                'icon' => '👥',
                'description' => 'Arbeitsgruppen-Leiter',
                'permissions' => [
                    ['module'=>'cellerar','permission'=>'expense'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'request'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => [],
            ],
            'mitarbeiter' => [
                'name' => 'Mitarbeiter',
                'icon' => '🤝',
                'description' => 'Allgemeiner Mitarbeiter',
                'permissions' => [
                    ['module'=>'liturgus','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'view'],
                    ['module'=>'agenda','permission'=>'request'],
                    ['module'=>'tagesplan','permission'=>'view'],
                ],
                'services' => [],
            ],
        ];
    }

    /**
     * Import the starter pack (all templates that don't exist yet).
     */
    public static function import_starter_pack(): array {
        $pack = self::get_starter_pack();
        $created = [];

        foreach ($pack as $slug => $data) {
            global $wpdb;
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . self::t_templates() . " WHERE slug = %s", $slug
            ));

            if (!$exists) {
                $data['slug'] = $slug;
                $data['is_starter'] = 1;
                $data['sort_order'] = array_search($slug, array_keys($pack)) * 10;
                $id = self::create_template($data);
                if ($id) $created[] = $data['name'];
            }
        }

        return $created;
    }

    // =========================================================================
    // PUBLIC GETTERS (for UI)
    // =========================================================================

    public static function get_modules(): array {
        return self::MODULES;
    }

    public static function get_cap_bridge(): array {
        return self::CAP_BRIDGE;
    }

    /**
     * Full user permission profile for the edit UI.
     */
    public static function get_user_profile(int $user_id): array {
        $inst = self::get_instance();
        $user = get_userdata($user_id);

        return [
            'user_id'     => $user_id,
            'display_name'=> $user ? $user->display_name : '',
            'role'        => $user ? ($user->roles[0] ?? 'isidor_mitglied') : '',
            'templates'   => self::get_user_templates($user_id),
            'overrides'   => self::get_user_overrides($user_id),
            'service_overrides' => self::get_user_service_overrides($user_id),
            'effective_permissions' => $inst->get_effective_permissions($user_id),
            'effective_services'    => $inst->get_effective_services($user_id),
        ];
    }
}
