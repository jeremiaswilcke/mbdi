<?php
/**
 * Isidor Frontend User Manager
 * 
 * Erlaubt Pfarrer und Sekretariat die Benutzerverwaltung
 * direkt im Isidor-Frontend (ohne WordPress-Admin).
 *
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) exit;

class Isidor_User_Manager {
    
    private static $instance = null;
    
    /**
     * Isidor-Rollen für das Dropdown (neues 3-Rollen-System)
     */
    private const ISIDOR_ROLES = [
        'isidor_pfarrer'         => 'Pfarrer',
        'isidor_sekretaer'       => 'Sekretär(in)',
        'isidor_mitglied'        => 'Mitglied',
        // Legacy (für Anzeige bis Migration abgeschlossen)
        'isidor_pfarrer_godmode' => 'Pfarrer',
        'isidor_diakon'          => 'Diakon',
        'isidor_liturg_kantor'   => 'Liturg / Kantor',
        'isidor_mesner'          => 'Mesner',
        'isidor_ministrant'      => 'Ministrant',
        'isidor_mitarbeiter'     => 'Mitarbeiter',
        'isidor_ag_leiter'       => 'AG-Leiter',
        'isidor_pgr'             => 'PGR',
        'isidor_vvr'             => 'VVR',
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_shortcode('isidor_user_manager', [$this, 'render_shortcode']);
        add_shortcode('isidor_user_add', [$this, 'render_add_user']);
        
        // AJAX-Handler (für Frontend!)
        add_action('wp_ajax_isidor_fm_list_users', [$this, 'ajax_list_users']);
        add_action('wp_ajax_isidor_fm_get_user', [$this, 'ajax_get_user']);
        add_action('wp_ajax_isidor_fm_save_user', [$this, 'ajax_save_user']);
        add_action('wp_ajax_isidor_fm_create_user', [$this, 'ajax_create_user']);
        add_action('wp_ajax_isidor_fm_delete_user', [$this, 'ajax_delete_user']);
    }
    
    /**
     * Prüft ob der aktuelle User User-Management-Rechte hat.
     * Erlaubt: WP-Admins, Pfarrer (Godmode), Sekretäre, oder User mit core:admin
     */
    private function can_manage_users(): bool {
        if (current_user_can('manage_options')) return true;
        if (current_user_can('isidor_manage_users')) return true;
        
        $user = wp_get_current_user();
        if (in_array('isidor_pfarrer', $user->roles, true)) return true;
        if (in_array('isidor_sekretaer', $user->roles, true)) return true;
        if (in_array('isidor_sekretaer', $user->roles, true)) return true;
        
        // App Permissions: core → admin
        if (class_exists('Isidor_App_Permissions')) {
            $perms = Isidor_App_Permissions::get_instance();
            if ($perms->current_user_can('core', 'admin')) return true;
        }
        
        return false;
    }
    
    // =========================================================
    // SHORTCODE: User-Manager (Liste + Bearbeitung)
    // =========================================================
    
    public function render_shortcode($atts): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte melden Sie sich an.</p>';
        }
        if (!$this->can_manage_users()) {
            return '<div class="isidor-notice isidor-notice-error">Sie haben keine Berechtigung für die Benutzerverwaltung.</div>';
        }
        
        $nonce = wp_create_nonce('isidor_fm');
        
        // Rollen-Templates aus App Permissions
        $templates = [];
        if (class_exists('Isidor_App_Permissions')) {
            $templates = Isidor_App_Permissions::get_role_templates();
        }
        
        // Apps aus App Permissions
        $apps = [];
        if (class_exists('Isidor_App_Permissions')) {
            $apps = Isidor_App_Permissions::get_apps();
        }
        
        ob_start();
        ?>
        <div class="isidor-um" id="isidor-um" 
             data-nonce="<?php echo esc_attr($nonce); ?>"
             data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
            
            <!-- Kopfzeile -->
            <div class="isidor-um-header">
                <h2>👥 Benutzer verwalten</h2>
                <a href="<?php echo esc_url($this->get_add_user_url()); ?>" class="isidor-um-btn isidor-um-btn-primary">
                    ➕ Neuer Benutzer
                </a>
            </div>
            
            <!-- Filterliste -->
            <div class="isidor-um-filter">
                <input type="text" id="um-search" class="isidor-um-input" placeholder="🔍 Suchen …">
                <select id="um-role-filter" class="isidor-um-select">
                    <option value="">Alle Rollen</option>
                    <?php foreach (self::ISIDOR_ROLES as $slug => $label): ?>
                        <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- User-Liste -->
            <div class="isidor-um-list" id="um-user-list">
                <div class="isidor-um-loading">Lade Benutzer …</div>
            </div>
            
            <!-- Detail-Panel (wird von JS befüllt) -->
            <div class="isidor-um-detail" id="um-detail" style="display:none;">
                <div class="isidor-um-detail-header">
                    <h3 id="um-detail-name"></h3>
                    <button type="button" class="isidor-um-btn isidor-um-btn-ghost" id="um-detail-close">✕</button>
                </div>
                <div id="um-detail-body"></div>
            </div>

            <!-- Rollen-Templates als JSON für JS -->
            <?php
            // Nur die 3 Master-Rollen für Checkboxen
            $master_roles = [
                'isidor_pfarrer'   => 'Pfarrer',
                'isidor_sekretaer' => 'Sekretär(in)',
                'isidor_mitglied'  => 'Mitglied',
            ];
            // Neue Templates aus DB
            $new_tpls = [];
            if (class_exists('Isidor_Permissions')) {
                foreach (Isidor_Permissions::get_templates() as $t) {
                    $new_tpls['new_' . $t['id']] = [
                        'label' => ($t['icon'] ? $t['icon'] . ' ' : '') . $t['name'],
                        'id' => $t['id'],
                    ];
                }
            }
            // Fallback to old templates if none exist
            if (empty($new_tpls) && !empty($templates)) {
                $new_tpls = $templates;
            }
            ?>
            <script type="application/json" id="um-templates-data"><?php echo wp_json_encode($new_tpls, JSON_UNESCAPED_UNICODE); ?></script>
            <script type="application/json" id="um-apps-data"><?php echo wp_json_encode($apps, JSON_UNESCAPED_UNICODE); ?></script>
            <script type="application/json" id="um-roles-data"><?php echo wp_json_encode($master_roles, JSON_UNESCAPED_UNICODE); ?></script>
            <script type="application/json" id="um-all-roles-data"><?php echo wp_json_encode(self::ISIDOR_ROLES, JSON_UNESCAPED_UNICODE); ?></script>
        </div>
        
        <?php $this->render_styles(); ?>
        <?php $this->render_scripts(); ?>
        <?php
        return ob_get_clean();
    }
    
    // =========================================================
    // SHORTCODE: User anlegen
    // =========================================================
    
    public function render_add_user($atts): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte melden Sie sich an.</p>';
        }
        if (!$this->can_manage_users()) {
            return '<div class="isidor-notice isidor-notice-error">Sie haben keine Berechtigung.</div>';
        }
        
        $nonce = wp_create_nonce('isidor_fm');
        $templates = class_exists('Isidor_App_Permissions') ? Isidor_App_Permissions::get_role_templates() : [];
        
        ob_start();
        ?>
        <div class="isidor-um" id="isidor-um-add"
             data-nonce="<?php echo esc_attr($nonce); ?>"
             data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
            
            <div class="isidor-um-header">
                <h2>➕ Neuen Benutzer anlegen</h2>
            </div>
            
            <div class="isidor-um-form-card">
                <div class="isidor-um-form-row">
                    <label>Benutzername *</label>
                    <input type="text" id="new-username" class="isidor-um-input" placeholder="z.B. maria.huber" required>
                </div>
                <div class="isidor-um-form-row">
                    <label>E-Mail-Adresse *</label>
                    <input type="email" id="new-email" class="isidor-um-input" placeholder="name@example.com" required>
                </div>
                <div class="isidor-um-form-row-2col">
                    <div class="isidor-um-form-row">
                        <label>Vorname</label>
                        <input type="text" id="new-firstname" class="isidor-um-input">
                    </div>
                    <div class="isidor-um-form-row">
                        <label>Nachname</label>
                        <input type="text" id="new-lastname" class="isidor-um-input">
                    </div>
                </div>
                <div class="isidor-um-form-row">
                    <label>Isidor-Rolle *</label>
                    <select id="new-role" class="isidor-um-select">
                        <option value="isidor_mitglied" selected>Mitglied</option>
                        <option value="isidor_sekretaer">Sekretär(in)</option>
                        <option value="isidor_pfarrer">Pfarrer</option>
                    </select>
                </div>
                <div class="isidor-um-form-row">
                    <label>Berechtigungs-Vorlage</label>
                    <select id="new-template" class="isidor-um-select">
                        <option value="">– Keine Vorlage –</option>
                        <?php
                        if (class_exists('Isidor_Permissions')) {
                            $new_templates = Isidor_Permissions::get_templates();
                            foreach ($new_templates as $tpl) {
                                echo '<option value="new_' . esc_attr($tpl['id']) . '">' . esc_html(($tpl['icon'] ? $tpl['icon'] . ' ' : '') . $tpl['name']) . '</option>';
                            }
                        }
                        if (empty($new_templates)) {
                            foreach (($templates ?? []) as $key => $tpl) {
                                echo '<option value="' . esc_attr($key) . '">' . esc_html($tpl['label']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                    <small class="isidor-um-hint">Setzt App-Berechtigungen automatisch passend zur Rolle.</small>
                </div>
                <div class="isidor-um-form-row">
                    <label>
                        <input type="checkbox" id="new-send-mail" checked>
                        Einladungs-Mail senden (mit Login-Link &amp; Passwort)
                    </label>
                </div>
                
                <div class="isidor-um-form-actions">
                    <button type="button" class="isidor-um-btn isidor-um-btn-primary" id="btn-create-user">
                        ✅ Benutzer anlegen
                    </button>
                    <a href="<?php echo esc_url($this->get_manager_url()); ?>" class="isidor-um-btn isidor-um-btn-ghost">
                        Abbrechen
                    </a>
                </div>
                
                <div id="create-result" style="display:none;"></div>
            </div>
        </div>
        
        <?php $this->render_styles(); ?>
        <script>
        (function() {
            var wrap = document.getElementById("isidor-um-add");
            if (!wrap) return;
            var ajax = wrap.getAttribute("data-ajax");
            var nonce = wrap.getAttribute("data-nonce");
            
            document.getElementById("btn-create-user").addEventListener("click", function() {
                var btn = this;
                var username = document.getElementById("new-username").value.trim();
                var email = document.getElementById("new-email").value.trim();
                var firstname = document.getElementById("new-firstname").value.trim();
                var lastname = document.getElementById("new-lastname").value.trim();
                var role = document.getElementById("new-role").value;
                var template = document.getElementById("new-template").value;
                var sendMail = document.getElementById("new-send-mail").checked ? "1" : "0";
                var result = document.getElementById("create-result");
                
                if (!username || !email) {
                    result.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">Benutzername und E-Mail sind Pflichtfelder.</div>';
                    result.style.display = "block";
                    return;
                }
                
                btn.disabled = true;
                btn.textContent = "Wird angelegt …";
                
                var fd = new FormData();
                fd.append("action", "isidor_fm_create_user");
                fd.append("_wpnonce", nonce);
                fd.append("username", username);
                fd.append("email", email);
                fd.append("first_name", firstname);
                fd.append("last_name", lastname);
                fd.append("role", role);
                fd.append("template", template);
                fd.append("send_mail", sendMail);
                
                fetch(ajax, {method: "POST", body: fd})
                    .then(function(r) { return r.json(); })
                    .then(function(resp) {
                        if (resp.success) {
                            result.innerHTML = '<div class="isidor-um-msg isidor-um-msg-success">✅ ' + resp.data.message + '</div>';
                            document.getElementById("new-username").value = "";
                            document.getElementById("new-email").value = "";
                            document.getElementById("new-firstname").value = "";
                            document.getElementById("new-lastname").value = "";
                        } else {
                            result.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">❌ ' + (resp.data ? resp.data.message : "Fehler") + '</div>';
                        }
                        result.style.display = "block";
                        btn.disabled = false;
                        btn.textContent = "✅ Benutzer anlegen";
                    })
                    .catch(function() {
                        result.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">Verbindungsfehler.</div>';
                        result.style.display = "block";
                        btn.disabled = false;
                        btn.textContent = "✅ Benutzer anlegen";
                    });
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    // =========================================================
    // AJAX: User auflisten
    // =========================================================
    
    public function ajax_list_users(): void {
        check_ajax_referer('isidor_fm', '_wpnonce');
        if (!$this->can_manage_users()) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $search = sanitize_text_field($_POST['search'] ?? '');
        $role_filter = sanitize_text_field($_POST['role'] ?? '');
        
        $args = ['orderby' => 'display_name', 'order' => 'ASC'];
        if ($search) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }
        if ($role_filter) {
            $args['role'] = $role_filter;
        }
        
        $users = get_users($args);
        $list = [];
        
        foreach ($users as $user) {
            // Isidor-Rollen finden
            $isidor_roles = [];
            $role_labels = [];
            foreach (self::ISIDOR_ROLES as $slug => $label) {
                if (in_array($slug, $user->roles, true)) {
                    $isidor_roles[] = $slug;
                    $role_labels[] = $label;
                }
            }
            
            // WP-Standardrollen als Fallback
            if (empty($isidor_roles)) {
                $wp_roles = ['administrator' => 'Administrator', 'editor' => 'Redakteur', 'author' => 'Autor', 'subscriber' => 'Abonnent'];
                foreach ($wp_roles as $slug => $label) {
                    if (in_array($slug, $user->roles, true)) {
                        $isidor_roles[] = $slug;
                        $role_labels[] = $label;
                        break;
                    }
                }
            }

            // Templates laden
            $template_names = [];
            if (class_exists('Isidor_Permissions')) {
                $user_templates = Isidor_Permissions::get_user_templates($user->ID);
                foreach ($user_templates as $t) {
                    $template_names[] = ($t['icon'] ?? '') . ' ' . $t['name'];
                }
            }
            
            $list[] = [
                'id' => $user->ID,
                'username' => $user->user_login,
                'name' => $user->display_name,
                'email' => $user->user_email,
                'roles' => $isidor_roles,
                'role' => $isidor_roles[0] ?? '',
                'role_label' => !empty($role_labels) ? implode(', ', $role_labels) : 'Keine Rolle',
                'templates' => $template_names,
                'template_label' => !empty($template_names) ? implode(', ', $template_names) : '',
                'avatar' => get_avatar_url($user->ID, ['size' => 48]),
            ];
        }
        
        wp_send_json_success(['users' => $list]);
    }
    
    // =========================================================
    // AJAX: Einzelnen User laden (mit Berechtigungen)
    // =========================================================
    
    public function ajax_get_user(): void {
        check_ajax_referer('isidor_fm', '_wpnonce');
        if (!$this->can_manage_users()) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        $user = get_userdata($user_id);
        if (!$user) {
            wp_send_json_error(['message' => 'Benutzer nicht gefunden']);
        }
        
        // Isidor-Rollen (mehrere möglich)
        $isidor_roles = [];
        foreach (self::ISIDOR_ROLES as $slug => $label) {
            if (in_array($slug, $user->roles, true)) {
                $isidor_roles[] = $slug;
            }
        }
        
        // App Permissions
        $permissions = [];
        if (class_exists('Isidor_App_Permissions')) {
            $permissions = Isidor_App_Permissions::get_instance()->get_user_all_permissions($user_id);
        }
        
        wp_send_json_success([
            'id' => $user->ID,
            'username' => $user->user_login,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'email' => $user->user_email,
            'roles' => $isidor_roles,
            'role' => $isidor_roles[0] ?? '',  // Abwärtskompatibilität
            'permissions' => $permissions,
            'avatar' => get_avatar_url($user->ID, ['size' => 96]),
            'registered' => date_i18n('j. F Y', strtotime($user->user_registered)),
        ]);
    }
    
    // =========================================================
    // AJAX: User speichern (Rolle + Berechtigungen)
    // =========================================================
    
    public function ajax_save_user(): void {
        check_ajax_referer('isidor_fm', '_wpnonce');
        if (!$this->can_manage_users()) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        $user = get_userdata($user_id);
        if (!$user) {
            wp_send_json_error(['message' => 'Benutzer nicht gefunden']);
        }
        
        // Selbst-Schutz: Admins dürfen sich nicht selbst degradieren
        if ($user_id === get_current_user_id() && current_user_can('manage_options')) {
            // Admin darf sich nicht selbst die Admin-Rolle entziehen
        }
        
        // Rollen aktualisieren (genau eine Master-Rolle)
        $new_roles = $_POST['roles'] ?? [];
        if (is_array($new_roles) && !empty($new_roles)) {
            // Alle alten Isidor-Rollen entfernen
            foreach (array_keys(self::ISIDOR_ROLES) as $old_role) {
                $user->remove_role($old_role);
            }
            // Genau eine Master-Rolle setzen
            $master_role = sanitize_text_field($new_roles[0] ?? 'isidor_mitglied');
            $allowed = ['isidor_pfarrer', 'isidor_sekretaer', 'isidor_mitglied'];
            if (in_array($master_role, $allowed, true)) {
                $user->add_role($master_role);
            } else {
                $user->add_role('isidor_mitglied');
            }
        }
        
        // Templates zuweisen (neues System)
        $template_ids = $_POST['template_ids'] ?? [];
        if (is_array($template_ids) && class_exists('Isidor_Permissions')) {
            $clean_ids = [];
            foreach ($template_ids as $tid) {
                // Strip "new_" prefix if present
                $id = (int) str_replace('new_', '', $tid);
                if ($id > 0) $clean_ids[] = $id;
            }
            Isidor_Permissions::set_user_templates($user_id, $clean_ids);
        }
        
        // Legacy: Template anwenden (altes Format, Fallback)
        $template = sanitize_text_field($_POST['template'] ?? '');
        if ($template && class_exists('Isidor_App_Permissions')) {
            if (str_starts_with($template, 'new_') && class_exists('Isidor_Permissions')) {
                $tpl_id = (int) substr($template, 4);
                Isidor_Permissions::assign_template($user_id, $tpl_id);
            } else {
                Isidor_App_Permissions::get_instance()->apply_role_template($user_id, $template);
            }
            wp_send_json_success(['message' => 'Rolle und Vorlage gespeichert.']);
        }
        
        // Manuelle Berechtigungen speichern
        if (isset($_POST['permissions']) && class_exists('Isidor_App_Permissions')) {
            $perms_instance = Isidor_App_Permissions::get_instance();
            $apps = Isidor_App_Permissions::get_apps();
            
            // Alle löschen
            global $wpdb;
            $table = $wpdb->prefix . 'isidor_app_permissions';
            $wpdb->delete($table, ['user_id' => $user_id], ['%d']);
            
            // Neue setzen
            $permissions = $_POST['permissions'];
            if (is_array($permissions)) {
                foreach ($permissions as $app => $perms) {
                    $app = sanitize_text_field($app);
                    if (!isset($apps[$app])) continue;
                    if (is_array($perms)) {
                        foreach ($perms as $perm) {
                            $perms_instance->grant_permission($user_id, $app, sanitize_text_field($perm));
                        }
                    }
                }
            }
        }
        
        wp_send_json_success(['message' => 'Gespeichert.']);
    }
    
    // =========================================================
    // AJAX: User anlegen
    // =========================================================
    
    public function ajax_create_user(): void {
        check_ajax_referer('isidor_fm', '_wpnonce');
        if (!$this->can_manage_users()) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        $username = sanitize_user($_POST['username'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $role = sanitize_text_field($_POST['role'] ?? 'isidor_mitarbeiter');
        $template = sanitize_text_field($_POST['template'] ?? '');
        $send_mail = ($_POST['send_mail'] ?? '0') === '1';
        
        if (!$username || !$email) {
            wp_send_json_error(['message' => 'Benutzername und E-Mail sind Pflichtfelder.']);
        }
        
        if (username_exists($username)) {
            wp_send_json_error(['message' => 'Benutzername bereits vergeben.']);
        }
        if (email_exists($email)) {
            wp_send_json_error(['message' => 'E-Mail-Adresse bereits vergeben.']);
        }
        
        // Rolle validieren
        if (!isset(self::ISIDOR_ROLES[$role])) {
            $role = 'isidor_mitarbeiter';
        }
        
        // Passwort generieren
        $password = wp_generate_password(14, true, false);
        
        $user_id = wp_insert_user([
            'user_login' => $username,
            'user_email' => $email,
            'user_pass'  => $password,
            'first_name' => $first_name,
            'last_name'  => $last_name,
            'display_name' => trim($first_name . ' ' . $last_name) ?: $username,
            'role' => $role,
        ]);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => $user_id->get_error_message()]);
        }
        
        // Berechtigungs-Vorlage anwenden
        if ($template && class_exists('Isidor_App_Permissions')) {
            Isidor_App_Permissions::get_instance()->apply_role_template($user_id, $template);
        }
        
        // Einladungs-Mail senden
        if ($send_mail) {
            $parish_name = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : get_bloginfo('name');
            $login_url = home_url('/app/anmelden/');
            
            $message = sprintf(
                "Hallo %s,\n\nSie wurden als Benutzer bei %s eingerichtet.\n\n" .
                "Benutzername: %s\nPasswort: %s\n\nAnmelden: %s\n\n" .
                "Bitte ändern Sie Ihr Passwort nach der ersten Anmeldung.\n\nMit freundlichen Grüßen\n%s",
                $first_name ?: $username,
                $parish_name,
                $username,
                $password,
                $login_url,
                $parish_name
            );
            
            wp_mail(
                $email,
                sprintf('Ihr Zugang zu %s', $parish_name),
                $message,
                ['From: ' . $parish_name . ' <' . get_option('admin_email') . '>']
            );
        }
        
        $display_name = trim($first_name . ' ' . $last_name) ?: $username;
        wp_send_json_success([
            'message' => sprintf('%s wurde angelegt.', $display_name),
            'user_id' => $user_id,
        ]);
    }
    
    // =========================================================
    // AJAX: User löschen (nur Godmode / Admin)
    // =========================================================
    
    public function ajax_delete_user(): void {
        check_ajax_referer('isidor_fm', '_wpnonce');
        
        // User löschen nur für Admins und Pfarrer Godmode
        if (!current_user_can('manage_options')) {
            $user = wp_get_current_user();
            if (!in_array('isidor_pfarrer_godmode', $user->roles, true)) {
                wp_send_json_error(['message' => 'Nur Pfarrer (Godmode) und Administratoren können Benutzer löschen.']);
            }
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        
        // Selbst-Löschung verhindern
        if ($user_id === get_current_user_id()) {
            wp_send_json_error(['message' => 'Sie können sich nicht selbst löschen.']);
        }
        
        // Super-Admin Schutz
        if (is_super_admin($user_id)) {
            wp_send_json_error(['message' => 'Super-Admin kann nicht gelöscht werden.']);
        }
        
        require_once ABSPATH . 'wp-admin/includes/user.php';
        $result = wp_delete_user($user_id);
        
        if ($result) {
            wp_send_json_success(['message' => 'Benutzer gelöscht.']);
        } else {
            wp_send_json_error(['message' => 'Fehler beim Löschen.']);
        }
    }
    
    // =========================================================
    // Hilfsfunktionen
    // =========================================================
    
    private function get_add_user_url(): string {
        // Seite mit [isidor_user_add] finden
        global $wpdb;
        $page_id = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE '%[isidor_user_add]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1");
        return $page_id ? get_permalink($page_id) : '#';
    }
    
    private function get_manager_url(): string {
        global $wpdb;
        $page_id = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE '%[isidor_user_manager]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1");
        return $page_id ? get_permalink($page_id) : '#';
    }
    
    // =========================================================
    // CSS
    // =========================================================
    
    private function render_styles(): void {
        ?>
        <style>
        .isidor-um { max-width: 900px; }
        
        .isidor-um-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 20px; flex-wrap: wrap; gap: 12px;
        }
        .isidor-um-header h2 { margin: 0; font-size: 1.4em; }
        
        .isidor-um-btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 10px 18px; border-radius: var(--is-radius, 8px);
            font-size: 0.95em; font-weight: 600; cursor: pointer;
            text-decoration: none !important; border: none; transition: 0.15s;
        }
        .isidor-um-btn-primary {
            background: var(--is-primary, #2563eb); color: #fff !important;
        }
        .isidor-um-btn-primary:hover { opacity: 0.9; }
        .isidor-um-btn-danger {
            background: var(--is-danger, #dc2626); color: #fff !important;
        }
        .isidor-um-btn-ghost {
            background: var(--is-bg-sunken, #f1f5f9); color: var(--is-text, #0f172a) !important;
        }
        .isidor-um-btn-ghost:hover { background: var(--is-border, #e2e8f0); }
        .isidor-um-btn-sm { padding: 6px 12px; font-size: 0.85em; }
        
        .isidor-um-filter {
            display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap;
        }
        .isidor-um-input, .isidor-um-select {
            padding: 10px 14px; border: 1px solid var(--is-border, #e2e8f0);
            border-radius: var(--is-radius, 8px); font-size: 0.95em;
            background: var(--is-bg-raised, #fff); color: var(--is-text, #0f172a);
            font-family: inherit;
        }
        .isidor-um-input:focus, .isidor-um-select:focus {
            outline: none; border-color: var(--is-primary, #2563eb);
            box-shadow: 0 0 0 3px rgba(37,99,235,0.12);
        }
        .isidor-um-filter .isidor-um-input { flex: 1; min-width: 180px; }
        .isidor-um-filter .isidor-um-select { min-width: 160px; }
        
        /* User-Karten */
        .isidor-um-card {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 18px; background: var(--is-bg-raised, #fff);
            border: 1px solid var(--is-border, #e2e8f0);
            border-radius: var(--is-radius, 8px);
            margin-bottom: 8px; cursor: pointer; transition: 0.15s;
        }
        .isidor-um-card:hover {
            border-color: var(--is-primary, #2563eb);
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .isidor-um-card.active {
            border-color: var(--is-primary, #2563eb);
            background: var(--is-primary-subtle, #eff6ff);
        }
        .isidor-um-avatar {
            width: 42px; height: 42px; border-radius: 50%; flex-shrink: 0;
        }
        .isidor-um-card-info { flex: 1; min-width: 0; }
        .isidor-um-card-name { font-weight: 600; font-size: 0.95em; }
        .isidor-um-card-meta { font-size: 0.82em; color: var(--is-text-muted, #64748b); margin-top: 2px; }
        .isidor-um-card-role {
            display: inline-block; padding: 3px 10px; border-radius: 20px;
            font-size: 0.78em; font-weight: 600; flex-shrink: 0;
            background: var(--is-primary-subtle, #eff6ff); color: var(--is-primary-text, #1e40af);
        }
        
        /* Detail-Panel */
        .isidor-um-detail {
            margin-top: 20px; background: var(--is-bg-raised, #fff);
            border: 1px solid var(--is-border, #e2e8f0);
            border-radius: var(--is-radius, 8px); overflow: hidden;
        }
        .isidor-um-detail-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 16px 20px; background: var(--is-bg-sunken, #f1f5f9);
            border-bottom: 1px solid var(--is-border, #e2e8f0);
        }
        .isidor-um-detail-header h3 { margin: 0; font-size: 1.15em; }
        
        .isidor-um-detail-section {
            padding: 16px 20px; border-bottom: 1px solid var(--is-border-light, #f1f5f9);
        }
        .isidor-um-detail-section:last-child { border-bottom: none; }
        .isidor-um-detail-section h4 { margin: 0 0 12px 0; font-size: 0.95em; }
        
        .isidor-um-detail-row {
            display: flex; align-items: center; gap: 12px;
            margin-bottom: 10px; flex-wrap: wrap;
        }
        .isidor-um-detail-row label { min-width: 140px; font-weight: 600; font-size: 0.9em; }
        
        /* Berechtigungs-Grid */
        .isidor-um-perms-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px;
        }
        .isidor-um-perm-app {
            padding: 14px; background: var(--is-bg-sunken, #f8fafc);
            border-radius: var(--is-radius, 8px); border: 1px solid var(--is-border-light, #f1f5f9);
        }
        .isidor-um-perm-app-header {
            font-weight: 700; font-size: 0.95em; margin-bottom: 8px;
        }
        .isidor-um-perm-check { margin: 4px 0; font-size: 0.88em; }
        .isidor-um-perm-check label { cursor: pointer; display: flex; align-items: center; gap: 6px; }
        .isidor-um-perm-check input { margin: 0; }
        
        /* Rollen-Grid */
        .isidor-um-roles-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 4px 16px;
        }
        
        /* Nachrichten */
        .isidor-um-msg { padding: 12px 16px; border-radius: var(--is-radius, 8px); margin-top: 14px; font-size: 0.92em; }
        .isidor-um-msg-success { background: #dcfce7; color: #166534; }
        .isidor-um-msg-error { background: #fce4ec; color: #b71c1c; }
        
        .isidor-um-loading { text-align: center; padding: 40px; color: var(--is-text-muted, #64748b); }
        
        .isidor-um-hint { display: block; font-size: 0.82em; color: var(--is-text-muted, #64748b); margin-top: 4px; }
        
        .isidor-um-form-card {
            background: var(--is-bg-raised, #fff); padding: 24px;
            border: 1px solid var(--is-border, #e2e8f0);
            border-radius: var(--is-radius, 8px);
        }
        .isidor-um-form-row { margin-bottom: 16px; }
        .isidor-um-form-row label { display: block; font-weight: 600; font-size: 0.9em; margin-bottom: 6px; }
        .isidor-um-form-row .isidor-um-input,
        .isidor-um-form-row .isidor-um-select { width: 100%; box-sizing: border-box; }
        .isidor-um-form-row-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .isidor-um-form-actions { display: flex; gap: 12px; margin-top: 20px; }
        
        @media (max-width: 640px) {
            .isidor-um-form-row-2col { grid-template-columns: 1fr; }
            .isidor-um-perms-grid { grid-template-columns: 1fr; }
            .isidor-um-detail-row { flex-direction: column; align-items: flex-start; }
            .isidor-um-detail-row label { min-width: auto; }
        }
        </style>
        <?php
    }
    
    // =========================================================
    // JavaScript
    // =========================================================
    
    private function render_scripts(): void {
        ?>
        <script>
        (function() {
            var wrap = document.getElementById("isidor-um");
            if (!wrap) return;
            
            var ajax = wrap.getAttribute("data-ajax");
            var nonce = wrap.getAttribute("data-nonce");
            var roles = JSON.parse(document.getElementById("um-roles-data").textContent);
            var allRoles = JSON.parse(document.getElementById("um-all-roles-data").textContent);
            var templates = JSON.parse(document.getElementById("um-templates-data").textContent);
            var apps = JSON.parse(document.getElementById("um-apps-data").textContent);
            var list = document.getElementById("um-user-list");
            var detail = document.getElementById("um-detail");
            var detailBody = document.getElementById("um-detail-body");
            var detailName = document.getElementById("um-detail-name");
            var selectedId = 0;
            
            function post(action, data) {
                var fd = new FormData();
                fd.append("action", action);
                fd.append("_wpnonce", nonce);
                for (var k in data) fd.append(k, data[k]);
                return fetch(ajax, {method: "POST", body: fd}).then(function(r) { return r.json(); });
            }
            
            // === LISTE LADEN ===
            function loadUsers() {
                var search = document.getElementById("um-search").value;
                var role = document.getElementById("um-role-filter").value;
                
                list.innerHTML = '<div class="isidor-um-loading">Lade …</div>';
                
                post("isidor_fm_list_users", {search: search, role: role}).then(function(resp) {
                    if (!resp.success) { list.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">Fehler.</div>'; return; }
                    
                    var users = resp.data.users;
                    if (!users.length) {
                        list.innerHTML = '<div class="isidor-um-loading">Keine Benutzer gefunden.</div>';
                        return;
                    }
                    
                    var h = "";
                    for (var i = 0; i < users.length; i++) {
                        var u = users[i];
                        h += '<div class="isidor-um-card' + (u.id === selectedId ? ' active' : '') + '" data-uid="' + u.id + '">';
                        h += '<img class="isidor-um-avatar" src="' + u.avatar + '" alt="">';
                        h += '<div class="isidor-um-card-info">';
                        h += '<div class="isidor-um-card-name">' + u.name + '</div>';
                        h += '<div class="isidor-um-card-meta">' + u.email + '</div>';
                        h += '</div>';
                        h += '<span class="isidor-um-card-role">' + u.role_label + '</span>';
                        h += '</div>';
                    }
                    list.innerHTML = h;
                    
                    // Click-Handler
                    list.querySelectorAll(".isidor-um-card").forEach(function(card) {
                        card.addEventListener("click", function() {
                            openUser(parseInt(this.getAttribute("data-uid")));
                        });
                    });
                });
            }
            
            // === USER ÖFFNEN ===
            function openUser(uid) {
                selectedId = uid;
                
                // Karten-Highlight
                list.querySelectorAll(".isidor-um-card").forEach(function(c) {
                    c.classList.toggle("active", parseInt(c.getAttribute("data-uid")) === uid);
                });
                
                detailBody.innerHTML = '<div class="isidor-um-loading">Lade …</div>';
                detail.style.display = "block";
                
                post("isidor_fm_get_user", {user_id: uid}).then(function(resp) {
                    if (!resp.success) {
                        detailBody.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">' + (resp.data ? resp.data.message : "Fehler") + '</div>';
                        return;
                    }
                    
                    var u = resp.data;
                    detailName.textContent = u.first_name ? (u.first_name + " " + u.last_name) : u.username;
                    
                    var h = "";
                    
                    // === Info ===
                    h += '<div class="isidor-um-detail-section">';
                    h += '<div class="isidor-um-detail-row">';
                    h += '<label>Benutzername</label><span>' + u.username + '</span>';
                    h += '</div>';
                    h += '<div class="isidor-um-detail-row">';
                    h += '<label>E-Mail</label><span>' + u.email + '</span>';
                    h += '</div>';
                    h += '<div class="isidor-um-detail-row">';
                    h += '<label>Registriert seit</label><span>' + u.registered + '</span>';
                    h += '</div>';
                    h += '</div>';
                    
                    // === Rolle (Radio – genau eine) ===
                    h += '<div class="isidor-um-detail-section">';
                    h += '<h4>⛪ Master-Rolle</h4>';
                    h += '<div class="isidor-um-roles-grid">';
                    var userRoles = u.roles || [];
                    // Determine current master role
                    var currentRole = 'isidor_mitglied';
                    for (var slug in roles) {
                        if (userRoles.indexOf(slug) !== -1) { currentRole = slug; break; }
                    }
                    // Also check legacy roles
                    if (currentRole === 'isidor_mitglied') {
                        if (userRoles.indexOf('isidor_pfarrer_godmode') !== -1) currentRole = 'isidor_pfarrer';
                    }
                    for (var slug in roles) {
                        var rc = (slug === currentRole) ? ' checked' : '';
                        h += '<div class="isidor-um-perm-check"><label>';
                        h += '<input type="radio" name="um-master-role" class="um-role-radio" value="' + slug + '"' + rc + '>';
                        h += ' ' + roles[slug];
                        h += '</label></div>';
                    }
                    h += '</div>';
                    h += '</div>';
                    
                    // === Templates (Checkboxen – mehrere möglich) ===
                    h += '<div class="isidor-um-detail-section">';
                    h += '<h4>🔑 Templates</h4>';
                    h += '<p style="font-size:0.85em;color:var(--is-text-muted,#64748b);margin:0 0 10px;">Mehrere Templates möglich, z.\u00a0B. VVR-Mitglied + Lektor.</p>';
                    h += '<div class="isidor-um-roles-grid">';
                    var userTplNames = (u.templates || []);
                    for (var tk in templates) {
                        // Check if user has this template assigned
                        var tplLabel = templates[tk].label || tk;
                        var isAssigned = false;
                        // Match by name from user's template_label
                        if (u.template_label) {
                            userTplNames.forEach(function(tn) {
                                if (tplLabel.indexOf(tn.replace(/^[^\w]+/, '').trim()) !== -1) isAssigned = true;
                            });
                        }
                        var tc = isAssigned ? ' checked' : '';
                        h += '<div class="isidor-um-perm-check"><label>';
                        h += '<input type="checkbox" class="um-tpl-cb" data-tpl="' + tk + '"' + tc + '>';
                        h += ' ' + tplLabel;
                        h += '</label></div>';
                    }
                    h += '</div>';
                    h += '</div>';
                    
                    // === Berechtigungen ===
                    h += '<div class="isidor-um-detail-section">';
                    h += '<h4>🔐 App-Berechtigungen</h4>';
                    h += '<div class="isidor-um-perms-grid">';
                    
                    for (var appSlug in apps) {
                        var app = apps[appSlug];
                        h += '<div class="isidor-um-perm-app">';
                        h += '<div class="isidor-um-perm-app-header">' + app.icon + ' ' + app.name + '</div>';
                        
                        for (var pk in app.permissions) {
                            var checked = (u.permissions[appSlug] && u.permissions[appSlug].indexOf(pk) !== -1) ? ' checked' : '';
                            h += '<div class="isidor-um-perm-check"><label>';
                            h += '<input type="checkbox" data-app="' + appSlug + '" data-perm="' + pk + '"' + checked + '>';
                            h += ' ' + app.permissions[pk];
                            h += '</label></div>';
                        }
                        
                        h += '</div>';
                    }
                    
                    h += '</div></div>';
                    
                    // === Aktionen ===
                    h += '<div class="isidor-um-detail-section">';
                    h += '<div style="display:flex;gap:12px;flex-wrap:wrap;">';
                    h += '<button type="button" class="isidor-um-btn isidor-um-btn-primary" id="um-save-user">💾 Speichern</button>';
                    h += '<button type="button" class="isidor-um-btn isidor-um-btn-danger isidor-um-btn-sm" id="um-delete-user">🗑️ Benutzer löschen</button>';
                    h += '</div>';
                    h += '<div id="um-save-msg"></div>';
                    h += '</div>';
                    
                    detailBody.innerHTML = h;
                    
                    // Detail-Panel scrollen
                    setTimeout(function() { detail.scrollIntoView({behavior: "smooth", block: "nearest"}); }, 50);
                    
                    // --- Handler ---
                    
                    // Get selected master role (radio)
                    function getSelectedRole() {
                        var radio = detailBody.querySelector(".um-role-radio:checked");
                        return radio ? radio.value : 'isidor_mitglied';
                    }
                    
                    // Get selected template IDs
                    function getSelectedTemplates() {
                        var t = [];
                        detailBody.querySelectorAll(".um-tpl-cb:checked").forEach(function(cb) {
                            t.push(cb.getAttribute("data-tpl"));
                        });
                        return t;
                    }
                    
                    // Speichern
                    document.getElementById("um-save-user").addEventListener("click", function() {
                        var role = getSelectedRole();
                        var selTpls = getSelectedTemplates();
                        
                        var perms = {};
                        detailBody.querySelectorAll("input[data-app]:checked").forEach(function(cb) {
                            var a = cb.getAttribute("data-app");
                            var p = cb.getAttribute("data-perm");
                            if (!perms[a]) perms[a] = [];
                            perms[a].push(p);
                        });
                        
                        var fd = new FormData();
                        fd.append("action", "isidor_fm_save_user");
                        fd.append("_wpnonce", nonce);
                        fd.append("user_id", uid);
                        fd.append("roles[]", role);
                        selTpls.forEach(function(t) { fd.append("template_ids[]", t); });
                        for (var a in perms) {
                            for (var i = 0; i < perms[a].length; i++) {
                                fd.append("permissions[" + a + "][]", perms[a][i]);
                            }
                        }
                        
                        fetch(ajax, {method: "POST", body: fd}).then(function(r) { return r.json(); }).then(function(resp) {
                            var msg = document.getElementById("um-save-msg");
                            if (resp.success) {
                                msg.innerHTML = '<div class="isidor-um-msg isidor-um-msg-success">✅ ' + resp.data.message + '</div>';
                                loadUsers();
                            } else {
                                msg.innerHTML = '<div class="isidor-um-msg isidor-um-msg-error">❌ ' + (resp.data ? resp.data.message : "Fehler") + '</div>';
                            }
                        });
                    });
                    
                    // Löschen
                    document.getElementById("um-delete-user").addEventListener("click", function() {
                        if (!confirm("Benutzer wirklich UNWIDERRUFLICH löschen? Alle Daten gehen verloren!")) return;
                        if (!confirm("Sind Sie GANZ SICHER?")) return;
                        
                        post("isidor_fm_delete_user", {user_id: uid}).then(function(resp) {
                            if (resp.success) {
                                detail.style.display = "none";
                                selectedId = 0;
                                loadUsers();
                            } else {
                                alert(resp.data ? resp.data.message : "Fehler");
                            }
                        });
                    });
                });
            }
            
            // === EVENTS ===
            var searchTimer;
            document.getElementById("um-search").addEventListener("input", function() {
                clearTimeout(searchTimer);
                searchTimer = setTimeout(loadUsers, 300);
            });
            document.getElementById("um-role-filter").addEventListener("change", loadUsers);
            document.getElementById("um-detail-close").addEventListener("click", function() {
                detail.style.display = "none";
                selectedId = 0;
                list.querySelectorAll(".isidor-um-card").forEach(function(c) { c.classList.remove("active"); });
            });
            
            // Initial laden
            loadUsers();
        })();
        </script>
        <?php
    }
}
