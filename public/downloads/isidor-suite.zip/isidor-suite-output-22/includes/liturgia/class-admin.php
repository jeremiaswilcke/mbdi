<?php
/**
 * Liturgia Admin
 *
 * Admin-Menü, Übersicht, Detail-Seite, AJAX-Handler.
 * v2: User-Picker, Cantus-Katalog-Suche, Sync-Trigger.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Admin {

    private static $instance = null;

    public static function get_instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'add_menu'], 20);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);

        // AJAX Handlers – bestehend
        add_action('wp_ajax_liturgia_save_event', [$this, 'ajax_save_event']);
        add_action('wp_ajax_liturgia_delete_event', [$this, 'ajax_delete_event']);
        add_action('wp_ajax_liturgia_get_event', [$this, 'ajax_get_event']);
        add_action('wp_ajax_liturgia_save_element', [$this, 'ajax_save_element']);
        add_action('wp_ajax_liturgia_delete_element', [$this, 'ajax_delete_element']);
        add_action('wp_ajax_liturgia_reorder_elements', [$this, 'ajax_reorder_elements']);
        add_action('wp_ajax_liturgia_apply_template', [$this, 'ajax_apply_template']);
        add_action('wp_ajax_liturgia_save_template', [$this, 'ajax_save_template']);
        add_action('wp_ajax_liturgia_delete_template', [$this, 'ajax_delete_template']);
        add_action('wp_ajax_liturgia_update_status', [$this, 'ajax_update_status']);
        add_action('wp_ajax_liturgia_list_events', [$this, 'ajax_list_events']);

        // AJAX Handlers – neu v2
        add_action('wp_ajax_liturgia_search_users', [$this, 'ajax_search_users']);
        add_action('wp_ajax_liturgia_search_cantus_catalog', [$this, 'ajax_search_cantus_catalog']);
        add_action('wp_ajax_liturgia_save_element_persons', [$this, 'ajax_save_element_persons']);
        add_action('wp_ajax_liturgia_sync_to_modules', [$this, 'ajax_sync_to_modules']);
    }

    /**
     * Admin-Menü
     */
    public function add_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Liturgia – Gottesdienst-Planung',
            '📋 Liturgia',
            'manage_options',
            'liturgia',
            [$this, 'render_overview']
        );

        add_submenu_page(
            null, // hidden
            'Liturgia – Gottesdienst bearbeiten',
            'Liturgia Event',
            'manage_options',
            'liturgia-edit',
            [$this, 'render_detail']
        );
    }

    /**
     * Assets nur auf Liturgia-Seiten laden
     */
    public function enqueue_assets(string $hook): void {
        $screen = get_current_screen();
        if (!$screen || strpos($screen->id, 'liturgia') === false) {
            return;
        }

        // jQuery UI Sortable
        wp_enqueue_script('jquery-ui-sortable');

        // WordPress Editor
        wp_enqueue_editor();

        // Liturgia CSS
        wp_enqueue_style(
            'liturgia-admin',
            ISIDOR_SUITE_URL . 'assets/css/liturgia-admin.css',
            [],
            ISIDOR_LITURGIA_VERSION
        );

        // Liturgia JS
        wp_enqueue_script(
            'liturgia-admin',
            ISIDOR_SUITE_URL . 'assets/js/liturgia-admin.js',
            ['jquery', 'jquery-ui-sortable', 'wp-editor'],
            ISIDOR_LITURGIA_VERSION,
            true
        );

        wp_localize_script('liturgia-admin', 'liturgiaData', [
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('liturgia_nonce'),
            'elementTypes'  => Database::get_element_types(),
            'roles'         => Database::get_roles(),
            'locations'     => Database::get_locations(),
            'statuses'      => Database::get_statuses(),
            'eventTypes'    => Database::get_event_types(),
            'editUrl'       => admin_url('admin.php?page=liturgia-edit&id='),
            'overviewUrl'   => admin_url('admin.php?page=liturgia'),
            'printUrl'      => admin_url('admin.php?page=liturgia-edit&action=print&id='),
            'pdfUrl'        => admin_url('admin-ajax.php?action=liturgia_generate_pdf&id='),
            'hasCantus'     => class_exists('Cantus_DB'),
        ]);
    }

    // ========================================================================
    // SEITEN
    // ========================================================================

    /**
     * Übersicht aller Events
     */
    public function render_overview(): void {
        $statuses = Database::get_statuses();
        $event_types = Database::get_event_types();
        $templates = Templates::get_all();
        ?>
        <div class="wrap liturgia-wrap">
            <div class="liturgia-header">
                <h1>📋 Liturgia – Gottesdienst-Planung</h1>
                <button type="button" class="button button-primary liturgia-btn-create" id="liturgia-create-event">
                    + Neuen Gottesdienst planen
                </button>
            </div>

            <!-- Filter -->
            <div class="liturgia-filters">
                <label>
                    Zeitraum:
                    <select id="liturgia-filter-period">
                        <option value="upcoming">Kommende</option>
                        <option value="all">Alle</option>
                        <option value="past">Vergangene</option>
                        <option value="month">Diesen Monat</option>
                    </select>
                </label>
                <label>
                    Status:
                    <select id="liturgia-filter-status">
                        <option value="">Alle</option>
                        <?php foreach ($statuses as $key => $s): ?>
                            <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($s['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    Typ:
                    <select id="liturgia-filter-type">
                        <option value="">Alle</option>
                        <?php foreach ($event_types as $key => $label): ?>
                            <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <div class="liturgia-view-toggle">
                    <button type="button" class="button active" data-view="list" title="Listenansicht">☰</button>
                    <button type="button" class="button" data-view="calendar" title="Kalenderansicht">📅</button>
                </div>
            </div>

            <!-- Listenansicht -->
            <div id="liturgia-list-view">
                <table class="wp-list-table widefat fixed striped liturgia-events-table">
                    <thead>
                        <tr>
                            <th style="width:120px;">Datum</th>
                            <th>Titel</th>
                            <th style="width:140px;">Typ</th>
                            <th style="width:120px;">Status</th>
                            <th style="width:80px;">Elemente</th>
                            <th style="width:160px;">Aktionen</th>
                        </tr>
                    </thead>
                    <tbody id="liturgia-events-body">
                        <tr><td colspan="6" style="text-align:center;padding:40px;">Wird geladen...</td></tr>
                    </tbody>
                </table>
            </div>

            <!-- Kalenderansicht (einfach) -->
            <div id="liturgia-calendar-view" style="display:none;">
                <div id="liturgia-calendar-grid" class="liturgia-calendar"></div>
            </div>

            <!-- Schnell-Anlage Modal -->
            <div id="liturgia-create-modal" class="liturgia-modal" style="display:none;">
                <div class="liturgia-modal-content">
                    <div class="liturgia-modal-header">
                        <h3>Neuen Gottesdienst planen</h3>
                        <span class="liturgia-modal-close">&times;</span>
                    </div>
                    <div class="liturgia-modal-body">
                        <div class="liturgia-form-row">
                            <label>Titel *
                                <input type="text" id="liturgia-new-title" class="regular-text" placeholder="z.B. Ostersonntag Hochamt">
                            </label>
                        </div>
                        <div class="liturgia-form-row liturgia-form-row-2col">
                            <label>Datum *
                                <input type="date" id="liturgia-new-date">
                            </label>
                            <label>Typ
                                <select id="liturgia-new-type">
                                    <?php foreach ($event_types as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </div>
                        <div class="liturgia-form-row">
                            <label>Standardort
                                <input type="text" id="liturgia-new-location" class="regular-text" list="liturgia-locations-list" placeholder="z.B. Hauptschiff">
                                <datalist id="liturgia-locations-list">
                                    <?php foreach (Database::get_locations() as $loc): ?>
                                        <option value="<?php echo esc_attr($loc); ?>">
                                    <?php endforeach; ?>
                                </datalist>
                            </label>
                        </div>
                        <div class="liturgia-form-row">
                            <label>Vorlage verwenden
                                <select id="liturgia-new-template">
                                    <option value="">Ohne Vorlage (leer)</option>
                                    <?php foreach ($templates as $tpl): ?>
                                        <option value="<?php echo $tpl['id']; ?>">
                                            <?php echo esc_html($tpl['title']); ?>
                                            <?php if ($tpl['is_default']): ?> (Standard)<?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </div>
                    </div>
                    <div class="liturgia-modal-footer">
                        <button type="button" class="button liturgia-modal-cancel">Abbrechen</button>
                        <button type="button" class="button button-primary" id="liturgia-do-create">Erstellen & Bearbeiten</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Detail-Seite (einzelner Gottesdienst)
     */
    public function render_detail(): void {
        $event_id = (int) ($_GET['id'] ?? 0);

        // Druckansicht?
        if (isset($_GET['action']) && $_GET['action'] === 'print') {
            $this->render_print_view($event_id);
            return;
        }

        if (!$event_id) {
            wp_die('Kein Event angegeben.');
        }

        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event) {
            wp_die('Event nicht gefunden.');
        }

        $elements = Elements::get_for_event($event_id);
        $statuses = Database::get_statuses();
        $event_types = Database::get_event_types();
        $element_types = Database::get_element_types();
        $roles = Database::get_roles();
        $locations = Database::get_locations();
        $templates = Templates::get_all();
        $participants = Elements::get_participants($event_id);
        $total_duration = Elements::get_total_duration($event_id);
        $status_info = $statuses[$event['status']] ?? $statuses['entwurf'];
        ?>
        <div class="wrap liturgia-wrap liturgia-detail">
            <!-- Header -->
            <div class="liturgia-detail-header">
                <div class="liturgia-detail-header-left">
                    <a href="<?php echo admin_url('admin.php?page=liturgia'); ?>" class="liturgia-back">&larr; Zur&uuml;ck zur &Uuml;bersicht</a>
                    <h1 id="liturgia-event-title-display"><?php echo esc_html($event['event_title']); ?></h1>
                    <div class="liturgia-detail-meta">
                        <span class="liturgia-badge" style="background:<?php echo esc_attr($status_info['bg']); ?>;color:<?php echo esc_attr($status_info['color']); ?>">
                            <?php echo esc_html($status_info['label']); ?>
                        </span>
                        <span><?php echo esc_html($event_types[$event['event_type']] ?? $event['event_type']); ?></span>
                        <span><?php echo date_i18n('l, j. F Y', strtotime($event['event_date'])); ?></span>
                        <?php if ($event['location_default']): ?>
                            <span>&#x1F4CD; <?php echo esc_html($event['location_default']); ?></span>
                        <?php endif; ?>
                        <?php if ($total_duration > 0): ?>
                            <span>&#x23F1; ca. <?php echo $total_duration; ?> Min.</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="liturgia-detail-header-right">
                    <select id="liturgia-status-select" class="liturgia-status-select">
                        <?php foreach ($statuses as $key => $s): ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php selected($event['status'], $key); ?>>
                                <?php echo esc_html($s['label']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" class="button" id="liturgia-sync-btn" title="Cantus/Liturgus synchronisieren">&#x1F504; Sync</button>
                    <button type="button" class="button" id="liturgia-print-btn" title="Druckansicht">&#x1F5A8; Drucken</button>
                    <button type="button" class="button" id="liturgia-pdf-btn" title="Als PDF exportieren">&#x1F4C4; PDF</button>
                    <button type="button" class="button" id="liturgia-email-btn" title="Per E-Mail versenden">&#x2709; E-Mail</button>
                </div>
            </div>

            <input type="hidden" id="liturgia-event-id" value="<?php echo $event_id; ?>">

            <div class="liturgia-detail-layout">
                <!-- HAUPTBEREICH -->
                <div class="liturgia-detail-main">

                    <!-- Event-Kopfdaten (editierbar) -->
                    <div class="liturgia-section liturgia-event-meta-edit" id="liturgia-event-meta">
                        <div class="liturgia-section-header" style="cursor:pointer;" onclick="jQuery(this).next('.liturgia-section-body').slideToggle(200)">
                            <h3>&#x2699; Grunddaten bearbeiten</h3>
                            <span class="liturgia-toggle">&#x25BE;</span>
                        </div>
                        <div class="liturgia-section-body" style="display:none;">
                            <div class="liturgia-form-row liturgia-form-row-2col">
                                <label>Titel
                                    <input type="text" id="liturgia-edit-title" value="<?php echo esc_attr($event['event_title']); ?>" class="regular-text">
                                </label>
                                <label>Datum
                                    <input type="date" id="liturgia-edit-date" value="<?php echo esc_attr($event['event_date']); ?>">
                                </label>
                            </div>
                            <div class="liturgia-form-row liturgia-form-row-2col">
                                <label>Typ
                                    <select id="liturgia-edit-type">
                                        <?php foreach ($event_types as $key => $label): ?>
                                            <option value="<?php echo esc_attr($key); ?>" <?php selected($event['event_type'], $key); ?>>
                                                <?php echo esc_html($label); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <label>Standardort
                                    <input type="text" id="liturgia-edit-location" value="<?php echo esc_attr($event['location_default']); ?>" list="liturgia-locations-datalist">
                                    <datalist id="liturgia-locations-datalist">
                                        <?php foreach ($locations as $loc): ?>
                                            <option value="<?php echo esc_attr($loc); ?>">
                                        <?php endforeach; ?>
                                    </datalist>
                                </label>
                            </div>
                            <div class="liturgia-form-row">
                                <label>Verkn&uuml;pfte Messe (post_id)
                                    <input type="number" id="liturgia-edit-post-id" value="<?php echo esc_attr($event['post_id']); ?>" min="0" style="width:120px;">
                                    <span class="description">ID des isidor_messe Posts (0 = keine Verkn&uuml;pfung)</span>
                                </label>
                            </div>
                            <div class="liturgia-form-row">
                                <label>Allgemeine Anmerkungen</label>
                                <?php
                                wp_editor($event['notes'] ?? '', 'liturgia_event_notes', [
                                    'media_buttons' => false,
                                    'textarea_rows' => 6,
                                    'teeny'         => false,
                                    'quicktags'     => true,
                                    'tinymce'       => [
                                        'toolbar1' => 'bold,italic,underline,bullist,numlist,link,unlink,undo,redo',
                                        'toolbar2' => '',
                                    ],
                                ]);
                                ?>
                            </div>
                            <div class="liturgia-form-row" style="text-align:right;">
                                <button type="button" class="button button-primary" id="liturgia-save-meta">Grunddaten speichern</button>
                            </div>
                        </div>
                    </div>

                    <!-- Ablauf-Elemente -->
                    <div class="liturgia-section">
                        <div class="liturgia-section-header">
                            <h3>&#x1F4DC; Ablauf (<?php echo count($elements); ?> Elemente)</h3>
                            <div class="liturgia-section-actions">
                                <button type="button" class="button" id="liturgia-load-template">&#x1F4C2; Aus Vorlage laden</button>
                                <button type="button" class="button button-primary" id="liturgia-add-element">+ Element hinzuf&uuml;gen</button>
                            </div>
                        </div>

                        <div id="liturgia-elements-list" class="liturgia-elements-sortable">
                            <?php if (empty($elements)): ?>
                                <div class="liturgia-empty-state" id="liturgia-empty-state">
                                    <p>Noch keine Elemente. Starte mit einer Vorlage oder f&uuml;ge einzelne Elemente hinzu.</p>
                                </div>
                            <?php endif; ?>
                            <?php foreach ($elements as $el): ?>
                                <?php self::render_element_card($el, $element_types, $roles, $locations); ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- SEITENLEISTE -->
                <div class="liturgia-detail-sidebar">
                    <!-- Zusammenfassung -->
                    <div class="liturgia-sidebar-box">
                        <h4>Zusammenfassung</h4>
                        <ul class="liturgia-summary-list">
                            <li><strong>Elemente:</strong> <span id="liturgia-count-elements"><?php echo count($elements); ?></span></li>
                            <li><strong>Dauer:</strong> <span id="liturgia-total-duration"><?php echo $total_duration > 0 ? "ca. {$total_duration} Min." : '&ndash;'; ?></span></li>
                            <li><strong>Status:</strong> <span id="liturgia-summary-status"><?php echo esc_html($status_info['label']); ?></span></li>
                        </ul>
                    </div>

                    <!-- Beteiligte Personen -->
                    <div class="liturgia-sidebar-box">
                        <h4>Beteiligte Personen</h4>
                        <?php if (empty($participants)): ?>
                            <p class="liturgia-muted">Noch keine Personen zugewiesen.</p>
                        <?php else: ?>
                            <ul class="liturgia-participants-list" id="liturgia-participants">
                                <?php foreach ($participants as $role => $persons): ?>
                                    <li>
                                        <strong><?php echo esc_html($role); ?>:</strong>
                                        <?php
                                        $names = array_map(function($p) { return esc_html($p['display_name']); }, $persons);
                                        echo implode(', ', $names);
                                        ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- Aktionen -->
                    <div class="liturgia-sidebar-box">
                        <h4>Aktionen</h4>
                        <button type="button" class="button liturgia-sidebar-btn" id="liturgia-save-as-template">&#x1F4BE; Als Vorlage speichern</button>
                        <button type="button" class="button liturgia-sidebar-btn liturgia-btn-danger" id="liturgia-delete-event">&#x1F5D1; Event l&ouml;schen</button>
                    </div>

                    <!-- Sync-Info -->
                    <div class="liturgia-sidebar-box" id="liturgia-sync-info">
                        <h4>&#x1F504; Modul-Synchronisation</h4>
                        <p class="liturgia-muted" style="font-size:12px;">
                            Bei Status &laquo;Freigegeben&raquo; werden Lieder in Cantus und Dienste in Liturgus &uuml;bernommen.
                        </p>
                        <button type="button" class="button liturgia-sidebar-btn" id="liturgia-manual-sync">Jetzt synchronisieren</button>
                        <div id="liturgia-sync-result" style="margin-top:8px;"></div>
                    </div>

                    <!-- Vorlagen-Verwaltung -->
                    <div class="liturgia-sidebar-box">
                        <h4>Vorlagen</h4>
                        <ul class="liturgia-templates-list">
                            <?php foreach ($templates as $tpl): ?>
                                <li>
                                    <?php echo esc_html($tpl['title']); ?>
                                    <?php if ($tpl['is_default']): ?><small>(Standard)</small><?php endif; ?>
                                    <?php if (!$tpl['is_default']): ?>
                                        <button type="button" class="liturgia-btn-xs liturgia-btn-delete-template" data-id="<?php echo $tpl['id']; ?>" title="L&ouml;schen">&#x2717;</button>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Vorlage-laden Modal -->
            <div id="liturgia-template-modal" class="liturgia-modal" style="display:none;">
                <div class="liturgia-modal-content">
                    <div class="liturgia-modal-header">
                        <h3>Vorlage laden</h3>
                        <span class="liturgia-modal-close">&times;</span>
                    </div>
                    <div class="liturgia-modal-body">
                        <p><strong>Achtung:</strong> Bestehende Elemente werden durch die Vorlage ersetzt!</p>
                        <select id="liturgia-template-select" class="regular-text" style="width:100%;">
                            <option value="">Vorlage w&auml;hlen...</option>
                            <?php foreach ($templates as $tpl): ?>
                                <option value="<?php echo $tpl['id']; ?>">
                                    <?php echo esc_html($tpl['title']); ?>
                                    <?php if ($tpl['description']): ?> &ndash; <?php echo esc_html(wp_trim_words($tpl['description'], 10)); ?><?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="liturgia-modal-footer">
                        <button type="button" class="button liturgia-modal-cancel">Abbrechen</button>
                        <button type="button" class="button button-primary" id="liturgia-do-apply-template">Vorlage anwenden</button>
                    </div>
                </div>
            </div>

            <!-- E-Mail Modal -->
            <div id="liturgia-email-modal" class="liturgia-modal" style="display:none;">
                <div class="liturgia-modal-content liturgia-modal-wide">
                    <div class="liturgia-modal-header">
                        <h3>&#x2709; Per E-Mail versenden</h3>
                        <span class="liturgia-modal-close">&times;</span>
                    </div>
                    <div class="liturgia-modal-body">
                        <div class="liturgia-form-row">
                            <label><strong>Empf&auml;nger-Schnellauswahl:</strong></label>
                            <div style="display:flex;gap:8px;margin-top:6px;">
                                <button type="button" class="button liturgia-email-quick" data-group="participants">Alle Beteiligten</button>
                                <button type="button" class="button liturgia-email-quick" data-group="liturgieausschuss">Liturgieausschuss</button>
                            </div>
                        </div>
                        <div class="liturgia-form-row">
                            <label><strong>WordPress-Benutzer:</strong></label>
                            <div id="liturgia-email-users" class="liturgia-email-users-list" style="max-height:200px;overflow-y:auto;border:1px solid #ddd;padding:10px;border-radius:4px;">
                                Wird geladen...
                            </div>
                        </div>
                        <div class="liturgia-form-row">
                            <label><strong>Zus&auml;tzliche E-Mail-Adressen</strong> (kommagetrennt):
                                <input type="text" id="liturgia-email-extra" class="regular-text" placeholder="name@example.com, ...">
                            </label>
                        </div>
                    </div>
                    <div class="liturgia-modal-footer">
                        <span id="liturgia-email-status"></span>
                        <button type="button" class="button liturgia-modal-cancel">Abbrechen</button>
                        <button type="button" class="button button-primary" id="liturgia-do-send-email">&#x1F4E7; Senden (mit PDF)</button>
                    </div>
                </div>
            </div>

            <!-- Vorlage-speichern Modal -->
            <div id="liturgia-save-template-modal" class="liturgia-modal" style="display:none;">
                <div class="liturgia-modal-content">
                    <div class="liturgia-modal-header">
                        <h3>Als Vorlage speichern</h3>
                        <span class="liturgia-modal-close">&times;</span>
                    </div>
                    <div class="liturgia-modal-body">
                        <label>Vorlagenname *
                            <input type="text" id="liturgia-template-name" class="regular-text" style="width:100%;" placeholder="z.B. Karfreitag Liturgie">
                        </label>
                    </div>
                    <div class="liturgia-modal-footer">
                        <button type="button" class="button liturgia-modal-cancel">Abbrechen</button>
                        <button type="button" class="button button-primary" id="liturgia-do-save-template">Speichern</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Eine Element-Karte rendern (v2: mit User-Picker + Cantus-Suche)
     */
    public static function render_element_card(array $el, array $element_types, array $roles, array $locations): void {
        $type_label = $element_types[$el['element_type']] ?? $el['element_type'];
        $role_label = $roles[$el['responsible_role']] ?? $el['responsible_role'];
        $is_lied = in_array($el['element_type'], ['lied', 'einzug', 'kyrie', 'gloria', 'sanctus', 'agnus_dei', 'kommunion', 'antwortpsalm', 'ruf_vor_evangelium', 'gabenbereitung', 'auszug']);
        $is_lesung = in_array($el['element_type'], ['lesung', 'evangelium', 'fuerbitten']);
        $persons = $el['persons'] ?? [];
        ?>
        <div class="liturgia-element-card" data-id="<?php echo $el['id']; ?>" data-type="<?php echo esc_attr($el['element_type']); ?>">
            <div class="liturgia-element-handle" title="Ziehen zum Sortieren">&#x2630;</div>
            <div class="liturgia-element-header" onclick="liturgiaToggleElement(this)">
                <div class="liturgia-element-header-left">
                    <span class="liturgia-element-number"><?php echo $el['sort_order']; ?></span>
                    <span class="liturgia-element-type-badge"><?php echo esc_html($type_label); ?></span>
                    <strong class="liturgia-element-title"><?php echo esc_html($el['title']); ?></strong>
                </div>
                <div class="liturgia-element-header-right">
                    <?php if (!empty($persons)): ?>
                        <span class="liturgia-element-person">
                            <?php
                            $names = array_map(function($p) { return esc_html($p['display_name']); }, array_slice($persons, 0, 2));
                            echo implode(', ', $names);
                            if (count($persons) > 2) echo ' +' . (count($persons) - 2);
                            ?>
                        </span>
                    <?php else: ?>
                        <span class="liturgia-element-role"><?php echo esc_html($role_label); ?></span>
                    <?php endif; ?>
                    <?php if ($el['hymnal_number']): ?>
                        <span class="liturgia-element-gl"><?php echo esc_html($el['hymnal_number']); ?></span>
                    <?php endif; ?>
                    <?php if ($el['cantus_override']): ?>
                        <span class="liturgia-element-sync-badge" title="Wird zu Cantus synchronisiert">&#x1F3B5;</span>
                    <?php endif; ?>
                    <?php if ($el['reading_override']): ?>
                        <span class="liturgia-element-sync-badge" title="Wird zu Tagesplan synchronisiert">&#x1F4D6;</span>
                    <?php endif; ?>
                    <?php if ($el['location']): ?>
                        <span class="liturgia-element-loc">&#x1F4CD; <?php echo esc_html($el['location']); ?></span>
                    <?php endif; ?>
                    <span class="liturgia-element-toggle">&#x25BE;</span>
                </div>
            </div>
            <div class="liturgia-element-body" style="display:none;">
                <div class="liturgia-form-row liturgia-form-row-3col">
                    <label>Was?
                        <select class="liturgia-el-type">
                            <?php foreach ($element_types as $key => $lbl): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($el['element_type'], $key); ?>><?php echo esc_html($lbl); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Titel
                        <input type="text" class="liturgia-el-title regular-text" value="<?php echo esc_attr($el['title']); ?>">
                    </label>
                    <label>Dauer (Min.)
                        <input type="number" class="liturgia-el-duration" value="<?php echo esc_attr($el['duration_minutes']); ?>" min="0" style="width:80px;">
                    </label>
                </div>
                <div class="liturgia-form-row liturgia-form-row-2col">
                    <label>Rolle
                        <select class="liturgia-el-role">
                            <?php foreach ($roles as $key => $lbl): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($el['responsible_role'], $key); ?>><?php echo esc_html($lbl); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Wo?
                        <input type="text" class="liturgia-el-location regular-text" value="<?php echo esc_attr($el['location']); ?>" list="liturgia-locations-datalist" placeholder="z.B. Ambo">
                    </label>
                </div>

                <!-- v2: User-Picker (Multi-Person) -->
                <div class="liturgia-form-row">
                    <label><strong>Personen zuweisen</strong></label>
                    <div class="liturgia-person-picker" data-element-id="<?php echo $el['id']; ?>">
                        <div class="liturgia-person-tags">
                            <?php foreach ($persons as $p): ?>
                                <span class="liturgia-person-tag" data-user-id="<?php echo (int)$p['user_id']; ?>" data-name="<?php echo esc_attr($p['display_name']); ?>" data-role="<?php echo esc_attr($p['role']); ?>">
                                    <?php echo esc_html($p['display_name']); ?>
                                    <button type="button" class="liturgia-person-remove" title="Entfernen">&times;</button>
                                </span>
                            <?php endforeach; ?>
                        </div>
                        <div class="liturgia-person-search-wrap">
                            <input type="text" class="liturgia-person-search regular-text" placeholder="Person suchen (Name eingeben)..." autocomplete="off">
                            <div class="liturgia-person-results" style="display:none;"></div>
                        </div>
                        <div class="liturgia-person-guest-wrap" style="margin-top:4px;">
                            <input type="text" class="liturgia-person-guest-name" placeholder="Gast-Name (ohne WP-Konto)" style="width:200px;">
                            <button type="button" class="button liturgia-person-add-guest" style="margin-left:4px;">+ Gast</button>
                        </div>
                    </div>
                </div>

                <div class="liturgia-form-row">
                    <label>Details / Anweisungen</label>
                    <textarea class="liturgia-el-description liturgia-wp-editor" rows="4" id="liturgia_desc_<?php echo $el['id']; ?>"><?php echo esc_textarea($el['description']); ?></textarea>
                </div>

                <!-- Bedingt: Lied / Cantus -->
                <div class="liturgia-conditional liturgia-cond-lied" <?php if (!$is_lied): ?>style="display:none;"<?php endif; ?>>
                    <div class="liturgia-form-row liturgia-form-row-3col">
                        <label>GL/Lied-Nr.
                            <div class="liturgia-cantus-search-wrap">
                                <input type="text" class="liturgia-el-hymnal regular-text" value="<?php echo esc_attr($el['hymnal_number']); ?>" placeholder="z.B. GL 175" autocomplete="off">
                                <div class="liturgia-cantus-results" style="display:none;"></div>
                            </div>
                        </label>
                        <label>Lied-Typ
                            <select class="liturgia-el-cantus-type">
                                <option value="gl" <?php selected($el['cantus_song_type'] ?? 'gl', 'gl'); ?>>Gotteslob (GL)</option>
                                <option value="jd" <?php selected($el['cantus_song_type'] ?? '', 'jd'); ?>>Jodeldicke (JD)</option>
                                <option value="free" <?php selected($el['cantus_song_type'] ?? '', 'free'); ?>>Freitext</option>
                            </select>
                        </label>
                        <label>Strophen
                            <input type="text" class="liturgia-el-cantus-strophes regular-text" value="<?php echo esc_attr($el['cantus_song_strophes'] ?? ''); ?>" placeholder="z.B. 1,3,5">
                        </label>
                    </div>
                    <div class="liturgia-form-row">
                        <label>
                            <input type="checkbox" class="liturgia-el-cantus-override" value="1" <?php checked($el['cantus_override'], 1); ?>>
                            <strong>In Cantus &uuml;bernehmen</strong> &ndash; Dieses Lied wird in der Cantus-Planung f&uuml;r diese Messe &uuml;berschrieben
                        </label>
                    </div>
                </div>

                <!-- Bedingt: Lesung / Evangelium / Fürbitten -->
                <div class="liturgia-conditional liturgia-cond-lesung" <?php if (!$is_lesung): ?>style="display:none;"<?php endif; ?>>
                    <div class="liturgia-form-row liturgia-form-row-2col">
                        <label>Schriftstelle
                            <input type="text" class="liturgia-el-reading-ref regular-text" value="<?php echo esc_attr($el['reading_reference']); ?>" placeholder="z.B. Jes 52,13-53,12">
                        </label>
                        <label>
                            <input type="checkbox" class="liturgia-el-reading-override" value="1" <?php checked($el['reading_override'], 1); ?>>
                            <strong>Im Tagesplan &uuml;bernehmen</strong>
                        </label>
                    </div>
                    <div class="liturgia-form-row">
                        <label>Lesungstext / F&uuml;rbitten-Text</label>
                        <textarea class="liturgia-el-reading-text liturgia-wp-editor" rows="6" id="liturgia_reading_<?php echo $el['id']; ?>"><?php echo esc_textarea($el['reading_text']); ?></textarea>
                    </div>
                </div>

                <!-- Media / Technik Hinweise -->
                <div class="liturgia-form-row liturgia-media-section">
                    <label style="cursor:pointer;" onclick="jQuery(this).next('textarea').slideToggle(200)">
                        &#x1F3A5; Media/Technik-Hinweise <small>(klicken zum Ein-/Ausblenden)</small>
                    </label>
                    <textarea class="liturgia-el-media liturgia-wp-editor" rows="3" id="liturgia_media_<?php echo $el['id']; ?>" style="display:none;"><?php echo esc_textarea($el['media_notes']); ?></textarea>
                </div>

                <div class="liturgia-element-actions">
                    <button type="button" class="button button-primary liturgia-el-save">&#x1F4BE; Speichern</button>
                    <button type="button" class="button liturgia-el-delete liturgia-btn-danger">&#x1F5D1; L&ouml;schen</button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Druckansicht
     */
    private function render_print_view(int $event_id): void {
        include ISIDOR_SUITE_PATH . 'templates/liturgia/print-event.php';
        exit;
    }

    // ========================================================================
    // AJAX HANDLER – BESTEHEND
    // ========================================================================

    /**
     * Events auflisten (für Übersicht)
     */
    public function ajax_list_events(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_events';
        $el_table = $wpdb->prefix . 'liturgia_elements';

        $where = ['1=1'];
        $params = [];

        $period = sanitize_text_field($_POST['period'] ?? 'upcoming');
        $today = current_time('Y-m-d');
        if ($period === 'upcoming') {
            $where[] = 'e.event_date >= %s';
            $params[] = $today;
        } elseif ($period === 'past') {
            $where[] = 'e.event_date < %s';
            $params[] = $today;
        } elseif ($period === 'month') {
            $where[] = 'YEAR(e.event_date) = %d AND MONTH(e.event_date) = %d';
            $params[] = (int) current_time('Y');
            $params[] = (int) current_time('m');
        }

        $status = sanitize_text_field($_POST['status'] ?? '');
        if ($status !== '') {
            $where[] = 'e.status = %s';
            $params[] = $status;
        }

        $type = sanitize_text_field($_POST['event_type'] ?? '');
        if ($type !== '') {
            $where[] = 'e.event_type = %s';
            $params[] = $type;
        }

        $where_sql = implode(' AND ', $where);
        $order = $period === 'past' ? 'DESC' : 'ASC';

        $query = "SELECT e.*,
                         (SELECT COUNT(*) FROM {$el_table} el WHERE el.event_id = e.id) AS element_count,
                         u.display_name AS author_name
                  FROM {$table} e
                  LEFT JOIN {$wpdb->users} u ON e.created_by = u.ID
                  WHERE {$where_sql}
                  ORDER BY e.event_date {$order}
                  LIMIT 100";

        if (!empty($params)) {
            $query = $wpdb->prepare($query, ...$params);
        }

        $events = $wpdb->get_results($query, ARRAY_A);

        wp_send_json_success(['events' => $events ?: []]);
    }

    /**
     * Event speichern (Create/Update)
     */
    public function ajax_save_event(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_events';

        $id = (int) ($_POST['id'] ?? 0);
        $data = [
            'event_title'      => sanitize_text_field($_POST['event_title'] ?? ''),
            'event_date'       => sanitize_text_field($_POST['event_date'] ?? ''),
            'event_type'       => sanitize_text_field($_POST['event_type'] ?? 'hochamt'),
            'status'           => sanitize_text_field($_POST['status'] ?? 'entwurf'),
            'location_default' => sanitize_text_field($_POST['location_default'] ?? ''),
            'post_id'          => (int) ($_POST['post_id'] ?? 0),
            'notes'            => wp_kses_post($_POST['notes'] ?? ''),
        ];

        if (empty($data['event_title'])) {
            wp_send_json_error(['message' => 'Titel ist Pflichtfeld']);
        }
        if (empty($data['event_date'])) {
            wp_send_json_error(['message' => 'Datum ist Pflichtfeld']);
        }

        if ($id > 0) {
            $wpdb->update($table, $data, ['id' => $id]);
        } else {
            $data['created_by'] = get_current_user_id();
            $wpdb->insert($table, $data);
            $id = (int) $wpdb->insert_id;

            $template_id = (int) ($_POST['template_id'] ?? 0);
            if ($template_id > 0) {
                Templates::apply_to_event($template_id, $id);
            }
        }

        wp_send_json_success(['id' => $id, 'message' => 'Gespeichert']);
    }

    /**
     * Event löschen
     */
    public function ajax_delete_event(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['id'] ?? 0);
        if (!$id) {
            wp_send_json_error(['message' => 'Ungültige ID']);
        }

        global $wpdb;
        Elements::delete_for_event($id);
        $wpdb->delete($wpdb->prefix . 'liturgia_email_log', ['event_id' => $id], ['%d']);
        $wpdb->delete($wpdb->prefix . 'liturgia_events', ['id' => $id], ['%d']);

        wp_send_json_success(['message' => 'Event gelöscht']);
    }

    /**
     * Event laden (für AJAX-Refresh)
     */
    public function ajax_get_event(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['id'] ?? 0);

        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$event) {
            wp_send_json_error(['message' => 'Event nicht gefunden']);
        }

        $elements = Elements::get_for_event($id);

        wp_send_json_success([
            'event'    => $event,
            'elements' => $elements,
        ]);
    }

    /**
     * Element speichern (v2: inkl. Personen + neue Felder)
     */
    public function ajax_save_element(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['element_id'] ?? 0);
        $event_id = (int) ($_POST['event_id'] ?? 0);

        $data = [
            'element_type'       => $_POST['element_type'] ?? 'sonstiges',
            'title'              => $_POST['title'] ?? '',
            'description'        => $_POST['description'] ?? '',
            'responsible_role'   => $_POST['responsible_role'] ?? 'sonstige',
            'responsible_person' => $_POST['responsible_person'] ?? '',
            'location'           => $_POST['location'] ?? '',
            'duration_minutes'   => $_POST['duration_minutes'] ?? null,
            'cantus_override'    => $_POST['cantus_override'] ?? 0,
            'cantus_song_id'     => $_POST['cantus_song_id'] ?? null,
            'cantus_song_type'   => $_POST['cantus_song_type'] ?? 'gl',
            'cantus_song_strophes' => $_POST['cantus_song_strophes'] ?? '',
            'reading_override'   => $_POST['reading_override'] ?? 0,
            'reading_reference'  => $_POST['reading_reference'] ?? '',
            'reading_text'       => $_POST['reading_text'] ?? '',
            'hymnal_number'      => $_POST['hymnal_number'] ?? '',
            'media_notes'        => $_POST['media_notes'] ?? '',
        ];

        // Personen aus JSON-String dekodieren
        $persons_json = $_POST['persons'] ?? '';
        if ($persons_json && is_string($persons_json)) {
            $data['persons'] = json_decode(stripslashes($persons_json), true) ?: [];
        } elseif (is_array($persons_json)) {
            $data['persons'] = $persons_json;
        }

        if ($id > 0) {
            Elements::update($id, $data);
        } else {
            $data['event_id'] = $event_id;
            $id = Elements::create($data);
        }

        // Element zurückladen (mit Personen)
        $element = Elements::get($id);

        wp_send_json_success([
            'id'      => $id,
            'element' => $element,
            'message' => 'Element gespeichert',
        ]);
    }

    /**
     * Element löschen
     */
    public function ajax_delete_element(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['element_id'] ?? 0);
        Elements::delete($id);

        wp_send_json_success(['message' => 'Element gelöscht']);
    }

    /**
     * Elemente neu ordnen
     */
    public function ajax_reorder_elements(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);
        $order = array_map('intval', $_POST['order'] ?? []);

        Elements::reorder($event_id, $order);

        wp_send_json_success(['message' => 'Reihenfolge gespeichert']);
    }

    /**
     * Vorlage auf Event anwenden
     */
    public function ajax_apply_template(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);
        $template_id = (int) ($_POST['template_id'] ?? 0);

        Elements::delete_for_event($event_id);
        $count = Templates::apply_to_event($template_id, $event_id);

        wp_send_json_success(['message' => "{$count} Elemente aus Vorlage erstellt"]);
    }

    /**
     * Vorlage speichern (aus Event)
     */
    public function ajax_save_template(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);
        $title = sanitize_text_field($_POST['title'] ?? '');

        if (empty($title)) {
            wp_send_json_error(['message' => 'Vorlagenname ist Pflichtfeld']);
        }

        $id = Templates::create_from_event($event_id, $title);

        wp_send_json_success(['id' => $id, 'message' => 'Vorlage gespeichert']);
    }

    /**
     * Vorlage löschen
     */
    public function ajax_delete_template(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['template_id'] ?? 0);
        $result = Templates::delete($id);

        if (!$result) {
            wp_send_json_error(['message' => 'Standard-Vorlagen können nicht gelöscht werden']);
        }

        wp_send_json_success(['message' => 'Vorlage gelöscht']);
    }

    /**
     * Status aktualisieren (v2: mit Auto-Sync bei Freigabe)
     */
    public function ajax_update_status(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        global $wpdb;
        $id = (int) ($_POST['id'] ?? 0);
        $status = sanitize_text_field($_POST['status'] ?? '');

        $valid = array_keys(Database::get_statuses());
        if (!in_array($status, $valid, true)) {
            wp_send_json_error(['message' => 'Ungültiger Status']);
        }

        $wpdb->update(
            $wpdb->prefix . 'liturgia_events',
            ['status' => $status],
            ['id' => $id],
            ['%s'],
            ['%d']
        );

        // Auto-Sync bei Freigabe
        $sync_result = null;
        if ($status === 'freigegeben') {
            $sync_result = Integration::sync_all($id);
        }

        wp_send_json_success([
            'message' => 'Status aktualisiert',
            'sync'    => $sync_result,
        ]);
    }

    // ========================================================================
    // AJAX HANDLER – NEU (v2)
    // ========================================================================

    /**
     * WordPress-User suchen (für Person-Picker)
     */
    public function ajax_search_users(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $query = sanitize_text_field($_POST['q'] ?? '');
        if (strlen($query) < 2) {
            wp_send_json_success(['users' => []]);
        }

        $users = get_users([
            'search'         => "*{$query}*",
            'search_columns' => ['user_login', 'user_nicename', 'display_name', 'user_email'],
            'number'         => 20,
            'orderby'        => 'display_name',
            'fields'         => ['ID', 'display_name', 'user_email'],
        ]);

        $result = [];
        foreach ($users as $user) {
            $result[] = [
                'id'           => (int) $user->ID,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
            ];
        }

        wp_send_json_success(['users' => $result]);
    }

    /**
     * Cantus-Katalog durchsuchen (für Lied-Autocomplete)
     */
    public function ajax_search_cantus_catalog(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        if (!class_exists('Cantus_DB')) {
            wp_send_json_success(['songs' => [], 'message' => 'Cantus-Modul nicht aktiv']);
        }

        $query = sanitize_text_field($_POST['q'] ?? '');
        if (strlen($query) < 2) {
            wp_send_json_success(['songs' => []]);
        }

        $results = \Cantus_DB::search_catalog(['q' => $query]);

        $songs = [];
        foreach ($results as $song) {
            $songs[] = [
                'id'     => (int) $song['id'],
                'type'   => $song['type'] ?? 'gl',
                'number' => $song['nr_raw'] ?? '',
                'title'  => $song['title'] ?? '',
                'genre'  => $song['genre'] ?? '',
            ];
        }

        wp_send_json_success(['songs' => $songs]);
    }

    /**
     * Personen für ein Element speichern (separater Endpoint)
     */
    public function ajax_save_element_persons(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $element_id = (int) ($_POST['element_id'] ?? 0);
        $persons_json = $_POST['persons'] ?? '[]';

        if (is_string($persons_json)) {
            $persons = json_decode(stripslashes($persons_json), true) ?: [];
        } else {
            $persons = (array) $persons_json;
        }

        Elements::save_persons($element_id, $persons);

        wp_send_json_success([
            'message' => count($persons) . ' Personen gespeichert',
            'persons' => Elements::get_persons($element_id),
        ]);
    }

    /**
     * Manueller Sync zu Cantus + Liturgus
     */
    public function ajax_sync_to_modules(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);

        $result = Integration::sync_all($event_id);

        $messages = [];
        if ($result['cantus']) {
            $messages[] = 'Cantus synchronisiert';
        } else {
            $messages[] = 'Cantus: nicht möglich (Status/Verknüpfung prüfen)';
        }
        if ($result['liturgus']) {
            $messages[] = 'Liturgus synchronisiert';
        } else {
            $messages[] = 'Liturgus: nicht möglich (Status/Verknüpfung prüfen)';
        }

        wp_send_json_success([
            'sync'    => $result,
            'message' => implode(' | ', $messages),
        ]);
    }
}
