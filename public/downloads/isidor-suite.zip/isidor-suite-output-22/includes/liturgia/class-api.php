<?php
/**
 * Liturgia REST-API
 *
 * Endpoints für externe Integrationen, Cantus/Tagesplan-Overrides.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class API {

    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    /**
     * REST-Routes registrieren
     */
    public static function register_routes(): void {
        $ns = 'isidor/v1/liturgia';

        // Events
        register_rest_route($ns, '/events', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_events'],
            'permission_callback' => [self::class, 'check_read_permission'],
            'args'                => [
                'from'       => ['type' => 'string', 'format' => 'date'],
                'to'         => ['type' => 'string', 'format' => 'date'],
                'status'     => ['type' => 'string'],
                'event_type' => ['type' => 'string'],
            ],
        ]);

        register_rest_route($ns, '/event/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [self::class, 'get_event'],
                'permission_callback' => [self::class, 'check_read_permission'],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [self::class, 'update_event'],
                'permission_callback' => [self::class, 'check_write_permission'],
            ],
        ]);

        register_rest_route($ns, '/event', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'create_event'],
            'permission_callback' => [self::class, 'check_write_permission'],
        ]);

        // Overrides (für Cantus/Tagesplan-Integration)
        register_rest_route($ns, '/overrides/(?P<date>[0-9]{4}-[0-9]{2}-[0-9]{2})', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_overrides'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        register_rest_route($ns, '/readings/(?P<date>[0-9]{4}-[0-9]{2}-[0-9]{2})', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_readings'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // PDF
        register_rest_route($ns, '/event/(?P<id>\d+)/pdf', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_pdf'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // Print-View
        register_rest_route($ns, '/event/(?P<id>\d+)/print', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_print'],
            'permission_callback' => [self::class, 'check_read_permission'],
        ]);

        // Sync (Cantus + Liturgus)
        register_rest_route($ns, '/event/(?P<id>\d+)/sync', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'sync_event'],
            'permission_callback' => [self::class, 'check_write_permission'],
        ]);
    }

    // ========================================================================
    // Permission Callbacks
    // ========================================================================

    public static function check_read_permission(\WP_REST_Request $request): bool {
        return current_user_can('manage_options') || current_user_can('isidor_liturgia_view');
    }

    public static function check_write_permission(\WP_REST_Request $request): bool {
        return current_user_can('manage_options') || current_user_can('isidor_liturgia_manage');
    }

    // ========================================================================
    // Endpoints
    // ========================================================================

    /**
     * GET /events
     */
    public static function get_events(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_events';

        $where = ['1=1'];
        $params = [];

        if ($from = $request->get_param('from')) {
            $where[] = 'event_date >= %s';
            $params[] = sanitize_text_field($from);
        }

        if ($to = $request->get_param('to')) {
            $where[] = 'event_date <= %s';
            $params[] = sanitize_text_field($to);
        }

        if ($status = $request->get_param('status')) {
            $where[] = 'status = %s';
            $params[] = sanitize_text_field($status);
        }

        if ($type = $request->get_param('event_type')) {
            $where[] = 'event_type = %s';
            $params[] = sanitize_text_field($type);
        }

        $where_sql = implode(' AND ', $where);
        $query = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY event_date ASC LIMIT 200";

        if (!empty($params)) {
            $query = $wpdb->prepare($query, ...$params);
        }

        $events = $wpdb->get_results($query, ARRAY_A) ?: [];

        return new \WP_REST_Response($events, 200);
    }

    /**
     * GET /event/{id}
     */
    public static function get_event(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request->get_param('id');

        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$event) {
            return new \WP_REST_Response(['message' => 'Event nicht gefunden'], 404);
        }

        $event['elements'] = Elements::get_for_event($id);
        $event['participants'] = Elements::get_participants($id);
        $event['total_duration'] = Elements::get_total_duration($id);

        return new \WP_REST_Response($event, 200);
    }

    /**
     * POST /event
     */
    public static function create_event(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;

        $data = [
            'event_title'      => sanitize_text_field($request->get_param('event_title') ?? ''),
            'event_date'       => sanitize_text_field($request->get_param('event_date') ?? ''),
            'event_type'       => sanitize_text_field($request->get_param('event_type') ?? 'hochamt'),
            'status'           => 'entwurf',
            'location_default' => sanitize_text_field($request->get_param('location_default') ?? ''),
            'post_id'          => (int) ($request->get_param('post_id') ?? 0),
            'notes'            => wp_kses_post($request->get_param('notes') ?? ''),
            'created_by'       => get_current_user_id(),
        ];

        if (empty($data['event_title']) || empty($data['event_date'])) {
            return new \WP_REST_Response(['message' => 'Titel und Datum sind Pflichtfelder'], 400);
        }

        $wpdb->insert($wpdb->prefix . 'liturgia_events', $data);
        $id = (int) $wpdb->insert_id;

        return new \WP_REST_Response(['id' => $id, 'message' => 'Event erstellt'], 201);
    }

    /**
     * PUT /event/{id}
     */
    public static function update_event(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $id = (int) $request->get_param('id');

        $data = [];
        $allowed = ['event_title', 'event_date', 'event_type', 'status', 'location_default', 'post_id', 'notes'];

        foreach ($allowed as $field) {
            $val = $request->get_param($field);
            if ($val !== null) {
                if ($field === 'notes') {
                    $data[$field] = wp_kses_post($val);
                } elseif ($field === 'post_id') {
                    $data[$field] = (int) $val;
                } else {
                    $data[$field] = sanitize_text_field($val);
                }
            }
        }

        if (empty($data)) {
            return new \WP_REST_Response(['message' => 'Keine Daten zum Aktualisieren'], 400);
        }

        $wpdb->update($wpdb->prefix . 'liturgia_events', $data, ['id' => $id]);

        return new \WP_REST_Response(['message' => 'Event aktualisiert'], 200);
    }

    /**
     * GET /overrides/{date}
     *
     * Liefert Cantus-Overrides für ein bestimmtes Datum.
     * Cantus fragt hier nach, ob Liturgia für den Tag Lieder festgelegt hat.
     */
    public static function get_overrides(\WP_REST_Request $request): \WP_REST_Response {
        $date = sanitize_text_field($request->get_param('date'));

        return new \WP_REST_Response(
            Integration::get_cantus_overrides($date),
            200
        );
    }

    /**
     * GET /readings/{date}
     *
     * Liefert Lesungs-Overrides für ein bestimmtes Datum.
     * Tagesplan fragt hier nach, ob Liturgia Lesungen festgelegt hat.
     */
    public static function get_readings(\WP_REST_Request $request): \WP_REST_Response {
        $date = sanitize_text_field($request->get_param('date'));

        return new \WP_REST_Response(
            Integration::get_reading_overrides($date),
            200
        );
    }

    /**
     * GET /event/{id}/pdf
     */
    public static function get_pdf(\WP_REST_Request $request): void {
        $id = (int) $request->get_param('id');
        PDF::generate($id);
        exit;
    }

    /**
     * GET /event/{id}/print
     */
    public static function get_print(\WP_REST_Request $request): void {
        $id = (int) $request->get_param('id');
        PrintView::render($id);
        exit;
    }

    /**
     * POST /event/{id}/sync
     *
     * Manueller Sync: Schreibt Cantus-Lieder und Liturgus-Dienstplan-Zuweisungen.
     */
    public static function sync_event(\WP_REST_Request $request): \WP_REST_Response {
        $id = (int) $request->get_param('id');

        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$event) {
            return new \WP_REST_Response(['message' => 'Event nicht gefunden'], 404);
        }

        $result = Integration::sync_all($id);

        return new \WP_REST_Response([
            'message'  => 'Sync abgeschlossen',
            'cantus'   => $result['cantus'],
            'liturgus' => $result['liturgus'],
        ], 200);
    }
}
