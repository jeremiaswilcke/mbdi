<?php
/**
 * Liturgia Database
 *
 * Schema-Definition und Installation der DB-Tabellen
 * für das Liturgia-Modul (Gottesdienst-Detailplanung).
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Database {

    /** @var string DB-Version für Upgrades */
    const DB_VERSION = '2.0.0';

    /**
     * Tabellen anlegen (bei Plugin-Aktivierung)
     */
    public static function activate(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $events_table = $wpdb->prefix . 'liturgia_events';
        $elements_table = $wpdb->prefix . 'liturgia_elements';
        $email_log_table = $wpdb->prefix . 'liturgia_email_log';
        $templates_table = $wpdb->prefix . 'liturgia_templates';
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // === Events ===
        $sql_events = "CREATE TABLE {$events_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED DEFAULT 0,
            event_date DATE NOT NULL,
            event_title VARCHAR(255) NOT NULL DEFAULT '',
            event_type VARCHAR(30) NOT NULL DEFAULT 'hochamt',
            status VARCHAR(20) NOT NULL DEFAULT 'entwurf',
            location_default VARCHAR(255) NOT NULL DEFAULT '',
            notes LONGTEXT,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_event_date (event_date),
            KEY idx_status (status),
            KEY idx_post_id (post_id)
        ) {$charset};";

        dbDelta($sql_events);

        // === Elements ===
        $sql_elements = "CREATE TABLE {$elements_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id BIGINT UNSIGNED NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            element_type VARCHAR(40) NOT NULL DEFAULT 'sonstiges',
            title VARCHAR(255) NOT NULL DEFAULT '',
            description LONGTEXT,
            responsible_role VARCHAR(40) NOT NULL DEFAULT 'sonstige',
            responsible_person VARCHAR(255) NOT NULL DEFAULT '',
            location VARCHAR(255) NOT NULL DEFAULT '',
            duration_minutes INT UNSIGNED DEFAULT NULL,
            cantus_override TINYINT(1) NOT NULL DEFAULT 0,
            cantus_song_id BIGINT UNSIGNED DEFAULT NULL,
            cantus_song_type VARCHAR(10) NOT NULL DEFAULT 'gl',
            cantus_song_strophes VARCHAR(100) NOT NULL DEFAULT '',
            reading_override TINYINT(1) NOT NULL DEFAULT 0,
            reading_reference VARCHAR(255) NOT NULL DEFAULT '',
            reading_text LONGTEXT,
            hymnal_number VARCHAR(50) NOT NULL DEFAULT '',
            media_notes LONGTEXT,
            PRIMARY KEY (id),
            KEY idx_event_id (event_id),
            KEY idx_sort_order (event_id, sort_order)
        ) {$charset};";

        dbDelta($sql_elements);

        // === Element-Personen (Junction: n:m Element <-> User) ===
        $sql_persons = "CREATE TABLE {$persons_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            element_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            person_name VARCHAR(255) NOT NULL DEFAULT '',
            role VARCHAR(40) NOT NULL DEFAULT 'sonstige',
            sort_order TINYINT NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_element (element_id),
            KEY idx_user (user_id),
            UNIQUE KEY unique_assignment (element_id, user_id, role)
        ) {$charset};";

        dbDelta($sql_persons);

        // === E-Mail-Log ===
        $sql_email_log = "CREATE TABLE {$email_log_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id BIGINT UNSIGNED NOT NULL,
            recipients TEXT NOT NULL,
            subject VARCHAR(255) NOT NULL DEFAULT '',
            sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) NOT NULL DEFAULT 'success',
            error_message TEXT,
            PRIMARY KEY (id),
            KEY idx_event_id (event_id)
        ) {$charset};";

        dbDelta($sql_email_log);

        // === Vorlagen ===
        $sql_templates = "CREATE TABLE {$templates_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL DEFAULT '',
            description TEXT,
            event_type VARCHAR(30) NOT NULL DEFAULT 'hochamt',
            elements_json LONGTEXT NOT NULL,
            is_default TINYINT(1) NOT NULL DEFAULT 0,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$charset};";

        dbDelta($sql_templates);

        // Standard-Vorlage „Normales Sonntagshochamt" installieren
        self::install_default_templates();

        // Migration von v1 → v2
        self::maybe_migrate();

        update_option('liturgia_db_version', self::DB_VERSION);
    }

    /**
     * Migration: responsible_person → liturgia_element_persons
     *
     * Kopiert bestehende Freitext-Personenzuweisungen in die neue Junction-Tabelle.
     */
    private static function maybe_migrate(): void {
        global $wpdb;

        $current_version = get_option('liturgia_db_version', '0');
        if (version_compare($current_version, '2.0.0', '>=')) {
            return;
        }

        $elements_table = $wpdb->prefix . 'liturgia_elements';
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';

        // Alle Elemente mit gesetzter responsible_person migrieren
        $elements = $wpdb->get_results(
            "SELECT id, responsible_role, responsible_person FROM {$elements_table} WHERE responsible_person != ''",
            ARRAY_A
        );

        if (empty($elements)) {
            return;
        }

        foreach ($elements as $el) {
            // Prüfen ob schon migriert
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$persons_table} WHERE element_id = %d",
                $el['id']
            ));

            if ($exists > 0) {
                continue;
            }

            // Person als Freitext-Eintrag in Junction-Tabelle übernehmen
            $wpdb->insert($persons_table, [
                'element_id'  => (int) $el['id'],
                'user_id'     => 0,
                'person_name' => $el['responsible_person'],
                'role'        => $el['responsible_role'] ?: 'sonstige',
                'sort_order'  => 0,
            ]);
        }
    }

    /**
     * Tabellen löschen (Deinstallation)
     */
    public static function uninstall(): void {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}liturgia_element_persons");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}liturgia_email_log");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}liturgia_elements");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}liturgia_templates");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}liturgia_events");
        delete_option('liturgia_db_version');
        delete_option('liturgia_settings');
    }

    /**
     * Standard-Vorlagen installieren (einmalig)
     */
    private static function install_default_templates(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_templates';

        $exists = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE is_default = 1");
        if ($exists > 0) {
            return;
        }

        $default_elements = [
            ['sort_order' => 1,  'element_type' => 'einzug',              'title' => 'Einzug',                'responsible_role' => 'priester'],
            ['sort_order' => 2,  'element_type' => 'lied',                'title' => 'Eröffnungslied',        'responsible_role' => 'gemeinde'],
            ['sort_order' => 3,  'element_type' => 'kyrie',               'title' => 'Kyrie',                 'responsible_role' => 'priester'],
            ['sort_order' => 4,  'element_type' => 'gloria',              'title' => 'Gloria',                'responsible_role' => 'gemeinde'],
            ['sort_order' => 5,  'element_type' => 'lesung',              'title' => 'Erste Lesung',          'responsible_role' => 'lektor'],
            ['sort_order' => 6,  'element_type' => 'antwortpsalm',        'title' => 'Antwortpsalm',          'responsible_role' => 'kantor'],
            ['sort_order' => 7,  'element_type' => 'lesung',              'title' => 'Zweite Lesung',         'responsible_role' => 'lektor'],
            ['sort_order' => 8,  'element_type' => 'ruf_vor_evangelium',   'title' => 'Ruf vor dem Evangelium','responsible_role' => 'kantor'],
            ['sort_order' => 9,  'element_type' => 'evangelium',           'title' => 'Evangelium',            'responsible_role' => 'priester'],
            ['sort_order' => 10, 'element_type' => 'predigt',             'title' => 'Predigt',               'responsible_role' => 'priester'],
            ['sort_order' => 11, 'element_type' => 'fuerbitten',          'title' => 'Fürbitten',             'responsible_role' => 'lektor'],
            ['sort_order' => 12, 'element_type' => 'gabenbereitung',      'title' => 'Gabenbereitung',        'responsible_role' => 'messdiener'],
            ['sort_order' => 13, 'element_type' => 'lied',                'title' => 'Gabenlied',             'responsible_role' => 'gemeinde'],
            ['sort_order' => 14, 'element_type' => 'sanctus',             'title' => 'Sanctus',               'responsible_role' => 'gemeinde'],
            ['sort_order' => 15, 'element_type' => 'hochgebet',           'title' => 'Hochgebet',             'responsible_role' => 'priester'],
            ['sort_order' => 16, 'element_type' => 'vaterunser',          'title' => 'Vaterunser',            'responsible_role' => 'gemeinde'],
            ['sort_order' => 17, 'element_type' => 'friedensgruss',       'title' => 'Friedensgruß',          'responsible_role' => 'gemeinde'],
            ['sort_order' => 18, 'element_type' => 'agnus_dei',           'title' => 'Agnus Dei',             'responsible_role' => 'gemeinde'],
            ['sort_order' => 19, 'element_type' => 'kommunion',           'title' => 'Kommunion',             'responsible_role' => 'priester'],
            ['sort_order' => 20, 'element_type' => 'lied',                'title' => 'Danklied',              'responsible_role' => 'gemeinde'],
            ['sort_order' => 21, 'element_type' => 'schlussgebet',        'title' => 'Schlussgebet',          'responsible_role' => 'priester'],
            ['sort_order' => 22, 'element_type' => 'segen',               'title' => 'Segen & Entlassung',   'responsible_role' => 'priester'],
            ['sort_order' => 23, 'element_type' => 'auszug',              'title' => 'Auszug',                'responsible_role' => 'priester'],
            ['sort_order' => 24, 'element_type' => 'lied',                'title' => 'Schlusslied',           'responsible_role' => 'gemeinde'],
        ];

        $wpdb->insert($table, [
            'title'         => 'Normales Sonntagshochamt',
            'description'   => 'Standard-Ablauf für ein sonntägliches Hochamt mit allen liturgischen Elementen.',
            'event_type'    => 'hochamt',
            'elements_json' => wp_json_encode($default_elements),
            'is_default'    => 1,
            'created_by'    => 0,
        ]);
    }

    /**
     * Alle Event-Typen mit Labels
     */
    public static function get_event_types(): array {
        return [
            'hochamt'            => 'Hochamt',
            'wortgottesdienst'   => 'Wortgottesdienst',
            'andacht'            => 'Andacht',
            'prozession'         => 'Prozession',
            'sonderform'         => 'Sonderform',
        ];
    }

    /**
     * Alle Status-Werte mit Labels + Farben
     */
    public static function get_statuses(): array {
        return [
            'entwurf'        => ['label' => 'Entwurf',         'color' => '#6b7280', 'bg' => '#f3f4f6'],
            'in_abstimmung'  => ['label' => 'In Abstimmung',   'color' => '#d97706', 'bg' => '#fef3c7'],
            'freigegeben'    => ['label' => 'Freigegeben',     'color' => '#059669', 'bg' => '#d1fae5'],
            'abgeschlossen'  => ['label' => 'Abgeschlossen',   'color' => '#2563eb', 'bg' => '#dbeafe'],
        ];
    }

    /**
     * Alle Element-Typen mit Labels
     */
    public static function get_element_types(): array {
        return [
            'einzug'              => 'Einzug',
            'kyrie'               => 'Kyrie',
            'gloria'              => 'Gloria',
            'lesung'              => 'Lesung',
            'antwortpsalm'        => 'Antwortpsalm',
            'ruf_vor_evangelium'   => 'Ruf vor dem Evangelium',
            'evangelium'           => 'Evangelium',
            'predigt'              => 'Predigt',
            'fuerbitten'           => 'Fürbitten',
            'gabenbereitung'       => 'Gabenbereitung',
            'sanctus'              => 'Sanctus',
            'hochgebet'            => 'Hochgebet',
            'vaterunser'           => 'Vaterunser',
            'friedensgruss'        => 'Friedensgruß',
            'agnus_dei'            => 'Agnus Dei',
            'kommunion'            => 'Kommunion',
            'schlussgebet'         => 'Schlussgebet',
            'segen'                => 'Segen',
            'auszug'               => 'Auszug',
            'lied'                 => 'Lied',
            'sonstiges'            => 'Sonstiges',
        ];
    }

    /**
     * Alle Rollen mit Labels
     */
    public static function get_roles(): array {
        return [
            'priester'       => 'Priester',
            'diakon'         => 'Diakon',
            'lektor'         => 'Lektor/in',
            'kantor'         => 'Kantor/in',
            'chor'           => 'Chor',
            'organist'       => 'Organist/in',
            'messdiener'     => 'Messdiener/in',
            'gemeinde'       => 'Gemeinde',
            'liturgiegruppe' => 'Liturgiegruppe',
            'sonstige'       => 'Sonstige',
        ];
    }

    /**
     * Vordefinierte Orte
     */
    public static function get_locations(): array {
        return [
            'Altar',
            'Ambo',
            'Hauptschiff',
            'Taufbecken',
            'Kirchenvorplatz',
            'Sakristei',
            'Empore',
            'Prozessionsweg',
            'Seitenaltar',
        ];
    }
}
