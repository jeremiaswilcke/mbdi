<?php
/**
 * Liturgia Elements
 *
 * CRUD-Operationen für Liturgie-Elemente eines Events.
 * v2: Multi-User-Zuweisungen via Junction-Tabelle,
 *     Cantus- und Liturgus-Sync.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Elements {

    /**
     * Alle Elemente eines Events laden (sortiert) inkl. Personen
     */
    public static function get_for_event(int $event_id): array {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        $elements = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE event_id = %d ORDER BY sort_order ASC, id ASC",
                $event_id
            ),
            ARRAY_A
        ) ?: [];

        if (empty($elements)) {
            return [];
        }

        // Personen für alle Elemente in einem Query laden
        $element_ids = array_column($elements, 'id');
        $persons_by_element = self::get_persons_for_elements($element_ids);

        // Personen an Elemente anhängen
        foreach ($elements as &$el) {
            $el['persons'] = $persons_by_element[(int) $el['id']] ?? [];
        }
        unset($el);

        return $elements;
    }

    /**
     * Einzelnes Element laden (inkl. Personen)
     */
    public static function get(int $id): ?array {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        $row['persons'] = self::get_persons($id);
        return $row;
    }

    /**
     * Element erstellen
     */
    public static function create(array $data): int {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        // Personen separat behandeln
        $persons = $data['persons'] ?? [];
        unset($data['persons']);

        // Nächste sort_order ermitteln
        if (empty($data['sort_order'])) {
            $max = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT MAX(sort_order) FROM {$table} WHERE event_id = %d",
                $data['event_id']
            ));
            $data['sort_order'] = $max + 1;
        }

        $wpdb->insert($table, self::sanitize($data));
        $element_id = (int) $wpdb->insert_id;

        // Personen speichern
        if (!empty($persons) && $element_id > 0) {
            self::save_persons($element_id, $persons);
        }

        return $element_id;
    }

    /**
     * Element aktualisieren
     */
    public static function update(int $id, array $data): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        // Personen separat behandeln
        $persons = null;
        if (array_key_exists('persons', $data)) {
            $persons = $data['persons'];
            unset($data['persons']);
        }

        unset($data['id'], $data['event_id']); // nicht änderbar

        $result = $wpdb->update($table, self::sanitize($data), ['id' => $id], null, ['%d']);

        // Personen aktualisieren wenn mitgesendet
        if ($persons !== null) {
            self::save_persons($id, $persons);
        }

        return $result !== false;
    }

    /**
     * Element löschen (inkl. Personen)
     */
    public static function delete(int $id): bool {
        global $wpdb;

        // Zuerst Personen löschen
        $wpdb->delete(
            $wpdb->prefix . 'liturgia_element_persons',
            ['element_id' => $id],
            ['%d']
        );

        return $wpdb->delete(
            $wpdb->prefix . 'liturgia_elements',
            ['id' => $id],
            ['%d']
        ) !== false;
    }

    /**
     * Alle Elemente eines Events löschen (inkl. Personen)
     */
    public static function delete_for_event(int $event_id): bool {
        global $wpdb;
        $elements_table = $wpdb->prefix . 'liturgia_elements';
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';

        // Element-IDs sammeln
        $element_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$elements_table} WHERE event_id = %d",
            $event_id
        ));

        // Personen aller Elemente löschen
        if (!empty($element_ids)) {
            $placeholders = implode(',', array_fill(0, count($element_ids), '%d'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$persons_table} WHERE element_id IN ({$placeholders})",
                ...$element_ids
            ));
        }

        return $wpdb->delete($elements_table, ['event_id' => $event_id], ['%d']) !== false;
    }

    /**
     * Reihenfolge aktualisieren (Drag&Drop)
     *
     * @param int   $event_id
     * @param int[] $element_ids  IDs in gewünschter Reihenfolge
     */
    public static function reorder(int $event_id, array $element_ids): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        foreach ($element_ids as $order => $id) {
            $wpdb->update(
                $table,
                ['sort_order' => $order + 1],
                ['id' => (int) $id, 'event_id' => $event_id],
                ['%d'],
                ['%d', '%d']
            );
        }

        return true;
    }

    /**
     * Elemente aus Vorlagen-JSON erstellen
     *
     * @param int   $event_id
     * @param array $template_elements  Decoded JSON aus liturgia_templates
     */
    public static function create_from_template(int $event_id, array $template_elements): int {
        $count = 0;
        foreach ($template_elements as $el) {
            self::create([
                'event_id'         => $event_id,
                'sort_order'       => $el['sort_order'] ?? ($count + 1),
                'element_type'     => $el['element_type'] ?? 'sonstiges',
                'title'            => $el['title'] ?? '',
                'responsible_role' => $el['responsible_role'] ?? 'sonstige',
                'location'         => $el['location'] ?? '',
                'description'      => $el['description'] ?? '',
            ]);
            $count++;
        }
        return $count;
    }

    // =========================================================================
    // PERSONEN-VERWALTUNG (Junction-Tabelle)
    // =========================================================================

    /**
     * Personen eines Elements laden
     *
     * @return array[] [['id' => .., 'user_id' => .., 'person_name' => .., 'display_name' => .., 'role' => ..], ...]
     */
    public static function get_persons(int $element_id): array {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_element_persons';

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE element_id = %d ORDER BY sort_order ASC, id ASC",
            $element_id
        ), ARRAY_A) ?: [];

        return self::enrich_persons($rows);
    }

    /**
     * Personen für mehrere Elemente laden (Batch)
     *
     * @param int[] $element_ids
     * @return array<int, array[]> element_id => persons[]
     */
    public static function get_persons_for_elements(array $element_ids): array {
        if (empty($element_ids)) {
            return [];
        }

        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_element_persons';

        $placeholders = implode(',', array_fill(0, count($element_ids), '%d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE element_id IN ({$placeholders}) ORDER BY sort_order ASC, id ASC",
            ...$element_ids
        ), ARRAY_A) ?: [];

        $enriched = self::enrich_persons($rows);

        $grouped = [];
        foreach ($enriched as $row) {
            $grouped[(int) $row['element_id']][] = $row;
        }

        return $grouped;
    }

    /**
     * Personen eines Elements speichern (Delete + Re-Insert)
     *
     * @param array[] $persons [['user_id' => int, 'person_name' => string, 'role' => string], ...]
     */
    public static function save_persons(int $element_id, array $persons): void {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_element_persons';

        // Alte Einträge löschen
        $wpdb->delete($table, ['element_id' => $element_id], ['%d']);

        // Neue Einträge einfügen
        foreach ($persons as $order => $person) {
            $user_id = (int) ($person['user_id'] ?? 0);
            $person_name = sanitize_text_field($person['person_name'] ?? '');
            $role = sanitize_text_field($person['role'] ?? 'sonstige');

            // Mindestens user_id oder person_name muss gesetzt sein
            if ($user_id === 0 && $person_name === '') {
                continue;
            }

            $wpdb->insert($table, [
                'element_id'  => $element_id,
                'user_id'     => $user_id,
                'person_name' => $person_name,
                'role'        => $role,
                'sort_order'  => $order,
            ]);
        }
    }

    /**
     * Personen-Rows mit WP-User-Daten anreichern
     */
    private static function enrich_persons(array $rows): array {
        if (empty($rows)) {
            return [];
        }

        // Alle user_ids sammeln
        $user_ids = array_unique(array_filter(array_column($rows, 'user_id')));
        $user_map = [];

        if (!empty($user_ids)) {
            $users = get_users(['include' => $user_ids, 'fields' => ['ID', 'display_name', 'user_email']]);
            foreach ($users as $user) {
                $user_map[(int) $user->ID] = [
                    'display_name' => $user->display_name,
                    'user_email'   => $user->user_email,
                ];
            }
        }

        foreach ($rows as &$row) {
            $uid = (int) $row['user_id'];
            if ($uid > 0 && isset($user_map[$uid])) {
                $row['display_name'] = $user_map[$uid]['display_name'];
                $row['user_email'] = $user_map[$uid]['user_email'];
            } else {
                $row['display_name'] = $row['person_name'] ?: '(Unbekannt)';
                $row['user_email'] = '';
            }
        }
        unset($row);

        return $rows;
    }

    /**
     * Beteiligte Personen eines Events ermitteln (aus Junction-Tabelle)
     *
     * @return array<string, array[]>  role_label => [['display_name' => .., 'user_id' => ..], ...]
     */
    public static function get_participants(int $event_id): array {
        global $wpdb;
        $elements_table = $wpdb->prefix . 'liturgia_elements';
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, el.element_type
             FROM {$persons_table} p
             JOIN {$elements_table} el ON p.element_id = el.id
             WHERE el.event_id = %d
             ORDER BY p.role ASC, p.sort_order ASC",
            $event_id
        ), ARRAY_A) ?: [];

        $enriched = self::enrich_persons($rows);
        $roles = Database::get_roles();
        $participants = [];

        foreach ($enriched as $row) {
            $role_key = $row['role'];
            $role_label = $roles[$role_key] ?? $role_key;
            $participants[$role_label][] = [
                'display_name' => $row['display_name'],
                'user_id'      => (int) $row['user_id'],
                'user_email'   => $row['user_email'] ?? '',
            ];
        }

        // Duplikate entfernen (gleicher User + gleiche Rolle)
        foreach ($participants as &$persons) {
            $seen = [];
            $unique = [];
            foreach ($persons as $p) {
                $key = ($p['user_id'] > 0) ? "u{$p['user_id']}" : "n{$p['display_name']}";
                if (!isset($seen[$key])) {
                    $seen[$key] = true;
                    $unique[] = $p;
                }
            }
            $persons = $unique;
        }
        unset($persons);

        return $participants;
    }

    /**
     * Geschätzte Gesamtdauer berechnen (Minuten)
     */
    public static function get_total_duration(int $event_id): int {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_elements';

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(duration_minutes), 0) FROM {$table} WHERE event_id = %d",
            $event_id
        ));
    }

    /**
     * Daten sanitisieren
     */
    private static function sanitize(array $data): array {
        $clean = [];

        $int_fields = ['event_id', 'sort_order', 'duration_minutes', 'cantus_song_id', 'cantus_override', 'reading_override'];
        $text_fields = ['element_type', 'title', 'responsible_role', 'responsible_person', 'location', 'reading_reference', 'hymnal_number', 'cantus_song_type', 'cantus_song_strophes'];
        $html_fields = ['description', 'reading_text', 'media_notes'];

        foreach ($int_fields as $field) {
            if (array_key_exists($field, $data)) {
                $clean[$field] = ($data[$field] === null || $data[$field] === '') ? null : (int) $data[$field];
            }
        }

        foreach ($text_fields as $field) {
            if (array_key_exists($field, $data)) {
                $clean[$field] = sanitize_text_field($data[$field] ?? '');
            }
        }

        foreach ($html_fields as $field) {
            if (array_key_exists($field, $data)) {
                $clean[$field] = wp_kses_post($data[$field] ?? '');
            }
        }

        return $clean;
    }
}
