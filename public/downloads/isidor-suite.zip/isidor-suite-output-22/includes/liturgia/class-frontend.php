<?php
/**
 * Liturgia Frontend
 *
 * Shortcode [liturgia_planner] fuer die Frontend-Ansicht
 * der Gottesdienst-Planung. Read-only fuer Mitwirkende.
 *
 * @package IsidorSuite\Liturgia
 * @since 2.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Frontend {

    public static function init(): void {
        add_shortcode('liturgia_planner', [self::class, 'render_shortcode']);
        add_action('wp_enqueue_scripts', [self::class, 'maybe_enqueue_assets']);

        // AJAX for frontend (logged-in users)
        add_action('wp_ajax_liturgia_frontend_get_events', [self::class, 'ajax_get_events']);
        add_action('wp_ajax_liturgia_frontend_get_event_detail', [self::class, 'ajax_get_event_detail']);
    }

    public static function maybe_enqueue_assets(): void {
        // Only load on pages with our shortcode
        global $post;
        if (!$post || !has_shortcode($post->post_content, 'liturgia_planner')) return;

        wp_enqueue_style(
            'liturgia-frontend',
            ISIDOR_SUITE_URL . 'assets/css/liturgia-frontend.css',
            [],
            ISIDOR_LITURGIA_VERSION
        );
        wp_enqueue_script(
            'liturgia-frontend',
            ISIDOR_SUITE_URL . 'assets/js/liturgia-frontend.js',
            ['jquery'],
            ISIDOR_LITURGIA_VERSION,
            true
        );
        wp_localize_script('liturgia-frontend', 'liturgiaFrontend', [
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('liturgia_frontend_nonce'),
            'canPlan'   => current_user_can('isidor_liturgia_plan') ? '1' : '0',
            'canManage' => current_user_can('isidor_liturgia_manage') ? '1' : '0',
        ]);
    }

    public static function render_shortcode($atts): string {
        if (!is_user_logged_in()) {
            return '<p class="liturgia-login-required">Bitte einloggen um die Liturgia-Planung zu sehen.</p>';
        }

        if (!current_user_can('isidor_liturgia_view') && !current_user_can('manage_options')) {
            return '<p class="liturgia-no-permission">Keine Berechtigung f&uuml;r Liturgia.</p>';
        }

        ob_start();
        ?>
        <div class="liturgia-app" id="liturgia-frontend-app">
            <div class="liturgia-app-header">
                <h2>Liturgia &ndash; Gottesdienst-Planung</h2>
            </div>

            <!-- Event List View -->
            <div id="liturgia-fe-list" class="liturgia-fe-view">
                <div class="liturgia-fe-filters">
                    <select id="liturgia-fe-filter-period">
                        <option value="upcoming">Kommende</option>
                        <option value="all">Alle</option>
                        <option value="past">Vergangene</option>
                    </select>
                    <select id="liturgia-fe-filter-status">
                        <option value="">Alle Status</option>
                        <option value="entwurf">Entwurf</option>
                        <option value="in_abstimmung">In Abstimmung</option>
                        <option value="freigegeben">Freigegeben</option>
                        <option value="abgeschlossen">Abgeschlossen</option>
                    </select>
                </div>
                <div id="liturgia-fe-events" class="liturgia-fe-events-list">
                    <div class="liturgia-fe-loading">Wird geladen...</div>
                </div>
            </div>

            <!-- Event Detail View -->
            <div id="liturgia-fe-detail" class="liturgia-fe-view" style="display:none;">
                <button type="button" class="liturgia-fe-back" id="liturgia-fe-back">&larr; Zur&uuml;ck</button>
                <div id="liturgia-fe-detail-content"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // AJAX: Events list for frontend
    // =========================================================================

    public static function ajax_get_events(): void {
        check_ajax_referer('liturgia_frontend_nonce', '_wpnonce');

        if (!current_user_can('isidor_liturgia_view') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        global $wpdb;
        $table    = $wpdb->prefix . 'liturgia_events';
        $el_table = $wpdb->prefix . 'liturgia_elements';

        $where  = ['1=1'];
        $params = [];

        $period = sanitize_text_field($_POST['period'] ?? 'upcoming');
        $today  = current_time('Y-m-d');

        if ($period === 'upcoming') {
            $where[]  = 'e.event_date >= %s';
            $params[] = $today;
        } elseif ($period === 'past') {
            $where[]  = 'e.event_date < %s';
            $params[] = $today;
        }

        $status = sanitize_text_field($_POST['status'] ?? '');
        if ($status !== '') {
            $where[]  = 'e.status = %s';
            $params[] = $status;
        }

        $where_sql = implode(' AND ', $where);
        $order     = $period === 'past' ? 'DESC' : 'ASC';

        $query = "SELECT e.*, (SELECT COUNT(*) FROM {$el_table} el WHERE el.event_id = e.id) AS element_count
                  FROM {$table} e WHERE {$where_sql} ORDER BY e.event_date {$order} LIMIT 50";

        if (!empty($params)) {
            $query = $wpdb->prepare($query, ...$params);
        }

        $events = $wpdb->get_results($query, ARRAY_A) ?: [];

        // Add status labels + event type labels
        $statuses    = Database::get_statuses();
        $event_types = Database::get_event_types();

        foreach ($events as &$ev) {
            $ev['status_label'] = $statuses[$ev['status']]['label'] ?? $ev['status'];
            $ev['status_color'] = $statuses[$ev['status']]['color'] ?? '#666';
            $ev['status_bg']    = $statuses[$ev['status']]['bg']    ?? '#f3f4f6';
            $ev['type_label']   = $event_types[$ev['event_type']]   ?? $ev['event_type'];
            $ev['date_formatted'] = date_i18n('l, j. F Y', strtotime($ev['event_date']));
        }
        unset($ev);

        wp_send_json_success(['events' => $events]);
    }

    // =========================================================================
    // AJAX: Event detail for frontend
    // =========================================================================

    public static function ajax_get_event_detail(): void {
        check_ajax_referer('liturgia_frontend_nonce', '_wpnonce');

        if (!current_user_can('isidor_liturgia_view') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $id = (int) ($_POST['event_id'] ?? 0);

        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d", $id
        ), ARRAY_A);

        if (!$event) {
            wp_send_json_error(['message' => 'Event nicht gefunden']);
        }

        $elements       = Elements::get_for_event($id);
        $participants    = Elements::get_participants($id);
        $total_duration  = Elements::get_total_duration($id);

        $statuses          = Database::get_statuses();
        $event_types       = Database::get_event_types();
        $element_types_map = Database::get_element_types();

        $event['status_label'] = $statuses[$event['status']]['label'] ?? $event['status'];
        $event['status_color'] = $statuses[$event['status']]['color'] ?? '#666';
        $event['status_bg']    = $statuses[$event['status']]['bg']    ?? '#f3f4f6';
        $event['type_label']   = $event_types[$event['event_type']]   ?? $event['event_type'];
        $event['date_formatted'] = date_i18n('l, j. F Y', strtotime($event['event_date']));

        // Enrich elements with type labels
        foreach ($elements as &$el) {
            $el['type_label'] = $element_types_map[$el['element_type']] ?? $el['element_type'];
        }
        unset($el);

        // Flatten participants for JSON
        $flat_participants = [];
        foreach ($participants as $role => $persons) {
            $names = array_map(function ($p) {
                return $p['display_name'];
            }, $persons);
            $flat_participants[] = ['role' => $role, 'names' => $names];
        }

        wp_send_json_success([
            'event'          => $event,
            'elements'       => $elements,
            'participants'   => $flat_participants,
            'total_duration' => $total_duration,
        ]);
    }
}
