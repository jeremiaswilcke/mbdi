<?php
/**
 * Liturgia Integration
 *
 * Override-Logik: Liturgia-Einträge überschreiben Cantus-Lieder,
 * Tagesplan-Lesungen und Liturgus-Dienstplan wenn die Flags gesetzt sind.
 *
 * v2: Direkte Schreibzugriffe auf Cantus & Liturgus DB.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Integration {

    // =========================================================================
    // CANTUS SLOT-MAPPING
    // Liturgia-Element-Typ → Cantus slot_key (1-11)
    // =========================================================================
    private const CANTUS_SLOT_MAP = [
        'einzug'             => 1,
        'kyrie'              => 2,
        'gloria'             => 3,
        'antwortpsalm'       => 4,
        'ruf_vor_evangelium'  => 5,
        'gabenbereitung'     => 6,
        'sanctus'            => 7,
        'agnus_dei'          => 8,
        'kommunion'          => 9,
    ];

    // Lied-Titel-basiertes Mapping für Slot 10+11
    private const CANTUS_TITLE_SLOT_MAP = [
        'Danklied'    => 10,
        'Schlusslied' => 11,
    ];

    // =========================================================================
    // LITURGUS SLOT-MAPPING
    // Liturgia-Rolle → Liturgus slot_key
    // =========================================================================
    private const LITURGUS_SLOT_MAP = [
        'lektor'     => 'lektor',
        'kantor'     => 'kantor',
        'messdiener' => 'messdiener',
        'organist'   => 'organist',
        'chor'       => 'chor',
    ];

    /**
     * Hooks registrieren
     */
    public static function init(): void {
        // Cantus: Beim Laden der Lieder prüfen ob Override existiert
        add_filter('isidor_cantus_songs_for_date', [self::class, 'filter_cantus_songs'], 10, 2);

        // Tagesplan: Beim Laden der Lesungen prüfen ob Override existiert
        add_filter('isidor_tagesplan_readings_for_date', [self::class, 'filter_tagesplan_readings'], 10, 2);

        // Tagesplan: Beim Laden der Dienste prüfen ob Override existiert
        add_filter('isidor_tagesplan_dienste', [self::class, 'filter_tagesplan_dienste'], 10, 2);
    }

    // =========================================================================
    // CANTUS SYNC (Liturgia → Cantus DB)
    // =========================================================================

    /**
     * Alle Lieder eines Events in Cantus DB schreiben
     *
     * Wird aufgerufen beim Speichern eines Elements oder Status-Wechsel.
     * Nur bei Status freigegeben/abgeschlossen.
     */
    public static function sync_to_cantus(int $event_id): bool {
        global $wpdb;

        // Event laden
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event || !in_array($event['status'], ['freigegeben', 'abgeschlossen'])) {
            return false;
        }

        $messe_id = (int) $event['post_id'];
        if ($messe_id <= 0) {
            return false; // Kein verknüpfter Messe-Post
        }

        // Cantus_DB verfügbar?
        if (!class_exists('Cantus_DB')) {
            return false;
        }

        // Alle Lied-Elemente mit cantus_override holen
        $elements = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_elements
             WHERE event_id = %d AND cantus_override = 1
             ORDER BY sort_order ASC",
            $event_id
        ), ARRAY_A) ?: [];

        $user_id = get_current_user_id() ?: (int) $event['created_by'];

        foreach ($elements as $el) {
            $slot_key = self::resolve_cantus_slot($el);
            if ($slot_key === null) {
                continue;
            }

            $song_type = $el['cantus_song_type'] ?: 'gl';
            $data = [
                'type'       => $song_type,
                'number'     => $el['hymnal_number'] ?: '',
                'strophes'   => $el['cantus_song_strophes'] ?: '',
                'free_title' => ($song_type === 'free') ? $el['title'] : '',
            ];

            \Cantus_DB::save_song($messe_id, $slot_key, $data, $user_id);
        }

        return true;
    }

    /**
     * Cantus-Slot für ein Liturgia-Element ermitteln
     */
    private static function resolve_cantus_slot(array $element): ?int {
        $type = $element['element_type'];

        // Direktes Mapping
        if (isset(self::CANTUS_SLOT_MAP[$type])) {
            return self::CANTUS_SLOT_MAP[$type];
        }

        // Titel-basiertes Mapping für generische "Lied"-Elemente
        if ($type === 'lied') {
            $title = trim($element['title']);
            foreach (self::CANTUS_TITLE_SLOT_MAP as $keyword => $slot) {
                if (stripos($title, $keyword) !== false) {
                    return $slot;
                }
            }
            // Eröffnungslied = Einzug-Slot
            if (stripos($title, 'Eröffnung') !== false) {
                return 1;
            }
            // Gabenlied = Gabenbereitung-Slot
            if (stripos($title, 'Gaben') !== false) {
                return 6;
            }
        }

        return null;
    }

    // =========================================================================
    // LITURGUS SYNC (Liturgia → Liturgus Assignments DB)
    // =========================================================================

    /**
     * Personen-Zuweisungen eines Events in Liturgus schreiben
     *
     * Nur mappbare Rollen (lektor, kantor, messdiener, organist, chor).
     * Priester wird NICHT gesyncht.
     */
    public static function sync_to_liturgus(int $event_id): bool {
        global $wpdb;

        // Event laden
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event || !in_array($event['status'], ['freigegeben', 'abgeschlossen'])) {
            return false;
        }

        $messe_id = (int) $event['post_id'];
        if ($messe_id <= 0) {
            return false;
        }

        $assignments_table = $wpdb->prefix . 'liturgus_assignments';

        // Prüfen ob Liturgus-Tabelle existiert
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$assignments_table}'");
        if (!$table_exists) {
            return false;
        }

        // Alle Personen des Events laden, gruppiert nach Rolle
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';
        $elements_table = $wpdb->prefix . 'liturgia_elements';

        $persons = $wpdb->get_results($wpdb->prepare(
            "SELECT p.user_id, p.role, p.sort_order
             FROM {$persons_table} p
             JOIN {$elements_table} el ON p.element_id = el.id
             WHERE el.event_id = %d AND p.user_id > 0
             ORDER BY p.role ASC, p.sort_order ASC",
            $event_id
        ), ARRAY_A) ?: [];

        // Nach Liturgus-Slot gruppieren
        $by_slot = [];
        foreach ($persons as $p) {
            $liturgus_slot = self::LITURGUS_SLOT_MAP[$p['role']] ?? null;
            if ($liturgus_slot === null) {
                continue;
            }
            // Duplikate vermeiden
            if (!isset($by_slot[$liturgus_slot])) {
                $by_slot[$liturgus_slot] = [];
            }
            $uid = (int) $p['user_id'];
            if (!in_array($uid, $by_slot[$liturgus_slot])) {
                $by_slot[$liturgus_slot][] = $uid;
            }
        }

        // Für jeden Slot: bestehende Liturgus-Assignments löschen und neu setzen
        foreach ($by_slot as $slot_key => $user_ids) {
            // Bestehende löschen
            $wpdb->delete($assignments_table, [
                'messe_id' => $messe_id,
                'slot_key' => $slot_key,
            ]);

            // Neue einfügen
            foreach ($user_ids as $position => $uid) {
                $wpdb->insert($assignments_table, [
                    'messe_id'   => $messe_id,
                    'slot_key'   => $slot_key,
                    'position'   => $position + 1,
                    'is_backup'  => 0,
                    'user_id'    => $uid,
                    'status'     => 'assigned',
                    'created_at' => current_time('mysql'),
                ]);
            }
        }

        return true;
    }

    /**
     * Vollständiger Sync: Cantus + Liturgus
     *
     * Aufgerufen bei Status-Wechsel zu 'freigegeben'
     */
    public static function sync_all(int $event_id): array {
        return [
            'cantus'  => self::sync_to_cantus($event_id),
            'liturgus' => self::sync_to_liturgus($event_id),
        ];
    }

    // =========================================================================
    // FILTER-CALLBACKS (Read-Richtung: Andere Module lesen Liturgia-Daten)
    // =========================================================================

    /**
     * Cantus-Overrides für ein Datum liefern
     */
    public static function get_cantus_overrides(string $date): array {
        global $wpdb;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT el.*, ev.event_title, ev.event_date
             FROM {$wpdb->prefix}liturgia_elements el
             JOIN {$wpdb->prefix}liturgia_events ev ON el.event_id = ev.id
             WHERE ev.event_date = %s
               AND el.cantus_override = 1
               AND ev.status IN ('freigegeben', 'abgeschlossen')
             ORDER BY el.sort_order ASC",
            $date
        ), ARRAY_A) ?: [];

        $overrides = [];
        foreach ($results as $row) {
            $overrides[] = [
                'event_id'          => (int) $row['event_id'],
                'event_title'       => $row['event_title'],
                'element_id'        => (int) $row['id'],
                'title'             => $row['title'],
                'hymnal_number'     => $row['hymnal_number'],
                'cantus_song_id'    => $row['cantus_song_id'] ? (int) $row['cantus_song_id'] : null,
                'cantus_song_type'  => $row['cantus_song_type'] ?? 'gl',
                'cantus_song_strophes' => $row['cantus_song_strophes'] ?? '',
                'description'       => $row['description'],
                'sort_order'        => (int) $row['sort_order'],
            ];
        }

        return $overrides;
    }

    /**
     * Lesungs-Overrides für ein Datum liefern
     */
    public static function get_reading_overrides(string $date): array {
        global $wpdb;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT el.*, ev.event_title, ev.event_date
             FROM {$wpdb->prefix}liturgia_elements el
             JOIN {$wpdb->prefix}liturgia_events ev ON el.event_id = ev.id
             WHERE ev.event_date = %s
               AND el.reading_override = 1
               AND el.element_type IN ('lesung', 'evangelium', 'fuerbitten')
               AND ev.status IN ('freigegeben', 'abgeschlossen')
             ORDER BY el.sort_order ASC",
            $date
        ), ARRAY_A) ?: [];

        $overrides = [];
        foreach ($results as $row) {
            // Personen für dieses Element laden (Lektoren)
            $persons = Elements::get_persons((int) $row['id']);
            $person_names = array_map(function($p) { return $p['display_name']; }, $persons);

            $overrides[] = [
                'event_id'          => (int) $row['event_id'],
                'event_title'       => $row['event_title'],
                'element_id'        => (int) $row['id'],
                'element_type'      => $row['element_type'],
                'title'             => $row['title'],
                'reading_reference' => $row['reading_reference'],
                'reading_text'      => $row['reading_text'],
                'sort_order'        => (int) $row['sort_order'],
                'persons'           => $person_names,
            ];
        }

        return $overrides;
    }

    /**
     * Filter: Cantus-Lieder ggf. durch Liturgia-Overrides ersetzen
     */
    public static function filter_cantus_songs(array $songs, string $date): array {
        $overrides = self::get_cantus_overrides($date);

        if (empty($overrides)) {
            return $songs;
        }

        foreach ($overrides as $override) {
            $found = false;

            if (!empty($override['cantus_song_id'])) {
                foreach ($songs as &$song) {
                    if (isset($song['id']) && (int) $song['id'] === $override['cantus_song_id']) {
                        $song['title'] = $override['title'];
                        $song['hymnal_number'] = $override['hymnal_number'];
                        $song['liturgia_override'] = true;
                        $song['liturgia_event'] = $override['event_title'];
                        $found = true;
                        break;
                    }
                }
                unset($song);
            }

            if (!$found) {
                $songs[] = [
                    'title'            => $override['title'],
                    'hymnal_number'    => $override['hymnal_number'],
                    'liturgia_override'=> true,
                    'liturgia_event'   => $override['event_title'],
                    'sort_order'       => $override['sort_order'],
                ];
            }
        }

        return $songs;
    }

    /**
     * Filter: Tagesplan-Lesungen ggf. durch Liturgia-Overrides ersetzen
     */
    public static function filter_tagesplan_readings(array $readings, string $date): array {
        $overrides = self::get_reading_overrides($date);

        if (empty($overrides)) {
            return $readings;
        }

        foreach ($overrides as $override) {
            $replaced = false;

            foreach ($readings as &$reading) {
                if (isset($reading['type']) && $reading['type'] === $override['element_type']) {
                    $reading['title'] = $override['title'];
                    $reading['reference'] = $override['reading_reference'];
                    $reading['text'] = $override['reading_text'];
                    $reading['liturgia_override'] = true;
                    $reading['liturgia_event'] = $override['event_title'];
                    $reading['persons'] = $override['persons'];
                    $replaced = true;
                    break;
                }
            }
            unset($reading);

            if (!$replaced) {
                $readings[] = [
                    'type'              => $override['element_type'],
                    'title'             => $override['title'],
                    'reference'         => $override['reading_reference'],
                    'text'              => $override['reading_text'],
                    'liturgia_override' => true,
                    'liturgia_event'    => $override['event_title'],
                    'persons'           => $override['persons'],
                ];
            }
        }

        return $readings;
    }

    /**
     * Filter: Tagesplan-Dienste ggf. durch Liturgia-Overrides ersetzen
     *
     * Wenn Liturgia Personen für eine Rolle zuweist, überschreibt das die Liturgus-Einträge.
     */
    public static function filter_tagesplan_dienste(array $dienste, int $messe_id): array {
        global $wpdb;

        // Liturgia-Event für diese Messe finden
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT id, status FROM {$wpdb->prefix}liturgia_events
             WHERE post_id = %d AND status IN ('freigegeben', 'abgeschlossen')
             LIMIT 1",
            $messe_id
        ), ARRAY_A);

        if (!$event) {
            return $dienste;
        }

        // Alle Liturgia-Personen nach Rolle gruppiert
        $persons_table = $wpdb->prefix . 'liturgia_element_persons';
        $elements_table = $wpdb->prefix . 'liturgia_elements';

        $persons = $wpdb->get_results($wpdb->prepare(
            "SELECT p.user_id, p.person_name, p.role
             FROM {$persons_table} p
             JOIN {$elements_table} el ON p.element_id = el.id
             WHERE el.event_id = %d
             ORDER BY p.role ASC, p.sort_order ASC",
            $event['id']
        ), ARRAY_A) ?: [];

        if (empty($persons)) {
            return $dienste;
        }

        // Gruppieren nach Liturgus-Slot
        $overrides = [];
        foreach ($persons as $p) {
            $slot = self::LITURGUS_SLOT_MAP[$p['role']] ?? null;
            if ($slot === null) continue;

            $uid = (int) $p['user_id'];
            $name = $p['person_name'];

            if ($uid > 0) {
                $user = get_userdata($uid);
                $name = $user ? $user->display_name : $name;
            }

            if (!isset($overrides[$slot])) {
                $overrides[$slot] = [];
            }
            $overrides[$slot][] = [
                'user_id'      => $uid,
                'display_name' => $name,
                'is_backup'    => 0,
                'status'       => 'assigned',
                'liturgia_override' => true,
            ];
        }

        // Dienste überschreiben
        foreach ($overrides as $slot => $slot_persons) {
            $dienste[$slot] = $slot_persons;
        }

        return $dienste;
    }

    /**
     * Prüft ob für ein bestimmtes Datum + post_id ein Liturgia-Event existiert
     */
    public static function has_event_for_date(string $date, int $post_id = 0): ?int {
        global $wpdb;

        $where = 'event_date = %s AND status IN ("freigegeben", "abgeschlossen")';
        $params = [$date];

        if ($post_id > 0) {
            $where .= ' AND post_id = %d';
            $params[] = $post_id;
        }

        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}liturgia_events WHERE {$where} LIMIT 1",
            ...$params
        ));

        return $id ? (int) $id : null;
    }
}
