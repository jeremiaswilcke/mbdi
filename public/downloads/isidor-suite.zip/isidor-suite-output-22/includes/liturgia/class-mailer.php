<?php
/**
 * Liturgia Mailer
 *
 * E-Mail-Versand: Gottesdienst-Ablauf als PDF per Mail verschicken,
 * mit Empfänger-Auswahl und Versand-Log.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Mailer {

    /**
     * AJAX-Hooks registrieren
     */
    public static function init(): void {
        add_action('wp_ajax_liturgia_send_email', [self::class, 'ajax_send']);
        add_action('wp_ajax_liturgia_get_email_users', [self::class, 'ajax_get_users']);
        add_action('wp_ajax_liturgia_email_log', [self::class, 'ajax_get_log']);
    }

    /**
     * AJAX: E-Mail versenden
     */
    public static function ajax_send(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);
        $user_ids = array_map('intval', $_POST['user_ids'] ?? []);
        $extra_emails = sanitize_text_field($_POST['extra_emails'] ?? '');

        // Empfänger sammeln
        $recipients = [];

        // WordPress-Benutzer
        foreach ($user_ids as $uid) {
            $user = get_userdata($uid);
            if ($user && $user->user_email) {
                $recipients[] = $user->user_email;
            }
        }

        // Zusätzliche Adressen
        if ($extra_emails) {
            $extras = array_map('trim', explode(',', $extra_emails));
            foreach ($extras as $email) {
                if (is_email($email)) {
                    $recipients[] = $email;
                }
            }
        }

        $recipients = array_unique($recipients);

        if (empty($recipients)) {
            wp_send_json_error(['message' => 'Keine Empfänger ausgewählt']);
        }

        // Event laden
        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event) {
            wp_send_json_error(['message' => 'Event nicht gefunden']);
        }

        // PDF generieren
        $pdf_path = PDF::generate($event_id, true);

        if (!$pdf_path || !file_exists($pdf_path)) {
            wp_send_json_error(['message' => 'PDF konnte nicht erstellt werden']);
        }

        // Einstellungen
        $settings = Settings::get_all();
        $from_name = $settings['email_from_name'] ?? get_bloginfo('name');
        $from_email = $settings['email_from_address'] ?? get_option('admin_email');

        // Betreff
        $date_str = date_i18n('j.m.Y', strtotime($event['event_date']));
        $subject = "Liturgia: {$event['event_title']} - {$date_str}";

        // HTML-Body
        $body = self::build_email_body($event);

        // Headers
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            "From: {$from_name} <{$from_email}>",
        ];

        // Versand
        $success_count = 0;
        $error_count = 0;
        $errors = [];

        foreach ($recipients as $to) {
            $sent = wp_mail($to, $subject, $body, $headers, [$pdf_path]);

            if ($sent) {
                $success_count++;
            } else {
                $error_count++;
                $errors[] = $to;
            }
        }

        // Log
        self::log_send($event_id, $recipients, $subject, $success_count, $error_count, $errors);

        // Temp-PDF aufräumen
        if (file_exists($pdf_path)) {
            @unlink($pdf_path);
        }

        if ($error_count > 0) {
            wp_send_json_success([
                'message' => "{$success_count} E-Mails gesendet, {$error_count} fehlgeschlagen.",
                'errors'  => $errors,
            ]);
        } else {
            wp_send_json_success([
                'message' => "{$success_count} E-Mail(s) erfolgreich versendet!",
            ]);
        }
    }

    /**
     * AJAX: Benutzer für Empfänger-Auswahl laden
     */
    public static function ajax_get_users(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);

        // Alle Benutzer mit relevanten Rollen
        $settings = Settings::get_all();
        $allowed_roles = $settings['email_recipient_roles'] ?? ['administrator', 'editor'];

        $users = get_users([
            'role__in' => $allowed_roles,
            'orderby'  => 'display_name',
            'order'    => 'ASC',
        ]);

        $user_list = [];
        foreach ($users as $user) {
            $user_list[] = [
                'id'    => $user->ID,
                'name'  => $user->display_name,
                'email' => $user->user_email,
                'roles' => array_values($user->roles),
            ];
        }

        // Beteiligte Personen des Events (v2: user_id direkt aus Junction-Tabelle)
        $participant_user_ids = [];
        if ($event_id) {
            $participants = Elements::get_participants($event_id);
            foreach ($participants as $role => $persons) {
                foreach ($persons as $person) {
                    if (!empty($person['user_id']) && (int) $person['user_id'] > 0) {
                        $participant_user_ids[] = (int) $person['user_id'];
                    }
                }
            }
        }

        wp_send_json_success([
            'users'        => $user_list,
            'participants' => array_unique($participant_user_ids),
        ]);
    }

    /**
     * AJAX: E-Mail-Log laden
     */
    public static function ajax_get_log(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $event_id = (int) ($_POST['event_id'] ?? 0);

        global $wpdb;
        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_email_log
             WHERE event_id = %d
             ORDER BY sent_at DESC
             LIMIT 20",
            $event_id
        ), ARRAY_A) ?: [];

        wp_send_json_success(['logs' => $logs]);
    }

    /**
     * E-Mail Body bauen (HTML)
     */
    private static function build_email_body(array $event): string {
        $elements = Elements::get_for_event((int) $event['id']);
        $event_types = Database::get_event_types();
        $statuses = Database::get_statuses();

        $type_label = $event_types[$event['event_type']] ?? $event['event_type'];
        $status_info = $statuses[$event['status']] ?? $statuses['entwurf'];
        $date_str = date_i18n('l, j. F Y', strtotime($event['event_date']));

        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/liturgia/email-event.php';
        return ob_get_clean();
    }

    /**
     * Versand loggen
     */
    private static function log_send(int $event_id, array $recipients, string $subject, int $success, int $errors, array $error_emails): void {
        global $wpdb;

        $status = $errors > 0 ? ($success > 0 ? 'partial' : 'failed') : 'success';
        $error_msg = $errors > 0 ? 'Fehler bei: ' . implode(', ', $error_emails) : null;

        $wpdb->insert($wpdb->prefix . 'liturgia_email_log', [
            'event_id'      => $event_id,
            'recipients'    => implode(', ', $recipients),
            'subject'       => $subject,
            'status'        => $status,
            'error_message' => $error_msg,
        ]);
    }
}
