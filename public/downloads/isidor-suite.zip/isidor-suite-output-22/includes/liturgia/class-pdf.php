<?php
/**
 * Liturgia PDF-Export
 *
 * Generiert ein PDF des kompletten Gottesdienst-Ablaufs.
 * Nutzt die im Plugin enthaltene FPDF-Bibliothek (lib/fpdf/fpdf.php)
 * oder alternativ TCPDF falls verfügbar.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class PDF {

    /**
     * AJAX Handler für PDF-Download
     */
    public static function init(): void {
        add_action('wp_ajax_liturgia_generate_pdf', [self::class, 'ajax_generate']);
    }

    /**
     * AJAX: PDF generieren und ausliefern
     */
    public static function ajax_generate(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung');
        }

        $id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
        if (!$id) {
            wp_die('Keine Event-ID');
        }

        self::generate($id);
        exit;
    }

    /**
     * PDF für ein Event generieren
     *
     * @param int  $event_id
     * @param bool $return_path  Wenn true, wird der Temp-Pfad zurückgegeben statt direkt auszuliefern
     * @return string|void       Pfad zur Temp-Datei (wenn $return_path = true)
     */
    public static function generate(int $event_id, bool $return_path = false) {
        global $wpdb;

        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event) {
            wp_die('Event nicht gefunden');
        }

        $elements = Elements::get_for_event($event_id);
        $participants = Elements::get_participants($event_id);
        $event_types = Database::get_event_types();
        $element_types = Database::get_element_types();
        $roles = Database::get_roles();
        $statuses = Database::get_statuses();
        $settings = Settings::get_all();

        // FPDF laden
        $fpdf_path = ISIDOR_SUITE_PATH . 'lib/fpdf/fpdf.php';
        if (!file_exists($fpdf_path)) {
            wp_die('FPDF-Bibliothek nicht gefunden. Bitte lib/fpdf/fpdf.php installieren.');
        }
        require_once $fpdf_path;

        $pdf = new \FPDF('P', 'mm', 'A4');
        $pdf->SetAutoPageBreak(true, 25);
        $pdf->AddPage();

        // Font
        $pdf->SetFont('Helvetica', '', 10);

        // === HEADER ===

        // Logo
        $logo_id = $settings['logo_attachment_id'] ?? 0;
        if ($logo_id) {
            $logo_path = get_attached_file($logo_id);
            if ($logo_path && file_exists($logo_path)) {
                $ext = strtolower(pathinfo($logo_path, PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
                    $pdf->Image($logo_path, 10, 10, 30);
                    $pdf->SetXY(45, 10);
                }
            }
        }

        // Titel
        $pdf->SetFont('Helvetica', 'B', 18);
        $pdf->Cell(0, 10, self::utf8($event['event_title']), 0, 1);

        $pdf->SetFont('Helvetica', '', 11);
        $date_str = date_i18n('l, j. F Y', strtotime($event['event_date']));
        $type_str = $event_types[$event['event_type']] ?? $event['event_type'];
        $status_str = $statuses[$event['status']]['label'] ?? $event['status'];

        $pdf->Cell(0, 6, self::utf8("{$type_str} | {$date_str}"), 0, 1);

        if ($event['location_default']) {
            $pdf->Cell(0, 6, self::utf8("Ort: {$event['location_default']}"), 0, 1);
        }

        $pdf->Cell(0, 6, self::utf8("Status: {$status_str}"), 0, 1);

        $pdf->Ln(4);
        $pdf->SetDrawColor(200, 200, 200);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->Ln(6);

        // === ANMERKUNGEN ===
        if (!empty($event['notes'])) {
            $pdf->SetFont('Helvetica', 'B', 11);
            $pdf->Cell(0, 6, 'Anmerkungen', 0, 1);
            $pdf->SetFont('Helvetica', '', 9);
            $notes_text = self::html_to_text($event['notes']);
            $pdf->MultiCell(0, 5, self::utf8($notes_text));
            $pdf->Ln(4);
        }

        // === ABLAUF ===
        $pdf->SetFont('Helvetica', 'B', 13);
        $pdf->Cell(0, 8, self::utf8('Ablauf'), 0, 1);
        $pdf->Ln(2);

        foreach ($elements as $el) {
            // Seitenumbruch prüfen
            if ($pdf->GetY() > 250) {
                $pdf->AddPage();
            }

            $el_type_label = $element_types[$el['element_type']] ?? $el['element_type'];
            $role_label = $roles[$el['responsible_role']] ?? $el['responsible_role'];

            // Nummer + Typ + Titel
            $pdf->SetFont('Helvetica', 'B', 11);
            $header = "{$el['sort_order']}. {$el_type_label}";
            if ($el['title'] !== $el_type_label) {
                $header .= " – {$el['title']}";
            }
            $pdf->Cell(0, 6, self::utf8($header), 0, 1);

            // Metadaten-Zeile
            $meta_parts = [];
            if (!empty($el['persons'])) {
                $person_names = array_map(function ($p) { return $p['display_name']; }, $el['persons']);
                $meta_parts[] = implode(', ', $person_names);
            } elseif ($el['responsible_person']) {
                $meta_parts[] = $el['responsible_person'];
            } else {
                $meta_parts[] = $role_label;
            }
            if ($el['location']) {
                $meta_parts[] = "Ort: {$el['location']}";
            }
            if ($el['duration_minutes']) {
                $meta_parts[] = "ca. {$el['duration_minutes']} Min.";
            }
            if ($el['hymnal_number']) {
                $meta_parts[] = $el['hymnal_number'];
            }

            if (!empty($meta_parts)) {
                $pdf->SetFont('Helvetica', 'I', 9);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->Cell(0, 5, self::utf8(implode(' | ', $meta_parts)), 0, 1);
                $pdf->SetTextColor(0, 0, 0);
            }

            // Beschreibung
            if (!empty($el['description'])) {
                $pdf->SetFont('Helvetica', '', 9);
                $desc_text = self::html_to_text($el['description']);
                $pdf->MultiCell(0, 4.5, self::utf8($desc_text));
            }

            // Schriftstelle
            if (!empty($el['reading_reference'])) {
                $pdf->SetFont('Helvetica', 'B', 9);
                $pdf->Cell(0, 5, self::utf8("Schriftstelle: {$el['reading_reference']}"), 0, 1);
            }

            // Lesungstext
            if (!empty($el['reading_text'])) {
                $pdf->SetFont('Helvetica', '', 9);
                $reading_text = self::html_to_text($el['reading_text']);
                $pdf->MultiCell(0, 4.5, self::utf8($reading_text));
            }

            $pdf->Ln(3);
        }

        // === BETEILIGTE PERSONEN ===
        if (!empty($participants)) {
            if ($pdf->GetY() > 230) {
                $pdf->AddPage();
            }

            $pdf->Ln(4);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(4);

            $pdf->SetFont('Helvetica', 'B', 12);
            $pdf->Cell(0, 7, self::utf8('Beteiligte Personen'), 0, 1);
            $pdf->Ln(2);

            $pdf->SetFont('Helvetica', '', 10);
            foreach ($participants as $role => $persons) {
                $pdf->Cell(50, 6, self::utf8("{$role}:"), 0, 0);
                $person_names = array_map(function ($p) { return $p['display_name']; }, $persons);
                $pdf->Cell(0, 6, self::utf8(implode(', ', $person_names)), 0, 1);
            }
        }

        // === FOOTER ===
        $footer_text = $settings['pdf_footer'] ?? '';
        if ($footer_text) {
            $pdf->SetY(-20);
            $pdf->SetFont('Helvetica', 'I', 8);
            $pdf->SetTextColor(150, 150, 150);
            $pdf->Cell(0, 5, self::utf8($footer_text), 0, 1, 'C');
        }

        // Datum-Zeile
        $pdf->SetY(-15);
        $pdf->SetFont('Helvetica', 'I', 7);
        $pdf->SetTextColor(180, 180, 180);
        $pdf->Cell(0, 4, self::utf8('Erstellt am ' . date_i18n('d.m.Y H:i') . ' mit Liturgia / Isidor Suite'), 0, 0, 'R');

        // === OUTPUT ===
        $filename = sanitize_file_name('Liturgia_' . $event['event_title'] . '_' . $event['event_date'] . '.pdf');

        if ($return_path) {
            $tmp = wp_tempnam($filename);
            $pdf->Output('F', $tmp);
            return $tmp;
        }

        // Direkt an Browser senden
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $pdf->Output('D', $filename);
    }

    /**
     * UTF-8 → Latin1 Konvertierung für FPDF
     */
    private static function utf8(string $text): string {
        return iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $text) ?: $text;
    }

    /**
     * HTML in reinen Text konvertieren
     */
    private static function html_to_text(string $html): string {
        // <br>, <p>, <li> → Zeilenumbrüche
        $text = preg_replace('/<br\s*\/?>/', "\n", $html);
        $text = preg_replace('/<\/p>/', "\n", $text);
        $text = preg_replace('/<li>/', "- ", $text);
        $text = preg_replace('/<\/li>/', "\n", $text);
        $text = wp_strip_all_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
        $text = preg_replace("/\n{3,}/", "\n\n", $text);
        return trim($text);
    }
}
