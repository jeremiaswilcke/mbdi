<?php
/**
 * Liturgia Print View
 *
 * Druckansicht für Gottesdienst-Abläufe (Browser-Druck).
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class PrintView {

    /**
     * Druckansicht rendern und ausgeben (HTML)
     */
    public static function render(int $event_id): void {
        global $wpdb;

        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        if (!$event) {
            wp_die('Event nicht gefunden.');
        }

        $elements = Elements::get_for_event($event_id);
        $participants = Elements::get_participants($event_id);
        $total_duration = Elements::get_total_duration($event_id);
        $event_types = Database::get_event_types();
        $element_types = Database::get_element_types();
        $roles = Database::get_roles();
        $statuses = Database::get_statuses();
        $settings = Settings::get_all();

        include ISIDOR_SUITE_PATH . 'templates/liturgia/print-event.php';
    }
}
