<?php
/**
 * Liturgia Settings
 *
 * Plugin-Einstellungen: Logo, E-Mail-Konfiguration, PDF-Footer.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Settings {

    private static $option_key = 'liturgia_settings';

    /**
     * Hooks registrieren
     */
    public static function init(): void {
        add_action('admin_menu', [self::class, 'add_menu'], 21);
        add_action('wp_ajax_liturgia_save_settings', [self::class, 'ajax_save']);
    }

    /**
     * Untermenü-Eintrag
     */
    public static function add_menu(): void {
        add_submenu_page(
            null, // Hidden – erreichbar über Link in Liturgia
            'Liturgia Einstellungen',
            'Liturgia Einstellungen',
            'manage_options',
            'liturgia-settings',
            [self::class, 'render_page']
        );
    }

    /**
     * Alle Einstellungen laden
     */
    public static function get_all(): array {
        $defaults = [
            'logo_attachment_id'     => 0,
            'email_from_name'        => get_bloginfo('name'),
            'email_from_address'     => get_option('admin_email'),
            'email_recipient_roles'  => ['administrator', 'editor'],
            'pdf_footer'             => '',
            'liturgieausschuss_ids'  => [],
        ];

        $saved = get_option(self::$option_key, []);

        return wp_parse_args($saved, $defaults);
    }

    /**
     * Einstellung(en) speichern
     */
    public static function save(array $data): void {
        $current = self::get_all();
        $merged = wp_parse_args($data, $current);
        update_option(self::$option_key, $merged);
    }

    /**
     * AJAX: Einstellungen speichern
     */
    public static function ajax_save(): void {
        check_ajax_referer('liturgia_nonce', '_wpnonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $data = [
            'logo_attachment_id'     => (int) ($_POST['logo_attachment_id'] ?? 0),
            'email_from_name'        => sanitize_text_field($_POST['email_from_name'] ?? ''),
            'email_from_address'     => sanitize_email($_POST['email_from_address'] ?? ''),
            'pdf_footer'             => sanitize_text_field($_POST['pdf_footer'] ?? ''),
            'email_recipient_roles'  => array_map('sanitize_text_field', $_POST['email_recipient_roles'] ?? []),
            'liturgieausschuss_ids'  => array_map('intval', $_POST['liturgieausschuss_ids'] ?? []),
        ];

        self::save($data);

        wp_send_json_success(['message' => 'Einstellungen gespeichert']);
    }

    /**
     * Settings-Seite rendern
     */
    public static function render_page(): void {
        $settings = self::get_all();
        $all_roles = wp_roles()->get_names();
        $all_users = get_users(['orderby' => 'display_name', 'order' => 'ASC']);
        ?>
        <div class="wrap liturgia-wrap">
            <h1>📋 Liturgia – Einstellungen</h1>

            <div class="liturgia-settings-form">
                <!-- Logo -->
                <div class="liturgia-settings-section">
                    <h2>🖼️ Pfarr-Logo (für PDF-Header)</h2>
                    <div class="liturgia-form-row">
                        <div id="liturgia-logo-preview" style="margin-bottom:10px;">
                            <?php if ($settings['logo_attachment_id']): ?>
                                <?php echo wp_get_attachment_image($settings['logo_attachment_id'], 'medium'); ?>
                            <?php else: ?>
                                <span class="liturgia-muted">Kein Logo ausgewählt</span>
                            <?php endif; ?>
                        </div>
                        <input type="hidden" id="liturgia-logo-id" value="<?php echo esc_attr($settings['logo_attachment_id']); ?>">
                        <button type="button" class="button" id="liturgia-upload-logo">Logo auswählen</button>
                        <button type="button" class="button" id="liturgia-remove-logo" <?php if (!$settings['logo_attachment_id']): ?>style="display:none;"<?php endif; ?>>Logo entfernen</button>
                    </div>
                </div>

                <!-- E-Mail -->
                <div class="liturgia-settings-section">
                    <h2>✉️ E-Mail-Einstellungen</h2>
                    <div class="liturgia-form-row liturgia-form-row-2col">
                        <label>Absendername
                            <input type="text" id="liturgia-from-name" class="regular-text" value="<?php echo esc_attr($settings['email_from_name']); ?>">
                        </label>
                        <label>Absender-E-Mail
                            <input type="email" id="liturgia-from-email" class="regular-text" value="<?php echo esc_attr($settings['email_from_address']); ?>">
                        </label>
                    </div>
                    <div class="liturgia-form-row">
                        <label>Empfänger-Rollen (für Auswahlliste)</label>
                        <div class="liturgia-checkbox-list" style="max-height:200px;overflow-y:auto;">
                            <?php foreach ($all_roles as $role_key => $role_name): ?>
                                <label style="display:block;padding:3px 0;">
                                    <input type="checkbox" class="liturgia-setting-role" value="<?php echo esc_attr($role_key); ?>"
                                        <?php checked(in_array($role_key, $settings['email_recipient_roles'])); ?>>
                                    <?php echo esc_html($role_name); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Liturgieausschuss -->
                <div class="liturgia-settings-section">
                    <h2>👥 Liturgieausschuss</h2>
                    <p class="description">Diese Benutzer erscheinen als Schnellauswahl beim E-Mail-Versand.</p>
                    <div class="liturgia-form-row">
                        <div class="liturgia-checkbox-list" style="max-height:250px;overflow-y:auto;">
                            <?php foreach ($all_users as $user): ?>
                                <label style="display:block;padding:3px 0;">
                                    <input type="checkbox" class="liturgia-setting-ausschuss" value="<?php echo $user->ID; ?>"
                                        <?php checked(in_array($user->ID, $settings['liturgieausschuss_ids'])); ?>>
                                    <?php echo esc_html($user->display_name); ?>
                                    <small>(<?php echo esc_html($user->user_email); ?>)</small>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- PDF -->
                <div class="liturgia-settings-section">
                    <h2>📄 PDF-Einstellungen</h2>
                    <div class="liturgia-form-row">
                        <label>PDF-Fußzeile
                            <input type="text" id="liturgia-pdf-footer" class="regular-text" style="width:100%;" value="<?php echo esc_attr($settings['pdf_footer']); ?>" placeholder="z.B. Pfarre Mariabrunn – Vertraulich">
                        </label>
                    </div>
                </div>

                <div style="margin-top:20px;">
                    <button type="button" class="button button-primary button-hero" id="liturgia-save-settings">💾 Einstellungen speichern</button>
                    <span id="liturgia-settings-status" style="margin-left:15px;"></span>
                </div>
            </div>

            <div style="margin-top:30px;">
                <a href="<?php echo admin_url('admin.php?page=liturgia'); ?>">← Zurück zu Liturgia</a>
            </div>
        </div>
        <?php
    }
}
