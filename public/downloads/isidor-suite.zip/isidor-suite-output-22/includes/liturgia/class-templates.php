<?php
/**
 * Liturgia Templates
 *
 * Vorlagen-System: Standard-Messabläufe speichern und wiederverwenden.
 *
 * @package IsidorSuite\Liturgia
 * @since 1.0.0
 */

namespace Isidor\Liturgia;

if (!defined('ABSPATH')) exit;

class Templates {

    /**
     * Alle Vorlagen laden
     */
    public static function get_all(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_templates';

        return $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY is_default DESC, title ASC",
            ARRAY_A
        ) ?: [];
    }

    /**
     * Einzelne Vorlage laden
     */
    public static function get(int $id): ?array {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_templates';

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            ARRAY_A
        );

        if ($row) {
            $row['elements'] = json_decode($row['elements_json'], true) ?: [];
        }

        return $row ?: null;
    }

    /**
     * Neue Vorlage erstellen
     */
    public static function create(array $data): int {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_templates';

        $wpdb->insert($table, [
            'title'         => sanitize_text_field($data['title'] ?? ''),
            'description'   => sanitize_textarea_field($data['description'] ?? ''),
            'event_type'    => sanitize_text_field($data['event_type'] ?? 'hochamt'),
            'elements_json' => wp_json_encode($data['elements'] ?? []),
            'is_default'    => 0,
            'created_by'    => get_current_user_id(),
        ]);

        return (int) $wpdb->insert_id;
    }

    /**
     * Vorlage aus bestehendem Event erstellen
     */
    public static function create_from_event(int $event_id, string $title): int {
        $elements = Elements::get_for_event($event_id);

        // Nur relevante Felder behalten
        $template_elements = [];
        foreach ($elements as $el) {
            $template_elements[] = [
                'sort_order'       => $el['sort_order'],
                'element_type'     => $el['element_type'],
                'title'            => $el['title'],
                'responsible_role' => $el['responsible_role'],
                'location'         => $el['location'],
                'description'      => $el['description'] ?? '',
            ];
        }

        // Event-Daten laden für event_type
        global $wpdb;
        $event = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}liturgia_events WHERE id = %d",
            $event_id
        ), ARRAY_A);

        return self::create([
            'title'       => $title,
            'description' => sprintf('Erstellt aus: %s (%s)', $event['event_title'] ?? '', $event['event_date'] ?? ''),
            'event_type'  => $event['event_type'] ?? 'hochamt',
            'elements'    => $template_elements,
        ]);
    }

    /**
     * Vorlage löschen (nur nicht-Standard)
     */
    public static function delete(int $id): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'liturgia_templates';

        // Standard-Vorlagen nicht löschbar
        $is_default = $wpdb->get_var($wpdb->prepare(
            "SELECT is_default FROM {$table} WHERE id = %d",
            $id
        ));

        if ($is_default) {
            return false;
        }

        return $wpdb->delete($table, ['id' => $id], ['%d']) !== false;
    }

    /**
     * Vorlage auf ein Event anwenden
     *
     * Bestehende Elemente werden NICHT gelöscht, sondern die Vorlage
     * wird angehängt. Zum Ersetzen muss der Aufrufer vorher Elements::delete_for_event() nutzen.
     */
    public static function apply_to_event(int $template_id, int $event_id): int {
        $template = self::get($template_id);
        if (!$template || empty($template['elements'])) {
            return 0;
        }

        return Elements::create_from_template($event_id, $template['elements']);
    }
}
