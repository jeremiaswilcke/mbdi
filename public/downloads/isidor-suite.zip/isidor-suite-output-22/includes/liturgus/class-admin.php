<?php
/**
 * Liturgus Backend Admin
 */
class Liturgus_Admin {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_post_liturgus_assign', [$this, 'handle_assign']);
        add_action('admin_post_liturgus_save_slots', [$this, 'handle_save_slots']);
    }
    
    public function add_menu() {
        add_menu_page(
            'Liturgus Dienste',
            'Liturgus',
            'liturgus_assign_others',
            'liturgus-admin',
            [$this, 'render_page'],
            'dashicons-groups',
            30
        );
        add_submenu_page(
            'liturgus-admin',
            'Dienste-Vorlage',
            'Dienste-Vorlage',
            'manage_options',
            'liturgus-slots',
            [$this, 'render_slots_page']
        );
    }
    
    public function render_page() {
        if (!current_user_can('liturgus_assign_others')) {
            wp_die('Keine Berechtigung');
        }
        
        // Messe-Filter
        $from = $_GET['from'] ?? date('Y-m-d');
        $to = $_GET['to'] ?? date('Y-m-d', strtotime('+28 days'));
        
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [[
                'key' => '_is_date',
                'value' => [$from, $to],
                'compare' => 'BETWEEN',
                'type' => 'DATE'
            ]]
        ]);
        
        // User mit Liturgus-Berechtigung (neues Permissions-System)
        $all_liturgus_users = [];
        $users_by_service = [];
        
        if (class_exists('Isidor_Permissions')) {
            // Get users per service for slot-specific dropdowns
            $service_map = Liturgus_Service_Integration::get_slot_service_map();
            foreach ($service_map as $slot_key => $service_slug) {
                $user_ids = Isidor_Permissions::get_users_for_service($service_slug);
                $users_by_service[$slot_key] = $user_ids;
                $all_liturgus_users = array_merge($all_liturgus_users, $user_ids);
            }
            $all_liturgus_users = array_unique($all_liturgus_users);
        }
        
        // Fallback: also include users with WP capability (legacy)
        $wp_users = get_users(['capability' => 'liturgus_signup']);
        foreach ($wp_users as $u) {
            if (!in_array($u->ID, $all_liturgus_users)) {
                $all_liturgus_users[] = $u->ID;
            }
        }
        
        // Always include admins
        $admins = get_users(['role' => 'administrator']);
        foreach ($admins as $a) {
            if (!in_array($a->ID, $all_liturgus_users)) {
                $all_liturgus_users[] = $a->ID;
            }
        }
        
        // Load user objects
        $users = [];
        if (!empty($all_liturgus_users)) {
            $users = get_users(['include' => $all_liturgus_users, 'orderby' => 'display_name', 'order' => 'ASC']);
        }
        
        ?>
        <div class="wrap">
            <h1>Liturgus - Dienste zuweisen</h1>
            
            <form method="get">
                <input type="hidden" name="page" value="liturgus-admin">
                Von: <input type="date" name="from" value="<?php echo esc_attr($from); ?>">
                Bis: <input type="date" name="to" value="<?php echo esc_attr($to); ?>">
                <button type="submit" class="button">Filtern</button>
            </form>
            
            <br>
            
            <?php foreach ($messen as $messe): 
                $date = get_post_meta($messe->ID, '_is_date', true);
                $time = get_post_meta($messe->ID, '_is_time', true);
                $slots = Liturgus_Slots::get_all();
                $current_assignments = Liturgus_Assignments::get_for_messe($messe->ID);
                
                // Assignments in Array umformen [slot_id => [main => user_id, backup => user_id]]
                $assignments = [];
                foreach ($current_assignments as $a) {
                    if (!isset($assignments[$a['slot_key']])) {
                        $assignments[$a['slot_key']] = ['main' => null, 'backup' => null];
                    }
                    
                    if ($a['is_backup']) {
                        $assignments[$a['slot_key']]['backup'] = $a['user_id'];
                    } else {
                        $assignments[$a['slot_key']]['main'] = $a['user_id'];
                    }
                }
            ?>
                <div class="card" style="margin-bottom: 20px;">
                    <h2><?php echo date('D d.m.Y', strtotime($date)); ?> | <?php echo $time; ?></h2>
                    <h3><?php echo esc_html($messe->post_title); ?></h3>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                        <?php wp_nonce_field('liturgus_assign', 'liturgus_nonce'); ?>
                        <input type="hidden" name="action" value="liturgus_assign">
                        <input type="hidden" name="messe_id" value="<?php echo $messe->ID; ?>">
                        
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th>Dienst</th>
                                    <th>Hauptdienst</th>
                                    <th>Ersatz</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($slots as $slot): 
                                    $main = $assignments[$slot['slot_key']]['main'] ?? null;
                                    $backup = $assignments[$slot['slot_key']]['backup'] ?? null;
                                ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($slot['label']); ?></strong></td>
                                        <td>
                                            <select name="main[<?php echo $slot['slot_key']; ?>]">
                                                <option value="">-- Frei --</option>
                                                <?php foreach ($users as $user): ?>
                                                    <option value="<?php echo $user->ID; ?>" <?php selected($main, $user->ID); ?>>
                                                        <?php echo esc_html($user->display_name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="backup[<?php echo $slot['slot_key']; ?>]">
                                                <option value="">-- Kein Ersatz --</option>
                                                <?php foreach ($users as $user): ?>
                                                    <option value="<?php echo $user->ID; ?>" <?php selected($backup, $user->ID); ?>>
                                                        <?php echo esc_html($user->display_name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary">Zuweisungen speichern</button>
                        </p>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
    
    public function handle_assign() {
        check_admin_referer('liturgus_assign', 'liturgus_nonce');
        
        if (!current_user_can('liturgus_assign_others')) {
            wp_die('Keine Berechtigung');
        }
        
        $messe_id = intval($_POST['messe_id']);
        $main = $_POST['main'] ?? [];
        $backup = $_POST['backup'] ?? [];
        
        global $wpdb;
        $table = $wpdb->prefix . 'liturgus_assignments';
        
        // Alle bisherigen löschen
        $wpdb->delete($table, ['messe_id' => $messe_id]);
        
        // Neue speichern
        foreach ($main as $slot_key => $user_id) {
            if ($user_id) {
                $wpdb->insert($table, [
                    'messe_id' => $messe_id,
                    'slot_key' => sanitize_text_field($slot_key),
                    'user_id' => intval($user_id),
                    'is_backup' => 0,
                    'position' => 1,
                    'status' => 'assigned',
                    'created_at' => current_time('mysql')
                ]);
                
                // Email senden
                self::send_assignment_email($user_id, $messe_id, $slot_key, false);
            }
        }
        
        foreach ($backup as $slot_key => $user_id) {
            if ($user_id) {
                $wpdb->insert($table, [
                    'messe_id' => $messe_id,
                    'slot_key' => sanitize_text_field($slot_key),
                    'user_id' => intval($user_id),
                    'is_backup' => 1,
                    'position' => 1,
                    'status' => 'assigned',
                    'created_at' => current_time('mysql')
                ]);
                
                // Email senden
                self::send_assignment_email($user_id, $messe_id, $slot_key, true);
            }
        }
        
        wp_redirect(admin_url('admin.php?page=liturgus-admin&saved=1'));
        exit;
    }
    
    /**
     * Email bei Zuweisung
     */
    private static function send_assignment_email($user_id, $messe_id, $slot_key, $is_backup) {
        $user = get_userdata($user_id);
        $messe = get_post($messe_id);
        $date = get_post_meta($messe_id, '_is_date', true);
        $time = get_post_meta($messe_id, '_is_time', true);
        $slot = Liturgus_Slots::get($slot_key);
        
        $subject = 'Dienst zugewiesen: ' . $slot['label'];
        
        $body = "Liebe/r " . $user->display_name . ",\n\n";
        $body .= "Du wurdest für einen Dienst eingeteilt:\n\n";
        $body .= "Messe: " . $messe->post_title . "\n";
        $body .= "Datum: " . date('d.m.Y', strtotime($date)) . " um " . $time . "\n";
        $body .= "Dienst: " . $slot['label'];
        
        if ($is_backup) {
            $body .= " (ERSATZDIENST)\n\n";
            $body .= "Du bist als Ersatz eingeteilt. Bitte sei bereit einzuspringen, falls der Hauptdienst ausfällt.\n";
        } else {
            $body .= "\n";
        }
        
        $body .= "\nBei Verhinderung bitte rechtzeitig im Dashboard austragen oder Tausch anfragen.\n";
        $body .= "Dashboard: " . isidor_app_link('dienste') . "\n";
        
        wp_mail($user->user_email, $subject, $body);
    }

    // =========================================================================
    // DIENSTE-VORLAGE (Slot Template Management)
    // =========================================================================

    public function render_slots_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung');
        }

        $slots = Liturgus_Slots::get_all_including_inactive();
        $saved = isset($_GET['saved']);
        $error = $_GET['slot_error'] ?? '';
        ?>
        <div class="wrap">
            <h1>Dienste-Vorlage</h1>
            <p class="description">Hier verwalten Sie die globale Vorlage für Liturgie-Dienste. Einzelne Messen können davon abweichen.</p>

            <?php if ($saved): ?>
                <div class="notice notice-success is-dismissible"><p>Änderungen gespeichert.</p></div>
            <?php endif; ?>
            <?php if ($error === 'delete_has_assignments'): ?>
                <div class="notice notice-error is-dismissible"><p>Slot konnte nicht gelöscht werden — es existieren noch Zuweisungen dafür.</p></div>
            <?php elseif ($error === 'key_exists'): ?>
                <div class="notice notice-error is-dismissible"><p>Ein Dienst mit diesem Schlüssel existiert bereits.</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('liturgus_save_slots', 'liturgus_slots_nonce'); ?>
                <input type="hidden" name="action" value="liturgus_save_slots">

                <table class="wp-list-table widefat fixed striped" id="liturgus-slots-table">
                    <thead>
                        <tr>
                            <th style="width:30px;">⇕</th>
                            <th style="width:140px;">Schlüssel</th>
                            <th>Bezeichnung</th>
                            <th style="width:80px;">Positionen</th>
                            <th style="width:80px;">Backup</th>
                            <th style="width:60px;">Aktiv</th>
                            <th style="width:60px;"></th>
                        </tr>
                    </thead>
                    <tbody id="liturgus-slots-body">
                        <?php foreach ($slots as $s): ?>
                        <tr data-key="<?php echo esc_attr($s['slot_key']); ?>">
                            <td class="liturgus-drag-handle" style="cursor:grab;text-align:center;">☰</td>
                            <td>
                                <code><?php echo esc_html($s['slot_key']); ?></code>
                                <input type="hidden" name="slots[<?php echo esc_attr($s['slot_key']); ?>][slot_key]" value="<?php echo esc_attr($s['slot_key']); ?>">
                            </td>
                            <td><input type="text" name="slots[<?php echo esc_attr($s['slot_key']); ?>][label]" value="<?php echo esc_attr($s['label']); ?>" class="regular-text" required></td>
                            <td><input type="number" name="slots[<?php echo esc_attr($s['slot_key']); ?>][positions]" value="<?php echo intval($s['positions']); ?>" min="1" max="20" style="width:60px;"></td>
                            <td><input type="number" name="slots[<?php echo esc_attr($s['slot_key']); ?>][backup_positions]" value="<?php echo intval($s['backup_positions']); ?>" min="0" max="20" style="width:60px;"></td>
                            <td style="text-align:center;">
                                <input type="checkbox" name="slots[<?php echo esc_attr($s['slot_key']); ?>][active]" value="1" <?php checked($s['active'], 1); ?>>
                            </td>
                            <td>
                                <button type="submit" name="delete_slot" value="<?php echo esc_attr($s['slot_key']); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('Dienst &quot;<?php echo esc_attr($s['label']); ?>&quot; löschen?');">✕</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <input type="hidden" name="slot_order" id="liturgus-slot-order" value="">

                <h3 style="margin-top:24px;">Neuen Dienst hinzufügen</h3>
                <table class="form-table">
                    <tr>
                        <th>Schlüssel</th>
                        <td><input type="text" name="new_slot_key" value="" placeholder="z.B. chor" pattern="[a-z0-9_]+" class="regular-text" style="max-width:160px;"><p class="description">Nur Kleinbuchstaben, Zahlen, Unterstriche. Kann nachher nicht geändert werden.</p></td>
                    </tr>
                    <tr>
                        <th>Bezeichnung</th>
                        <td><input type="text" name="new_slot_label" value="" placeholder="z.B. Chor" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Positionen / Backup</th>
                        <td>
                            <input type="number" name="new_slot_positions" value="1" min="1" max="20" style="width:60px;">
                            <input type="number" name="new_slot_backup" value="1" min="0" max="20" style="width:60px;">
                        </td>
                    </tr>
                </table>

                <p>
                    <button type="submit" class="button button-primary">Änderungen speichern</button>
                </p>
            </form>
        </div>

        <script>
        (function(){
            // Simple drag & drop sort
            var tbody = document.getElementById('liturgus-slots-body');
            var dragging = null;
            tbody.querySelectorAll('.liturgus-drag-handle').forEach(function(h){
                h.parentElement.draggable = true;
                h.parentElement.addEventListener('dragstart', function(e) {
                    dragging = this;
                    this.style.opacity = '0.4';
                    e.dataTransfer.effectAllowed = 'move';
                });
                h.parentElement.addEventListener('dragend', function() {
                    this.style.opacity = '1';
                    dragging = null;
                    tbody.querySelectorAll('tr').forEach(function(r){ r.style.borderTop = ''; });
                });
                h.parentElement.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'move';
                    this.style.borderTop = '2px solid #16a34a';
                });
                h.parentElement.addEventListener('dragleave', function() {
                    this.style.borderTop = '';
                });
                h.parentElement.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.style.borderTop = '';
                    if (dragging !== this) tbody.insertBefore(dragging, this);
                    updateOrder();
                });
            });
            function updateOrder() {
                var keys = [];
                tbody.querySelectorAll('tr').forEach(function(r){ if(r.dataset.key) keys.push(r.dataset.key); });
                document.getElementById('liturgus-slot-order').value = keys.join(',');
            }
        })();
        </script>
        <?php
    }

    public function handle_save_slots() {
        if (!current_user_can('manage_options') || !wp_verify_nonce($_POST['liturgus_slots_nonce'] ?? '', 'liturgus_save_slots')) {
            wp_die('Keine Berechtigung');
        }

        $redirect = admin_url('admin.php?page=liturgus-slots');

        // Delete slot?
        if (!empty($_POST['delete_slot'])) {
            $key = sanitize_key($_POST['delete_slot']);
            if (!Liturgus_Slots::delete($key)) {
                wp_redirect($redirect . '&slot_error=delete_has_assignments');
                exit;
            }
            wp_redirect($redirect . '&saved=1');
            exit;
        }

        // Update existing slots
        $slots = $_POST['slots'] ?? [];
        foreach ($slots as $key => $data) {
            $key = sanitize_key($key);
            Liturgus_Slots::update($key, [
                'label'            => $data['label'] ?? '',
                'positions'        => $data['positions'] ?? 1,
                'backup_positions' => $data['backup_positions'] ?? 0,
                'active'           => isset($data['active']) ? 1 : 0,
            ]);
        }

        // Update sort order
        if (!empty($_POST['slot_order'])) {
            $order = array_map('sanitize_key', explode(',', $_POST['slot_order']));
            Liturgus_Slots::update_sort_order($order);
        }

        // New slot?
        $new_key = sanitize_key($_POST['new_slot_key'] ?? '');
        $new_label = sanitize_text_field($_POST['new_slot_label'] ?? '');
        if ($new_key && $new_label) {
            $id = Liturgus_Slots::create([
                'slot_key'         => $new_key,
                'label'            => $new_label,
                'positions'        => intval($_POST['new_slot_positions'] ?? 1),
                'backup_positions' => intval($_POST['new_slot_backup'] ?? 1),
            ]);
            if (!$id) {
                wp_redirect($redirect . '&slot_error=key_exists');
                exit;
            }
        }

        wp_redirect($redirect . '&saved=1');
        exit;
    }
}

