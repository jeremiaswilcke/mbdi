<?php
/**
 * Dashboard
 */
class Liturgus_Dashboard {
    
    public function __construct() {
        add_shortcode('liturgus_dashboard', [$this, 'render']);
        add_shortcode('liturgus_my_services', [$this, 'render']);
        add_shortcode('liturgus_schedule', [$this, 'render']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    }
    
    public function enqueue() {
        if (!is_singular()) return;
        $content = get_post()->post_content ?? '';
        if (!has_shortcode($content, 'liturgus_dashboard') 
            && !has_shortcode($content, 'liturgus_my_services')
            && !has_shortcode($content, 'liturgus_schedule')
            && !has_shortcode($content, 'isidor_app')
            && !str_contains($content, 'liturgus_')) {
            return;
        }
        
        wp_enqueue_style('liturgus', ISIDOR_SUITE_URL . 'assets/css/liturgus.css', [], ISIDOR_LITURGUS_VERSION);
        wp_enqueue_script('liturgus', ISIDOR_SUITE_URL . 'assets/js/liturgus.js', ['jquery'], ISIDOR_LITURGUS_VERSION, true);
        
        wp_localize_script('liturgus', 'liturgusData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('liturgus_nonce')
        ]);
    }
    
    public function render() {
        if (!is_user_logged_in()) {
            return '<p>Bitte einloggen um Dienste zu verwalten.</p>';
        }
        
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/liturgus/dashboard.php';
        return ob_get_clean();
    }
}
