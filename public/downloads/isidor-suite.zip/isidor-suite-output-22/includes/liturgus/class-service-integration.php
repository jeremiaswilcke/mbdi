<?php
/**
 * Liturgus Service Integration
 *
 * Verbindet das neue Permission-System mit Liturgus:
 * - Pro-Messe Slot-Konfiguration
 * - Dienst-basierte Signup-Filterung
 * - Dienst-basierte E-Mail-Steuerung
 * - Predigt-Berechtigung
 * - Liturgia-Override
 *
 * @package IsidorSuite
 * @since 12.0.0
 */

if (!defined('ABSPATH')) exit;

class Liturgus_Service_Integration {

    public static function init(): void {
        // Signup-Filter: User darf sich nur für zugewiesene Dienste eintragen
        add_filter('liturgus_can_signup', [self::class, 'filter_signup'], 10, 3);

        // Vacancy display: nur Dienste zeigen, die der User hat
        add_filter('liturgus_filter_vacant_slots', [self::class, 'filter_vacant_for_user'], 10, 2);

        // Email-Filter: nur an User mit passendem Dienst
        add_filter('liturgus_reminder_users', [self::class, 'filter_reminder_users'], 10, 2);

        // Admin: Messe-Slot-Konfiguration
        add_action('wp_ajax_liturgus_get_messe_slots', [self::class, 'ajax_get_messe_slots']);
        add_action('wp_ajax_liturgus_save_messe_slots', [self::class, 'ajax_save_messe_slots']);
    }

    // =========================================================================
    // DB TABLE
    // =========================================================================

    public static function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'liturgus_messe_slots';
    }

    public static function create_table(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table = self::table_name();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED NOT NULL,
            slot_key VARCHAR(50) NOT NULL,
            positions INT NOT NULL DEFAULT 1,
            backup_positions INT NOT NULL DEFAULT 0,
            is_disabled TINYINT(1) DEFAULT 0,
            custom_label VARCHAR(100) DEFAULT NULL,
            sort_order INT DEFAULT 0,
            UNIQUE KEY messe_slot (messe_id, slot_key),
            KEY idx_messe (messe_id)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    // =========================================================================
    // SLOT RESOLUTION: Global → Messe-spezifisch → Liturgia
    // =========================================================================

    /**
     * Mapping: slot_key → service_slug (für Berechtigungsprüfung)
     *
     * Verbindet die Liturgus-Slot-Keys mit den Service-Types
     * aus dem Permission-System.
     */
    private const SLOT_SERVICE_MAP = [
        'technik'          => 'technik',
        'mesner'           => 'mesner',
        'orgel'            => 'orgel',
        'band'             => 'orgel',     // Band = gleiche Berechtigung wie Orgel
        'kantor'           => 'kantor',
        'lektor_1'         => 'lesung',
        'lektor_2'         => 'lesung',
        'lektor_3'         => 'lesung',
        'lektor_4'         => 'lesung',
        'kommunionhelfer'  => 'kommunionhelfer',
        'ministranten'     => 'ministrant',
        'predigt'          => 'predigt',
        'kiwogo_leiter'    => 'kiwogo',
        'priester'         => 'diakon',    // Priester/Diakon
        'diakon'           => 'diakon',
        'liturg'           => 'liturg',
        'fuerbitten'       => 'fuerbitten',
        'vorsaenger'       => 'vorsaenger',
        'streaming'        => 'streaming',
    ];

    /**
     * Get the effective slot configuration for a specific Messe.
     *
     * Resolution order:
     * 1. Liturgia (highest priority) — if Liturgia has data for this Messe
     * 2. Messe-spezifische Slots — from liturgus_messe_slots table
     * 3. Global Slots — from liturgus_slots table (default)
     *
     * @param int $messe_id
     * @return array[] Slot-Array with keys: slot_key, label, positions, backup_positions, sort_order, source
     */
    public static function get_effective_slots(int $messe_id): array {
        // 1. Check Liturgia first (highest priority)
        $liturgia_slots = self::get_liturgia_override($messe_id);
        if ($liturgia_slots !== null) {
            return $liturgia_slots;
        }

        // 2. Check messe-specific config
        $messe_slots = self::get_messe_slot_config($messe_id);

        // 3. Start with global slots
        $global_slots = Liturgus_Slots::get_all();

        if (empty($messe_slots)) {
            // No messe-specific config → return global with source tag
            return array_map(function($s) {
                $s['source'] = 'global';
                return $s;
            }, $global_slots);
        }

        // Merge: messe-specific overrides global
        $result = [];
        $messe_by_key = [];
        foreach ($messe_slots as $ms) {
            $messe_by_key[$ms['slot_key']] = $ms;
        }

        foreach ($global_slots as $slot) {
            $key = $slot['slot_key'];

            if (isset($messe_by_key[$key])) {
                $override = $messe_by_key[$key];

                // Disabled? Skip this slot entirely
                if (!empty($override['is_disabled'])) {
                    continue;
                }

                // Apply overrides
                $slot['positions'] = (int) $override['positions'];
                $slot['backup_positions'] = (int) $override['backup_positions'];
                if (!empty($override['custom_label'])) {
                    $slot['label'] = $override['custom_label'];
                }
                if (isset($override['sort_order'])) {
                    $slot['sort_order'] = (int) $override['sort_order'];
                }
                $slot['source'] = 'messe';
            } else {
                $slot['source'] = 'global';
            }

            $result[] = $slot;
        }

        // Add any messe-only slots (not in global)
        $global_keys = array_column($global_slots, 'slot_key');
        foreach ($messe_slots as $ms) {
            if (!in_array($ms['slot_key'], $global_keys) && empty($ms['is_disabled'])) {
                $result[] = [
                    'slot_key'         => $ms['slot_key'],
                    'label'            => $ms['custom_label'] ?: $ms['slot_key'],
                    'positions'        => (int) $ms['positions'],
                    'backup_positions' => (int) $ms['backup_positions'],
                    'sort_order'       => (int) $ms['sort_order'],
                    'active'           => 1,
                    'source'           => 'messe',
                ];
            }
        }

        usort($result, fn($a, $b) => ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0));
        return $result;
    }

    /**
     * Get messe-specific slot configuration.
     */
    private static function get_messe_slot_config(int $messe_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::table_name() . " WHERE messe_id = %d ORDER BY sort_order",
            $messe_id
        ), ARRAY_A) ?: [];
    }

    /**
     * Check if Liturgia has overriding data for this Messe.
     * Returns slot config from Liturgia or null if not planned in Liturgia.
     */
    private static function get_liturgia_override(int $messe_id): ?array {
        // Check if Liturgia module is active and has data for this Messe
        if (!class_exists('Isidor_Liturgia_DB')) {
            return null;
        }

        // Liturgia stores plans by date — find the matching Liturgia plan
        $messe_date = get_post_meta($messe_id, '_is_date', true);
        $messe_time = get_post_meta($messe_id, '_is_time', true);
        if (!$messe_date) return null;

        global $wpdb;
        $liturgia_table = $wpdb->prefix . 'isidor_liturgia_services';

        // Check if this table exists (Liturgia might not be installed)
        if ($wpdb->get_var("SHOW TABLES LIKE '{$liturgia_table}'") !== $liturgia_table) {
            return null;
        }

        // Find Liturgia service plan for this date/time
        $liturgia_plan = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$liturgia_table}
             WHERE service_date = %s AND (service_time = %s OR service_time IS NULL)
             ORDER BY sort_order",
            $messe_date, $messe_time
        ), ARRAY_A);

        if (empty($liturgia_plan)) {
            return null; // No Liturgia data → fall through to messe/global
        }

        // Convert Liturgia elements to Liturgus slot format
        $slots = [];
        foreach ($liturgia_plan as $element) {
            // Map Liturgia element types to Liturgus slot keys
            $slot_key = self::map_liturgia_to_slot($element);
            if (!$slot_key) continue;

            // Check if already in result (merge positions)
            $found = false;
            foreach ($slots as &$s) {
                if ($s['slot_key'] === $slot_key) {
                    $s['positions']++;
                    $found = true;
                    break;
                }
            }
            unset($s);

            if (!$found) {
                $slots[] = [
                    'slot_key'         => $slot_key,
                    'label'            => $element['label'] ?? $slot_key,
                    'positions'        => 1,
                    'backup_positions' => 0,
                    'sort_order'       => (int) ($element['sort_order'] ?? 0),
                    'active'           => 1,
                    'source'           => 'liturgia',
                ];
            }
        }

        return !empty($slots) ? $slots : null;
    }

    /**
     * Map a Liturgia element to a Liturgus slot_key.
     * Override this mapping as Liturgia evolves.
     */
    private static function map_liturgia_to_slot(array $element): ?string {
        $type = $element['element_type'] ?? $element['type'] ?? '';
        $map = [
            'lesung'           => 'lektor_1',
            'lesung_1'         => 'lektor_1',
            'lesung_2'         => 'lektor_2',
            'fuerbitten'       => 'lektor_1',
            'kommunion'        => 'kommunionhelfer',
            'kommunionhelfer'  => 'kommunionhelfer',
            'predigt'          => 'predigt',
            'musik'            => 'orgel',
            'orgel'            => 'orgel',
            'kantor'           => 'kantor',
            'ministrant'       => 'ministranten',
            'ministranten'     => 'ministranten',
            'mesner'           => 'mesner',
            'technik'          => 'technik',
            'kindergottesdienst' => 'kiwogo_leiter',
        ];
        return $map[$type] ?? null;
    }

    // =========================================================================
    // SIGNUP FILTER
    // =========================================================================

    /**
     * Filter: Darf dieser User sich für diesen Slot eintragen?
     *
     * Prüft:
     * 1. Hat User die liturgus_signup Capability? (Grundvoraussetzung)
     * 2. Hat User den passenden Dienst zugewiesen? (Service-Match)
     * 3. Predigt: Nur mit liturgus_predigt Capability
     *
     * @param bool   $can_signup   Current permission state
     * @param string $slot_key     The slot being signed up for
     * @param int    $user_id      User ID
     * @return bool
     */
    public static function filter_signup(bool $can_signup, string $slot_key, int $user_id): bool {
        if (!$can_signup) return false;

        // Admins, Pfarrer, Sekretär can always signup (via role)
        if (user_can($user_id, 'manage_options') ||
            user_can($user_id, 'isidor_manage_templates')) {
            return true;
        }

        // Predigt: special check
        if ($slot_key === 'predigt') {
            return user_can($user_id, 'liturgus_predigt');
        }

        // Map slot_key to service_slug
        $service_slug = self::SLOT_SERVICE_MAP[$slot_key] ?? null;
        if (!$service_slug) {
            // Unknown/custom slot → only allow users with liturgus_manage capability
            return user_can($user_id, 'liturgus_manage');
        }

        // Check if user has this service assigned
        $perms = Isidor_Permissions::get_instance();
        $user_services = $perms->get_effective_services($user_id);

        return in_array($service_slug, $user_services, true);
    }

    /**
     * Filter vacant slots for display: only show slots the user can sign up for.
     */
    public static function filter_vacant_for_user(array $vacant_slots, int $user_id): array {
        // Admins see everything
        if (user_can($user_id, 'manage_options') || user_can($user_id, 'liturgus_manage')) {
            return $vacant_slots;
        }

        $perms = Isidor_Permissions::get_instance();
        $user_services = $perms->get_effective_services($user_id);

        return array_filter($vacant_slots, function($slot) use ($user_services, $user_id) {
            $key = $slot['slot_key'];

            // Predigt: special
            if ($key === 'predigt') {
                return user_can($user_id, 'liturgus_predigt');
            }

            $service = self::SLOT_SERVICE_MAP[$key] ?? null;
            if (!$service) return user_can($user_id, 'liturgus_manage'); // Unknown/custom → managers only

            return in_array($service, $user_services, true);
        });
    }

    // =========================================================================
    // EMAIL FILTER
    // =========================================================================

    /**
     * Filter: Welche User bekommen die Erinnerungs-Email für einen Slot?
     *
     * Statt alle User mit liturgus_signup zu nehmen, werden nur die
     * User genommen, die den passenden Dienst zugewiesen haben.
     *
     * @param array  $users     Current user list
     * @param string $slot_key  The slot with vacancies
     * @return array Filtered user list
     */
    public static function filter_reminder_users(array $users, string $slot_key): array {
        $service = self::SLOT_SERVICE_MAP[$slot_key] ?? null;
        if (!$service) return $users;

        $eligible_user_ids = Isidor_Permissions::get_users_for_service($service);

        return array_filter($users, function($user) use ($eligible_user_ids) {
            $uid = is_object($user) ? $user->ID : (int) $user;
            return in_array($uid, $eligible_user_ids, true);
        });
    }

    // =========================================================================
    // MESSE SLOT CONFIG (AJAX for Admin/Frontend)
    // =========================================================================

    /**
     * Get the slot configuration for a specific Messe.
     * Returns both global defaults and messe-specific overrides.
     */
    public static function ajax_get_messe_slots(): void {
        check_ajax_referer('liturgus_nonce', 'nonce');

        if (!current_user_can('liturgus_manage')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $messe_id = intval($_POST['messe_id'] ?? $_GET['messe_id'] ?? 0);
        if (!$messe_id) wp_send_json_error(['message' => 'Keine Messe angegeben']);

        $effective = self::get_effective_slots($messe_id);
        $global = Liturgus_Slots::get_all();
        $messe_config = self::get_messe_slot_config($messe_id);

        wp_send_json_success([
            'effective' => $effective,
            'global'    => $global,
            'messe'     => $messe_config,
            'messe_id'  => $messe_id,
        ]);
    }

    /**
     * Save messe-specific slot configuration.
     *
     * Expects POST data:
     * - messe_id: int
     * - slots: array of {slot_key, positions, backup_positions, is_disabled, custom_label, sort_order}
     * - reset: bool (optional) — reset to global defaults
     */
    public static function ajax_save_messe_slots(): void {
        check_ajax_referer('liturgus_nonce', 'nonce');

        if (!current_user_can('liturgus_manage')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }

        $messe_id = intval($_POST['messe_id'] ?? 0);
        if (!$messe_id) wp_send_json_error(['message' => 'Keine Messe angegeben']);

        global $wpdb;
        $table = self::table_name();

        // Reset? Delete all messe-specific config
        if (!empty($_POST['reset'])) {
            $wpdb->delete($table, ['messe_id' => $messe_id]);
            wp_send_json_success(['message' => 'Auf Standard zurückgesetzt']);
            return;
        }

        // Parse slots from JSON
        $slots_raw = $_POST['slots'] ?? '[]';
        if (is_string($slots_raw)) {
            $slots = json_decode(stripslashes($slots_raw), true);
        } else {
            $slots = $slots_raw;
        }

        if (!is_array($slots)) {
            wp_send_json_error(['message' => 'Ungültige Daten']);
            return;
        }

        // Delete existing config for this messe
        $wpdb->delete($table, ['messe_id' => $messe_id]);

        // Insert new config
        foreach ($slots as $s) {
            if (empty($s['slot_key'])) continue;
            $wpdb->insert($table, [
                'messe_id'         => $messe_id,
                'slot_key'         => sanitize_key($s['slot_key']),
                'positions'        => intval($s['positions'] ?? 1),
                'backup_positions' => intval($s['backup_positions'] ?? 0),
                'is_disabled'      => intval($s['is_disabled'] ?? 0),
                'custom_label'     => sanitize_text_field($s['custom_label'] ?? ''),
                'sort_order'       => intval($s['sort_order'] ?? 0),
            ]);
        }

        wp_send_json_success([
            'message'   => 'Gespeichert',
            'effective' => self::get_effective_slots($messe_id),
        ]);
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Get the service_slug for a slot_key.
     */
    public static function get_service_for_slot(string $slot_key): ?string {
        return self::SLOT_SERVICE_MAP[$slot_key] ?? null;
    }

    /**
     * Get all slot-to-service mappings.
     */
    public static function get_slot_service_map(): array {
        return self::SLOT_SERVICE_MAP;
    }
}
