<?php
/**
 * Slots Management — Global Default Template
 */
class Liturgus_Slots {

    public function __construct() {}

    public static function get_all() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}liturgus_slots WHERE active = 1 ORDER BY sort_order",
            ARRAY_A
        );
    }

    public static function get_all_including_inactive() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}liturgus_slots ORDER BY sort_order",
            ARRAY_A
        );
    }

    public static function get($slot_key) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}liturgus_slots WHERE slot_key = %s", $slot_key),
            ARRAY_A
        );
    }

    public static function create(array $data): ?int {
        global $wpdb;
        $slot_key = sanitize_key($data['slot_key'] ?? '');
        $label = sanitize_text_field($data['label'] ?? '');
        if (empty($slot_key) || empty($label)) return null;
        if (self::get($slot_key)) return null;

        $max = (int) $wpdb->get_var("SELECT MAX(sort_order) FROM {$wpdb->prefix}liturgus_slots");
        $wpdb->insert($wpdb->prefix . 'liturgus_slots', [
            'slot_key'         => $slot_key,
            'label'            => $label,
            'positions'        => max(1, intval($data['positions'] ?? 1)),
            'backup_positions' => max(0, intval($data['backup_positions'] ?? 1)),
            'sort_order'       => $max + 10,
            'active'           => 1,
        ]);
        return $wpdb->insert_id ?: null;
    }

    public static function update(string $slot_key, array $data): bool {
        global $wpdb;
        $update = [];
        if (isset($data['label'])) $update['label'] = sanitize_text_field($data['label']);
        if (isset($data['positions'])) $update['positions'] = max(1, intval($data['positions']));
        if (isset($data['backup_positions'])) $update['backup_positions'] = max(0, intval($data['backup_positions']));
        if (isset($data['sort_order'])) $update['sort_order'] = intval($data['sort_order']);
        if (isset($data['active'])) $update['active'] = $data['active'] ? 1 : 0;
        if (empty($update)) return false;
        return (bool) $wpdb->update($wpdb->prefix . 'liturgus_slots', $update, ['slot_key' => $slot_key]);
    }

    public static function delete(string $slot_key): bool {
        global $wpdb;
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}liturgus_assignments WHERE slot_key = %s", $slot_key
        ));
        if ($count > 0) return false;
        return (bool) $wpdb->delete($wpdb->prefix . 'liturgus_slots', ['slot_key' => $slot_key]);
    }

    public static function update_sort_order(array $order): void {
        global $wpdb;
        foreach ($order as $i => $slot_key) {
            $wpdb->update($wpdb->prefix . 'liturgus_slots', ['sort_order' => ($i + 1) * 10], ['slot_key' => sanitize_key($slot_key)]);
        }
    }
}
