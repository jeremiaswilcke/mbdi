<?php

/**
 * Isidor Matrikel — Sakramentenverwaltung
 */

if (!defined('ABSPATH')) exit;

class Isidor_Matrikel {
    
    private static $instance = null;
    
    public const TYPES = [
        'taufe'     => ['label' => 'Taufe', 'icon' => '💧', 'color' => '#0ea5e9'],
        'firmung'   => ['label' => 'Firmung', 'icon' => '🔥', 'color' => '#f97316'],
        'hochzeit'  => ['label' => 'Hochzeit', 'icon' => '💒', 'color' => '#ec4899'],
        'begraebnis'=> ['label' => 'Begräbnis', 'icon' => '🕯️', 'color' => '#6b7280'],
    ];
    
    public const STATUS = [
        'anfrage'   => ['label' => 'Anfrage', 'color' => '#f59e0b'],
        'geplant'   => ['label' => 'Geplant', 'color' => '#3b82f6'],
        'vorbereitung' => ['label' => 'In Vorbereitung', 'color' => '#8b5cf6'],
        'bestaetigt'=> ['label' => 'Bestätigt', 'color' => '#10b981'],
        'abgeschlossen' => ['label' => 'Abgeschlossen', 'color' => '#6b7280'],
        'storniert' => ['label' => 'Storniert', 'color' => '#ef4444'],
    ];
    
    public const CHECKLISTS = [
        'taufe' => [
            'Taufgespräch geführt',
            'Geburtsurkunde vorhanden',
            'Paten-Daten vollständig',
            'Taufkerze besorgt',
            'Taufkleid vorbereitet',
            'Termin bestätigt',
            'Matrikeleintrag erstellt',
        ],
        'hochzeit' => [
            'Erstes Brautgespräch',
            'Ehevorbereitungskurs',
            'Taufscheine beider Partner',
            'Ledigenbestätigung/Firmnachweis',
            'Aufgebot bestellt',
            'Kirchenmusik geklärt',
            'Blumenschmuck organisiert',
            'Trauzeugen-Daten vollständig',
            'Zweites Brautgespräch',
            'Termin bestätigt',
            'Matrikeleintrag erstellt',
        ],
        'begraebnis' => [
            'Totengespräch geführt',
            'Sterbeurkunde vorhanden',
            'Termin mit Bestattung abgestimmt',
            'Ablauf besprochen',
            'Lieder ausgewählt',
            'Parte/Gedenkbild',
            'Matrikeleintrag erstellt',
        ],
        'firmung' => [
            'Anmeldung eingegangen',
            'Taufschein vorhanden',
            'Firmvorbereitung abgeschlossen',
            'Pate bestätigt',
            'Firmname gewählt',
            'Matrikeleintrag erstellt',
        ],
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        register_activation_hook(ISIDOR_SUITE_FILE, [$this, 'activate']);
        add_action('admin_menu', [$this, 'add_admin_menu'], 26);
        add_action('admin_init', [$this, 'handle_admin_actions']);
        add_action('admin_init', [$this, 'maybe_setup_capabilities']);
    }
    
    /**
     * Capabilities einmalig setzen (nach Update)
     */
    public function maybe_setup_capabilities(): void {
        if (get_option('isidor_matrikel_caps_set') !== ISIDOR_SUITE_VERSION) {
            $this->setup_capabilities();
            update_option('isidor_matrikel_caps_set', ISIDOR_SUITE_VERSION);
        }
    }
    
    public function activate(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        // Fälle
        $sql_cases = "CREATE TABLE {$wpdb->prefix}isidor_matrikel_cases (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'anfrage',
            person_name VARCHAR(200) NOT NULL,
            person_birth_date DATE NULL,
            person_address TEXT NULL,
            person_phone VARCHAR(50) NULL,
            person_email VARCHAR(100) NULL,
            partner_name VARCHAR(200) NULL,
            partner_birth_date DATE NULL,
            parent1_name VARCHAR(200) NULL,
            parent2_name VARCHAR(200) NULL,
            sponsor1_name VARCHAR(200) NULL,
            sponsor1_address TEXT NULL,
            sponsor2_name VARCHAR(200) NULL,
            sponsor2_address TEXT NULL,
            ceremony_date DATE NULL,
            ceremony_time TIME NULL,
            ceremony_location VARCHAR(200) NULL,
            celebrant VARCHAR(100) NULL,
            death_date DATE NULL,
            burial_type VARCHAR(50) NULL,
            cemetery VARCHAR(200) NULL,
            notes TEXT NULL,
            internal_notes TEXT NULL,
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            KEY type (type),
            KEY status (status),
            KEY ceremony_date (ceremony_date)
        ) $charset;";
        dbDelta($sql_cases);
        
        // Termine
        $sql_appointments = "CREATE TABLE {$wpdb->prefix}isidor_matrikel_appointments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            case_id BIGINT UNSIGNED NOT NULL,
            title VARCHAR(200) NOT NULL,
            appointment_date DATETIME NOT NULL,
            duration_minutes INT DEFAULT 60,
            location VARCHAR(200) NULL,
            notes TEXT NULL,
            completed TINYINT(1) DEFAULT 0,
            created_at DATETIME NOT NULL,
            KEY case_id (case_id)
        ) $charset;";
        dbDelta($sql_appointments);
        
        // Dokumente/Checklisten
        $sql_documents = "CREATE TABLE {$wpdb->prefix}isidor_matrikel_documents (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            case_id BIGINT UNSIGNED NOT NULL,
            type ENUM('checklist', 'document') NOT NULL DEFAULT 'checklist',
            title VARCHAR(200) NOT NULL,
            file_url VARCHAR(500) NULL,
            completed TINYINT(1) DEFAULT 0,
            completed_at DATETIME NULL,
            completed_by BIGINT UNSIGNED NULL,
            notes TEXT NULL,
            sort_order INT DEFAULT 0,
            created_at DATETIME NOT NULL,
            KEY case_id (case_id)
        ) $charset;";
        dbDelta($sql_documents);
        
        // Gebühren
        $sql_fees = "CREATE TABLE {$wpdb->prefix}isidor_matrikel_fees (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            case_id BIGINT UNSIGNED NOT NULL,
            description VARCHAR(200) NOT NULL,
            amount_cents INT NOT NULL,
            type ENUM('fee', 'stipend', 'donation', 'other') DEFAULT 'fee',
            status ENUM('pending', 'paid', 'waived') DEFAULT 'pending',
            paid_at DATETIME NULL,
            payment_method VARCHAR(50) NULL,
            notes TEXT NULL,
            created_at DATETIME NOT NULL,
            KEY case_id (case_id)
        ) $charset;";
        dbDelta($sql_fees);
        
        $this->setup_capabilities();
    }
    
    private function setup_capabilities(): void {
        $admin_roles = ['administrator', 'isidor_pfarrer_godmode', 'isidor_sekretaer'];
        foreach ($admin_roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('isidor_matrikel_view');
                $role->add_cap('isidor_matrikel_edit');
                $role->add_cap('isidor_matrikel_delete');
                $role->add_cap('isidor_matrikel_admin');
            }
        }
        $role = get_role('isidor_diakon');
        if ($role) {
            $role->add_cap('isidor_matrikel_view');
            $role->add_cap('isidor_matrikel_edit');
        }
    }
    
    public function add_admin_menu(): void {
        // Use manage_options as fallback for admins who don't have the custom cap yet
        $cap = current_user_can('isidor_matrikel_view') ? 'isidor_matrikel_view' : 'manage_options';
        add_submenu_page('isidor-os', 'Matrikel', '📜 Matrikel', $cap, 'isidor-matrikel', [$this, 'render_admin_page']);
        add_submenu_page(null, 'Fall bearbeiten', '', $cap, 'isidor-matrikel-edit', [$this, 'render_edit_page']);
    }
    
    public function handle_admin_actions(): void {
        if (!isset($_POST['isidor_matrikel_action'])) return;
        $action = sanitize_text_field($_POST['isidor_matrikel_action']);
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'isidor_matrikel_' . $action)) {
            wp_die('Sicherheitsprüfung fehlgeschlagen');
        }
        
        switch ($action) {
            case 'save_case': $this->save_case(); break;
            case 'delete_case': $this->delete_case(); break;
            case 'toggle_checklist': $this->toggle_checklist_item(); break;
            case 'add_appointment': $this->add_appointment(); break;
            case 'add_fee': $this->add_fee(); break;
            case 'mark_fee_paid': $this->mark_fee_paid(); break;
        }
    }
    
    private function save_case(): void {
        if (!current_user_can('isidor_matrikel_edit')) wp_die('Keine Berechtigung');
        global $wpdb;
        
        $case_id = (int)($_POST['case_id'] ?? 0);
        $now = current_time('mysql');
        $type = sanitize_text_field($_POST['type'] ?? 'taufe');
        
        $data = [
            'type' => $type,
            'status' => sanitize_text_field($_POST['status'] ?? 'anfrage'),
            'person_name' => sanitize_text_field($_POST['person_name'] ?? ''),
            'person_birth_date' => $this->sanitize_date($_POST['person_birth_date'] ?? ''),
            'person_address' => sanitize_textarea_field($_POST['person_address'] ?? ''),
            'person_phone' => sanitize_text_field($_POST['person_phone'] ?? ''),
            'person_email' => sanitize_email($_POST['person_email'] ?? ''),
            'partner_name' => sanitize_text_field($_POST['partner_name'] ?? ''),
            'partner_birth_date' => $this->sanitize_date($_POST['partner_birth_date'] ?? ''),
            'parent1_name' => sanitize_text_field($_POST['parent1_name'] ?? ''),
            'parent2_name' => sanitize_text_field($_POST['parent2_name'] ?? ''),
            'sponsor1_name' => sanitize_text_field($_POST['sponsor1_name'] ?? ''),
            'sponsor1_address' => sanitize_textarea_field($_POST['sponsor1_address'] ?? ''),
            'sponsor2_name' => sanitize_text_field($_POST['sponsor2_name'] ?? ''),
            'sponsor2_address' => sanitize_textarea_field($_POST['sponsor2_address'] ?? ''),
            'ceremony_date' => $this->sanitize_date($_POST['ceremony_date'] ?? ''),
            'ceremony_time' => sanitize_text_field($_POST['ceremony_time'] ?? ''),
            'ceremony_location' => sanitize_text_field($_POST['ceremony_location'] ?? ''),
            'celebrant' => sanitize_text_field($_POST['celebrant'] ?? ''),
            'death_date' => $this->sanitize_date($_POST['death_date'] ?? ''),
            'burial_type' => sanitize_text_field($_POST['burial_type'] ?? ''),
            'cemetery' => sanitize_text_field($_POST['cemetery'] ?? ''),
            'notes' => sanitize_textarea_field($_POST['notes'] ?? ''),
            'internal_notes' => sanitize_textarea_field($_POST['internal_notes'] ?? ''),
            'updated_at' => $now,
        ];
        
        if ($case_id > 0) {
            $wpdb->update($wpdb->prefix . 'isidor_matrikel_cases', $data, ['id' => $case_id]);
        } else {
            $data['created_by'] = get_current_user_id();
            $data['created_at'] = $now;
            $wpdb->insert($wpdb->prefix . 'isidor_matrikel_cases', $data);
            $case_id = (int)$wpdb->insert_id;
            
            // Checkliste erstellen
            if (isset(self::CHECKLISTS[$type])) {
                $order = 0;
                foreach (self::CHECKLISTS[$type] as $item) {
                    $wpdb->insert($wpdb->prefix . 'isidor_matrikel_documents', [
                        'case_id' => $case_id,
                        'type' => 'checklist',
                        'title' => $item,
                        'sort_order' => $order++,
                        'created_at' => $now,
                    ]);
                }
            }
        }
        
        wp_redirect(admin_url('admin.php?page=isidor-matrikel-edit&id=' . $case_id . '&saved=1'));
        exit;
    }
    
    private function delete_case(): void {
        if (!current_user_can('isidor_matrikel_delete')) wp_die('Keine Berechtigung');
        global $wpdb;
        $case_id = (int)($_POST['case_id'] ?? 0);
        if ($case_id <= 0) wp_die('Ungültige ID');
        
        $wpdb->delete($wpdb->prefix . 'isidor_matrikel_cases', ['id' => $case_id]);
        $wpdb->delete($wpdb->prefix . 'isidor_matrikel_appointments', ['case_id' => $case_id]);
        $wpdb->delete($wpdb->prefix . 'isidor_matrikel_documents', ['case_id' => $case_id]);
        $wpdb->delete($wpdb->prefix . 'isidor_matrikel_fees', ['case_id' => $case_id]);
        
        wp_redirect(admin_url('admin.php?page=isidor-matrikel&deleted=1'));
        exit;
    }
    
    private function toggle_checklist_item(): void {
        global $wpdb;
        $item_id = (int)($_POST['item_id'] ?? 0);
        $completed = (int)($_POST['completed'] ?? 0);
        
        $wpdb->update($wpdb->prefix . 'isidor_matrikel_documents', [
            'completed' => $completed,
            'completed_at' => $completed ? current_time('mysql') : null,
            'completed_by' => $completed ? get_current_user_id() : null,
        ], ['id' => $item_id]);
        
        wp_send_json_success();
    }
    
    private function add_appointment(): void {
        global $wpdb;
        $case_id = (int)($_POST['case_id'] ?? 0);
        
        $wpdb->insert($wpdb->prefix . 'isidor_matrikel_appointments', [
            'case_id' => $case_id,
            'title' => sanitize_text_field($_POST['appt_title'] ?? ''),
            'appointment_date' => sanitize_text_field($_POST['appt_date'] ?? '') . ' ' . sanitize_text_field($_POST['appt_time'] ?? '00:00'),
            'duration_minutes' => (int)($_POST['appt_duration'] ?? 60),
            'location' => sanitize_text_field($_POST['appt_location'] ?? ''),
            'notes' => sanitize_textarea_field($_POST['appt_notes'] ?? ''),
            'created_at' => current_time('mysql'),
        ]);
        
        wp_redirect(admin_url('admin.php?page=isidor-matrikel-edit&id=' . $case_id . '&tab=appointments'));
        exit;
    }
    
    private function add_fee(): void {
        global $wpdb;
        $case_id = (int)($_POST['case_id'] ?? 0);
        $amount = (float)($_POST['fee_amount'] ?? 0);
        
        $wpdb->insert($wpdb->prefix . 'isidor_matrikel_fees', [
            'case_id' => $case_id,
            'description' => sanitize_text_field($_POST['fee_description'] ?? ''),
            'amount_cents' => (int)($amount * 100),
            'type' => sanitize_text_field($_POST['fee_type'] ?? 'fee'),
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ]);
        
        wp_redirect(admin_url('admin.php?page=isidor-matrikel-edit&id=' . $case_id . '&tab=fees'));
        exit;
    }
    
    private function mark_fee_paid(): void {
        global $wpdb;
        $fee_id = (int)($_POST['fee_id'] ?? 0);
        $case_id = (int)($_POST['case_id'] ?? 0);
        
        $wpdb->update($wpdb->prefix . 'isidor_matrikel_fees', [
            'status' => 'paid',
            'paid_at' => current_time('mysql'),
            'payment_method' => sanitize_text_field($_POST['payment_method'] ?? 'bar'),
        ], ['id' => $fee_id]);
        
        wp_redirect(admin_url('admin.php?page=isidor-matrikel-edit&id=' . $case_id . '&tab=fees'));
        exit;
    }
    
    private function sanitize_date(?string $date){
        if (empty($date)) return null;
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return $date;
        return null;
    }
    
    public function get_case(int $id): ?object {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_matrikel_cases WHERE id = %d", $id
        ));
    }
    
    public function get_cases(array $args = []): array {
        global $wpdb;
        $where = ['1=1'];
        $params = [];
        
        if (!empty($args['type'])) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        if (!empty($args['status'])) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        if (!empty($args['search'])) {
            $where[] = '(person_name LIKE %s OR partner_name LIKE %s)';
            $params[] = '%' . $wpdb->esc_like($args['search']) . '%';
            $params[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }
        
        $order = $args['order'] ?? 'ceremony_date DESC';
        $limit = $args['limit'] ?? 50;
        
        $sql = "SELECT * FROM {$wpdb->prefix}isidor_matrikel_cases WHERE " . implode(' AND ', $where) . " ORDER BY {$order} LIMIT {$limit}";
        
        return $wpdb->get_results(empty($params) ? $sql : $wpdb->prepare($sql, $params));
    }
    
    public function get_appointments(int $case_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_matrikel_appointments WHERE case_id = %d ORDER BY appointment_date", $case_id
        ));
    }
    
    public function get_checklist(int $case_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_matrikel_documents WHERE case_id = %d ORDER BY sort_order", $case_id
        ));
    }
    
    public function get_fees(int $case_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_matrikel_fees WHERE case_id = %d ORDER BY created_at", $case_id
        ));
    }
    
    public function get_checklist_progress(int $case_id): array {
        global $wpdb;
        $total = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_matrikel_documents WHERE case_id = %d AND type = 'checklist'", $case_id
        ));
        $done = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_matrikel_documents WHERE case_id = %d AND type = 'checklist' AND completed = 1", $case_id
        ));
        return ['total' => $total, 'done' => $done, 'percent' => $total > 0 ? round($done / $total * 100) : 0];
    }
    
    public function get_fee_summary(int $case_id): array {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT status, SUM(amount_cents) as total FROM {$wpdb->prefix}isidor_matrikel_fees WHERE case_id = %d GROUP BY status", $case_id
        ), OBJECT_K);
        return [
            'pending' => ($rows['pending']->total ?? 0) / 100,
            'paid' => ($rows['paid']->total ?? 0) / 100,
        ];
    }
    
    /* ================================================================
       ADMIN PAGES
       ================================================================ */
    
    public function render_admin_page(): void {
        $type_filter = sanitize_text_field($_GET['type'] ?? '');
        $status_filter = sanitize_text_field($_GET['status'] ?? '');
        $search = sanitize_text_field($_GET['s'] ?? '');
        
        $cases = $this->get_cases([
            'type' => $type_filter,
            'status' => $status_filter,
            'search' => $search,
        ]);
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">📜 Matrikel — Sakramentenverwaltung</h1>
            <a href="<?php echo admin_url('admin.php?page=isidor-matrikel-edit'); ?>" class="page-title-action">+ Neuer Fall</a>
            
            <!-- Filter -->
            <form method="get" style="margin:20px 0; display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="page" value="isidor-matrikel">
                
                <select name="type">
                    <option value="">Alle Typen</option>
                    <?php foreach (self::TYPES as $key => $t): ?>
                        <option value="<?php echo $key; ?>" <?php selected($type_filter, $key); ?>><?php echo $t['icon'] . ' ' . $t['label']; ?></option>
                    <?php endforeach; ?>
                </select>
                
                <select name="status">
                    <option value="">Alle Status</option>
                    <?php foreach (self::STATUS as $key => $s): ?>
                        <option value="<?php echo $key; ?>" <?php selected($status_filter, $key); ?>><?php echo $s['label']; ?></option>
                    <?php endforeach; ?>
                </select>
                
                <input type="text" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Suche..." style="width:200px;">
                <button type="submit" class="button">Filtern</button>
            </form>
            
            <!-- Tabelle -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:40px;">Typ</th>
                        <th>Name</th>
                        <th>Datum</th>
                        <th>Status</th>
                        <th>Checkliste</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cases)): ?>
                        <tr><td colspan="6">Keine Fälle gefunden.</td></tr>
                    <?php else: foreach ($cases as $c): 
                        $t = self::TYPES[$c->type] ?? ['icon' => '?', 'label' => $c->type];
                        $s = self::STATUS[$c->status] ?? ['label' => $c->status, 'color' => '#666'];
                        $progress = $this->get_checklist_progress($c->id);
                    ?>
                        <tr>
                            <td title="<?php echo esc_attr($t['label']); ?>"><?php echo $t['icon']; ?></td>
                            <td>
                                <strong><a href="<?php echo admin_url('admin.php?page=isidor-matrikel-edit&id=' . $c->id); ?>">
                                    <?php echo esc_html($c->person_name); ?>
                                </a></strong>
                                <?php if ($c->partner_name): ?>
                                    <br><small>& <?php echo esc_html($c->partner_name); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($c->ceremony_date): ?>
                                    <?php echo date('d.m.Y', strtotime($c->ceremony_date)); ?>
                                    <?php if ($c->ceremony_time): echo ' ' . substr($c->ceremony_time, 0, 5); endif; ?>
                                <?php else: ?>
                                    <span style="opacity:0.5;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="background:<?php echo $s['color']; ?>; color:#fff; padding:2px 8px; border-radius:4px; font-size:0.8em;">
                                    <?php echo esc_html($s['label']); ?>
                                </span>
                            </td>
                            <td>
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <div style="flex:1; height:6px; background:#e5e7eb; border-radius:3px; overflow:hidden;">
                                        <div style="width:<?php echo $progress['percent']; ?>%; height:100%; background:#10b981;"></div>
                                    </div>
                                    <span style="font-size:0.8em; color:#666;"><?php echo $progress['done']; ?>/<?php echo $progress['total']; ?></span>
                                </div>
                            </td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=isidor-matrikel-edit&id=' . $c->id); ?>" class="button button-small">Bearbeiten</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public function render_edit_page(): void {
        $case_id = (int)($_GET['id'] ?? 0);
        $case = $case_id > 0 ? $this->get_case($case_id) : null;
        $is_new = !$case;
        $tab = sanitize_text_field($_GET['tab'] ?? 'details');
        
        $appointments = $case ? $this->get_appointments($case_id) : [];
        $checklist = $case ? $this->get_checklist($case_id) : [];
        $fees = $case ? $this->get_fees($case_id) : [];
        $progress = $case ? $this->get_checklist_progress($case_id) : ['total' => 0, 'done' => 0, 'percent' => 0];
        $fee_summary = $case ? $this->get_fee_summary($case_id) : ['pending' => 0, 'paid' => 0];
        
        $type = $case->type ?? 'taufe';
        $type_info = self::TYPES[$type] ?? self::TYPES['taufe'];
        ?>
        <div class="wrap">
            <h1>
                <?php if ($is_new): ?>
                    📜 Neuer Sakramentsfall
                <?php else: ?>
                    <?php echo $type_info['icon']; ?> <?php echo esc_html($case->person_name); ?>
                    <?php if ($case->partner_name): ?> & <?php echo esc_html($case->partner_name); ?><?php endif; ?>
                <?php endif; ?>
            </h1>
            
            <?php if (isset($_GET['saved'])): ?>
                <div class="notice notice-success is-dismissible"><p>✓ Gespeichert!</p></div>
            <?php endif; ?>
            
            <?php if (!$is_new): ?>
            <!-- Tabs -->
            <nav class="nav-tab-wrapper" style="margin-bottom:20px;">
                <a href="?page=isidor-matrikel-edit&id=<?php echo $case_id; ?>&tab=details" 
                   class="nav-tab <?php echo $tab === 'details' ? 'nav-tab-active' : ''; ?>">📋 Details</a>
                <a href="?page=isidor-matrikel-edit&id=<?php echo $case_id; ?>&tab=checklist" 
                   class="nav-tab <?php echo $tab === 'checklist' ? 'nav-tab-active' : ''; ?>">
                   ✓ Checkliste <span style="background:#10b981; color:#fff; padding:1px 6px; border-radius:10px; font-size:0.8em; margin-left:4px;"><?php echo $progress['done']; ?>/<?php echo $progress['total']; ?></span>
                </a>
                <a href="?page=isidor-matrikel-edit&id=<?php echo $case_id; ?>&tab=appointments" 
                   class="nav-tab <?php echo $tab === 'appointments' ? 'nav-tab-active' : ''; ?>">📅 Termine</a>
                <a href="?page=isidor-matrikel-edit&id=<?php echo $case_id; ?>&tab=fees" 
                   class="nav-tab <?php echo $tab === 'fees' ? 'nav-tab-active' : ''; ?>">
                   💰 Gebühren <?php if ($fee_summary['pending'] > 0): ?><span style="background:#f59e0b; color:#fff; padding:1px 6px; border-radius:10px; font-size:0.8em;">€<?php echo number_format($fee_summary['pending'], 2, ',', '.'); ?></span><?php endif; ?>
                </a>
            </nav>
            <?php endif; ?>
            
            <?php if ($is_new || $tab === 'details'): ?>
                <?php $this->render_details_form($case); ?>
            <?php elseif ($tab === 'checklist'): ?>
                <?php $this->render_checklist_tab($case_id, $checklist); ?>
            <?php elseif ($tab === 'appointments'): ?>
                <?php $this->render_appointments_tab($case_id, $appointments); ?>
            <?php elseif ($tab === 'fees'): ?>
                <?php $this->render_fees_tab($case_id, $fees); ?>
            <?php endif; ?>
        </div>
        <?php
    }
    
    private function render_details_form(?object $case): void {
        $is_new = !$case;
        ?>
        <form method="post" style="max-width:900px;">
            <?php wp_nonce_field('isidor_matrikel_save_case'); ?>
            <input type="hidden" name="isidor_matrikel_action" value="save_case">
            <input type="hidden" name="case_id" value="<?php echo $case->id ?? 0; ?>">
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                <!-- Linke Spalte -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top:0;">Grunddaten</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th>Typ</th>
                            <td>
                                <select name="type" id="case_type" <?php echo !$is_new ? 'disabled' : ''; ?> style="width:100%;">
                                    <?php foreach (self::TYPES as $key => $t): ?>
                                        <option value="<?php echo $key; ?>" <?php selected($case->type ?? 'taufe', $key); ?>><?php echo $t['icon'] . ' ' . $t['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (!$is_new): ?><input type="hidden" name="type" value="<?php echo $case->type; ?>"><?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <select name="status" style="width:100%;">
                                    <?php foreach (self::STATUS as $key => $s): ?>
                                        <option value="<?php echo $key; ?>" <?php selected($case->status ?? 'anfrage', $key); ?>><?php echo $s['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>Name *</th>
                            <td><input type="text" name="person_name" value="<?php echo esc_attr($case->person_name ?? ''); ?>" required style="width:100%;"></td>
                        </tr>
                        <tr>
                            <th>Geburtsdatum</th>
                            <td><input type="date" name="person_birth_date" value="<?php echo esc_attr($case->person_birth_date ?? ''); ?>"></td>
                        </tr>
                        <tr class="field-partner" style="<?php echo ($case->type ?? '') !== 'hochzeit' ? 'display:none;' : ''; ?>">
                            <th>Partner</th>
                            <td><input type="text" name="partner_name" value="<?php echo esc_attr($case->partner_name ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr class="field-parents" style="<?php echo !in_array($case->type ?? '', ['taufe', 'firmung']) ? 'display:none;' : ''; ?>">
                            <th>Eltern</th>
                            <td>
                                <input type="text" name="parent1_name" value="<?php echo esc_attr($case->parent1_name ?? ''); ?>" placeholder="Elternteil 1" style="width:100%; margin-bottom:4px;">
                                <input type="text" name="parent2_name" value="<?php echo esc_attr($case->parent2_name ?? ''); ?>" placeholder="Elternteil 2" style="width:100%;">
                            </td>
                        </tr>
                        <tr>
                            <th>Pate/Zeuge 1</th>
                            <td><input type="text" name="sponsor1_name" value="<?php echo esc_attr($case->sponsor1_name ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr>
                            <th>Pate/Zeuge 2</th>
                            <td><input type="text" name="sponsor2_name" value="<?php echo esc_attr($case->sponsor2_name ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                    </table>
                </div>
                
                <!-- Rechte Spalte -->
                <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top:0;">Termin & Kontakt</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th>Datum</th>
                            <td><input type="date" name="ceremony_date" value="<?php echo esc_attr($case->ceremony_date ?? ''); ?>"></td>
                        </tr>
                        <tr>
                            <th>Uhrzeit</th>
                            <td><input type="time" name="ceremony_time" value="<?php echo esc_attr(substr($case->ceremony_time ?? '', 0, 5)); ?>"></td>
                        </tr>
                        <tr>
                            <th>Ort</th>
                            <td><input type="text" name="ceremony_location" value="<?php echo esc_attr($case->ceremony_location ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr>
                            <th>Zelebrant</th>
                            <td><input type="text" name="celebrant" value="<?php echo esc_attr($case->celebrant ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr>
                            <th>Telefon</th>
                            <td><input type="tel" name="person_phone" value="<?php echo esc_attr($case->person_phone ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr>
                            <th>E-Mail</th>
                            <td><input type="email" name="person_email" value="<?php echo esc_attr($case->person_email ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                        <tr class="field-death" style="<?php echo ($case->type ?? '') !== 'begraebnis' ? 'display:none;' : ''; ?>">
                            <th>Sterbedatum</th>
                            <td><input type="date" name="death_date" value="<?php echo esc_attr($case->death_date ?? ''); ?>"></td>
                        </tr>
                        <tr class="field-death" style="<?php echo ($case->type ?? '') !== 'begraebnis' ? 'display:none;' : ''; ?>">
                            <th>Friedhof</th>
                            <td><input type="text" name="cemetery" value="<?php echo esc_attr($case->cemetery ?? ''); ?>" style="width:100%;"></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Notizen -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-top:20px;">
                <h3 style="margin-top:0;">Notizen</h3>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                    <div>
                        <label><strong>Allgemeine Notizen</strong></label>
                        <textarea name="notes" rows="4" style="width:100%; margin-top:8px;"><?php echo esc_textarea($case->notes ?? ''); ?></textarea>
                    </div>
                    <div>
                        <label><strong>Interne Notizen</strong> (nur für Mitarbeiter)</label>
                        <textarea name="internal_notes" rows="4" style="width:100%; margin-top:8px;"><?php echo esc_textarea($case->internal_notes ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            
            <p style="margin-top:20px;">
                <button type="submit" class="button button-primary button-large">💾 Speichern</button>
                <a href="<?php echo admin_url('admin.php?page=isidor-matrikel'); ?>" class="button button-large">Abbrechen</a>
                
                <?php if (!$is_new && current_user_can('isidor_matrikel_delete')): ?>
                    <button type="button" class="button button-link-delete" style="float:right;" onclick="if(confirm('Wirklich löschen?')){document.getElementById('delete-form').submit();}">🗑️ Löschen</button>
                <?php endif; ?>
            </p>
        </form>
        
        <?php if (!$is_new): ?>
        <form id="delete-form" method="post" style="display:none;">
            <?php wp_nonce_field('isidor_matrikel_delete_case'); ?>
            <input type="hidden" name="isidor_matrikel_action" value="delete_case">
            <input type="hidden" name="case_id" value="<?php echo $case->id; ?>">
        </form>
        <?php endif; ?>
        
        <script>
        document.getElementById('case_type')?.addEventListener('change', function() {
            var type = this.value;
            document.querySelectorAll('.field-partner').forEach(el => el.style.display = type === 'hochzeit' ? '' : 'none');
            document.querySelectorAll('.field-parents').forEach(el => el.style.display = (type === 'taufe' || type === 'firmung') ? '' : 'none');
            document.querySelectorAll('.field-death').forEach(el => el.style.display = type === 'begraebnis' ? '' : 'none');
        });
        </script>
        <?php
    }
    
    private function render_checklist_tab(int $case_id, array $checklist): void {
        ?>
        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); max-width:600px;">
            <h3 style="margin-top:0;">✓ Checkliste</h3>
            
            <?php if (empty($checklist)): ?>
                <p style="opacity:0.7;">Keine Checklisten-Einträge.</p>
            <?php else: ?>
                <ul style="list-style:none; padding:0; margin:0;">
                    <?php foreach ($checklist as $item): ?>
                        <li style="padding:12px 0; border-bottom:1px solid #e5e7eb; display:flex; align-items:center; gap:12px;">
                            <input type="checkbox" 
                                   <?php checked($item->completed, 1); ?> 
                                   onchange="toggleChecklist(<?php echo $item->id; ?>, this.checked)"
                                   style="width:20px; height:20px;">
                            <span style="<?php echo $item->completed ? 'text-decoration:line-through; opacity:0.6;' : ''; ?>">
                                <?php echo esc_html($item->title); ?>
                            </span>
                            <?php if ($item->completed && $item->completed_at): ?>
                                <small style="margin-left:auto; color:#666;">
                                    <?php echo date('d.m.', strtotime($item->completed_at)); ?>
                                </small>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        
        <script>
        function toggleChecklist(itemId, completed) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=isidor_toggle_checklist&_wpnonce=<?php echo wp_create_nonce('isidor_matrikel_toggle_checklist'); ?>&isidor_matrikel_action=toggle_checklist&item_id=' + itemId + '&completed=' + (completed ? 1 : 0)
            });
        }
        </script>
        <?php
    }
    
    private function render_appointments_tab(int $case_id, array $appointments): void {
        ?>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:900px;">
            <!-- Liste -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top:0;">📅 Termine</h3>
                
                <?php if (empty($appointments)): ?>
                    <p style="opacity:0.7;">Keine Termine vorhanden.</p>
                <?php else: ?>
                    <?php foreach ($appointments as $a): ?>
                        <div style="padding:12px 0; border-bottom:1px solid #e5e7eb;">
                            <strong><?php echo esc_html($a->title); ?></strong><br>
                            <small style="color:#666;">
                                📅 <?php echo date('d.m.Y H:i', strtotime($a->appointment_date)); ?>
                                <?php if ($a->location): ?> · 📍 <?php echo esc_html($a->location); ?><?php endif; ?>
                            </small>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Formular -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top:0;">+ Neuer Termin</h3>
                
                <form method="post">
                    <?php wp_nonce_field('isidor_matrikel_add_appointment'); ?>
                    <input type="hidden" name="isidor_matrikel_action" value="add_appointment">
                    <input type="hidden" name="case_id" value="<?php echo $case_id; ?>">
                    
                    <p><input type="text" name="appt_title" placeholder="Titel (z.B. Taufgespräch)" required style="width:100%;"></p>
                    <p>
                        <input type="date" name="appt_date" required style="width:48%;">
                        <input type="time" name="appt_time" value="10:00" style="width:48%;">
                    </p>
                    <p><input type="text" name="appt_location" placeholder="Ort" style="width:100%;"></p>
                    <p><textarea name="appt_notes" placeholder="Notizen..." rows="2" style="width:100%;"></textarea></p>
                    <p><button type="submit" class="button button-primary">Termin hinzufügen</button></p>
                </form>
            </div>
        </div>
        <?php
    }
    
    private function render_fees_tab(int $case_id, array $fees): void {
        $summary = $this->get_fee_summary($case_id);
        ?>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:900px;">
            <!-- Liste -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top:0;">💰 Gebühren & Stipendien</h3>
                
                <div style="display:flex; gap:20px; margin-bottom:16px; padding:12px; background:#f8fafc; border-radius:8px;">
                    <div>
                        <small style="color:#666;">Offen</small><br>
                        <strong style="color:#f59e0b;">€ <?php echo number_format($summary['pending'], 2, ',', '.'); ?></strong>
                    </div>
                    <div>
                        <small style="color:#666;">Bezahlt</small><br>
                        <strong style="color:#10b981;">€ <?php echo number_format($summary['paid'], 2, ',', '.'); ?></strong>
                    </div>
                </div>
                
                <?php if (empty($fees)): ?>
                    <p style="opacity:0.7;">Keine Gebühren eingetragen.</p>
                <?php else: ?>
                    <?php foreach ($fees as $f): ?>
                        <div style="padding:12px 0; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <strong><?php echo esc_html($f->description); ?></strong><br>
                                <small style="color:#666;"><?php echo ucfirst($f->type); ?></small>
                            </div>
                            <div style="text-align:right;">
                                <strong>€ <?php echo number_format($f->amount_cents / 100, 2, ',', '.'); ?></strong><br>
                                <?php if ($f->status === 'paid'): ?>
                                    <span style="color:#10b981; font-size:0.8em;">✓ Bezahlt</span>
                                <?php else: ?>
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('isidor_matrikel_mark_fee_paid'); ?>
                                        <input type="hidden" name="isidor_matrikel_action" value="mark_fee_paid">
                                        <input type="hidden" name="fee_id" value="<?php echo $f->id; ?>">
                                        <input type="hidden" name="case_id" value="<?php echo $case_id; ?>">
                                        <input type="hidden" name="payment_method" value="bar">
                                        <button type="submit" class="button button-small">Als bezahlt</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Formular -->
            <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top:0;">+ Neue Gebühr</h3>
                
                <form method="post">
                    <?php wp_nonce_field('isidor_matrikel_add_fee'); ?>
                    <input type="hidden" name="isidor_matrikel_action" value="add_fee">
                    <input type="hidden" name="case_id" value="<?php echo $case_id; ?>">
                    
                    <p><input type="text" name="fee_description" placeholder="Beschreibung (z.B. Messintention)" required style="width:100%;"></p>
                    <p><input type="number" name="fee_amount" placeholder="Betrag in €" step="0.01" min="0" required style="width:100%;"></p>
                    <p>
                        <select name="fee_type" style="width:100%;">
                            <option value="fee">Gebühr</option>
                            <option value="stipend">Stipendium</option>
                            <option value="donation">Spende</option>
                            <option value="other">Sonstiges</option>
                        </select>
                    </p>
                    <p><button type="submit" class="button button-primary">Gebühr hinzufügen</button></p>
                </form>
            </div>
        </div>
        <?php
    }
}
