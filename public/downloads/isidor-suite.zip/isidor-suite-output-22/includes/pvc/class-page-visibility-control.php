<?php
/**
 * Plugin Name: Page Visibility Control
 * Plugin URI: https://wilcke.at
 * Description: Definiert welche Benutzerrollen spezifische Seiten sehen dürfen
 * Version: 1.0.0
 * Author: Kaiserliche Hoheit
 * Author URI: https://wilcke.at
 * License: GPL v2 or later
 * Text Domain: page-visibility-control
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants (nur wenn nicht schon durch Isidor Suite oder standalone definiert)
if (!defined('PVC_VERSION')) {
    define('PVC_VERSION', '1.0.0');
}
if (!defined('PVC_PLUGIN_DIR')) {
    define('PVC_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('PVC_PLUGIN_URL')) {
    define('PVC_PLUGIN_URL', plugin_dir_url(__FILE__));
}

/**
 * Main Plugin Class
 */
if (!class_exists('Page_Visibility_Control')) {
class Page_Visibility_Control {
    
    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Meta key for storing allowed roles
     */
    private $meta_key = '_pvc_allowed_roles';
    
    /**
     * Meta key for redirect URL
     */
    private $redirect_meta_key = '_pvc_redirect_url';
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta_box'));
        add_action('template_redirect', array($this, 'check_page_access'));
        add_filter('the_posts', array($this, 'filter_posts_in_lists'), 10, 2);
        
        // Menu visibility controls
        add_action('wp_nav_menu_item_custom_fields', array($this, 'add_menu_item_fields'), 10, 4);
        add_action('wp_update_nav_menu_item', array($this, 'save_menu_item_fields'), 10, 2);
        add_filter('wp_nav_menu_objects', array($this, 'filter_menu_items'), 10, 2);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_menu_admin_assets'));
    }
    
    /**
     * Load text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain('page-visibility-control', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    /**
     * Add meta box to pages
     */
    public function add_meta_box() {
        add_meta_box(
            'pvc_visibility_settings',
            __('Sichtbarkeitseinstellungen', 'page-visibility-control'),
            array($this, 'render_meta_box'),
            'page',
            'side',
            'high'
        );
    }
    
    /**
     * Render meta box
     */
    public function render_meta_box($post) {
        wp_nonce_field('pvc_save_meta_box', 'pvc_meta_box_nonce');
        
        $allowed_roles = get_post_meta($post->ID, $this->meta_key, true);
        $redirect_url = get_post_meta($post->ID, $this->redirect_meta_key, true);
        
        if (empty($allowed_roles) || !is_array($allowed_roles)) {
            $allowed_roles = array('all');
        }
        
        $all_roles = wp_roles()->get_names();
        ?>
        <div class="pvc-meta-box">
            <p>
                <strong><?php _e('Wer darf diese Seite sehen?', 'page-visibility-control'); ?></strong>
            </p>
            
            <label style="display: block; margin-bottom: 8px;">
                <input type="checkbox" name="pvc_allowed_roles[]" value="all" 
                    <?php checked(in_array('all', $allowed_roles)); ?> 
                    id="pvc_role_all">
                <strong><?php _e('Alle (öffentlich)', 'page-visibility-control'); ?></strong>
            </label>
            
            <div id="pvc_roles_list" style="margin-left: 20px; <?php echo in_array('all', $allowed_roles) ? 'display:none;' : ''; ?>">
                <?php foreach ($all_roles as $role_slug => $role_name) : ?>
                    <label style="display: block; margin-bottom: 5px;">
                        <input type="checkbox" name="pvc_allowed_roles[]" value="<?php echo esc_attr($role_slug); ?>" 
                            <?php checked(in_array($role_slug, $allowed_roles)); ?>>
                        <?php echo esc_html($role_name); ?>
                    </label>
                <?php endforeach; ?>
            </div>
            
            <hr style="margin: 15px 0;">
            
            <p>
                <label for="pvc_redirect_url">
                    <strong><?php _e('Redirect-URL (optional)', 'page-visibility-control'); ?></strong>
                </label>
                <input type="url" id="pvc_redirect_url" name="pvc_redirect_url" 
                    value="<?php echo esc_url($redirect_url); ?>" 
                    class="widefat" 
                    placeholder="<?php echo esc_url(home_url('/')); ?>">
                <span class="description">
                    <?php _e('Wohin sollen nicht-berechtigte Benutzer weitergeleitet werden? Leer lassen für 404-Fehler.', 'page-visibility-control'); ?>
                </span>
            </p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#pvc_role_all').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#pvc_roles_list').slideUp();
                    $('#pvc_roles_list input[type="checkbox"]').prop('checked', false);
                } else {
                    $('#pvc_roles_list').slideDown();
                }
            });
        });
        </script>
        
        <style>
        .pvc-meta-box label {
            cursor: pointer;
        }
        .pvc-meta-box input[type="checkbox"] {
            margin-right: 5px;
        }
        </style>
        <?php
    }
    
    /**
     * Save meta box data
     */
    public function save_meta_box($post_id) {
        // Check nonce
        if (!isset($_POST['pvc_meta_box_nonce']) || !wp_verify_nonce($_POST['pvc_meta_box_nonce'], 'pvc_save_meta_box')) {
            return;
        }
        
        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save allowed roles
        if (isset($_POST['pvc_allowed_roles'])) {
            $allowed_roles = array_map('sanitize_text_field', $_POST['pvc_allowed_roles']);
            update_post_meta($post_id, $this->meta_key, $allowed_roles);
        } else {
            delete_post_meta($post_id, $this->meta_key);
        }
        
        // Save redirect URL
        if (isset($_POST['pvc_redirect_url']) && !empty($_POST['pvc_redirect_url'])) {
            $redirect_url = esc_url_raw($_POST['pvc_redirect_url']);
            update_post_meta($post_id, $this->redirect_meta_key, $redirect_url);
        } else {
            delete_post_meta($post_id, $this->redirect_meta_key);
        }
    }
    
    /**
     * Check if user can access current page
     */
    public function check_page_access() {
        if (!is_page()) {
            return;
        }
        
        $post_id = get_the_ID();
        $post = get_post($post_id);
        if (!$post) return;
        
        // Never restrict the login page — otherwise redirect loop
        $content = $post->post_content ?? '';
        $slug = $post->post_name ?? '';
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        if (
            has_shortcode($content, 'isidor_login') ||
            str_contains($slug, 'anmelden') ||
            str_contains($slug, 'login') ||
            str_contains($uri, 'anmelden') ||
            str_contains($uri, 'login')
        ) {
            return;
        }
        
        if (!$this->can_user_view_page($post_id)) {
            $redirect_url = get_post_meta($post_id, $this->redirect_meta_key, true);
            
            if (!empty($redirect_url)) {
                // Prevent redirect loop: don't redirect to current page
                $current = trailingslashit(home_url(parse_url($uri, PHP_URL_PATH)));
                $target = trailingslashit($redirect_url);
                if ($current === $target) {
                    return; // Would loop
                }
                wp_redirect($redirect_url);
                exit;
            } else {
                // Not logged in? Redirect to login instead of 404
                if (!is_user_logged_in()) {
                    $login_page = get_page_by_path('app/anmelden');
                    if ($login_page) {
                        wp_redirect(add_query_arg('redirect_to', urlencode($uri), get_permalink($login_page)));
                        exit;
                    }
                }
                global $wp_query;
                $wp_query->set_404();
                status_header(404);
                get_template_part(404);
                exit;
            }
        }
    }
    
    /**
     * Check if current user can view a specific page
     */
    private function can_user_view_page($post_id) {
        // Admins can always see everything
        if (current_user_can('manage_options')) {
            return true;
        }
        
        $allowed_roles = get_post_meta($post_id, $this->meta_key, true);
        
        // If no restrictions set, or explicitly set to "all"
        if (empty($allowed_roles) || in_array('all', $allowed_roles)) {
            return true;
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return false;
        }
        
        // Get current user's roles
        $user = wp_get_current_user();
        $user_roles = (array) $user->roles;
        
        // Check if user has any of the allowed roles
        $has_permission = !empty(array_intersect($user_roles, $allowed_roles));
        
        // Also check: if the page allows ANY isidor_* role and the user has ANY isidor_* role, allow
        $page_has_isidor = false;
        $user_has_isidor = false;
        foreach ($allowed_roles as $r) {
            if (str_starts_with($r, 'isidor_')) { $page_has_isidor = true; break; }
        }
        foreach ($user_roles as $r) {
            if (str_starts_with($r, 'isidor_')) { $user_has_isidor = true; break; }
        }
        if ($page_has_isidor && $user_has_isidor) {
            $has_permission = true;
        }
        
        return $has_permission;
    }
    
    /**
     * Filter pages from lists (menus, archives, etc.)
     */
    public function filter_posts_in_lists($posts, $query) {
        // Don't filter in admin
        if (is_admin()) {
            return $posts;
        }
        
        // Only filter pages
        if (!$query->is_main_query() || $query->get('post_type') !== 'page') {
            return $posts;
        }
        
        $filtered_posts = array();
        
        foreach ($posts as $post) {
            if ($this->can_user_view_page($post->ID)) {
                $filtered_posts[] = $post;
            }
        }
        
        return $filtered_posts;
    }
    
    /**
     * Enqueue admin assets for menu screen
     */
    public function enqueue_menu_admin_assets($hook) {
        if ($hook !== 'nav-menus.php') {
            return;
        }
        
        wp_add_inline_style('wp-admin', '
            .pvc-menu-roles-wrapper {
                margin: 10px 0;
                padding: 10px;
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 3px;
            }
            .pvc-menu-roles-wrapper label {
                display: block;
                margin: 5px 0;
                cursor: pointer;
            }
            .pvc-menu-roles-wrapper input[type="checkbox"] {
                margin-right: 5px;
            }
            .pvc-menu-roles-toggle {
                font-weight: 600;
                color: #2271b1;
                cursor: pointer;
                user-select: none;
            }
            .pvc-menu-roles-toggle:hover {
                color: #135e96;
            }
            .pvc-menu-roles-list {
                margin-top: 8px;
                margin-left: 20px;
            }
        ');
        
        wp_add_inline_script('nav-menu', '
            jQuery(document).ready(function($) {
                $(document).on("change", ".pvc-menu-role-all", function() {
                    var $wrapper = $(this).closest(".pvc-menu-roles-wrapper");
                    var $rolesList = $wrapper.find(".pvc-menu-roles-list");
                    
                    if ($(this).is(":checked")) {
                        $rolesList.slideUp();
                        $rolesList.find("input[type=checkbox]").prop("checked", false);
                    } else {
                        $rolesList.slideDown();
                    }
                });
                
                // Beim Laden: Verstecke Rollenliste wenn "Alle" gecheckt ist
                $(".pvc-menu-role-all:checked").each(function() {
                    $(this).closest(".pvc-menu-roles-wrapper").find(".pvc-menu-roles-list").hide();
                });
            });
        ');
    }
    
    /**
     * Add custom fields to menu items
     */
    public function add_menu_item_fields($item_id, $item, $depth, $args) {
        $allowed_roles = get_post_meta($item_id, '_pvc_menu_allowed_roles', true);
        
        if (empty($allowed_roles) || !is_array($allowed_roles)) {
            $allowed_roles = array('all');
        }
        
        $all_roles = wp_roles()->get_names();
        ?>
        <div class="pvc-menu-roles-wrapper field-pvc-visibility description-wide">
            <p class="description">
                <span class="pvc-menu-roles-toggle">
                    🔒 <?php _e('Sichtbarkeitseinstellungen', 'page-visibility-control'); ?>
                </span>
            </p>
            
            <label style="display: block; margin: 8px 0;">
                <input type="checkbox" 
                    class="pvc-menu-role-all"
                    name="pvc_menu_allowed_roles[<?php echo $item_id; ?>][]" 
                    value="all" 
                    <?php checked(in_array('all', $allowed_roles)); ?>>
                <strong><?php _e('Alle (öffentlich sichtbar)', 'page-visibility-control'); ?></strong>
            </label>
            
            <div class="pvc-menu-roles-list">
                <p class="description" style="margin: 5px 0;">
                    <?php _e('Oder wähle spezifische Rollen:', 'page-visibility-control'); ?>
                </p>
                <?php foreach ($all_roles as $role_slug => $role_name) : ?>
                    <label>
                        <input type="checkbox" 
                            name="pvc_menu_allowed_roles[<?php echo $item_id; ?>][]" 
                            value="<?php echo esc_attr($role_slug); ?>" 
                            <?php checked(in_array($role_slug, $allowed_roles)); ?>>
                        <?php echo esc_html($role_name); ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Save menu item custom fields
     */
    public function save_menu_item_fields($menu_id, $menu_item_db_id) {
        if (isset($_POST['pvc_menu_allowed_roles'][$menu_item_db_id])) {
            $allowed_roles = array_map('sanitize_text_field', $_POST['pvc_menu_allowed_roles'][$menu_item_db_id]);
            update_post_meta($menu_item_db_id, '_pvc_menu_allowed_roles', $allowed_roles);
        } else {
            // If nothing is checked, set to "all"
            update_post_meta($menu_item_db_id, '_pvc_menu_allowed_roles', array('all'));
        }
    }
    
    /**
     * Filter menu items based on user roles
     */
    public function filter_menu_items($items, $args) {
        // Admins can see everything
        if (current_user_can('manage_options')) {
            return $items;
        }
        
        $filtered_items = array();
        
        foreach ($items as $item) {
            if ($this->can_user_view_menu_item($item->ID)) {
                $filtered_items[] = $item;
            }
        }
        
        return $filtered_items;
    }
    
    /**
     * Check if current user can view a menu item
     */
    private function can_user_view_menu_item($item_id) {
        $allowed_roles = get_post_meta($item_id, '_pvc_menu_allowed_roles', true);
        
        // If no restrictions set, or explicitly set to "all"
        if (empty($allowed_roles) || in_array('all', $allowed_roles)) {
            return true;
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return false;
        }
        
        // Get current user's roles
        $user = wp_get_current_user();
        $user_roles = (array) $user->roles;
        
        // Check if user has any of the allowed roles
        return !empty(array_intersect($user_roles, $allowed_roles));
    }
}
} // end if (!class_exists('Page_Visibility_Control'))

// Initialize plugin (nur wenn nicht schon durch standalone Plugin geladen)
if (!function_exists('pvc_init')) {
    function pvc_init() {
        return Page_Visibility_Control::get_instance();
    }
    add_action('init', 'pvc_init');
}
