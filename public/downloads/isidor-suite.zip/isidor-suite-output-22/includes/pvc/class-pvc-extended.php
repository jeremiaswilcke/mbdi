<?php
/**
 * Page Visibility Control - Extended Functions
 * 
 * Optionale erweiterte Funktionen für das Plugin
 * Um diese zu aktivieren, include diese Datei im Haupt-Plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('PVC_Extended')) {
class PVC_Extended {
    
    /**
     * Constructor
     */
    public function __construct() {
        // Shortcode für bedingte Inhalte
        add_shortcode('pvc_content', array($this, 'conditional_content_shortcode'));
        
        // Admin-Spalte in der Seitenliste
        add_filter('manage_pages_columns', array($this, 'add_visibility_column'));
        add_action('manage_pages_custom_column', array($this, 'render_visibility_column'), 10, 2);
        
        // Quick Edit Support
        add_action('quick_edit_custom_box', array($this, 'quick_edit_box'), 10, 2);
        add_action('save_post', array($this, 'save_quick_edit'), 10, 1);
        
        // Bulk Edit Support
        add_action('bulk_edit_custom_box', array($this, 'bulk_edit_box'), 10, 2);
    }
    
    /**
     * Shortcode für rollenbasierte Inhalte innerhalb von Seiten
     * 
     * Verwendung:
     * [pvc_content roles="editor,author"]Nur Editoren und Autoren sehen diesen Text[/pvc_content]
     */
    public function conditional_content_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'roles' => '',
            'logged_in' => '',
        ), $atts);
        
        // Check logged in status if specified
        if (!empty($atts['logged_in'])) {
            $must_be_logged_in = filter_var($atts['logged_in'], FILTER_VALIDATE_BOOLEAN);
            if ($must_be_logged_in && !is_user_logged_in()) {
                return '';
            }
            if (!$must_be_logged_in && is_user_logged_in()) {
                return '';
            }
        }
        
        // If no roles specified and logged in check passed, show content
        if (empty($atts['roles'])) {
            return do_shortcode($content);
        }
        
        // Check roles
        $allowed_roles = array_map('trim', explode(',', $atts['roles']));
        
        // Admins can always see
        if (current_user_can('manage_options')) {
            return do_shortcode($content);
        }
        
        if (!is_user_logged_in()) {
            return '';
        }
        
        $user = wp_get_current_user();
        $user_roles = (array) $user->roles;
        
        if (!empty(array_intersect($user_roles, $allowed_roles))) {
            return do_shortcode($content);
        }
        
        return '';
    }
    
    /**
     * Admin-Spalte hinzufügen
     */
    public function add_visibility_column($columns) {
        $new_columns = array();
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'title') {
                $new_columns['pvc_visibility'] = __('Sichtbarkeit', 'page-visibility-control');
            }
        }
        return $new_columns;
    }
    
    /**
     * Admin-Spalte rendern
     */
    public function render_visibility_column($column, $post_id) {
        if ($column === 'pvc_visibility') {
            $allowed_roles = get_post_meta($post_id, '_pvc_allowed_roles', true);
            
            if (empty($allowed_roles) || in_array('all', $allowed_roles)) {
                echo '<span style="color: #46b450;">● ' . __('Öffentlich', 'page-visibility-control') . '</span>';
            } else {
                $role_names = array();
                foreach ($allowed_roles as $role) {
                    $role_obj = get_role($role);
                    if ($role_obj) {
                        $wp_roles = wp_roles();
                        $role_names[] = translate_user_role($wp_roles->roles[$role]['name']);
                    }
                }
                echo '<span style="color: #dc3232;">🔒 ' . implode(', ', $role_names) . '</span>';
            }
        }
    }
    
    /**
     * Quick Edit Box
     */
    public function quick_edit_box($column_name, $post_type) {
        if ($column_name !== 'pvc_visibility' || $post_type !== 'page') {
            return;
        }
        
        $all_roles = wp_roles()->get_names();
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e('Sichtbarkeit', 'page-visibility-control'); ?></span>
                    <span class="input-text-wrap">
                        <label>
                            <input type="checkbox" name="pvc_quick_edit_all" value="1" checked>
                            <?php _e('Öffentlich (alle)', 'page-visibility-control'); ?>
                        </label>
                        <div id="pvc_quick_edit_roles" style="display:none; margin-left: 20px;">
                            <?php foreach ($all_roles as $role_slug => $role_name) : ?>
                                <label style="display: block;">
                                    <input type="checkbox" name="pvc_quick_edit_roles[]" value="<?php echo esc_attr($role_slug); ?>">
                                    <?php echo esc_html($role_name); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </span>
                </label>
            </div>
        </fieldset>
        <script>
        jQuery(document).ready(function($) {
            $('input[name="pvc_quick_edit_all"]').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#pvc_quick_edit_roles').hide();
                } else {
                    $('#pvc_quick_edit_roles').show();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Save Quick Edit
     */
    public function save_quick_edit($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (isset($_POST['pvc_quick_edit_all'])) {
            update_post_meta($post_id, '_pvc_allowed_roles', array('all'));
        } elseif (isset($_POST['pvc_quick_edit_roles'])) {
            $roles = array_map('sanitize_text_field', $_POST['pvc_quick_edit_roles']);
            update_post_meta($post_id, '_pvc_allowed_roles', $roles);
        }
    }
    
    /**
     * Bulk Edit Box
     */
    public function bulk_edit_box($column_name, $post_type) {
        if ($column_name !== 'pvc_visibility' || $post_type !== 'page') {
            return;
        }
        
        $all_roles = wp_roles()->get_names();
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e('Sichtbarkeit', 'page-visibility-control'); ?></span>
                    <span class="input-text-wrap">
                        <select name="pvc_bulk_edit_action">
                            <option value=""><?php _e('— Keine Änderung —', 'page-visibility-control'); ?></option>
                            <option value="all"><?php _e('Auf Öffentlich setzen', 'page-visibility-control'); ?></option>
                            <option value="custom"><?php _e('Auf spezifische Rollen setzen', 'page-visibility-control'); ?></option>
                        </select>
                        
                        <div id="pvc_bulk_edit_roles" style="display:none; margin-top: 10px; margin-left: 20px;">
                            <?php foreach ($all_roles as $role_slug => $role_name) : ?>
                                <label style="display: block;">
                                    <input type="checkbox" name="pvc_bulk_edit_roles[]" value="<?php echo esc_attr($role_slug); ?>">
                                    <?php echo esc_html($role_name); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </span>
                </label>
            </div>
        </fieldset>
        <script>
        jQuery(document).ready(function($) {
            $('select[name="pvc_bulk_edit_action"]').on('change', function() {
                if ($(this).val() === 'custom') {
                    $('#pvc_bulk_edit_roles').show();
                } else {
                    $('#pvc_bulk_edit_roles').hide();
                }
            });
        });
        </script>
        <?php
    }
}
} // end if (!class_exists('PVC_Extended'))

// Initialize extended functions
if (class_exists('PVC_Extended')) {
    new PVC_Extended();
}
