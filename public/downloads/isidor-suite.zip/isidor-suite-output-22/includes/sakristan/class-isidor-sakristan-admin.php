<?php

/**
 * Isidor Sakristan – Admin
 * 
 * - Menü unter Isidor OS
 * - Messe-Detail: Sakristei-Notizen bearbeiten
 * - Einstellungen: Checkliste-Template, Notiz-Felder, Benachrichtigungen
 */
class Isidor_Sakristan_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_post_isidor_sakr_save_messe', [$this, 'handle_save_messe']);
        add_action('admin_post_isidor_sakr_save_settings', [$this, 'handle_save_settings']);
    }

    public function add_menu(): void {
        // Hauptmenü unter Isidor OS
        add_submenu_page(
            'isidor-os',
            'Sakristei',
            '🕯️ Sakristei',
            'isidor_sakristan_view',
            'isidor-sakristan',
            [$this, 'render_admin_page']
        );
        
        // Einstellungen
        add_submenu_page(
            'isidor-os',
            'Sakristei-Einstellungen',
            '⚙️ Sakristei-Einst.',
            'isidor_sakristan_edit',
            'isidor-sakristan-settings',
            [$this, 'render_settings_page']
        );
    }

    /* ----------------------------------------------------------
       Admin-Seite: Messen-Liste / Detail
       ---------------------------------------------------------- */

    public function render_admin_page(): void {
        $messe_id = isset($_GET['messe_id']) ? intval($_GET['messe_id']) : 0;
        if ($messe_id) {
            $this->render_messe_detail($messe_id);
        } else {
            $this->render_messe_list();
        }
    }

    private function render_messe_list(): void {
        $from = sanitize_text_field($_GET['from'] ?? date('Y-m-d'));
        $to   = sanitize_text_field($_GET['to'] ?? date('Y-m-d', strtotime('+28 days')));
        
        $messen = get_posts([
            'post_type'      => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_key'       => '_is_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => [[
                'key' => '_is_date', 'value' => [$from, $to],
                'compare' => 'BETWEEN', 'type' => 'DATE'
            ]],
        ]);
        
        echo '<div class="wrap">';
        echo '<h1>🕯️ Sakristei: Kommende Messen</h1>';
        
        // Zeitraum-Filter
        echo '<form method="get" style="margin-bottom:16px;">';
        echo '<input type="hidden" name="page" value="isidor-sakristan">';
        echo '<label>Von: <input type="date" name="from" value="' . esc_attr($from) . '"></label> ';
        echo '<label>Bis: <input type="date" name="to" value="' . esc_attr($to) . '"></label> ';
        submit_button('Filtern', 'secondary', '', false);
        echo '</form>';
        
        if (empty($messen)) {
            echo '<p>Keine Messen im Zeitraum.</p></div>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Datum</th><th>Uhrzeit</th><th>Titel</th><th>Status</th><th>Offene ToDos</th><th>Aktion</th></tr></thead><tbody>';
        
        global $wpdb;
        $todo_table = $wpdb->prefix . 'isidor_sakr_todos';
        
        foreach ($messen as $m) {
            $date = get_post_meta($m->ID, '_is_date', true);
            $time = get_post_meta($m->ID, '_is_time', true);
            $done = get_post_meta($m->ID, '_is_sakr_completed', true);
            $open = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$todo_table} WHERE messe_id = %d AND status = 'offen'", $m->ID
            ));
            
            $status = $done
                ? '<span style="color:#16a34a;">✅ Erledigt</span>'
                : '<span style="color:#d97706;">⬜ Offen</span>';
            $todo_badge = $open > 0 ? '<span style="background:#fef3c7;color:#d97706;padding:2px 8px;border-radius:10px;font-size:0.85em;">' . $open . '</span>' : '—';
            
            $link = admin_url('admin.php?page=isidor-sakristan&messe_id=' . $m->ID);
            
            printf(
                '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href="%s" class="button button-small">Bearbeiten</a></td></tr>',
                esc_html(date_i18n('D, j. M Y', strtotime($date))),
                esc_html($time),
                esc_html($m->post_title),
                $status,
                $todo_badge,
                esc_url($link)
            );
        }
        echo '</tbody></table></div>';
    }

    private function render_messe_detail(int $id): void {
        if (!current_user_can('isidor_sakristan_edit')) {
            wp_die('Keine Rechte.');
        }
        
        $messe = get_post($id);
        if (!$messe) { wp_die('Messe nicht gefunden.'); }
        
        $notes_def   = get_option('isidor_sakr_note_fields', []);
        $saved_notes = get_post_meta($id, '_is_sakr_notes', true) ?: [];
        $date        = get_post_meta($id, '_is_date', true);
        $time        = get_post_meta($id, '_is_time', true);
        $saved       = !empty($_GET['saved']);
        
        echo '<div class="wrap">';
        echo '<a href="' . admin_url('admin.php?page=isidor-sakristan') . '" class="page-title-action">← Zurück</a>';
        echo '<h1>🕯️ Sakristei-Planung: ' . esc_html($messe->post_title) . '</h1>';
        echo '<p>' . esc_html(date_i18n('l, j. F Y', strtotime($date))) . ' · ' . esc_html($time) . ' Uhr</p>';
        
        if ($saved) {
            echo '<div class="notice notice-success"><p>Sakristei-Infos gespeichert.</p></div>';
        }
        
        echo '<form method="post" action="' . admin_url('admin-post.php') . '">';
        wp_nonce_field('isidor_sakr_save');
        echo '<input type="hidden" name="action" value="isidor_sakr_save_messe">';
        echo '<input type="hidden" name="messe_id" value="' . $id . '">';
        
        echo '<table class="form-table">';
        foreach ($notes_def as $field) {
            $val = $saved_notes[$field['key']] ?? '';
            echo '<tr><th scope="row"><label>' . esc_html($field['label']) . '</label></th><td>';
            if ($field['type'] === 'textarea') {
                echo '<textarea name="notes[' . esc_attr($field['key']) . ']" class="large-text" rows="3">' . esc_textarea($val) . '</textarea>';
            } else {
                echo '<input type="' . esc_attr($field['type']) . '" name="notes[' . esc_attr($field['key']) . ']" value="' . esc_attr($val) . '" class="regular-text">';
            }
            echo '</td></tr>';
        }
        echo '</table>';
        
        submit_button('Sakristei-Infos speichern');
        echo '</form></div>';
    }

    public function handle_save_messe(): void {
        check_admin_referer('isidor_sakr_save');
        if (!current_user_can('isidor_sakristan_edit')) wp_die('Keine Berechtigung.');

        $id = intval($_POST['messe_id']);
        $notes = isset($_POST['notes']) && is_array($_POST['notes'])
            ? array_map('sanitize_text_field', $_POST['notes'])
            : [];
        
        update_post_meta($id, '_is_sakr_notes', $notes);
        update_post_meta($id, '_is_sakr_last_update', time());

        wp_redirect(admin_url('admin.php?page=isidor-sakristan&messe_id=' . $id . '&saved=1'));
        exit;
    }

    /* ----------------------------------------------------------
       Einstellungen: Checkliste + Notiz-Felder
       ---------------------------------------------------------- */

    public function render_settings_page(): void {
        if (!current_user_can('isidor_sakristan_edit')) {
            wp_die('Keine Berechtigung.');
        }
        
        $todo_tpl   = get_option('isidor_sakr_todo_template', []);
        $note_fields = get_option('isidor_sakr_note_fields', []);
        $saved = !empty($_GET['saved']);
        
        echo '<div class="wrap">';
        echo '<h1>⚙️ Sakristei-Einstellungen</h1>';
        
        if ($saved) {
            echo '<div class="notice notice-success"><p>Einstellungen gespeichert.</p></div>';
        }
        
        echo '<form method="post" action="' . admin_url('admin-post.php') . '">';
        wp_nonce_field('isidor_sakr_save_settings');
        echo '<input type="hidden" name="action" value="isidor_sakr_save_settings">';
        
        // Checkliste
        echo '<h2>☑️ Standard-Checkliste</h2>';
        echo '<p class="description">Diese Punkte erscheinen automatisch bei jeder Messe.</p>';
        echo '<table class="widefat" style="max-width:700px;">';
        echo '<thead><tr><th>Aufgabe</th><th>Kategorie</th><th style="width:60px;">Pflicht</th></tr></thead><tbody>';
        
        foreach ($todo_tpl as $i => $item) {
            echo '<tr>';
            echo '<td><input type="text" name="todo_tpl[' . $i . '][label]" value="' . esc_attr($item['label']) . '" class="regular-text"></td>';
            echo '<td><input type="text" name="todo_tpl[' . $i . '][category]" value="' . esc_attr($item['category'] ?? '') . '" class="small-text" style="width:120px;"></td>';
            echo '<td><input type="checkbox" name="todo_tpl[' . $i . '][required]" value="1" ' . checked(!empty($item['required']), true, false) . '></td>';
            echo '<input type="hidden" name="todo_tpl[' . $i . '][id]" value="' . esc_attr($item['id'] ?? sanitize_title($item['label'])) . '">';
            echo '</tr>';
        }
        // Leere Zeile für neue Einträge
        $n = count($todo_tpl);
        echo '<tr style="background:#f0fdf4;">';
        echo '<td><input type="text" name="todo_tpl[' . $n . '][label]" placeholder="Neuer Punkt…" class="regular-text"></td>';
        echo '<td><input type="text" name="todo_tpl[' . $n . '][category]" placeholder="Kategorie" class="small-text" style="width:120px;"></td>';
        echo '<td><input type="checkbox" name="todo_tpl[' . $n . '][required]" value="1"></td>';
        echo '</tr>';
        
        echo '</tbody></table>';
        
        // Notiz-Felder
        echo '<h2 style="margin-top:32px;">📋 Hinweis-Felder</h2>';
        echo '<p class="description">Diese Felder können pro Messe vom Sekretariat ausgefüllt werden und sind im Mesner-Frontend sichtbar.</p>';
        echo '<table class="widefat" style="max-width:700px;">';
        echo '<thead><tr><th>Bezeichnung</th><th>Typ</th><th>Sichtbar für Mesner</th></tr></thead><tbody>';
        
        foreach ($note_fields as $i => $field) {
            echo '<tr>';
            echo '<td><input type="text" name="notes_cfg[' . $i . '][label]" value="' . esc_attr($field['label']) . '" class="regular-text"></td>';
            echo '<td><select name="notes_cfg[' . $i . '][type]">';
            foreach (['text' => 'Text', 'number' => 'Zahl', 'textarea' => 'Mehrzeilig'] as $t => $l) {
                echo '<option value="' . $t . '"' . selected($field['type'], $t, false) . '>' . $l . '</option>';
            }
            echo '</select></td>';
            echo '<td><input type="checkbox" name="notes_cfg[' . $i . '][visible_to_mesner]" value="1" ' . checked(!empty($field['visible_to_mesner']), true, false) . '></td>';
            echo '<input type="hidden" name="notes_cfg[' . $i . '][key]" value="' . esc_attr($field['key']) . '">';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        
        submit_button('Einstellungen speichern');
        echo '</form></div>';
    }

    public function handle_save_settings(): void {
        check_admin_referer('isidor_sakr_save_settings');
        if (!current_user_can('isidor_sakristan_edit')) wp_die('Keine Berechtigung.');
        
        // Checkliste
        $todo_tpl = [];
        if (!empty($_POST['todo_tpl']) && is_array($_POST['todo_tpl'])) {
            foreach ($_POST['todo_tpl'] as $item) {
                $label = sanitize_text_field($item['label'] ?? '');
                if (!$label) continue;
                $todo_tpl[] = [
                    'id'       => sanitize_title($item['id'] ?? $label),
                    'label'    => $label,
                    'category' => sanitize_text_field($item['category'] ?? ''),
                    'required' => !empty($item['required']),
                ];
            }
        }
        update_option('isidor_sakr_todo_template', $todo_tpl);
        
        // Notiz-Felder
        $notes_cfg = [];
        if (!empty($_POST['notes_cfg']) && is_array($_POST['notes_cfg'])) {
            foreach ($_POST['notes_cfg'] as $field) {
                $label = sanitize_text_field($field['label'] ?? '');
                if (!$label) continue;
                $notes_cfg[] = [
                    'key'              => sanitize_key($field['key'] ?? sanitize_title($label)),
                    'label'            => $label,
                    'type'             => sanitize_text_field($field['type'] ?? 'text'),
                    'visible_to_mesner' => !empty($field['visible_to_mesner']),
                ];
            }
        }
        update_option('isidor_sakr_note_fields', $notes_cfg);
        
        wp_redirect(admin_url('admin.php?page=isidor-sakristan-settings&saved=1'));
        exit;
    }
}
