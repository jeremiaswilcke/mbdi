<?php

/**
 * Isidor Sakristan – REST API
 * 
 * Endpoints:
 * GET  /isidor/v1/sakristei/messen     – Messen mit Sakristei-Status
 * GET  /isidor/v1/sakristei/todos      – ToDos (Filter: messe_id, status)
 * GET  /isidor/v1/sakristei/timelog    – Dienstzeiten (Filter: user_id, month)
 */
class Isidor_Sakristan_REST {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes(): void {
        $ns = 'isidor/v1';
        
        register_rest_route($ns, '/sakristei/messen', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_messen'],
            'permission_callback' => [$this, 'can_view'],
        ]);
        
        register_rest_route($ns, '/sakristei/todos', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_todos'],
            'permission_callback' => [$this, 'can_view'],
        ]);
        
        register_rest_route($ns, '/sakristei/timelog', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_timelog'],
            'permission_callback' => [$this, 'can_view_timelog'],
        ]);
    }

    public function can_view(): bool {
        return current_user_can('isidor_sakristan_view');
    }

    public function can_view_timelog(): bool {
        return current_user_can('isidor_sakristan_timelog') || current_user_can('isidor_sakristan_edit');
    }

    /** Messen mit Sakristei-Status + offene ToDo-Anzahl */
    public function get_messen(\WP_REST_Request $request): \WP_REST_Response {
        $from = sanitize_text_field($request->get_param('from') ?: date('Y-m-d'));
        $to   = sanitize_text_field($request->get_param('to') ?: date('Y-m-d', strtotime('+28 days')));

        $messen = get_posts([
            'post_type'      => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_key'       => '_is_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => [[
                'key' => '_is_date', 'value' => [$from, $to],
                'compare' => 'BETWEEN', 'type' => 'DATE'
            ]],
        ]);

        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        
        $data = [];
        foreach ($messen as $m) {
            $open_todos = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE messe_id = %d AND status = 'offen'", $m->ID
            ));
            
            $data[] = [
                'id'          => $m->ID,
                'title'       => $m->post_title,
                'date'        => get_post_meta($m->ID, '_is_date', true),
                'time'        => get_post_meta($m->ID, '_is_time', true),
                'liturgical'  => get_post_meta($m->ID, '_is_liturgical', true),
                'completed'   => (bool) get_post_meta($m->ID, '_is_sakr_completed', true),
                'notes'       => get_post_meta($m->ID, '_is_sakr_notes', true) ?: [],
                'open_todos'  => $open_todos,
            ];
        }
        return rest_ensure_response($data);
    }

    /** ToDos – filter by messe_id and/or status */
    public function get_todos(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        
        $messe_id = $request->get_param('messe_id');
        $status   = sanitize_text_field($request->get_param('status') ?: 'offen');
        
        $where = [];
        $params = [];
        
        if ($messe_id !== null) {
            $where[] = $messe_id ? "messe_id = %d" : "messe_id IS NULL";
            if ($messe_id) $params[] = (int) $messe_id;
        }
        if ($status !== 'alle') {
            $where[] = "status = %s";
            $params[] = $status;
        }
        
        $where_sql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        $sql = "SELECT * FROM {$table} {$where_sql} ORDER BY priority DESC, created_at DESC LIMIT 200";
        
        $rows = $params 
            ? $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A)
            : $wpdb->get_results($sql, ARRAY_A);
        
        return rest_ensure_response($rows ?: []);
    }

    /** Dienstzeiten – filter by user and month */
    public function get_timelog(\WP_REST_Request $request): \WP_REST_Response {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_timelog';
        
        $user_id = $request->get_param('user_id') ? (int)$request->get_param('user_id') : get_current_user_id();
        $month   = sanitize_text_field($request->get_param('month') ?: date('Y-m'));
        
        // Nur eigene Daten oder Admin
        if ($user_id !== get_current_user_id() && !current_user_can('isidor_sakristan_edit')) {
            return rest_ensure_response(['error' => 'Nur eigene Daten einsehbar.']);
        }
        
        $start = $month . '-01';
        $end   = date('Y-m-t', strtotime($start));
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d AND log_date BETWEEN %s AND %s ORDER BY log_date DESC",
            $user_id, $start, $end
        ), ARRAY_A);
        
        $total = array_sum(array_column($entries, 'hours'));
        
        return rest_ensure_response([
            'user_id' => $user_id,
            'month'   => $month,
            'total_hours' => round($total, 2),
            'entries' => $entries ?: [],
        ]);
    }
}
