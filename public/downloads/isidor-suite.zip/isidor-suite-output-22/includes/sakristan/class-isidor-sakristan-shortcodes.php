<?php

/**
 * Isidor Sakristan – Frontend Shortcodes
 * 
 * Shortcodes:
 * - [isidor_sakristan_dashboard] → Hauptansicht (Übersicht/Detail/ToDo/Zeitlog)
 * - [isidor_sakristan_messe]     → Messe-Detail
 * - [isidor_sakristan_uebersicht] → Alias für Dashboard
 */
class Isidor_Sakristan_Shortcodes {

    public function __construct() {
        add_shortcode('isidor_sakristan_messe', [$this, 'render_detail']);
        add_shortcode('isidor_sakristan_uebersicht', [$this, 'render_dashboard']);
        add_shortcode('isidor_sakristan_dashboard', [$this, 'render_dashboard']);
        
        // AJAX Handlers
        add_action('wp_ajax_isidor_sakr_complete', [$this, 'ajax_complete_messe']);
        add_action('wp_ajax_isidor_sakr_toggle_todo', [$this, 'ajax_toggle_todo']);
        add_action('wp_ajax_isidor_sakr_toggle_checklist', [$this, 'ajax_toggle_checklist']);
        add_action('wp_ajax_isidor_sakr_create_todo', [$this, 'ajax_create_todo']);
        add_action('wp_ajax_isidor_sakr_delete_todo', [$this, 'ajax_delete_todo']);
        add_action('wp_ajax_isidor_sakr_save_timelog', [$this, 'ajax_save_timelog']);
        add_action('wp_ajax_isidor_sakr_delete_timelog', [$this, 'ajax_delete_timelog']);
    }

    /* ================================================================
       DASHBOARD – Tab-basiertes Layout
       ================================================================ */

    public function render_dashboard($atts): string {
        if (!current_user_can('isidor_sakristan_view')) {
            return '<div class="sakr-notice sakr-notice-error">Keine Berechtigung für die Sakristei-App.</div>';
        }
        
        // Messe-Detail?
        if (isset($_GET['messe']) && intval($_GET['messe'])) {
            return $this->render_detail(['id' => intval($_GET['messe'])]);
        }
        
        $tab = sanitize_text_field($_GET['sakr_tab'] ?? 'messen');
        $page_url = get_permalink();
        
        ob_start(); ?>
        <div class="isidor-sakristan-app">
            <div class="sakr-header">
                <h2>🕯️ Sakristei</h2>
            </div>
            
            <nav class="sakr-tabs">
                <a href="<?php echo esc_url(add_query_arg('sakr_tab', 'messen', $page_url)); ?>" 
                   class="sakr-tab <?php echo $tab === 'messen' ? 'active' : ''; ?>">⛪ Messen</a>
                <a href="<?php echo esc_url(add_query_arg('sakr_tab', 'todos', $page_url)); ?>" 
                   class="sakr-tab <?php echo $tab === 'todos' ? 'active' : ''; ?>">📋 Aufgaben</a>
                <?php if (current_user_can('isidor_sakristan_timelog') || current_user_can('isidor_sakristan_timelog_view')): ?>
                <a href="<?php echo esc_url(add_query_arg('sakr_tab', 'zeit', $page_url)); ?>" 
                   class="sakr-tab <?php echo $tab === 'zeit' ? 'active' : ''; ?>">⏱️ Dienstzeit</a>
                <?php endif; ?>
            </nav>
            
            <div class="sakr-tab-content">
                <?php
                switch ($tab) {
                    case 'todos':
                        $this->render_todos_tab();
                        break;
                    case 'zeit':
                        if (current_user_can('isidor_sakristan_timelog') || current_user_can('isidor_sakristan_timelog_view')) {
                            $this->render_timelog_tab();
                        }
                        break;
                    default:
                        $this->render_messen_tab();
                        break;
                }
                ?>
            </div>
        </div>
        <?php return ob_get_clean();
    }

    /* ================================================================
       TAB: MESSEN – Übersicht der kommenden Gottesdienste
       ================================================================ */

    private function render_messen_tab(): void {
        $from = date('Y-m-d');
        $to = date('Y-m-d', strtotime('+28 days'));
        
        $messen = get_posts([
            'post_type'      => 'isidor_messe',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_key'       => '_is_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => [[
                'key' => '_is_date', 'value' => [$from, $to],
                'compare' => 'BETWEEN', 'type' => 'DATE'
            ]],
        ]);
        
        if (empty($messen)) {
            echo '<div class="sakr-empty">Keine Messen in den nächsten 4 Wochen.</div>';
            return;
        }
        
        $page_url = get_permalink();
        $current_date = '';
        $today = date('Y-m-d');
        
        foreach ($messen as $m) {
            $date = get_post_meta($m->ID, '_is_date', true);
            $time = get_post_meta($m->ID, '_is_time', true);
            $completed = (bool) get_post_meta($m->ID, '_is_sakr_completed', true);
            $is_special = (bool) get_post_meta($m->ID, '_is_special', true);
            $todo_count = $this->count_open_todos_for_messe($m->ID);
            
            // Tagesgruppierung
            if ($date !== $current_date) {
                $current_date = $date;
                $dow = (int) date('N', strtotime($date));
                $is_sunday = ($dow === 7);
                $is_today = ($date === $today);
                $classes = 'sakr-day-header';
                if ($is_sunday)  $classes .= ' sakr-day-sunday';
                if ($is_today)   $classes .= ' sakr-day-today';
                echo '<h3 class="' . $classes . '">';
                echo esc_html(date_i18n('l, j. F Y', strtotime($date)));
                if ($is_today) echo ' <span class="sakr-badge sakr-badge-today">Heute</span>';
                echo '</h3>';
            }
            
            $link = add_query_arg('messe', $m->ID, $page_url);
            $card_class = 'sakr-messe-card';
            if ($completed) $card_class .= ' sakr-completed';
            if ($is_special) $card_class .= ' sakr-special';
            ?>
            <a href="<?php echo esc_url($link); ?>" class="<?php echo $card_class; ?>">
                <span class="sakr-messe-status"><?php echo $completed ? '✅' : '⬜'; ?></span>
                <div class="sakr-messe-info">
                    <strong class="sakr-messe-time"><?php echo esc_html($time); ?></strong>
                    <span class="sakr-messe-title"><?php echo esc_html($m->post_title); ?></span>
                </div>
                <?php if ($todo_count > 0): ?>
                    <span class="sakr-badge sakr-badge-todo"><?php echo $todo_count; ?> offen</span>
                <?php endif; ?>
                <span class="sakr-messe-arrow">›</span>
            </a>
            <?php
        }
    }

    /* ================================================================
       MESSE-DETAIL – Vollansicht einer Messe
       ================================================================ */

    public function render_detail($atts): string {
        $id = !empty($atts['id']) ? intval($atts['id']) : (isset($_GET['messe']) ? intval($_GET['messe']) : 0);
        if (!$id) return '<div class="sakr-notice">Keine Messe ausgewählt.</div>';

        $messe = get_post($id);
        if (!$messe || $messe->post_type !== 'isidor_messe') {
            return '<div class="sakr-notice sakr-notice-error">Messe nicht gefunden.</div>';
        }
        
        $date       = get_post_meta($id, '_is_date', true);
        $time       = get_post_meta($id, '_is_time', true);
        $liturgical = get_post_meta($id, '_is_liturgical', true);
        $completed  = (bool) get_post_meta($id, '_is_sakr_completed', true);
        $completed_by = get_post_meta($id, '_is_sakr_completed_by', true);
        $completed_at = get_post_meta($id, '_is_sakr_completed_at', true);
        
        $notes_def    = get_option('isidor_sakr_note_fields', []);
        $saved_notes  = get_post_meta($id, '_is_sakr_notes', true) ?: [];
        $todo_tpl     = get_option('isidor_sakr_todo_template', []);
        $checked      = get_post_meta($id, '_is_sakr_toDos', true) ?: [];
        
        // Dynamische ToDos für diese Messe
        $dynamic_todos = $this->get_todos_for_messe($id);

        ob_start(); ?>
        <div class="isidor-sakristan-detail" data-messe-id="<?php echo $id; ?>">
            <a href="<?php echo esc_url(remove_query_arg('messe')); ?>" class="sakr-back-link">← Übersicht</a>
            
            <!-- Header -->
            <div class="sakr-detail-header">
                <div class="sakr-detail-title-row">
                    <h2><?php echo esc_html($messe->post_title); ?></h2>
                    <?php if ($completed): ?>
                        <span class="sakr-badge sakr-badge-done">✅ Vorbereitet</span>
                    <?php endif; ?>
                </div>
                <div class="sakr-detail-meta">
                    📅 <?php echo date_i18n('l, j. F Y', strtotime($date)); ?> · ⏰ <?php echo esc_html($time); ?> Uhr
                    <?php if ($liturgical): ?>
                        · <span class="sakr-liturgical-badge"><?php echo esc_html($liturgical); ?></span>
                    <?php endif; ?>
                </div>
                <?php if ($completed && $completed_at): ?>
                    <div class="sakr-completed-info">
                        Markiert am <?php echo date_i18n('j. F, H:i', (int)$completed_at); ?> Uhr
                        <?php if ($completed_by): 
                            $user = get_userdata((int)$completed_by);
                            if ($user) echo ' von ' . esc_html($user->display_name);
                        endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="sakr-detail-grid">
            
                <!-- 🎵 Liedblatt-Info -->
                <div class="sakr-block">
                    <h3>🎵 Liedblatt-Info</h3>
                    <div class="sakr-block-content">
                        <?php echo apply_filters('isidor_cantus_get_messe_songs_html', '<p class="sakr-muted">Cantus-Modul nicht aktiv.</p>', $id); ?>
                    </div>
                </div>
                
                <!-- 📋 Hinweise / Notizen -->
                <?php 
                $has_notes = false;
                foreach ($notes_def as $f) {
                    if (!empty($f['visible_to_mesner']) && !empty($saved_notes[$f['key']])) {
                        $has_notes = true; break;
                    }
                }
                ?>
                <div class="sakr-block">
                    <h3>📋 Hinweise</h3>
                    <div class="sakr-block-content">
                    <?php if ($has_notes): ?>
                        <?php foreach ($notes_def as $f): 
                            if (!empty($f['visible_to_mesner']) && !empty($saved_notes[$f['key']])): ?>
                            <div class="sakr-note-item">
                                <span class="sakr-note-label"><?php echo esc_html($f['label']); ?></span>
                                <span class="sakr-note-value"><?php echo esc_html($saved_notes[$f['key']]); ?></span>
                            </div>
                        <?php endif; endforeach; ?>
                    <?php else: ?>
                        <p class="sakr-muted">Keine Hinweise eingetragen.</p>
                    <?php endif; ?>
                    </div>
                </div>

                <!-- ☑️ Standard-Checkliste -->
                <?php if (!empty($todo_tpl)): ?>
                <div class="sakr-block">
                    <h3>☑️ Standard-Checkliste</h3>
                    <div class="sakr-block-content">
                        <div class="sakr-checklist" id="sakr-checklist-standard">
                        <?php foreach ($todo_tpl as $t): 
                            $is_checked = isset($checked[$t['id']]);
                        ?>
                            <label class="sakr-check-item <?php echo $is_checked ? 'checked' : ''; ?>">
                                <input type="checkbox"
                                    class="sakr-checklist-cb"
                                    data-key="<?php echo esc_attr($t['id']); ?>"
                                    data-messe="<?php echo $id; ?>"
                                    <?php checked($is_checked); ?>
                                    <?php disabled($completed && !current_user_can('isidor_sakristan_edit')); ?>>
                                <span class="sakr-check-label"><?php echo esc_html($t['label']); ?></span>
                                <?php if (!empty($t['category'])): ?>
                                    <span class="sakr-check-cat"><?php echo esc_html($t['category']); ?></span>
                                <?php endif; ?>
                            </label>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- 📌 Aufgaben für diese Messe (dynamisch) -->
                <div class="sakr-block">
                    <h3>📌 Aufgaben für diese Messe</h3>
                    <div class="sakr-block-content">
                        <div class="sakr-todo-list" id="sakr-messe-todos">
                        <?php if (empty($dynamic_todos)): ?>
                            <p class="sakr-muted sakr-no-todos">Keine speziellen Aufgaben.</p>
                        <?php else: ?>
                            <?php foreach ($dynamic_todos as $todo): ?>
                                <?php $this->render_todo_item($todo); ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </div>
                        
                        <?php if (current_user_can('isidor_sakristan_todo_create')): ?>
                        <div class="sakr-add-todo">
                            <input type="text" id="sakr-new-todo-title" placeholder="Neue Aufgabe hinzufügen…" class="sakr-input">
                            <select id="sakr-new-todo-priority" class="sakr-select sakr-select-sm">
                                <option value="normal">Normal</option>
                                <option value="hoch">Hoch</option>
                                <option value="dringend">Dringend</option>
                            </select>
                            <button type="button" id="sakr-add-todo-btn" class="sakr-btn sakr-btn-sm" data-messe="<?php echo $id; ?>">+ Hinzufügen</button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Aktions-Leiste -->
            <?php if (current_user_can('isidor_sakristan_check') && !$completed): ?>
            <div class="sakr-action-bar">
                <button type="button" class="sakr-btn sakr-btn-success sakr-btn-lg" id="sakr-complete-btn" data-messe="<?php echo $id; ?>">
                    ✅ Sakristei vorbereitet — Pfarrer informieren
                </button>
            </div>
            <?php endif; ?>
        </div>
        <?php return ob_get_clean();
    }

    /* ================================================================
       TAB: AUFGABEN – Alle offenen ToDos (messe + allgemein)
       ================================================================ */

    private function render_todos_tab(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        
        $filter = sanitize_text_field($_GET['todo_filter'] ?? 'offen');
        $where_status = $filter === 'alle' ? "1=1" : $wpdb->prepare("t.status = %s", $filter);
        
        $todos = $wpdb->get_results("
            SELECT t.*, p.post_title AS messe_title,
                   pm_date.meta_value AS messe_date,
                   pm_time.meta_value AS messe_time
            FROM {$table} t
            LEFT JOIN {$wpdb->posts} p ON t.messe_id = p.ID
            LEFT JOIN {$wpdb->postmeta} pm_date ON t.messe_id = pm_date.post_id AND pm_date.meta_key = '_is_date'
            LEFT JOIN {$wpdb->postmeta} pm_time ON t.messe_id = pm_time.post_id AND pm_time.meta_key = '_is_time'
            WHERE {$where_status}
            ORDER BY 
                CASE t.priority WHEN 'dringend' THEN 0 WHEN 'hoch' THEN 1 ELSE 2 END,
                COALESCE(t.due_date, '9999-12-31') ASC,
                t.created_at DESC
            LIMIT 100
        ", ARRAY_A);
        
        $page_url = remove_query_arg('messe');
        $page_url = add_query_arg('sakr_tab', 'todos', $page_url);
        ?>
        
        <div class="sakr-todos-header">
            <div class="sakr-filter-pills">
                <a href="<?php echo esc_url(add_query_arg('todo_filter', 'offen', $page_url)); ?>" 
                   class="sakr-pill <?php echo $filter === 'offen' ? 'active' : ''; ?>">Offen</a>
                <a href="<?php echo esc_url(add_query_arg('todo_filter', 'erledigt', $page_url)); ?>" 
                   class="sakr-pill <?php echo $filter === 'erledigt' ? 'active' : ''; ?>">Erledigt</a>
                <a href="<?php echo esc_url(add_query_arg('todo_filter', 'alle', $page_url)); ?>" 
                   class="sakr-pill <?php echo $filter === 'alle' ? 'active' : ''; ?>">Alle</a>
            </div>
        </div>
        
        <?php if (current_user_can('isidor_sakristan_todo_create')): ?>
        <div class="sakr-add-todo sakr-add-todo-general">
            <h4>Neue Aufgabe anlegen</h4>
            <div class="sakr-add-todo-form">
                <input type="text" id="sakr-gen-todo-title" placeholder="Aufgabe…" class="sakr-input sakr-input-wide">
                <input type="date" id="sakr-gen-todo-date" class="sakr-input" value="<?php echo date('Y-m-d'); ?>">
                <select id="sakr-gen-todo-priority" class="sakr-select">
                    <option value="normal">Normal</option>
                    <option value="hoch">Hoch</option>
                    <option value="dringend">Dringend</option>
                </select>
                <button type="button" id="sakr-gen-add-btn" class="sakr-btn">+ Anlegen</button>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="sakr-todo-list" id="sakr-global-todos">
        <?php if (empty($todos)): ?>
            <div class="sakr-empty">Keine Aufgaben im Filter „<?php echo esc_html($filter); ?>".</div>
        <?php else: ?>
            <?php foreach ($todos as $todo): ?>
                <?php $this->render_todo_item($todo, true); ?>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
        <?php
    }

    private function render_todo_item(array $todo, bool $show_messe = false): void {
        $is_done = ($todo['status'] === 'erledigt');
        $prio_class = '';
        $prio_label = '';
        if ($todo['priority'] === 'dringend') { $prio_class = 'sakr-prio-urgent'; $prio_label = '🔴'; }
        elseif ($todo['priority'] === 'hoch')  { $prio_class = 'sakr-prio-high';   $prio_label = '🟠'; }
        
        $creator = get_userdata((int)($todo['created_by'] ?? 0));
        $creator_name = $creator ? $creator->display_name : '—';
        ?>
        <div class="sakr-todo-item <?php echo $prio_class; ?> <?php echo $is_done ? 'sakr-done' : ''; ?>" data-todo-id="<?php echo (int)$todo['id']; ?>">
            <label class="sakr-todo-check-wrap">
                <input type="checkbox" class="sakr-todo-cb"
                    data-id="<?php echo (int)$todo['id']; ?>"
                    <?php checked($is_done); ?>
                    <?php if (!current_user_can('isidor_sakristan_check') && !current_user_can('isidor_sakristan_edit')) echo 'disabled'; ?>>
            </label>
            <div class="sakr-todo-content">
                <span class="sakr-todo-title"><?php echo $prio_label; ?> <?php echo esc_html($todo['title']); ?></span>
                <div class="sakr-todo-meta">
                    <span class="sakr-todo-creator">von <?php echo esc_html($creator_name); ?></span>
                    <?php if (!empty($todo['due_date'])): ?>
                        · <span class="sakr-todo-due">bis <?php echo date_i18n('j. M', strtotime($todo['due_date'])); ?></span>
                    <?php endif; ?>
                    <?php if ($show_messe && !empty($todo['messe_title'])): ?>
                        · <span class="sakr-todo-messe">⛪ <?php echo esc_html($todo['messe_title']); ?>
                            <?php if (!empty($todo['messe_date'])): ?>
                                (<?php echo date_i18n('j.n.', strtotime($todo['messe_date'])); ?>
                                <?php echo !empty($todo['messe_time']) ? $todo['messe_time'] : ''; ?>)
                            <?php endif; ?>
                        </span>
                    <?php elseif ($show_messe && empty($todo['messe_id'])): ?>
                        · <span class="sakr-todo-messe sakr-todo-general">📋 Allgemein</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (current_user_can('isidor_sakristan_todo_create')): ?>
                <button type="button" class="sakr-todo-delete" data-id="<?php echo (int)$todo['id']; ?>" title="Löschen">×</button>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ================================================================
       TAB: DIENSTZEIT – Erfassung & Monatsübersicht
       
       Sichtbarkeit:
       - isidor_sakristan_timelog      → eigene Zeiten eintragen + sehen
       - isidor_sakristan_timelog_view → Daten aller Mitarbeiter einsehen
         (Pfarrer, Diakon, PGR, VVR)
       ================================================================ */

    private function render_timelog_tab(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_timelog';
        $user_id = get_current_user_id();
        $can_enter    = current_user_can('isidor_sakristan_timelog');
        $can_view_all = current_user_can('isidor_sakristan_timelog_view');
        
        $month = sanitize_text_field($_GET['tl_month'] ?? date('Y-m'));
        $month_start = $month . '-01';
        $month_end = date('Y-m-t', strtotime($month_start));
        
        $prev = date('Y-m', strtotime($month_start . ' -1 month'));
        $next = date('Y-m', strtotime($month_start . ' +1 month'));
        $page_url = add_query_arg('sakr_tab', 'zeit', remove_query_arg(['messe','tl_month']));
        
        // Eigene Einträge (nur wenn User selbst erfassen darf)
        $entries = [];
        $total_hours = 0;
        if ($can_enter) {
            $entries = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table} WHERE user_id = %d AND log_date BETWEEN %s AND %s ORDER BY log_date DESC, start_time DESC",
                $user_id, $month_start, $month_end
            ), ARRAY_A);
            $total_hours = array_sum(array_column($entries, 'hours'));
        }
        
        // Übersicht aller Mitarbeiter (Pfarrer, Diakon, PGR, VVR)
        $all_users_summary = [];
        if ($can_view_all) {
            $all_users_summary = $wpdb->get_results($wpdb->prepare(
                "SELECT user_id, SUM(hours) AS total, COUNT(*) AS entries 
                 FROM {$table} WHERE log_date BETWEEN %s AND %s 
                 GROUP BY user_id ORDER BY total DESC",
                $month_start, $month_end
            ), ARRAY_A);
        }
        ?>
        
        <!-- Monat-Navigation -->
        <div class="sakr-timelog-nav">
            <a href="<?php echo esc_url(add_query_arg('tl_month', $prev, $page_url)); ?>" class="sakr-btn sakr-btn-sm">← <?php echo date_i18n('M Y', strtotime($prev . '-01')); ?></a>
            <h3 class="sakr-timelog-month"><?php echo date_i18n('F Y', strtotime($month_start)); ?></h3>
            <a href="<?php echo esc_url(add_query_arg('tl_month', $next, $page_url)); ?>" class="sakr-btn sakr-btn-sm"><?php echo date_i18n('M Y', strtotime($next . '-01')); ?> →</a>
        </div>
        
        <?php /* ---- Eintragen: nur für Mesner/Sekretär (timelog-Cap) ---- */ ?>
        <?php if ($can_enter): ?>
        <div class="sakr-timelog-form-card">
            <h4>Dienstzeit eintragen</h4>
            <div class="sakr-timelog-form">
                <div class="sakr-form-row">
                    <label>Datum</label>
                    <input type="date" id="sakr-tl-date" class="sakr-input" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="sakr-form-row">
                    <label>Von</label>
                    <input type="time" id="sakr-tl-start" class="sakr-input" value="08:00">
                </div>
                <div class="sakr-form-row">
                    <label>Bis</label>
                    <input type="time" id="sakr-tl-end" class="sakr-input" value="12:00">
                </div>
                <div class="sakr-form-row">
                    <label>Kategorie</label>
                    <select id="sakr-tl-category" class="sakr-select">
                        <option value="sakristei">Sakristei</option>
                        <option value="buero">Büro</option>
                        <option value="sonstiges">Sonstiges</option>
                    </select>
                </div>
                <div class="sakr-form-row sakr-form-row-wide">
                    <label>Notiz</label>
                    <input type="text" id="sakr-tl-note" class="sakr-input sakr-input-wide" placeholder="Optional…">
                </div>
                <div class="sakr-form-row">
                    <button type="button" id="sakr-tl-save-btn" class="sakr-btn">Eintragen</button>
                </div>
            </div>
        </div>
        
        <!-- Eigene Einträge -->
        <div class="sakr-timelog-summary">
            <strong>Meine Stunden <?php echo date_i18n('F', strtotime($month_start)); ?>:</strong> 
            <span class="sakr-hours-total"><?php echo number_format($total_hours, 1, ',', '.'); ?> Stunden</span>
            (<?php echo count($entries); ?> Einträge)
        </div>
        
        <?php if (!empty($entries)): ?>
        <div class="sakr-timelog-table-wrap">
            <table class="sakr-timelog-table">
                <thead>
                    <tr>
                        <th>Datum</th>
                        <th>Von – Bis</th>
                        <th>Stunden</th>
                        <th>Kategorie</th>
                        <th>Notiz</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($entries as $e): ?>
                    <tr data-tl-id="<?php echo (int)$e['id']; ?>">
                        <td><?php echo date_i18n('D, j. M', strtotime($e['log_date'])); ?></td>
                        <td><?php echo $e['start_time'] ? substr($e['start_time'],0,5) . ' – ' . substr($e['end_time'],0,5) : '—'; ?></td>
                        <td><strong><?php echo number_format((float)$e['hours'], 1, ',', ''); ?></strong></td>
                        <td><span class="sakr-cat-pill sakr-cat-<?php echo esc_attr($e['category']); ?>"><?php echo esc_html(ucfirst($e['category'])); ?></span></td>
                        <td><?php echo esc_html($e['note'] ?? ''); ?></td>
                        <td><button type="button" class="sakr-tl-delete" data-id="<?php echo (int)$e['id']; ?>" title="Löschen">×</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php elseif (!$can_view_all): ?>
            <div class="sakr-empty">Noch keine Einträge in diesem Monat.</div>
        <?php endif; ?>
        <?php endif; /* /can_enter */ ?>
        
        <?php /* ---- Übersicht: nur für Pfarrer, Diakon, PGR, VVR (timelog_view-Cap) ---- */ ?>
        <?php if ($can_view_all): ?>
        <div class="sakr-timelog-admin">
            <h4>📊 Monatsübersicht aller Mitarbeiter</h4>
            <?php if (!empty($all_users_summary)): ?>
            <table class="sakr-timelog-table">
                <thead><tr><th>Mitarbeiter</th><th>Einträge</th><th>Stunden gesamt</th></tr></thead>
                <tbody>
                <?php 
                $grand_total = 0;
                foreach ($all_users_summary as $row):
                    $u = get_userdata((int)$row['user_id']);
                    $name = $u ? $u->display_name : 'User #' . $row['user_id'];
                    $grand_total += (float)$row['total'];
                ?>
                    <tr>
                        <td><?php echo esc_html($name); ?></td>
                        <td><?php echo (int)$row['entries']; ?></td>
                        <td><strong><?php echo number_format((float)$row['total'], 1, ',', '.'); ?> h</strong></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="border-top:2px solid #e2e8f0;">
                        <td><strong>Gesamt</strong></td>
                        <td></td>
                        <td><strong><?php echo number_format($grand_total, 1, ',', '.'); ?> h</strong></td>
                    </tr>
                </tfoot>
            </table>
            <?php else: ?>
                <div class="sakr-empty">Keine Einträge in diesem Monat.</div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php
    }

    /* ================================================================
       AJAX HANDLERS
       ================================================================ */

    /** Messe als vorbereitet markieren */
    public function ajax_complete_messe(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_check')) wp_send_json_error('Keine Berechtigung.');
        
        $id = intval($_POST['messe_id'] ?? 0);
        if (!$id) wp_send_json_error('Ungültige Messe.');
        
        update_post_meta($id, '_is_sakr_completed', 1);
        update_post_meta($id, '_is_sakr_completed_by', get_current_user_id());
        update_post_meta($id, '_is_sakr_completed_at', time());

        $this->send_notification_mail($id);
        wp_send_json_success(['message' => 'Messe als vorbereitet markiert.']);
    }

    /** Standard-Checkliste: Einzelne Checkbox togglen */
    public function ajax_toggle_checklist(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_check') && !current_user_can('isidor_sakristan_edit')) {
            wp_send_json_error('Keine Berechtigung.');
        }
        
        $messe_id = intval($_POST['messe_id'] ?? 0);
        $key      = sanitize_text_field($_POST['key'] ?? '');
        $checked  = (bool)($_POST['checked'] ?? false);
        
        if (!$messe_id || !$key) wp_send_json_error('Fehlende Parameter.');
        
        $todos = get_post_meta($messe_id, '_is_sakr_toDos', true) ?: [];
        if ($checked) {
            $todos[$key] = ['by' => get_current_user_id(), 'at' => time()];
        } else {
            unset($todos[$key]);
        }
        update_post_meta($messe_id, '_is_sakr_toDos', $todos);
        
        wp_send_json_success(['checklist' => $todos]);
    }

    /** Dynamische ToDos: Toggle erledigt/offen */
    public function ajax_toggle_todo(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_check') && !current_user_can('isidor_sakristan_edit')) {
            wp_send_json_error('Keine Berechtigung.');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        $id = intval($_POST['todo_id'] ?? 0);
        if (!$id) wp_send_json_error('Ungültige ID.');
        
        $current = $wpdb->get_var($wpdb->prepare("SELECT status FROM {$table} WHERE id = %d", $id));
        $new_status = ($current === 'erledigt') ? 'offen' : 'erledigt';
        
        $wpdb->update($table, [
            'status'       => $new_status,
            'completed_by' => $new_status === 'erledigt' ? get_current_user_id() : null,
            'completed_at' => $new_status === 'erledigt' ? current_time('mysql') : null,
        ], ['id' => $id]);
        
        wp_send_json_success(['status' => $new_status]);
    }

    /** Neues dynamisches ToDo anlegen */
    public function ajax_create_todo(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_todo_create')) wp_send_json_error('Keine Berechtigung.');
        
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        
        $title    = sanitize_text_field($_POST['title'] ?? '');
        $messe_id = intval($_POST['messe_id'] ?? 0) ?: null;
        $priority = sanitize_text_field($_POST['priority'] ?? 'normal');
        $due_date = sanitize_text_field($_POST['due_date'] ?? '') ?: null;
        
        if (!$title) wp_send_json_error('Titel fehlt.');
        if (!in_array($priority, ['normal','hoch','dringend'])) $priority = 'normal';
        
        $wpdb->insert($table, [
            'messe_id'   => $messe_id,
            'title'      => $title,
            'priority'   => $priority,
            'due_date'   => $due_date,
            'created_by' => get_current_user_id(),
            'status'     => 'offen',
        ]);
        
        $new_id = $wpdb->insert_id;
        if (!$new_id) wp_send_json_error('Datenbankfehler.');
        
        // HTML für den neuen Eintrag rendern
        $todo = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $new_id), ARRAY_A);
        ob_start();
        $this->render_todo_item($todo, ($messe_id === null));
        $html = ob_get_clean();
        
        wp_send_json_success(['id' => $new_id, 'html' => $html]);
    }

    /** ToDo löschen */
    public function ajax_delete_todo(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_todo_create')) wp_send_json_error('Keine Berechtigung.');
        
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_todos';
        $id = intval($_POST['todo_id'] ?? 0);
        if (!$id) wp_send_json_error('Ungültige ID.');
        
        $wpdb->delete($table, ['id' => $id]);
        wp_send_json_success();
    }

    /** Dienstzeit eintragen */
    public function ajax_save_timelog(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_timelog')) wp_send_json_error('Keine Berechtigung.');
        
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_timelog';
        
        $log_date   = sanitize_text_field($_POST['log_date'] ?? '');
        $start_time = sanitize_text_field($_POST['start_time'] ?? '');
        $end_time   = sanitize_text_field($_POST['end_time'] ?? '');
        $category   = sanitize_text_field($_POST['category'] ?? 'sakristei');
        $note       = sanitize_text_field($_POST['note'] ?? '');
        
        if (!$log_date || !$start_time || !$end_time) {
            wp_send_json_error('Datum und Zeiten sind Pflichtfelder.');
        }
        
        // Stunden berechnen
        $start_ts = strtotime("2000-01-01 {$start_time}");
        $end_ts   = strtotime("2000-01-01 {$end_time}");
        if ($end_ts <= $start_ts) {
            wp_send_json_error('Endzeit muss nach Startzeit liegen.');
        }
        $hours = round(($end_ts - $start_ts) / 3600, 2);
        
        if (!in_array($category, ['sakristei','buero','sonstiges'])) $category = 'sakristei';
        
        $wpdb->insert($table, [
            'user_id'    => get_current_user_id(),
            'log_date'   => $log_date,
            'start_time' => $start_time,
            'end_time'   => $end_time,
            'hours'      => $hours,
            'category'   => $category,
            'note'       => $note,
        ]);
        
        if (!$wpdb->insert_id) wp_send_json_error('Datenbankfehler.');
        
        wp_send_json_success([
            'id'    => $wpdb->insert_id,
            'hours' => $hours,
            'message' => number_format($hours, 1, ',', '') . ' Stunden eingetragen.',
        ]);
    }

    /** Dienstzeit-Eintrag löschen */
    public function ajax_delete_timelog(): void {
        check_ajax_referer('sakristan_nonce', 'nonce');
        if (!current_user_can('isidor_sakristan_timelog')) wp_send_json_error('Keine Berechtigung.');
        
        global $wpdb;
        $table = $wpdb->prefix . 'isidor_sakr_timelog';
        $id = intval($_POST['tl_id'] ?? 0);
        if (!$id) wp_send_json_error('Ungültige ID.');
        
        // Nur eigene Einträge löschen (außer Admin)
        if (!current_user_can('isidor_sakristan_edit')) {
            $owner = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id = %d", $id));
            if ((int)$owner !== get_current_user_id()) {
                wp_send_json_error('Nur eigene Einträge löschbar.');
            }
        }
        
        $wpdb->delete($table, ['id' => $id]);
        wp_send_json_success();
    }

    /* ================================================================
       HELPERS
       ================================================================ */

    private function get_todos_for_messe(int $messe_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}isidor_sakr_todos WHERE messe_id = %d ORDER BY 
                CASE priority WHEN 'dringend' THEN 0 WHEN 'hoch' THEN 1 ELSE 2 END,
                created_at ASC",
            $messe_id
        ), ARRAY_A) ?: [];
    }

    private function count_open_todos_for_messe(int $messe_id): int {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_sakr_todos WHERE messe_id = %d AND status = 'offen'",
            $messe_id
        ));
    }

    private function send_notification_mail(int $id): void {
        $emails = get_option('isidor_sakr_notify_emails');
        if (!$emails) {
            $users = get_users(['role__in' => ['administrator', 'isidor_pfarrer_godmode', 'isidor_pfarrer']]);
            $emails = wp_list_pluck($users, 'user_email');
        }
        if (empty($emails)) return;
        
        $date = get_post_meta($id, '_is_date', true);
        $time = get_post_meta($id, '_is_time', true);
        $user = wp_get_current_user();
        
        $parish = class_exists('Isidor_Parish_Settings') ? Isidor_Parish_Settings::name() : 'Pfarre';
        
        $msg = sprintf(
            "Messe am %s um %s Uhr wurde von %s als VORBEREITET markiert.\n\n%s\nIsidor OS · %s",
            date_i18n('l, j. F Y', strtotime($date)),
            $time,
            $user->display_name,
            get_the_title($id),
            $parish
        );
        
        wp_mail($emails, "✅ Sakristei vorbereitet: " . get_the_title($id), $msg);
    }
}
