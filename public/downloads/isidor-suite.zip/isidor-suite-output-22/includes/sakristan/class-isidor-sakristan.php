<?php

/**
 * Isidor Sakristan – Hauptklasse
 * 
 * Verwaltet DB-Tabellen, Capabilities, und Assets für die Sakristei-App.
 * 
 * DB-Tabellen:
 * - isidor_sakr_todos: Dynamische Aufgaben (pro Messe oder allgemein)
 * - isidor_sakr_timelog: Dienstzeit-Einträge für Mesner/Sekretär
 */
class Isidor_Sakristan {

    public const VERSION = '2.0.0';
    public const DB_VERSION_KEY = 'isidor_sakr_db_version';
    public const DB_VERSION = '2.0';

    /* ----------------------------------------------------------
       Activation / DB Setup
       ---------------------------------------------------------- */

    public static function activate(): void {
        self::setup_capabilities();
        self::init_default_options();
        self::create_tables();
    }

    public static function create_tables(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        // ToDos – dynamische Aufgaben (an Messe gebunden oder allgemein)
        $sql_todos = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}isidor_sakr_todos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            messe_id BIGINT UNSIGNED DEFAULT NULL COMMENT 'NULL = allgemeine Aufgabe',
            title VARCHAR(500) NOT NULL,
            description TEXT DEFAULT NULL,
            category VARCHAR(100) DEFAULT 'allgemein',
            priority ENUM('normal','hoch','dringend') DEFAULT 'normal',
            due_date DATE DEFAULT NULL,
            created_by BIGINT UNSIGNED NOT NULL,
            assigned_to BIGINT UNSIGNED DEFAULT NULL COMMENT 'NULL = alle Mesner',
            status ENUM('offen','erledigt','storniert') DEFAULT 'offen',
            completed_by BIGINT UNSIGNED DEFAULT NULL,
            completed_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_messe (messe_id),
            KEY idx_status (status),
            KEY idx_due (due_date),
            KEY idx_assigned (assigned_to)
        ) {$charset};";

        // Dienstzeit-Erfassung
        $sql_timelog = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}isidor_sakr_timelog (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            log_date DATE NOT NULL,
            start_time TIME DEFAULT NULL,
            end_time TIME DEFAULT NULL,
            hours DECIMAL(5,2) NOT NULL DEFAULT 0,
            messe_id BIGINT UNSIGNED DEFAULT NULL,
            note VARCHAR(500) DEFAULT NULL,
            category ENUM('sakristei','buero','sonstiges') DEFAULT 'sakristei',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_date (user_id, log_date),
            KEY idx_month (log_date)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_todos);
        dbDelta($sql_timelog);
        
        update_option(self::DB_VERSION_KEY, self::DB_VERSION);
    }

    private static function setup_capabilities(): void {
        $admin = get_role('administrator');
        if ($admin) {
            foreach (['isidor_sakristan_view','isidor_sakristan_edit','isidor_sakristan_check','isidor_sakristan_todo_create','isidor_sakristan_timelog','isidor_sakristan_timelog_view'] as $cap) {
                $admin->add_cap($cap);
            }
        }

        // Pfarrer/Diakon/Sekretär: sehen + bearbeiten + ToDos anlegen
        foreach (['isidor_pfarrer_godmode','isidor_pfarrer','isidor_diakon','isidor_sekretaer'] as $slug) {
            $role = get_role($slug);
            if ($role) {
                $role->add_cap('isidor_sakristan_view');
                $role->add_cap('isidor_sakristan_edit');
                $role->add_cap('isidor_sakristan_todo_create');
            }
        }

        // Pfarrer + Diakon: Dienstzeit-Daten aller Mitarbeiter einsehen
        foreach (['isidor_pfarrer_godmode','isidor_pfarrer','isidor_diakon'] as $slug) {
            $role = get_role($slug);
            if ($role) {
                $role->add_cap('isidor_sakristan_timelog_view');
            }
        }

        // PGR + VVR: Dienstzeit-Daten aller Mitarbeiter einsehen (Aufsicht)
        foreach (['isidor_pgr','isidor_vvr'] as $slug) {
            $role = get_role($slug);
            if ($role) {
                $role->add_cap('isidor_sakristan_view');
                $role->add_cap('isidor_sakristan_timelog_view');
            }
        }

        // Mesner: sehen + abhaken + eigene Zeiterfassung
        $mesner = get_role('isidor_mesner');
        if ($mesner) {
            $mesner->add_cap('isidor_sakristan_view');
            $mesner->add_cap('isidor_sakristan_check');
            $mesner->add_cap('isidor_sakristan_timelog');
        }

        // Sekretär: eigene Zeiterfassung
        $sekr = get_role('isidor_sekretaer');
        if ($sekr) {
            $sekr->add_cap('isidor_sakristan_timelog');
        }
    }

    private static function init_default_options(): void {
        if (!get_option('isidor_sakr_todo_template')) {
            update_option('isidor_sakr_todo_template', [
                ['id' => 'gewand',  'label' => 'Gewänder bereitlegen',    'category' => 'Liturgie', 'required' => true],
                ['id' => 'kelch',   'label' => 'Kelch & Hostienschalen',  'category' => 'Liturgie', 'required' => true],
                ['id' => 'mikro',   'label' => 'Mikrofone prüfen',        'category' => 'Technik',  'required' => true],
                ['id' => 'kerzen',  'label' => 'Kerzen kontrollieren',    'category' => 'Liturgie', 'required' => false],
                ['id' => 'heizung', 'label' => 'Heizung/Lüftung prüfen', 'category' => 'Technik',  'required' => false],
            ]);
        }
        if (!get_option('isidor_sakr_note_fields')) {
            update_option('isidor_sakr_note_fields', [
                ['key' => 'farbe',    'label' => 'Liturgische Farbe',   'type' => 'text',     'visible_to_mesner' => true],
                ['key' => 'hostien',  'label' => 'Hostienanzahl ca.',   'type' => 'number',   'visible_to_mesner' => true],
                ['key' => 'technik',  'label' => 'Technik-Hinweise',    'type' => 'textarea', 'visible_to_mesner' => true],
                ['key' => 'besonders','label' => 'Besonderheiten',      'type' => 'textarea', 'visible_to_mesner' => true],
            ]);
        }
        if (!get_option('isidor_sakr_todo_categories')) {
            update_option('isidor_sakr_todo_categories', [
                'liturgie'   => 'Liturgie',
                'technik'    => 'Technik',
                'reinigung'  => 'Reinigung',
                'dekoration' => 'Dekoration',
                'verwaltung' => 'Verwaltung',
                'sonstiges'  => 'Sonstiges',
            ]);
        }
    }

    /* ----------------------------------------------------------
       Constructor + Assets
       ---------------------------------------------------------- */

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend']);
        
        // DB-Version prüfen
        if (get_option(self::DB_VERSION_KEY) !== self::DB_VERSION) {
            self::create_tables();
        }
    }

    public function enqueue_frontend(): void {
        if (!is_singular()) return;
        $post = get_post();
        if (!$post || !str_contains($post->post_content, 'isidor_sakristan')) return;
        
        wp_enqueue_style(
            'isidor-sakristan',
            ISIDOR_SUITE_URL . 'assets/css/sakristan.css',
            ['isidor-shell'],
            self::VERSION
        );
        wp_enqueue_script(
            'isidor-sakristan',
            ISIDOR_SUITE_URL . 'assets/js/sakristan.js',
            ['jquery'],
            self::VERSION,
            true
        );
        wp_localize_script('isidor-sakristan', 'sakristanData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('sakristan_nonce'),
        ]);
    }
}
