<?php
/**
 * Isidor Messtipendien / Intentionen
 * 
 * Verwaltet Messintentionen und Stipendien:
 * - Intention pro Messe
 * - Spender
 * - Betrag
 * - Export/API für externe Verwendung
 */

if (!defined('ABSPATH')) exit;

class Isidor_Stipendien {
    
    /** @var Isidor_Stipendien|null */
    private static $instance = null;
    
    /** DB Version */
    private const DB_VERSION = '1.0';
    private const DB_VERSION_KEY = 'isidor_stipendien_db_version';
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', [$this, 'maybe_upgrade_db']);
        add_action('admin_menu', [$this, 'add_admin_menu'], 25);
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_action('save_post_isidor_messe', [$this, 'save_meta']);
        add_action('rest_api_init', [$this, 'register_api']);
        
        // Shortcodes
        add_shortcode('isidor_messen_export', [$this, 'render_export_view']);
        add_shortcode('isidor_messen_public', [$this, 'render_public_view']);
    }
    
    /**
     * Datenbank upgraden
     */
    public function maybe_upgrade_db() {
        if (get_option(self::DB_VERSION_KEY) !== self::DB_VERSION) {
            $this->create_tables();
            update_option(self::DB_VERSION_KEY, self::DB_VERSION);
        }
    }
    
    /**
     * Tabellen erstellen
     */
    private function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $sql = "CREATE TABLE {$wpdb->prefix}isidor_stipendien (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            messe_id BIGINT UNSIGNED NOT NULL,
            intention TEXT NOT NULL,
            spender VARCHAR(255) DEFAULT '',
            betrag INT UNSIGNED DEFAULT 0,
            status VARCHAR(20) DEFAULT 'offen',
            notiz TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by BIGINT UNSIGNED,
            KEY messe_id (messe_id),
            KEY status (status)
        ) $charset;";
        
        dbDelta($sql);
    }
    
    /**
     * Admin-Menü
     */
    public function add_admin_menu() {
        add_submenu_page(
            'isidor-os',
            'Messtipendien',
            '🕯️ Stipendien',
            'edit_posts',
            'isidor-stipendien',
            [$this, 'render_admin_page']
        );
    }
    
    /**
     * Meta Box in Messen-Editor
     */
    public function add_meta_box() {
        add_meta_box(
            'isidor_messe_intention',
            '🕯️ Intention / Stipendium',
            [$this, 'render_meta_box'],
            'isidor_messe',
            'normal',
            'high'
        );
        
        add_meta_box(
            'isidor_messe_details',
            '📖 Messe-Details',
            [$this, 'render_details_meta_box'],
            'isidor_messe',
            'normal',
            'default'
        );
    }
    
    /**
     * Meta Box rendern
     */
    public function render_meta_box($post) {
        wp_nonce_field('isidor_intention_nonce', 'intention_nonce');
        
        $intention = get_post_meta($post->ID, '_is_intention', true);
        $spender = get_post_meta($post->ID, '_is_spender', true);
        $betrag = get_post_meta($post->ID, '_is_stipendium_betrag', true);
        $predigt = get_post_meta($post->ID, '_is_predigt', true);
        ?>
        <table class="form-table">
            <tr>
                <th><label for="is_intention">Intention</label></th>
                <td>
                    <textarea name="is_intention" id="is_intention" rows="3" class="large-text"><?php 
                        echo esc_textarea($intention); 
                    ?></textarea>
                    <p class="description">Für wen wird die Messe gelesen?</p>
                </td>
            </tr>
            <tr>
                <th><label for="is_spender">Spender</label></th>
                <td>
                    <input type="text" name="is_spender" id="is_spender" 
                           value="<?php echo esc_attr($spender); ?>" class="regular-text">
                </td>
            </tr>
            <tr>
                <th><label for="is_stipendium_betrag">Stipendium (€)</label></th>
                <td>
                    <input type="number" name="is_stipendium_betrag" id="is_stipendium_betrag" 
                           value="<?php echo esc_attr($betrag); ?>" min="0" step="1" style="width:100px;">
                </td>
            </tr>
            <tr>
                <th><label for="is_predigt">Predigt</label></th>
                <td>
                    <textarea name="is_predigt" id="is_predigt" rows="4" class="large-text"><?php 
                        echo esc_textarea($predigt); 
                    ?></textarea>
                    <p class="description">Notizen zur Predigt</p>
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Details Meta Box
     */
    public function render_details_meta_box($post) {
        $lesungen = get_post_meta($post->ID, '_is_lesungen', true);
        $evangelium = get_post_meta($post->ID, '_is_evangelium', true);
        $besonderheiten = get_post_meta($post->ID, '_is_besonderheiten', true);
        $extra_dienste = get_post_meta($post->ID, '_is_extra_dienste', true);
        $hat_band = get_post_meta($post->ID, '_is_hat_band', true);
        ?>
        <table class="form-table">
            <tr>
                <th><label for="is_lesungen">Lesungen</label></th>
                <td>
                    <input type="text" name="is_lesungen" id="is_lesungen" 
                           value="<?php echo esc_attr($lesungen); ?>" class="large-text">
                    <p class="description">z.B. "Röm 8,28-30; Mt 13,44-46"</p>
                </td>
            </tr>
            <tr>
                <th><label for="is_evangelium">Evangelium</label></th>
                <td>
                    <input type="text" name="is_evangelium" id="is_evangelium" 
                           value="<?php echo esc_attr($evangelium); ?>" class="large-text">
                </td>
            </tr>
            <tr>
                <th>Musik</th>
                <td>
                    <label>
                        <input type="checkbox" name="is_hat_band" value="1" 
                               <?php checked($hat_band, '1'); ?>>
                        Mit Band (statt nur Orgel)
                    </label>
                </td>
            </tr>
            <tr>
                <th>Erweiterte Dienste</th>
                <td>
                    <label style="display:block; margin-bottom:5px;">
                        <input type="checkbox" name="is_extra_dienste[mehr_lektoren]" value="1" 
                               <?php checked(isset($extra_dienste['mehr_lektoren'])); ?>>
                        Mehr als 2 Lektoren benötigt
                    </label>
                    <label style="display:block; margin-bottom:5px;">
                        <input type="checkbox" name="is_extra_dienste[mehr_kommunionhelfer]" value="1" 
                               <?php checked(isset($extra_dienste['mehr_kommunionhelfer'])); ?>>
                        Mehr als 1 Kommunionhelfer benötigt
                    </label>
                    <label style="display:block; margin-bottom:5px;">
                        <input type="checkbox" name="is_extra_dienste[mesner]" value="1" 
                               <?php checked(isset($extra_dienste['mesner'])); ?>>
                        Mesner benötigt
                    </label>
                </td>
            </tr>
            <tr>
                <th><label for="is_besonderheiten">Besonderheiten</label></th>
                <td>
                    <textarea name="is_besonderheiten" id="is_besonderheiten" rows="3" class="large-text"><?php 
                        echo esc_textarea($besonderheiten); 
                    ?></textarea>
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Meta speichern
     */
    public function save_meta($post_id) {
        if (!isset($_POST['intention_nonce']) || 
            !wp_verify_nonce($_POST['intention_nonce'], 'isidor_intention_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        
        // Intention fields
        update_post_meta($post_id, '_is_intention', sanitize_textarea_field($_POST['is_intention'] ?? ''));
        update_post_meta($post_id, '_is_spender', sanitize_text_field($_POST['is_spender'] ?? ''));
        update_post_meta($post_id, '_is_stipendium_betrag', (int) ($_POST['is_stipendium_betrag'] ?? 0));
        update_post_meta($post_id, '_is_predigt', sanitize_textarea_field($_POST['is_predigt'] ?? ''));
        
        // Details fields
        update_post_meta($post_id, '_is_lesungen', sanitize_text_field($_POST['is_lesungen'] ?? ''));
        update_post_meta($post_id, '_is_evangelium', sanitize_text_field($_POST['is_evangelium'] ?? ''));
        update_post_meta($post_id, '_is_besonderheiten', sanitize_textarea_field($_POST['is_besonderheiten'] ?? ''));
        update_post_meta($post_id, '_is_hat_band', isset($_POST['is_hat_band']) ? '1' : '');
        update_post_meta($post_id, '_is_extra_dienste', $_POST['is_extra_dienste'] ?? []);
    }
    
    /**
     * Admin-Seite
     */
    public function render_admin_page() {
        global $wpdb;
        
        $start = isset($_GET['start']) ? sanitize_text_field($_GET['start']) : date('Y-m-d');
        $end = isset($_GET['end']) ? sanitize_text_field($_GET['end']) : date('Y-m-d', strtotime('+30 days'));
        
        // Messen mit Intentionen laden
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => '_is_date',
                    'value' => [$start, $end],
                    'compare' => 'BETWEEN',
                    'type' => 'DATE'
                ]
            ],
            'orderby' => 'meta_value',
            'meta_key' => '_is_date',
            'order' => 'ASC'
        ]);
        ?>
        <div class="wrap">
            <h1>🕯️ Messtipendien & Intentionen</h1>
            
            <form method="get" style="margin:20px 0; display:flex; gap:10px; align-items:center;">
                <input type="hidden" name="page" value="isidor-stipendien">
                <label>Von: <input type="date" name="start" value="<?php echo esc_attr($start); ?>"></label>
                <label>Bis: <input type="date" name="end" value="<?php echo esc_attr($end); ?>"></label>
                <button type="submit" class="button">Filtern</button>
                <a href="<?php echo admin_url('admin.php?page=isidor-stipendien&export=csv&start=' . $start . '&end=' . $end); ?>" 
                   class="button">📥 CSV Export</a>
            </form>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:100px;">Datum</th>
                        <th style="width:60px;">Zeit</th>
                        <th>Messe</th>
                        <th>Intention</th>
                        <th style="width:120px;">Spender</th>
                        <th style="width:80px;">Betrag</th>
                        <th style="width:100px;">Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messen as $messe): 
                        $date = get_post_meta($messe->ID, '_is_date', true);
                        $time = get_post_meta($messe->ID, '_is_time', true);
                        $intention = get_post_meta($messe->ID, '_is_intention', true);
                        $spender = get_post_meta($messe->ID, '_is_spender', true);
                        $betrag = get_post_meta($messe->ID, '_is_stipendium_betrag', true);
                    ?>
                    <tr>
                        <td><?php echo date_i18n('D, d.m.Y', strtotime($date)); ?></td>
                        <td><?php echo esc_html($time); ?></td>
                        <td><strong><?php echo esc_html($messe->post_title); ?></strong></td>
                        <td><?php echo esc_html($intention ?: '—'); ?></td>
                        <td><?php echo esc_html($spender ?: '—'); ?></td>
                        <td><?php echo $betrag ? '€ ' . number_format($betrag, 0, ',', '.') : '—'; ?></td>
                        <td>
                            <a href="<?php echo get_edit_post_link($messe->ID); ?>" class="button button-small">Bearbeiten</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($messen)): ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding:20px;">
                            Keine Messen im gewählten Zeitraum.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div style="margin-top:30px; padding:20px; background:#f0f0f1; border-radius:8px;">
                <h3>📤 API für externe Verwendung</h3>
                <p>Messen-Daten können über die REST API abgerufen werden:</p>
                <code style="display:block; padding:10px; background:#fff; border-radius:4px;">
                    <?php echo rest_url('isidor/v1/messen?start=' . $start . '&end=' . $end); ?>
                </code>
                <p style="margin-top:10px;">
                    <strong>Shortcode für öffentliche Anzeige:</strong><br>
                    <code>[isidor_messen_public start="<?php echo $start; ?>" end="<?php echo $end; ?>"]</code>
                </p>
            </div>
        </div>
        <?php
        
        // CSV Export
        if (isset($_GET['export']) && $_GET['export'] === 'csv') {
            $this->export_csv($messen);
        }
    }
    
    /**
     * CSV Export
     */
    private function export_csv($messen) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="messen-' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM for Excel
        
        fputcsv($output, ['Datum', 'Zeit', 'Messe', 'Liturgischer Name', 'Intention', 'Spender', 'Betrag', 'Lesungen', 'Evangelium', 'Predigt']);
        
        foreach ($messen as $messe) {
            fputcsv($output, [
                get_post_meta($messe->ID, '_is_date', true),
                get_post_meta($messe->ID, '_is_time', true),
                $messe->post_title,
                get_post_meta($messe->ID, '_is_liturgical', true),
                get_post_meta($messe->ID, '_is_intention', true),
                get_post_meta($messe->ID, '_is_spender', true),
                get_post_meta($messe->ID, '_is_stipendium_betrag', true),
                get_post_meta($messe->ID, '_is_lesungen', true),
                get_post_meta($messe->ID, '_is_evangelium', true),
                get_post_meta($messe->ID, '_is_predigt', true),
            ]);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * REST API registrieren
     */
    public function register_api() {
        register_rest_route('isidor/v1', '/messen', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_messen'],
            'permission_callback' => '__return_true',
        ]);
    }
    
    /**
     * API: Messen abrufen
     */
    public function api_get_messen($request) {
        $start = $request->get_param('start') ?: date('Y-m-d');
        $end = $request->get_param('end') ?: date('Y-m-d', strtotime('+30 days'));
        
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => '_is_date',
                    'value' => [$start, $end],
                    'compare' => 'BETWEEN',
                    'type' => 'DATE'
                ]
            ],
            'orderby' => 'meta_value',
            'meta_key' => '_is_date',
            'order' => 'ASC'
        ]);
        
        $result = [];
        foreach ($messen as $messe) {
            $result[] = [
                'id' => $messe->ID,
                'title' => $messe->post_title,
                'date' => get_post_meta($messe->ID, '_is_date', true),
                'time' => get_post_meta($messe->ID, '_is_time', true),
                'liturgical_name' => get_post_meta($messe->ID, '_is_liturgical', true),
                'intention' => get_post_meta($messe->ID, '_is_intention', true),
                'lesungen' => get_post_meta($messe->ID, '_is_lesungen', true),
                'evangelium' => get_post_meta($messe->ID, '_is_evangelium', true),
                'predigt' => get_post_meta($messe->ID, '_is_predigt', true),
            ];
        }
        
        return rest_ensure_response($result);
    }
    
    /**
     * Shortcode: Öffentliche Messen-Liste
     */
    public function render_public_view($atts) {
        $atts = shortcode_atts([
            'start' => date('Y-m-d'),
            'end' => date('Y-m-d', strtotime('+14 days')),
            'show_intention' => 'true',
        ], $atts);
        
        $messen = get_posts([
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => '_is_date',
                    'value' => [$atts['start'], $atts['end']],
                    'compare' => 'BETWEEN',
                    'type' => 'DATE'
                ]
            ],
            'orderby' => 'meta_value',
            'meta_key' => '_is_date',
            'order' => 'ASC'
        ]);
        
        ob_start();
        ?>
        <div class="isidor-messen-public">
            <?php foreach ($messen as $messe): 
                $date = get_post_meta($messe->ID, '_is_date', true);
                $time = get_post_meta($messe->ID, '_is_time', true);
                $intention = get_post_meta($messe->ID, '_is_intention', true);
                $liturgical = get_post_meta($messe->ID, '_is_liturgical', true);
            ?>
            <div class="isidor-messe-item" style="padding:15px; margin-bottom:15px; background:#f9f9f9; border-radius:8px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div>
                        <strong style="font-size:1.1em;">
                            <?php echo date_i18n('l, j. F', strtotime($date)); ?> — <?php echo esc_html($time); ?> Uhr
                        </strong>
                        <div style="color:#666; margin-top:2px;">
                            <?php echo esc_html($messe->post_title); ?>
                            <?php if ($liturgical): ?>
                                <span style="color:#68b9b2;">• <?php echo esc_html($liturgical); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if ($atts['show_intention'] === 'true' && $intention): ?>
                <div style="margin-top:10px; padding-top:10px; border-top:1px solid #e0e0e0; color:#555;">
                    <em>🕯️ <?php echo esc_html($intention); ?></em>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php if (empty($messen)): ?>
            <p>Keine Messen im gewählten Zeitraum.</p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
