<?php

/**
 * Isidor Tagesplan — Detaillierter Liturgie-Ablauf
 * 
 * Erweiterung für den Tagesplan:
 * - Schritt-für-Schritt Messablauf
 * - Fürbitten-Texte
 * - Ansagen
 * - Druckbare Ablaufpläne für Ministranten/Lektoren
 */

if (!defined('ABSPATH')) exit;

class Isidor_Tagesplan_Detail {
    
    private static $instance = null;
    
    /**
     * Standard-Ablaufschritte für eine Heilige Messe
     */
    public const DEFAULT_STEPS = [
        // Eröffnung
        ['section' => 'eröffnung', 'key' => 'einzug', 'label' => 'Einzug', 'roles' => ['ministrant', 'zelebrant'], 'notes' => ''],
        ['section' => 'eröffnung', 'key' => 'begruessung', 'label' => 'Begrüßung / Kreuzzeichen', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'eröffnung', 'key' => 'einfuehrung', 'label' => 'Einführung', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'eröffnung', 'key' => 'bussakt', 'label' => 'Bußakt / Kyrie', 'roles' => ['zelebrant', 'kantor'], 'notes' => ''],
        ['section' => 'eröffnung', 'key' => 'gloria', 'label' => 'Gloria', 'roles' => ['kantor', 'gemeinde'], 'notes' => 'Entfällt in Advent und Fastenzeit'],
        ['section' => 'eröffnung', 'key' => 'tagesgebet', 'label' => 'Tagesgebet', 'roles' => ['zelebrant'], 'notes' => ''],
        
        // Wortgottesdienst
        ['section' => 'wortgottesdienst', 'key' => 'lesung1', 'label' => '1. Lesung', 'roles' => ['lektor'], 'notes' => ''],
        ['section' => 'wortgottesdienst', 'key' => 'antwortpsalm', 'label' => 'Antwortpsalm', 'roles' => ['kantor', 'gemeinde'], 'notes' => ''],
        ['section' => 'wortgottesdienst', 'key' => 'lesung2', 'label' => '2. Lesung', 'roles' => ['lektor'], 'notes' => 'An Sonntagen und Hochfesten'],
        ['section' => 'wortgottesdienst', 'key' => 'ruf_evangelium', 'label' => 'Ruf vor dem Evangelium', 'roles' => ['kantor', 'gemeinde'], 'notes' => ''],
        ['section' => 'wortgottesdienst', 'key' => 'evangelium', 'label' => 'Evangelium', 'roles' => ['zelebrant', 'diakon', 'ministrant'], 'notes' => 'Kerzen und Weihrauch'],
        ['section' => 'wortgottesdienst', 'key' => 'predigt', 'label' => 'Predigt', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'wortgottesdienst', 'key' => 'credo', 'label' => 'Glaubensbekenntnis', 'roles' => ['gemeinde'], 'notes' => 'An Sonntagen und Hochfesten'],
        ['section' => 'wortgottesdienst', 'key' => 'fuerbitten', 'label' => 'Fürbitten', 'roles' => ['lektor', 'zelebrant'], 'notes' => ''],
        
        // Eucharistiefeier
        ['section' => 'eucharistie', 'key' => 'gabenbereitung', 'label' => 'Gabenbereitung', 'roles' => ['ministrant', 'zelebrant'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'gabengebet', 'label' => 'Gabengebet', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'praefation', 'label' => 'Präfation', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'sanctus', 'label' => 'Sanctus', 'roles' => ['kantor', 'gemeinde'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'hochgebet', 'label' => 'Hochgebet', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'vater_unser', 'label' => 'Vater unser', 'roles' => ['gemeinde'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'friedensgruss', 'label' => 'Friedensgruß', 'roles' => ['gemeinde'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'agnus_dei', 'label' => 'Agnus Dei / Brotbrechen', 'roles' => ['kantor', 'gemeinde'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'kommunion', 'label' => 'Kommunion', 'roles' => ['zelebrant', 'kommunionhelfer', 'ministrant'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'danklied', 'label' => 'Danklied / Stille', 'roles' => ['kantor', 'gemeinde'], 'notes' => ''],
        ['section' => 'eucharistie', 'key' => 'schlussgebet', 'label' => 'Schlussgebet', 'roles' => ['zelebrant'], 'notes' => ''],
        
        // Entlassung
        ['section' => 'entlassung', 'key' => 'vermeldungen', 'label' => 'Vermeldungen', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'entlassung', 'key' => 'segen', 'label' => 'Segen', 'roles' => ['zelebrant'], 'notes' => ''],
        ['section' => 'entlassung', 'key' => 'entlassung', 'label' => 'Entlassung', 'roles' => ['zelebrant', 'diakon'], 'notes' => ''],
        ['section' => 'entlassung', 'key' => 'auszug', 'label' => 'Auszug', 'roles' => ['ministrant', 'zelebrant'], 'notes' => ''],
    ];
    
    public const SECTIONS = [
        'eröffnung' => ['label' => 'Eröffnung', 'icon' => '🚪', 'color' => '#3b82f6'],
        'wortgottesdienst' => ['label' => 'Wortgottesdienst', 'icon' => '📖', 'color' => '#8b5cf6'],
        'eucharistie' => ['label' => 'Eucharistiefeier', 'icon' => '🍞', 'color' => '#f59e0b'],
        'entlassung' => ['label' => 'Entlassung', 'icon' => '✨', 'color' => '#10b981'],
    ];
    
    public const ROLES = [
        'zelebrant' => ['label' => 'Zelebrant', 'short' => 'Z'],
        'diakon' => ['label' => 'Diakon', 'short' => 'D'],
        'lektor' => ['label' => 'Lektor/in', 'short' => 'L'],
        'kantor' => ['label' => 'Kantor/in', 'short' => 'K'],
        'ministrant' => ['label' => 'Ministrant/in', 'short' => 'M'],
        'kommunionhelfer' => ['label' => 'Kommunionhelfer/in', 'short' => 'KH'],
        'gemeinde' => ['label' => 'Gemeinde', 'short' => 'G'],
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_ajax_isidor_save_detail_step', [$this, 'ajax_save_step']);
        add_action('wp_ajax_isidor_save_fuerbitten', [$this, 'ajax_save_fuerbitten']);
        add_action('wp_ajax_isidor_save_vermeldungen', [$this, 'ajax_save_vermeldungen']);
        add_action('wp_ajax_isidor_print_ablauf', [$this, 'ajax_print_ablauf']);
        add_action('wp_ajax_nopriv_isidor_print_ablauf', [$this, 'ajax_print_ablauf']);
    }
    
    /**
     * Detail-Daten für eine Messe abrufen
     */
    public function get_detail(int $messe_id): array {
        $saved = get_post_meta($messe_id, '_is_tagesplan_detail', true);
        
        if (empty($saved) || !is_array($saved)) {
            // Default-Struktur
            $saved = [
                'steps' => [],
                'fuerbitten' => [
                    'einleitung' => '',
                    'bitten' => [],
                    'abschluss' => '',
                ],
                'vermeldungen' => '',
                'sonstige_texte' => '',
            ];
        }
        
        return $saved;
    }
    
    /**
     * Schritt-Daten mit Defaults mergen
     */
    public function get_steps_with_data(int $messe_id): array {
        $detail = $this->get_detail($messe_id);
        $saved_steps = $detail['steps'] ?? [];
        
        $steps = [];
        foreach (self::DEFAULT_STEPS as $default) {
            $key = $default['key'];
            $step = array_merge($default, [
                'enabled' => $saved_steps[$key]['enabled'] ?? true,
                'custom_notes' => $saved_steps[$key]['custom_notes'] ?? '',
                'assigned_person' => $saved_steps[$key]['assigned_person'] ?? '',
                'time_offset' => $saved_steps[$key]['time_offset'] ?? null,
            ]);
            $steps[$key] = $step;
        }
        
        return $steps;
    }
    
    /**
     * Detail-Tab rendern (für Frontend)
     */
    public function render_detail_tab(int $messe_id): string {
        $messe = get_post($messe_id);
        if (!$messe) return '<p>Messe nicht gefunden.</p>';
        
        $detail = $this->get_detail($messe_id);
        $steps = $this->get_steps_with_data($messe_id);
        $fuerbitten = $detail['fuerbitten'] ?? [];
        $vermeldungen = $detail['vermeldungen'] ?? '';
        
        $can_edit = current_user_can('edit_posts');
        
        ob_start();
        ?>
        <div class="tagesplan-detail">
            <!-- Ablauf -->
            <div class="tagesplan-detail-section">
                <h3>📋 Liturgie-Ablauf</h3>
                
                <?php 
                $current_section = '';
                foreach ($steps as $key => $step): 
                    // Sektion-Header
                    if ($step['section'] !== $current_section):
                        if ($current_section !== '') echo '</div>'; // Vorherige Sektion schließen
                        $current_section = $step['section'];
                        $sec = self::SECTIONS[$current_section];
                ?>
                    <div class="tagesplan-detail-section-group" data-section="<?php echo $current_section; ?>">
                        <h4 style="color:<?php echo $sec['color']; ?>;">
                            <?php echo $sec['icon']; ?> <?php echo $sec['label']; ?>
                        </h4>
                <?php endif; ?>
                    
                    <div class="tagesplan-detail-step <?php echo $step['enabled'] ? '' : 'disabled'; ?>" data-key="<?php echo $key; ?>">
                        <div class="step-checkbox">
                            <?php if ($can_edit): ?>
                                <input type="checkbox" <?php checked($step['enabled']); ?> 
                                       onchange="toggleDetailStep(<?php echo $messe_id; ?>, '<?php echo $key; ?>', this.checked)">
                            <?php else: ?>
                                <span><?php echo $step['enabled'] ? '✓' : '○'; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="step-content">
                            <div class="step-label"><?php echo esc_html($step['label']); ?></div>
                            <div class="step-roles">
                                <?php foreach ($step['roles'] as $role): 
                                    $r = self::ROLES[$role] ?? ['short' => '?'];
                                ?>
                                    <span class="role-badge" title="<?php echo esc_attr($r['label'] ?? $role); ?>">
                                        <?php echo $r['short']; ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                            <?php if ($step['notes'] || $step['custom_notes']): ?>
                                <div class="step-notes">
                                    <?php echo esc_html($step['custom_notes'] ?: $step['notes']); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                <?php endforeach; ?>
                </div> <!-- Letzte Sektion schließen -->
            </div>
            
            <!-- Fürbitten -->
            <div class="tagesplan-detail-section">
                <h3>🙏 Fürbitten</h3>
                
                <?php if ($can_edit): ?>
                    <div class="fuerbitten-editor">
                        <div class="fuerbitten-row">
                            <label>Einleitung</label>
                            <textarea id="fuerbitten_einleitung" rows="2" placeholder="Einleitung zu den Fürbitten..."><?php echo esc_textarea($fuerbitten['einleitung'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="fuerbitten-row">
                            <label>Bitten</label>
                            <div id="fuerbitten_bitten">
                                <?php 
                                $bitten = $fuerbitten['bitten'] ?? [];
                                if (empty($bitten)) $bitten = ['', '', '', ''];
                                foreach ($bitten as $i => $bitte): 
                                ?>
                                    <div class="bitte-row">
                                        <span class="bitte-num"><?php echo $i + 1; ?>.</span>
                                        <textarea rows="2" placeholder="Fürbitte..."><?php echo esc_textarea($bitte); ?></textarea>
                                        <button type="button" class="remove-bitte" onclick="removeBitte(this)">✕</button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button type="button" class="add-bitte" onclick="addBitte()">+ Weitere Bitte</button>
                        </div>
                        
                        <div class="fuerbitten-row">
                            <label>Abschluss</label>
                            <textarea id="fuerbitten_abschluss" rows="2" placeholder="Abschlussgebet..."><?php echo esc_textarea($fuerbitten['abschluss'] ?? ''); ?></textarea>
                        </div>
                        
                        <button type="button" class="btn btn-primary" onclick="saveFuerbitten(<?php echo $messe_id; ?>)">
                            💾 Fürbitten speichern
                        </button>
                    </div>
                <?php else: ?>
                    <div class="fuerbitten-display">
                        <?php if (!empty($fuerbitten['einleitung'])): ?>
                            <p><em><?php echo nl2br(esc_html($fuerbitten['einleitung'])); ?></em></p>
                        <?php endif; ?>
                        
                        <?php if (!empty($fuerbitten['bitten'])): ?>
                            <ol>
                                <?php foreach ($fuerbitten['bitten'] as $bitte): ?>
                                    <?php if (trim($bitte)): ?>
                                        <li><?php echo nl2br(esc_html($bitte)); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ol>
                        <?php endif; ?>
                        
                        <?php if (!empty($fuerbitten['abschluss'])): ?>
                            <p><em><?php echo nl2br(esc_html($fuerbitten['abschluss'])); ?></em></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Vermeldungen -->
            <div class="tagesplan-detail-section">
                <h3>📢 Vermeldungen / Ansagen</h3>
                
                <?php if ($can_edit): ?>
                    <textarea id="vermeldungen_text" rows="5" placeholder="Vermeldungen für diese Messe..."><?php echo esc_textarea($vermeldungen); ?></textarea>
                    <button type="button" class="btn btn-primary" onclick="saveVermeldungen(<?php echo $messe_id; ?>)">
                        💾 Vermeldungen speichern
                    </button>
                <?php else: ?>
                    <?php if ($vermeldungen): ?>
                        <div class="vermeldungen-display">
                            <?php echo nl2br(esc_html($vermeldungen)); ?>
                        </div>
                    <?php else: ?>
                        <p style="opacity:0.6;">Keine Vermeldungen eingetragen.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <!-- Druck-Buttons -->
            <div class="tagesplan-detail-actions">
                <button type="button" class="btn btn-outline" onclick="printAblauf(<?php echo $messe_id; ?>, 'ministrant')">
                    🖨️ Ministranten-Ablauf drucken
                </button>
                <button type="button" class="btn btn-outline" onclick="printAblauf(<?php echo $messe_id; ?>, 'lektor')">
                    🖨️ Lektoren-Ablauf drucken
                </button>
                <button type="button" class="btn btn-outline" onclick="printAblauf(<?php echo $messe_id; ?>, 'full')">
                    🖨️ Vollständigen Ablauf drucken
                </button>
            </div>
        </div>
        
        <style>
        .tagesplan-detail { max-width: 800px; }
        .tagesplan-detail-section { 
            background: #fff; 
            border-radius: 12px; 
            padding: 20px; 
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .tagesplan-detail-section h3 { margin: 0 0 16px; font-size: 1.1rem; }
        .tagesplan-detail-section-group { margin-bottom: 16px; }
        .tagesplan-detail-section-group h4 { 
            margin: 16px 0 8px; 
            font-size: 0.9rem; 
            font-weight: 600;
            padding-bottom: 4px;
            border-bottom: 2px solid currentColor;
        }
        
        .tagesplan-detail-step {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 10px 12px;
            border-radius: 8px;
            transition: background 0.15s;
        }
        .tagesplan-detail-step:hover { background: #f8fafc; }
        .tagesplan-detail-step.disabled { opacity: 0.4; }
        .tagesplan-detail-step.disabled .step-label { text-decoration: line-through; }
        
        .step-checkbox { width: 24px; padding-top: 2px; }
        .step-checkbox input { width: 18px; height: 18px; }
        .step-content { flex: 1; }
        .step-label { font-weight: 500; }
        .step-roles { display: flex; gap: 4px; margin-top: 4px; }
        .role-badge {
            font-size: 0.7rem;
            padding: 2px 6px;
            background: #e2e8f0;
            border-radius: 4px;
            color: #475569;
        }
        .step-notes { 
            font-size: 0.85rem; 
            color: #64748b; 
            margin-top: 4px;
            font-style: italic;
        }
        
        /* Fürbitten Editor */
        .fuerbitten-editor textarea, #vermeldungen_text {
            width: 100%;
            padding: 10px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.95rem;
            resize: vertical;
        }
        .fuerbitten-row { margin-bottom: 16px; }
        .fuerbitten-row label { display: block; font-weight: 600; margin-bottom: 6px; }
        .bitte-row { display: flex; gap: 8px; align-items: flex-start; margin-bottom: 8px; }
        .bitte-row .bitte-num { width: 24px; padding-top: 10px; font-weight: 600; color: #64748b; }
        .bitte-row textarea { flex: 1; }
        .bitte-row .remove-bitte {
            width: 32px; height: 32px;
            border: none; background: transparent;
            color: #ef4444; cursor: pointer;
            font-size: 1.2rem;
        }
        .add-bitte {
            background: none; border: 1px dashed #cbd5e1;
            padding: 8px 16px; border-radius: 6px;
            cursor: pointer; color: #64748b;
        }
        .add-bitte:hover { border-color: #94a3b8; color: #475569; }
        
        /* Actions */
        .tagesplan-detail-actions {
            display: flex; gap: 12px; flex-wrap: wrap;
        }
        .btn { 
            padding: 10px 20px; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 0.95rem;
            border: none;
        }
        .btn-primary { background: var(--is-primary, #2563eb); color: #fff; }
        .btn-outline { background: #fff; border: 1px solid #e2e8f0; color: #334155; }
        </style>
        
        <script>
        function toggleDetailStep(messeId, key, enabled) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=isidor_save_detail_step&messe_id=' + messeId + '&key=' + key + '&enabled=' + (enabled ? 1 : 0) + '&_wpnonce=<?php echo wp_create_nonce('isidor_tagesplan_detail'); ?>'
            });
        }
        
        function addBitte() {
            var container = document.getElementById('fuerbitten_bitten');
            var count = container.querySelectorAll('.bitte-row').length + 1;
            var html = '<div class="bitte-row"><span class="bitte-num">' + count + '.</span><textarea rows="2" placeholder="Fürbitte..."></textarea><button type="button" class="remove-bitte" onclick="removeBitte(this)">✕</button></div>';
            container.insertAdjacentHTML('beforeend', html);
        }
        
        function removeBitte(btn) {
            btn.closest('.bitte-row').remove();
            // Nummern aktualisieren
            document.querySelectorAll('#fuerbitten_bitten .bitte-num').forEach((el, i) => el.textContent = (i+1) + '.');
        }
        
        function saveFuerbitten(messeId) {
            var bitten = [];
            document.querySelectorAll('#fuerbitten_bitten textarea').forEach(ta => bitten.push(ta.value));
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=isidor_save_fuerbitten&messe_id=' + messeId + 
                      '&einleitung=' + encodeURIComponent(document.getElementById('fuerbitten_einleitung').value) +
                      '&abschluss=' + encodeURIComponent(document.getElementById('fuerbitten_abschluss').value) +
                      '&bitten=' + encodeURIComponent(JSON.stringify(bitten)) +
                      '&_wpnonce=<?php echo wp_create_nonce('isidor_tagesplan_detail'); ?>'
            }).then(() => alert('Fürbitten gespeichert!'));
        }
        
        function saveVermeldungen(messeId) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=isidor_save_vermeldungen&messe_id=' + messeId + 
                      '&text=' + encodeURIComponent(document.getElementById('vermeldungen_text').value) +
                      '&_wpnonce=<?php echo wp_create_nonce('isidor_tagesplan_detail'); ?>'
            }).then(() => alert('Vermeldungen gespeichert!'));
        }
        
        function printAblauf(messeId, mode) {
            window.open('<?php echo admin_url('admin-ajax.php'); ?>?action=isidor_print_ablauf&messe_id=' + messeId + '&mode=' + mode, '_blank');
        }
        </script>
        <?php
        return ob_get_clean();
    }
    
    /* ================================================================
       AJAX Handlers
       ================================================================ */
    
    public function ajax_save_step(): void {
        check_ajax_referer('isidor_tagesplan_detail', '_wpnonce');
        
        $messe_id = (int)($_POST['messe_id'] ?? 0);
        $key = sanitize_key($_POST['key'] ?? '');
        $enabled = (bool)($_POST['enabled'] ?? false);
        
        if (!$messe_id || !$key) wp_send_json_error();
        
        $detail = $this->get_detail($messe_id);
        if (!isset($detail['steps'])) $detail['steps'] = [];
        if (!isset($detail['steps'][$key])) $detail['steps'][$key] = [];
        $detail['steps'][$key]['enabled'] = $enabled;
        
        update_post_meta($messe_id, '_is_tagesplan_detail', $detail);
        wp_send_json_success();
    }
    
    public function ajax_save_fuerbitten(): void {
        check_ajax_referer('isidor_tagesplan_detail', '_wpnonce');
        
        $messe_id = (int)($_POST['messe_id'] ?? 0);
        if (!$messe_id) wp_send_json_error();
        
        $detail = $this->get_detail($messe_id);
        $detail['fuerbitten'] = [
            'einleitung' => sanitize_textarea_field($_POST['einleitung'] ?? ''),
            'bitten' => json_decode(stripslashes($_POST['bitten'] ?? '[]'), true) ?: [],
            'abschluss' => sanitize_textarea_field($_POST['abschluss'] ?? ''),
        ];
        
        update_post_meta($messe_id, '_is_tagesplan_detail', $detail);
        wp_send_json_success();
    }
    
    public function ajax_save_vermeldungen(): void {
        check_ajax_referer('isidor_tagesplan_detail', '_wpnonce');
        
        $messe_id = (int)($_POST['messe_id'] ?? 0);
        if (!$messe_id) wp_send_json_error();
        
        $detail = $this->get_detail($messe_id);
        $detail['vermeldungen'] = sanitize_textarea_field($_POST['text'] ?? '');
        
        update_post_meta($messe_id, '_is_tagesplan_detail', $detail);
        wp_send_json_success();
    }
    
    /**
     * Druckbaren Ablauf generieren
     */
    public function ajax_print_ablauf(): void {
        $messe_id = (int)($_GET['messe_id'] ?? 0);
        $mode = sanitize_key($_GET['mode'] ?? 'full');
        
        if (!$messe_id) wp_die('Keine Messe angegeben');
        
        $messe = get_post($messe_id);
        if (!$messe) wp_die('Messe nicht gefunden');
        
        $steps = $this->get_steps_with_data($messe_id);
        $detail = $this->get_detail($messe_id);
        $fuerbitten = $detail['fuerbitten'] ?? [];
        $vermeldungen = $detail['vermeldungen'] ?? '';
        
        // Messe-Daten
        $date = get_post_meta($messe_id, '_is_date', true);
        $time = get_post_meta($messe_id, '_is_time', true);
        $liturgical = get_post_meta($messe_id, '_is_liturgical', true) ?: $messe->post_title;
        
        // Parish-Name
        $parish_name = '';
        if (class_exists('Isidor_Parish_Settings')) {
            $parish_name = Isidor_Parish_Settings::name();
        }
        
        // Filter nach Rolle
        $role_filter = null;
        $title_suffix = '';
        if ($mode === 'ministrant') {
            $role_filter = 'ministrant';
            $title_suffix = ' — Ministranten-Ablauf';
        } elseif ($mode === 'lektor') {
            $role_filter = 'lektor';
            $title_suffix = ' — Lektoren-Ablauf';
        }
        
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ablauf <?php echo esc_html($liturgical); ?><?php echo $title_suffix; ?></title>
    <style>
        @page { margin: 15mm; }
        body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11pt; line-height: 1.5; }
        h1 { font-size: 16pt; margin: 0 0 5mm; border-bottom: 2px solid #333; padding-bottom: 3mm; }
        h2 { font-size: 13pt; margin: 8mm 0 3mm; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 2mm; }
        h3 { font-size: 11pt; margin: 5mm 0 2mm; }
        .header { display: flex; justify-content: space-between; margin-bottom: 5mm; }
        .header-left { font-weight: bold; }
        .header-right { text-align: right; color: #666; }
        .step { padding: 2mm 0; border-bottom: 1px dotted #ddd; display: flex; gap: 5mm; }
        .step-label { flex: 1; font-weight: 500; }
        .step-roles { color: #666; font-size: 9pt; }
        .step-notes { font-size: 9pt; color: #666; font-style: italic; margin-left: 10mm; }
        .section { margin-bottom: 5mm; }
        .section-title { font-weight: bold; background: #f0f0f0; padding: 2mm 3mm; margin-bottom: 2mm; }
        .fuerbitten ol { margin: 0; padding-left: 5mm; }
        .fuerbitten li { margin-bottom: 2mm; }
        .vermeldungen { background: #fffde7; padding: 3mm; border-left: 3px solid #ffc107; }
        .highlight { background: #e3f2fd; padding: 2mm 3mm; margin: 2mm 0; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom:10mm; padding:10px; background:#f0f0f0;">
        <button onclick="window.print()">🖨️ Drucken</button>
        <button onclick="window.close()">✕ Schließen</button>
    </div>
    
    <div class="header">
        <div class="header-left">
            <?php echo esc_html($parish_name); ?>
        </div>
        <div class="header-right">
            <?php if ($date): ?>
                <?php echo date('l, d.m.Y', strtotime($date)); ?>
                <?php if ($time): ?> · <?php echo esc_html($time); ?> Uhr<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <h1><?php echo esc_html($liturgical); ?><?php echo $title_suffix; ?></h1>
    
    <!-- Ablauf -->
    <?php
    $current_section = '';
    foreach ($steps as $key => $step):
        if (!$step['enabled']) continue;
        
        // Rollen-Filter
        if ($role_filter && !in_array($role_filter, $step['roles'])) continue;
        
        // Sektion-Header
        if ($step['section'] !== $current_section):
            if ($current_section !== '') echo '</div>';
            $current_section = $step['section'];
            $sec = self::SECTIONS[$current_section];
    ?>
        <div class="section">
            <div class="section-title"><?php echo $sec['icon']; ?> <?php echo $sec['label']; ?></div>
    <?php endif; ?>
        
        <div class="step <?php echo in_array($role_filter, $step['roles']) ? 'highlight' : ''; ?>">
            <div class="step-label"><?php echo esc_html($step['label']); ?></div>
            <div class="step-roles">
                <?php 
                foreach ($step['roles'] as $role) {
                    $r = self::ROLES[$role] ?? ['short' => '?'];
                    echo '<span>' . $r['short'] . '</span> ';
                }
                ?>
            </div>
        </div>
        <?php if ($step['custom_notes'] || $step['notes']): ?>
            <div class="step-notes"><?php echo esc_html($step['custom_notes'] ?: $step['notes']); ?></div>
        <?php endif; ?>
        
    <?php endforeach; ?>
    </div>
    
    <?php if ($mode === 'full' || $mode === 'lektor'): ?>
    <!-- Fürbitten -->
    <?php if (!empty($fuerbitten['bitten']) && array_filter($fuerbitten['bitten'])): ?>
    <h2>🙏 Fürbitten</h2>
    <div class="fuerbitten">
        <?php if (!empty($fuerbitten['einleitung'])): ?>
            <p><em><?php echo nl2br(esc_html($fuerbitten['einleitung'])); ?></em></p>
        <?php endif; ?>
        
        <ol>
            <?php foreach ($fuerbitten['bitten'] as $bitte): ?>
                <?php if (trim($bitte)): ?>
                    <li><?php echo nl2br(esc_html($bitte)); ?></li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ol>
        
        <?php if (!empty($fuerbitten['abschluss'])): ?>
            <p><em><?php echo nl2br(esc_html($fuerbitten['abschluss'])); ?></em></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php if ($mode === 'full' && $vermeldungen): ?>
    <!-- Vermeldungen -->
    <h2>📢 Vermeldungen</h2>
    <div class="vermeldungen">
        <?php echo nl2br(esc_html($vermeldungen)); ?>
    </div>
    <?php endif; ?>
    
    <div style="margin-top:10mm; font-size:9pt; color:#999; text-align:center;">
        Erstellt mit Isidor Suite · <?php echo date('d.m.Y H:i'); ?>
    </div>
</body>
</html>
        <?php
        exit;
    }
}
