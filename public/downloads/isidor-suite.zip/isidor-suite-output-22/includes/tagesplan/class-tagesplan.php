<?php
/**
 * Isidor Tagesplan - Hauptklasse
 * 
 * Erstellt Tagespläne für Gottesdienste mit allen relevanten Informationen:
 * - Messe-Details
 * - Dienste (aus Liturgus)
 * - Lieder (aus Cantus)
 * - Anpassbares Template
 * 
 * @package IsidorSuite
 * @subpackage Tagesplan
 */

if (!defined('ABSPATH')) exit;

class Isidor_Tagesplan {
    
    private static $instance = null;
    
    /**
     * Standard-Template-Struktur
     */
    private const DEFAULT_TEMPLATE = [
        'header' => [
            'enabled' => true,
            'show_parish_name' => true,
            'show_date' => true,
            'show_liturgical_day' => true,
            'show_logo' => true,
        ],
        'messe_info' => [
            'enabled' => true,
            'show_time' => true,
            'show_celebrant' => true,
            'show_intention' => true,
            'show_notes' => true,
        ],
        'dienste' => [
            'enabled' => true,
            'title' => 'Dienste',
            'slots' => [
                'celebrant' => ['label' => 'Zelebrant', 'enabled' => true],
                'diakon' => ['label' => 'Diakon', 'enabled' => true],
                'lektor1' => ['label' => 'Lektor 1', 'enabled' => true],
                'lektor2' => ['label' => 'Lektor 2', 'enabled' => true],
                'kommunion' => ['label' => 'Kommunionhelfer', 'enabled' => true],
                'ministrant' => ['label' => 'Ministranten', 'enabled' => true],
                'mesner' => ['label' => 'Mesner', 'enabled' => true],
                'orgel' => ['label' => 'Orgel', 'enabled' => true],
                'kantor' => ['label' => 'Kantor', 'enabled' => true],
                'technik' => ['label' => 'Technik', 'enabled' => true],
            ],
        ],
        'lieder' => [
            'enabled' => true,
            'title' => 'Lieder',
            'show_strophes' => true,
            'show_songbook' => true,
            'slots' => [
                1 => ['label' => 'Einzug', 'enabled' => true],
                2 => ['label' => 'Kyrie', 'enabled' => true],
                3 => ['label' => 'Gloria', 'enabled' => true],
                4 => ['label' => 'Psalm', 'enabled' => true],
                5 => ['label' => 'Ruf vor dem Evangelium', 'enabled' => true],
                6 => ['label' => 'Gabenbereitung', 'enabled' => true],
                7 => ['label' => 'Sanctus', 'enabled' => true],
                8 => ['label' => 'Agnus Dei', 'enabled' => true],
                9 => ['label' => 'Kommunion', 'enabled' => true],
                10 => ['label' => 'Danklied', 'enabled' => true],
                11 => ['label' => 'Auszug', 'enabled' => true],
            ],
        ],
        'lesungen' => [
            'enabled' => true,
            'title' => 'Lesungen',
            'show_lesung1' => true,
            'show_lesung2' => true,
            'show_evangelium' => true,
        ],
        'hinweise' => [
            'enabled' => true,
            'title' => 'Hinweise & Ankündigungen',
        ],
        'footer' => [
            'enabled' => true,
            'show_generated_time' => true,
            'custom_text' => '',
        ],
        'design' => [
            'primary_color' => '#1a365d',
            'font_family' => 'Arial, sans-serif',
            'font_size_base' => 12,
            'compact_mode' => false,
        ],
    ];
    
    /**
     * Singleton
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('init', [$this, 'register_shortcodes']);
        add_action('init', [$this, 'handle_exports']);
        add_action('wp_ajax_isidor_tagesplan_preview', [$this, 'ajax_preview']);
        add_action('wp_ajax_nopriv_isidor_tagesplan_preview', [$this, 'ajax_preview']);
        add_action('wp_ajax_isidor_tagesplan_data', [$this, 'ajax_get_data']);
        add_action('wp_ajax_nopriv_isidor_tagesplan_data', [$this, 'ajax_get_data']);
        add_action('wp_ajax_isidor_tagesplan_get_day', [$this, 'ajax_get_day']);
        add_action('wp_ajax_nopriv_isidor_tagesplan_get_day', [$this, 'ajax_get_day']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
    }
    
    /**
     * Admin-Menü hinzufügen
     */
    public function add_admin_menu(): void {
        add_submenu_page(
            'isidor-os',
            'Tagesplan',
            '📋 Tagesplan',
            'edit_posts',
            'isidor-tagesplan',
            [$this, 'render_admin_page']
        );
        
        add_submenu_page(
            'isidor-os',
            'Tagesplan Template',
            '📋 Template',
            'manage_options',
            'isidor-tagesplan-template',
            [$this, 'render_template_page']
        );
    }
    
    /**
     * Settings registrieren
     */
    public function register_settings(): void {
        register_setting('isidor_tagesplan', 'isidor_tagesplan_template');
        register_setting('isidor_tagesplan', 'isidor_tagesplan_parish_name');
        register_setting('isidor_tagesplan', 'isidor_tagesplan_logo_url');
    }
    
    /**
     * Shortcodes registrieren
     */
    public function register_shortcodes(): void {
        add_shortcode('isidor_tagesplan', [$this, 'shortcode_tagesplan']);
        add_shortcode('isidor_tagesplan_display', [$this, 'shortcode_display']);
        add_shortcode('isidor_tagesplan_heute', [$this, 'shortcode_heute']);
    }
    
    /**
     * Frontend Assets laden
     */
    public function enqueue_frontend_assets(): void {
        if (is_singular() && has_shortcode(get_post()->post_content ?? '', 'isidor_tagesplan_display')) {
            wp_enqueue_style(
                'isidor-tagesplan-display',
                ISIDOR_SUITE_URL . 'assets/css/tagesplan-display.css',
                [],
                ISIDOR_SUITE_VERSION
            );
            wp_enqueue_script(
                'isidor-tagesplan-display',
                ISIDOR_SUITE_URL . 'assets/js/tagesplan-display.js',
                ['jquery'],
                ISIDOR_SUITE_VERSION,
                true
            );
            wp_localize_script('isidor-tagesplan-display', 'isidorTagesplan', [
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('isidor_tagesplan'),
                'refresh_interval' => 60000, // 1 Minute
            ]);
        }
    }
    
    /**
     * Template holen (mit Defaults)
     */
    public function get_template(): array {
        $saved = get_option('isidor_tagesplan_template', []);
        return wp_parse_args($saved, self::DEFAULT_TEMPLATE);
    }
    
    /**
     * Template speichern
     */
    public function save_template(array $template): bool {
        return update_option('isidor_tagesplan_template', $template);
    }
    
    /**
     * Tagesplan-Daten für eine Messe sammeln
     */
    public function get_tagesplan_data(int $messe_id): array {
        $messe = get_post($messe_id);
        
        if (!$messe || $messe->post_type !== 'isidor_messe') {
            return ['error' => 'Messe nicht gefunden'];
        }
        
        $data = [
            'messe_id' => $messe_id,
            'generated_at' => current_time('c'),
            'parish_name' => class_exists('Isidor_Parish_Settings') 
                ? Isidor_Parish_Settings::name() 
                : get_option('isidor_tagesplan_parish_name', get_bloginfo('name')),
            'logo_url' => class_exists('Isidor_Parish_Settings') 
                ? Isidor_Parish_Settings::get('logo_url') 
                : get_option('isidor_tagesplan_logo_url', ''),
        ];
        
        // Messe-Grunddaten
        $data['messe'] = [
            'title' => $messe->post_title,
            'date' => get_post_meta($messe_id, '_is_date', true),
            'time' => get_post_meta($messe_id, '_is_time', true),
            'liturgical_day' => get_post_meta($messe_id, '_is_liturgical', true),
            'celebrant' => get_post_meta($messe_id, 'celebrant', true),
            'intention' => get_post_meta($messe_id, 'intention', true),
            'notes' => get_post_meta($messe_id, 'notes', true),
            'location' => get_post_meta($messe_id, 'location', true),
        ];
        
        // Formatiertes Datum
        if ($data['messe']['date']) {
            $timestamp = strtotime($data['messe']['date']);
            $data['messe']['date_formatted'] = wp_date('l, j. F Y', $timestamp);
            $data['messe']['date_short'] = wp_date('d.m.Y', $timestamp);
            $data['messe']['weekday'] = wp_date('l', $timestamp);
        }
        
        // Lesungen (neue Meta-Keys mit Fallback auf alte)
        $data['lesungen'] = [
            'lesung1'       => get_post_meta($messe_id, '_is_lesung1', true)
                             ?: get_post_meta($messe_id, 'lesung1', true),
            'antwortpsalm'  => get_post_meta($messe_id, '_is_antwortpsalm', true),
            'lesung2'       => get_post_meta($messe_id, '_is_lesung2', true)
                             ?: get_post_meta($messe_id, 'lesung2', true),
            'evangelium'    => get_post_meta($messe_id, '_is_evangelium', true)
                             ?: get_post_meta($messe_id, 'evangelium', true),
            'lit_farbe'     => get_post_meta($messe_id, '_is_lit_farbe', true),
            'schott_url'    => get_post_meta($messe_id, '_is_schott_url', true),
        ];
        $date = get_post_meta($messe_id, '_is_date', true) ?: '';
        $data['lesungen'] = apply_filters('isidor_tagesplan_readings_for_date', $data['lesungen'], $date);

        // Dienste aus Liturgus
        $data['dienste'] = $this->get_dienste_for_messe($messe_id);
        $data['dienste'] = apply_filters('isidor_tagesplan_dienste', $data['dienste'], $messe_id);
        
        // Lieder aus Cantus
        $data['lieder'] = $this->get_lieder_for_messe($messe_id);
        
        // Hinweise
        $data['hinweise'] = get_post_meta($messe_id, 'announcements', true) ?: '';
        
        return $data;
    }
    
    /**
     * Dienste für Messe holen (aus Liturgus)
     */
    private function get_dienste_for_messe(int $messe_id): array {
        $dienste = [];
        
        // Prüfen ob Liturgus aktiv
        if (class_exists('Liturgus_Assignments')) {
            $assignments = Liturgus_Assignments::get_for_messe($messe_id);
            
            foreach ($assignments as $assignment) {
                $user = get_userdata($assignment['user_id']);
                $dienste[$assignment['slot_key']] = [
                    'slot_key' => $assignment['slot_key'],
                    'user_id' => $assignment['user_id'],
                    'user_name' => $user ? $user->display_name : 'Unbekannt',
                    'is_backup' => $assignment['is_backup'] ?? false,
                ];
            }
        }
        
        // Fallback: Post-Meta direkt lesen
        $meta_slots = ['celebrant', 'diakon', 'lektor1', 'lektor2', 'kommunion', 
                       'ministrant', 'mesner', 'orgel', 'kantor', 'technik'];
        
        foreach ($meta_slots as $slot) {
            if (!isset($dienste[$slot])) {
                $value = get_post_meta($messe_id, 'dienst_' . $slot, true);
                if ($value) {
                    $dienste[$slot] = [
                        'slot_key' => $slot,
                        'user_id' => 0,
                        'user_name' => $value,
                        'is_backup' => false,
                    ];
                }
            }
        }
        
        return $dienste;
    }
    
    /**
     * Lieder für Messe holen (aus Cantus)
     */
    private function get_lieder_for_messe(int $messe_id): array {
        $lieder = [];
        
        // Prüfen ob Cantus aktiv
        if (class_exists('Cantus_DB')) {
            $songs = Cantus_DB::get_songs($messe_id);
            $songbook_map = ['gl' => 'GL', 'jd' => 'JD', 'free' => ''];
            
            foreach ($songs as $song) {
                $type = $song['type'] ?? 'gl';
                $full_title = '';
                if ($type === 'free') {
                    $full_title = $song['free_title'] ?? '';
                } else {
                    $full_title = $song['title'] ?? '';
                }
                // Kurzform für Anzeige (max 4 Wörter)
                $short = '';
                if ($full_title && class_exists('Cantus_Frontend')) {
                    $short = Cantus_Frontend::short_title($full_title);
                } else {
                    $short = $full_title;
                }
                
                $lieder[$song['slot_key']] = [
                    'slot_key'   => $song['slot_key'],
                    'type'       => $type,
                    'number'     => $song['number'] ?? '',
                    'title'      => $short,
                    'full_title' => $full_title,
                    'strophes'   => $song['strophes'] ?? '',
                    'songbook'   => $songbook_map[$type] ?? strtoupper($type),
                ];
            }
        }
        
        return $lieder;
    }
    
    /**
     * Tagesplan für heute/nächste Messe
     */
    public function get_next_messe(){
        $args = [
            'post_type' => 'isidor_messe',
            'posts_per_page' => 1,
            'meta_key' => '_is_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [
                [
                    'key' => '_is_date',
                    'value' => current_time('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE',
                ],
            ],
        ];
        
        $query = new WP_Query($args);
        
        if ($query->have_posts()) {
            return $query->posts[0]->ID;
        }
        
        return null;
    }
    
    /**
     * Messen für ein Datum
     */
    public function get_messen_for_date(string $date): array {
        $args = [
            'post_type' => 'isidor_messe',
            'posts_per_page' => -1,
            'meta_key' => '_is_time',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [
                [
                    'key' => '_is_date',
                    'value' => $date,
                    'compare' => '=',
                ],
            ],
        ];
        
        $query = new WP_Query($args);
        $messen = [];
        
        foreach ($query->posts as $post) {
            $messen[] = $post->ID;
        }
        
        return $messen;
    }
    
    /**
     * HTML für Tagesplan generieren
     */
    public function render_tagesplan(int $messe_id, bool $print_mode = false): string {
        $data = $this->get_tagesplan_data($messe_id);
        $template = $this->get_template();
        
        if (isset($data['error'])) {
            return '<div class="isidor-tagesplan-error">' . esc_html($data['error']) . '</div>';
        }
        
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/tagesplan/tagesplan.php';
        return ob_get_clean();
    }
    
    /**
     * Shortcode: Tagesplan für bestimmte Messe
     */
    public function shortcode_tagesplan($atts): string {
        $atts = shortcode_atts([
            'messe_id' => 0,
            'date' => '',
            'print' => false,
        ], $atts);
        
        $messe_id = intval($atts['messe_id']);
        
        if (!$messe_id && $atts['date']) {
            $messen = $this->get_messen_for_date($atts['date']);
            if (!empty($messen)) {
                $messe_id = $messen[0];
            }
        }
        
        if (!$messe_id) {
            return '<p>Keine Messe angegeben.</p>';
        }
        
        return $this->render_tagesplan($messe_id, (bool)$atts['print']);
    }
    
    /**
     * Shortcode: Digitale Display-Ansicht (Auto-Refresh)
     */
    public function shortcode_display($atts): string {
        $atts = shortcode_atts([
            'messe_id' => 0,
            'date' => 'today',
            'auto_refresh' => true,
            'fullscreen' => true,
        ], $atts);
        
        $date = $atts['date'] === 'today' ? current_time('Y-m-d') : $atts['date'];
        $messen = $this->get_messen_for_date($date);
        
        ob_start();
        include ISIDOR_SUITE_PATH . 'templates/tagesplan/display.php';
        return ob_get_clean();
    }
    
    /**
     * Shortcode: Heutiger Tagesplan mit Blätter-Navigation
     * Zeigt die nächste Messe, Pfeile navigieren nur zu Tagen mit Messen.
     */
    public function shortcode_heute($atts): string {
        if (!is_user_logged_in()) {
            return '<p>Bitte melden Sie sich an.</p>';
        }
        
        // Alle Mess-Tage laden (ab gestern, 60 Tage voraus + 30 zurück)
        $from = date('Y-m-d', strtotime('-30 days'));
        $to = date('Y-m-d', strtotime('+60 days'));
        
        $messe_dates = $this->get_messe_dates_in_range($from, $to);
        
        if (empty($messe_dates)) {
            return '<p class="isidor-no-messe">Keine Messen im Kalender gefunden.</p>';
        }
        
        // Heutigen oder nächsten Mess-Tag finden
        $today = current_time('Y-m-d');
        $current_index = 0;
        
        foreach ($messe_dates as $i => $date) {
            if ($date >= $today) {
                $current_index = $i;
                break;
            }
            $current_index = $i; // Falls alle in der Vergangenheit, nimm den letzten
        }
        
        // Erste Messe für den aktuellen Tag
        $messe_id = $this->get_first_messe_for_date($messe_dates[$current_index]);
        
        if (!$messe_id) {
            return '<p class="isidor-no-messe">Keine anstehende Messe gefunden.</p>';
        }
        
        $nonce = wp_create_nonce('isidor_tagesplan_nav');
        
        // JSON-Daten: alle Mess-Tage + aktueller Index
        $js_data = wp_json_encode([
            'dates' => $messe_dates,
            'currentIndex' => $current_index,
            'ajax' => admin_url('admin-ajax.php'),
            'nonce' => $nonce,
        ], JSON_UNESCAPED_UNICODE);
        
        $html = '<div class="isidor-tp-nav-wrap" id="tp-nav" data-tp=\'' . esc_attr($js_data) . '\'>';
        
        // Navigation Header
        $html .= '<div class="isidor-tp-nav-header">';
        $html .= '<button type="button" class="isidor-tp-nav-btn" id="tp-prev" title="Voriger Messtermin">◀</button>';
        $html .= '<div class="isidor-tp-nav-date" id="tp-date-label"></div>';
        $html .= '<button type="button" class="isidor-tp-nav-btn" id="tp-next" title="Nächster Messtermin">▶</button>';
        $html .= '</div>';
        
        // Content-Bereich (wird initial serverseitig befüllt, danach per AJAX)
        $html .= '<div class="isidor-tp-content" id="tp-content">';
        $html .= $this->render_tagesplan($messe_id);
        $html .= '</div>';
        
        $html .= '</div>';
        
        // Inline-Script
        $html .= $this->render_tagesplan_nav_script();
        // Inline-Styles
        $html .= $this->render_tagesplan_nav_styles();
        
        return $html;
    }
    
    /**
     * Alle Tage mit Messen in einem Zeitraum (dedupliziert, sortiert)
     */
    private function get_messe_dates_in_range(string $from, string $to): array {
        global $wpdb;
        
        $dates = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT pm.meta_value 
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_is_date'
               AND pm.meta_value BETWEEN %s AND %s
               AND p.post_type = 'isidor_messe'
               AND p.post_status = 'publish'
             ORDER BY pm.meta_value ASC",
            $from, $to
        ));
        
        return $dates ?: [];
    }
    
    /**
     * Erste Messe eines Tages (nach Uhrzeit sortiert)
     */
    private function get_first_messe_for_date(string $date){
        $query = new WP_Query([
            'post_type' => 'isidor_messe',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'meta_key' => '_is_time',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [['key' => '_is_date', 'value' => $date, 'compare' => '=']],
        ]);
        
        return $query->have_posts() ? $query->posts[0]->ID : null;
    }
    
    /**
     * JavaScript für die Tagesplan-Navigation
     */
    private function render_tagesplan_nav_script(): string {
        return '<script>
(function() {
    var wrap = document.getElementById("tp-nav");
    if (!wrap) return;
    
    var data = JSON.parse(wrap.getAttribute("data-tp"));
    var dates = data.dates;
    var idx = data.currentIndex;
    var content = document.getElementById("tp-content");
    var label = document.getElementById("tp-date-label");
    var prevBtn = document.getElementById("tp-prev");
    var nextBtn = document.getElementById("tp-next");
    var loading = false;
    
    var weekdays = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
    var months = ["","Jänner","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
    
    function formatDate(dateStr) {
        var d = new Date(dateStr + "T12:00:00");
        var wd = weekdays[d.getDay()];
        var day = d.getDate();
        var month = months[d.getMonth() + 1];
        var year = d.getFullYear();
        return wd + ", " + day + ". " + month + " " + year;
    }
    
    function updateLabel() {
        label.textContent = formatDate(dates[idx]);
        prevBtn.disabled = (idx <= 0);
        nextBtn.disabled = (idx >= dates.length - 1);
        prevBtn.style.opacity = (idx <= 0) ? "0.3" : "1";
        nextBtn.style.opacity = (idx >= dates.length - 1) ? "0.3" : "1";
    }
    
    function loadDay(newIdx) {
        if (newIdx < 0 || newIdx >= dates.length || loading) return;
        idx = newIdx;
        loading = true;
        updateLabel();
        
        content.style.opacity = "0.4";
        
        var fd = new FormData();
        fd.append("action", "isidor_tagesplan_get_day");
        fd.append("_wpnonce", data.nonce);
        fd.append("date", dates[idx]);
        
        fetch(data.ajax, {method: "POST", body: fd})
            .then(function(r) { return r.json(); })
            .then(function(resp) {
                if (resp.success && resp.data.html) {
                    content.innerHTML = resp.data.html;
                } else {
                    content.innerHTML = "<p>Keine Messe an diesem Tag.</p>";
                }
                content.style.opacity = "1";
                loading = false;
            })
            .catch(function() {
                content.innerHTML = "<p>Verbindungsfehler.</p>";
                content.style.opacity = "1";
                loading = false;
            });
    }
    
    prevBtn.addEventListener("click", function() { loadDay(idx - 1); });
    nextBtn.addEventListener("click", function() { loadDay(idx + 1); });
    
    // Keyboard Navigation
    document.addEventListener("keydown", function(e) {
        if (e.key === "ArrowLeft") loadDay(idx - 1);
        if (e.key === "ArrowRight") loadDay(idx + 1);
    });
    
    // Swipe-Support für Mobile
    var touchStartX = 0;
    wrap.addEventListener("touchstart", function(e) { touchStartX = e.touches[0].clientX; }, {passive: true});
    wrap.addEventListener("touchend", function(e) {
        var dx = e.changedTouches[0].clientX - touchStartX;
        if (Math.abs(dx) > 50) {
            if (dx > 0) loadDay(idx - 1);
            else loadDay(idx + 1);
        }
    }, {passive: true});
    
    // Initial Label setzen
    updateLabel();
})();
</script>';
    }
    
    /**
     * CSS für die Tagesplan-Navigation
     */
    private function render_tagesplan_nav_styles(): string {
        return '<style>
.isidor-tp-nav-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 16px; margin-bottom: 16px;
    background: var(--is-bg-raised, #fff);
    border: 1px solid var(--is-border, #e2e8f0);
    border-radius: var(--is-radius, 8px);
    gap: 12px;
}
.isidor-tp-nav-btn {
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--is-primary, #2563eb); color: #fff;
    border: none; font-size: 1.2em; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: 0.15s; flex-shrink: 0;
}
.isidor-tp-nav-btn:hover:not(:disabled) {
    background: var(--is-primary-hover, #1d4ed8);
    transform: scale(1.05);
}
.isidor-tp-nav-btn:disabled { cursor: default; }
.isidor-tp-nav-date {
    flex: 1; text-align: center;
    font-weight: 700; font-size: 1.05em;
    color: var(--is-text, #0f172a);
}
.isidor-tp-content {
    transition: opacity 0.2s ease;
}
@media (max-width: 480px) {
    .isidor-tp-nav-header { padding: 8px 10px; }
    .isidor-tp-nav-btn { width: 38px; height: 38px; font-size: 1em; }
    .isidor-tp-nav-date { font-size: 0.92em; }
}
</style>';
    }
    
    /**
     * Export Handler
     */
    public function handle_exports(): void {
        if (!isset($_GET['isidor_tagesplan_export'])) {
            return;
        }
        
        error_log('[Tagesplan Export] format=' . ($_GET['isidor_tagesplan_export'] ?? '') . ' messe_id=' . ($_GET['messe_id'] ?? '') . ' user=' . get_current_user_id());
        
        $format = sanitize_text_field($_GET['isidor_tagesplan_export']);
        $messe_id = intval($_GET['messe_id'] ?? 0);
        $date = sanitize_text_field($_GET['date'] ?? '');
        
        if (!$messe_id && $date) {
            $messen = $this->get_messen_for_date($date);
            if (empty($messen)) {
                wp_die('Keine Messe gefunden');
            }
            $messe_id = $messen[0];
        }
        
        if (!$messe_id) {
            wp_die('Messe-ID erforderlich');
        }
        
        switch ($format) {
            case 'pdf':
                $this->export_pdf($messe_id);
                break;
            case 'json':
                $this->export_json($messe_id);
                break;
            case 'html':
                $this->export_html($messe_id);
                break;
        }
        
        exit;
    }
    
    /**
     * PDF Export
     */
    public function export_pdf(int $messe_id): void {
        try {
            $data = $this->get_tagesplan_data($messe_id);
            $template = $this->get_template();
        
        if (isset($data['error'])) {
            wp_die($data['error']);
        }
        
        // PDF erstellen
        require_once ISIDOR_SUITE_PATH . 'lib/class-isidor-pdf.php';
        
        $pdf = new Isidor_PDF('P', 'mm', 'A4');
        $pdf->SetTitle('Tagesplan - ' . $data['messe']['date_formatted']);
        $pdf->AddPage();
        
        // Header
        $pdf->isidorHeader(
            $data['parish_name'],
            $data['messe']['date_formatted'] . ' · ' . $data['messe']['time'] . ' Uhr'
        );
        
        // Liturgischer Tag
        if (!empty($data['messe']['liturgical_day'])) {
            $pdf->SetFont('Arial', 'I', 11);
            $pdf->Cell(0, 8, $data['messe']['liturgical_day'], 0, 1, 'C');
            $pdf->Ln(5);
        }
        
        // Messe-Infos
        if ($template['messe_info']['enabled']) {
            $messe_info = [];
            if ($data['messe']['celebrant']) {
                $messe_info['Zelebrant'] = $data['messe']['celebrant'];
            }
            if ($data['messe']['intention']) {
                $messe_info['Intention'] = $data['messe']['intention'];
            }
            if ($data['messe']['location']) {
                $messe_info['Ort'] = $data['messe']['location'];
            }
            
            if (!empty($messe_info)) {
                $pdf->isidorInfoBox('Messe', $messe_info);
            }
        }
        
        // Dienste
        if ($template['dienste']['enabled'] && !empty($data['dienste'])) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, $template['dienste']['title'], 0, 1);
            
            $dienst_data = [];
            foreach ($template['dienste']['slots'] as $slot_key => $slot_config) {
                if ($slot_config['enabled'] && isset($data['dienste'][$slot_key])) {
                    $dienst_data[] = [
                        $slot_config['label'],
                        $data['dienste'][$slot_key]['user_name']
                    ];
                }
            }
            
            if (!empty($dienst_data)) {
                $pdf->isidorTable(['Dienst', 'Person'], $dienst_data, [50, 130]);
            }
        }
        
        // Lieder
        if ($template['lieder']['enabled'] && !empty($data['lieder'])) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, $template['lieder']['title'], 0, 1);
            
            $lieder_data = [];
            foreach ($template['lieder']['slots'] as $slot_key => $slot_config) {
                if ($slot_config['enabled'] && isset($data['lieder'][$slot_key])) {
                    $lied = $data['lieder'][$slot_key];
                    $lied_text = $lied['title'];
                    if ($lied['number']) {
                        $lied_text = $lied['songbook'] . ' ' . $lied['number'] . ': ' . $lied_text;
                    }
                    if ($lied['strophes'] && $template['lieder']['show_strophes']) {
                        $lied_text .= ' (Str. ' . $lied['strophes'] . ')';
                    }
                    
                    $lieder_data[] = [$slot_config['label'], $lied_text];
                }
            }
            
            if (!empty($lieder_data)) {
                $pdf->isidorTable(['Position', 'Lied'], $lieder_data, [45, 135]);
            }
        }
        
        // Lesungen
        if ($template['lesungen']['enabled']) {
            $lesungen_info = [];
            if (!empty($data['lesungen']['lesung1'])) {
                $lesungen_info['1. Lesung'] = $data['lesungen']['lesung1'];
            }
            if (!empty($data['lesungen']['antwortpsalm'])) {
                $lesungen_info['Antwortpsalm'] = $data['lesungen']['antwortpsalm'];
            }
            if (!empty($data['lesungen']['lesung2'])) {
                $lesungen_info['2. Lesung'] = $data['lesungen']['lesung2'];
            }
            if (!empty($data['lesungen']['evangelium'])) {
                $lesungen_info['Evangelium'] = $data['lesungen']['evangelium'];
            }
            
            if (!empty($lesungen_info)) {
                $pdf->Ln(5);
                $pdf->isidorInfoBox($template['lesungen']['title'], $lesungen_info);
            }
        }
        
        // Hinweise
        if ($template['hinweise']['enabled'] && !empty($data['hinweise'])) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, $template['hinweise']['title'], 0, 1);
            $pdf->SetFont('Arial', '', 10);
            $pdf->MultiCell(0, 5, $data['hinweise']);
        }
        
        // Footer
        if ($template['footer']['enabled']) {
            $pdf->Ln(10);
            $pdf->SetFont('Arial', 'I', 8);
            $pdf->SetTextColor(128, 128, 128);
            $footer_text = 'Erstellt: ' . wp_date('d.m.Y H:i');
            if ($template['footer']['custom_text']) {
                $footer_text .= ' · ' . $template['footer']['custom_text'];
            }
            $pdf->Cell(0, 5, $footer_text, 0, 1, 'C');
        }
        
        // Ausgabe
        while (ob_get_level()) { ob_end_clean(); }
        $filename = 'tagesplan_' . ($data['messe']['date_short'] ?? date('Y-m-d')) . '_' . 
                    str_replace(':', '-', $data['messe']['time'] ?? '00-00') . '.pdf';
        
        $pdf->Output('D', $filename);
        } catch (\Throwable $e) {
            error_log('[Tagesplan PDF ERROR] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            wp_die('PDF-Fehler: ' . esc_html($e->getMessage()));
        }
    }
    
    /**
     * JSON Export
     */
    public function export_json(int $messe_id): void {
        $data = $this->get_tagesplan_data($messe_id);
        
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="tagesplan_' . 
               ($data['messe']['date_short'] ?? date('Y-m-d')) . '.json"');
        
        echo wp_json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * HTML Export (Druckversion)
     */
    public function export_html(int $messe_id): void {
        $html = $this->render_tagesplan($messe_id, true);
        $data = $this->get_tagesplan_data($messe_id);
        
        header('Content-Type: text/html; charset=utf-8');
        
        echo '<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Tagesplan - ' . esc_html($data['messe']['date_formatted'] ?? '') . '</title>
    <style>
        @page { size: A4; margin: 15mm; }
        body { font-family: Arial, sans-serif; max-width: 210mm; margin: 0 auto; padding: 15mm; }
        @media print { body { padding: 0; } }
    </style>
</head>
<body>
' . $html . '
<script>window.onload = function() { window.print(); }</script>
</body>
</html>';
    }
    
    /**
     * AJAX: Tagesplan-Daten
     */
    public function ajax_get_data(): void {
        $messe_id = intval($_GET['messe_id'] ?? 0);
        $date = sanitize_text_field($_GET['date'] ?? '');
        
        if (!$messe_id && $date) {
            $messen = $this->get_messen_for_date($date);
            if (!empty($messen)) {
                $messe_id = $messen[0];
            }
        }
        
        if (!$messe_id) {
            $messe_id = $this->get_next_messe();
        }
        
        if (!$messe_id) {
            wp_send_json_error(['message' => 'Keine Messe gefunden']);
        }
        
        $data = $this->get_tagesplan_data($messe_id);
        wp_send_json_success($data);
    }
    
    /**
     * AJAX: Tag-Navigation – rendert Tagesplan-HTML für ein Datum
     * Wird von der Pfeil-Navigation im Frontend aufgerufen.
     */
    public function ajax_get_day(): void {
        check_ajax_referer('isidor_tagesplan_nav', '_wpnonce');
        
        $date = sanitize_text_field($_POST['date'] ?? '');
        if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            wp_send_json_error(['message' => 'Ungültiges Datum']);
        }
        
        $messen = $this->get_messen_for_date($date);
        
        if (empty($messen)) {
            wp_send_json_error(['message' => 'Keine Messe an diesem Tag']);
        }
        
        // Alle Messen des Tages rendern
        $html = '';
        foreach ($messen as $messe_id) {
            $html .= $this->render_tagesplan($messe_id);
        }
        
        wp_send_json_success(['html' => $html]);
    }
    
    /**
     * AJAX: Vorschau
     */
    public function ajax_preview(): void {
        $messe_id = intval($_POST['messe_id'] ?? 0);
        
        if (!$messe_id) {
            $messe_id = $this->get_next_messe();
        }
        
        if (!$messe_id) {
            wp_send_json_error(['message' => 'Keine Messe gefunden']);
        }
        
        $html = $this->render_tagesplan($messe_id);
        wp_send_json_success(['html' => $html]);
    }
    
    /**
     * Admin-Seite rendern
     */
    public function render_admin_page(): void {
        $today = current_time('Y-m-d');
        $selected_date = $_GET['date'] ?? $today;
        $messen = $this->get_messen_for_date($selected_date);
        
        include ISIDOR_SUITE_PATH . 'templates/tagesplan/admin.php';
    }
    
    /**
     * Template-Seite rendern
     */
    public function render_template_page(): void {
        // Template speichern
        if (isset($_POST['save_template']) && check_admin_referer('isidor_tagesplan_template')) {
            $template = $_POST['template'] ?? [];
            $this->save_template($template);
            
            update_option('isidor_tagesplan_parish_name', 
                sanitize_text_field($_POST['parish_name'] ?? ''));
            update_option('isidor_tagesplan_logo_url', 
                esc_url_raw($_POST['logo_url'] ?? ''));
            
            echo '<div class="notice notice-success"><p>Template gespeichert!</p></div>';
        }
        
        $template = $this->get_template();
        $parish_name = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::name() 
            : get_option('isidor_tagesplan_parish_name', get_bloginfo('name'));
        $logo_url = class_exists('Isidor_Parish_Settings') 
            ? Isidor_Parish_Settings::get('logo_url') 
            : get_option('isidor_tagesplan_logo_url', '');
        
        include ISIDOR_SUITE_PATH . 'templates/tagesplan/template-editor.php';
    }
    
    /**
     * Standard-Template zurücksetzen
     */
    public function reset_template(): bool {
        return delete_option('isidor_tagesplan_template');
    }
}
