<?php
/**
 * Plugin Name: Isidor Suite
 * Plugin URI: https://wilcke-worte.at/isidor
 * Description: Komplettes Pfarrverwaltungssystem – Core, Liturgus (Dienstplanung), Liturgia (Gottesdienst-Planung), Cellerar (Finanzen), Sakristan (Sakristei), Agenda (Termine/Räume), Cantus (Liedplanung), Page Visibility Control
 * Version: 2.2.0
 * Author: Wilcke Worte & Visionen / Mariabrunn Digital
 * Author URI: https://wilcke-worte.at
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: isidor-suite
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================================================
// EMERGENCY: Login page redirect loop protection
// This runs BEFORE WordPress fully loads — absolute earliest point possible
// ============================================================================
add_action('wp', function() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (!str_contains($uri, 'anmelden')) return;
    
    // Debug mode
    if (isset($_GET['debug_redirect'])) {
        echo '<pre style="background:#111;color:#0f0;padding:20px;font-size:14px;">';
        echo "=== ISIDOR REDIRECT DEBUG ===\n\n";
        echo "URI: " . esc_html($uri) . "\n";
        echo "Logged in: " . (is_user_logged_in() ? 'YES' : 'NO') . "\n";
        echo "is_page: " . (is_page() ? 'YES' : 'NO') . "\n";
        $post = get_post();
        if ($post) {
            echo "Post ID: " . $post->ID . "\n";
            echo "Post slug: " . $post->post_name . "\n";
            echo "Has isidor_login: " . (has_shortcode($post->post_content ?? '', 'isidor_login') ? 'YES' : 'NO') . "\n";
            $pvc_meta = get_post_meta($post->ID, '_isidor_pvc_roles', true);
            echo "PVC roles: " . print_r($pvc_meta, true) . "\n";
            $pvc_redirect = get_post_meta($post->ID, '_isidor_pvc_redirect', true);
            echo "PVC redirect: " . esc_html($pvc_redirect ?: '(none)') . "\n";
        }
        echo "\nActive template_redirect hooks:\n";
        global $wp_filter;
        if (isset($wp_filter['template_redirect'])) {
            foreach ($wp_filter['template_redirect']->callbacks as $pri => $cbs) {
                foreach ($cbs as $key => $cb) {
                    $name = $key;
                    if (is_array($cb['function']) && is_object($cb['function'][0])) {
                        $name = get_class($cb['function'][0]) . '::' . $cb['function'][1];
                    }
                    echo "  [$pri] $name\n";
                }
            }
        }
        echo '</pre>';
        exit;
    }
}, 1);


// ============================================================================
// PLUGIN CONSTANTS
// ============================================================================

define('ISIDOR_SUITE_VERSION', '2.2.0');
define('ISIDOR_SUITE_FILE', __FILE__);
define('ISIDOR_SUITE_PATH', plugin_dir_path(__FILE__));
define('ISIDOR_SUITE_URL', plugin_dir_url(__FILE__));
define('ISIDOR_SUITE_BASENAME', plugin_basename(__FILE__));

// Module-specific paths (for backward compatibility)
define('ISIDOR_CORE_PATH', ISIDOR_SUITE_PATH . 'includes/core/');
define('ISIDOR_LITURGUS_PATH', ISIDOR_SUITE_PATH . 'includes/liturgus/');
define('ISIDOR_LITURGUS_URL', ISIDOR_SUITE_URL . 'includes/liturgus/');
define('ISIDOR_CELLERAR_PATH', ISIDOR_SUITE_PATH . 'includes/cellerar/');
define('ISIDOR_CELLERAR_URL', ISIDOR_SUITE_URL . 'includes/cellerar/');
define('ISIDOR_SAKRISTAN_PATH', ISIDOR_SUITE_PATH . 'includes/sakristan/');
define('ISIDOR_SAKRISTAN_URL', ISIDOR_SUITE_URL . 'includes/sakristan/');
define('ISIDOR_AGENDA_PATH', ISIDOR_SUITE_PATH . 'includes/agenda/');
define('ISIDOR_AGENDA_URL', ISIDOR_SUITE_URL . 'includes/agenda/');
define('ISIDOR_CANTUS_PATH', ISIDOR_SUITE_PATH . 'includes/cantus/');
define('ISIDOR_CANTUS_URL', ISIDOR_SUITE_URL . 'includes/cantus/');
define('ISIDOR_LITURGIA_PATH', ISIDOR_SUITE_PATH . 'includes/liturgia/');
define('ISIDOR_LITURGIA_URL', ISIDOR_SUITE_URL . 'includes/liturgia/');
define('ISIDOR_CONSILIUM_PATH', ISIDOR_SUITE_PATH . 'includes/consilium/');
define('ISIDOR_CONSILIUM_URL', ISIDOR_SUITE_URL . 'includes/consilium/');
define('ISIDOR_CONSILIUM_VERSION', '1.0.0');

// PVC-Konstanten nur setzen wenn standalone PVC-Plugin nicht aktiv ist
// (Wird nur als Fallback benötigt, load_pvc() nutzt ISIDOR_SUITE_PATH direkt)
if (!defined('PVC_PLUGIN_DIR')) {
    define('PVC_PLUGIN_DIR', ISIDOR_SUITE_PATH . 'includes/pvc/');
}
if (!defined('PVC_PLUGIN_URL')) {
    define('PVC_PLUGIN_URL', ISIDOR_SUITE_URL . 'includes/pvc/');
}

// Version constants for modules (backward compatibility)
define('ISIDOR_CORE_VERSION', '1.1.0');
define('ISIDOR_LITURGUS_VERSION', '2.5.3');
define('ISIDOR_CELLERAR_VERSION', '1.0.0');
define('ISIDOR_SAKRISTAN_VERSION', '2.0.0');
define('ISIDOR_AGENDA_VERSION', '1.3.0');
define('ISIDOR_CANTUS_VERSION', '1.3.6');
define('ISIDOR_LITURGIA_VERSION', '2.0.0');
if (!defined('PVC_VERSION')) {
    define('PVC_VERSION', '1.0.0');
}

// Minimum requirements
define('ISIDOR_SUITE_MIN_PHP', '7.4');
define('ISIDOR_SUITE_MIN_WP', '6.0');

// ============================================================================
// MAIN PLUGIN CLASS
// ============================================================================

final class Isidor_Suite {
    
    private static $instance = null;
    
    /**
     * Active modules configuration
     * @var array
     */
    private $modules = [
        'core'      => true,
        'liturgus'  => true,
        'cellerar'  => true,
        'sakristan' => true,
        'agenda'    => true,
        'cantus'    => true,
        'tagesplan' => true,
        'liturgia'  => true,
        'pvc'       => true,
        'consilium' => true,
    ];
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_modules_config();
        
        // Globale Klassen laden
        require_once ISIDOR_SUITE_PATH . 'lib/class-isidor-pdf.php';
        require_once ISIDOR_CORE_PATH . 'class-app-permissions.php';
        require_once ISIDOR_CORE_PATH . 'class-permissions.php';
        require_once ISIDOR_CORE_PATH . 'class-permissions-rest.php';
        require_once ISIDOR_CORE_PATH . 'class-permissions-shortcodes.php';
        require_once ISIDOR_CORE_PATH . 'class-auto-setup.php';
        require_once ISIDOR_CORE_PATH . 'class-parish-settings.php';
        require_once ISIDOR_CORE_PATH . 'class-liturgical-calendar.php';
        require_once ISIDOR_CORE_PATH . 'class-app-shell.php';
        require_once ISIDOR_CORE_PATH . 'class-user-manager.php';
        require_once ISIDOR_CORE_PATH . 'class-backup.php';
        require_once ISIDOR_CORE_PATH . 'class-gdpr.php';
        require_once ISIDOR_CORE_PATH . 'class-impressum.php';
        require_once ISIDOR_CORE_PATH . 'class-github-updater.php';
        require_once ISIDOR_CORE_PATH . 'class-app-link.php';
        
        add_action('plugins_loaded', [$this, 'init'], 5);
        add_action('admin_menu', [$this, 'add_settings_menu'], 100);
        add_action('admin_init', [$this, 'register_settings']);

        // GitHub Auto-Updater
        // Configure: Replace 'YOUR-USERNAME' with your GitHub username
        //            For private repos, add a Personal Access Token
        $github_user  = defined('ISIDOR_GITHUB_USER')  ? ISIDOR_GITHUB_USER  : '';
        $github_repo  = defined('ISIDOR_GITHUB_REPO')  ? ISIDOR_GITHUB_REPO  : 'isidor-suite';
        $github_token = defined('ISIDOR_GITHUB_TOKEN') ? ISIDOR_GITHUB_TOKEN : null;
        if ($github_user) {
            new Isidor_GitHub_Updater(__FILE__, $github_user, $github_repo, $github_token);
        }

        // PWA App Link Bridge (for email links → PWA)
        Isidor_App_Link::init();
    }
    
    /**
     * Load module configuration from options
     */
    private function load_modules_config(): void {
        $saved_modules = get_option('isidor_suite_modules', []);
        if (!empty($saved_modules)) {
            $this->modules = array_merge($this->modules, $saved_modules);
        }
        // Core is always active
        $this->modules['core'] = true;

        // If consilium key doesn't exist in saved modules, ensure default applies
        if (!empty($saved_modules) && !array_key_exists('consilium', $saved_modules)) {
            $this->modules['consilium'] = true;
        }
    }
    
    /**
     * Check if a module is active
     */
    public function is_module_active(string $module): bool {
        return $this->modules[$module] ?? false;
    }
    
    /**
     * Initialize the plugin
     */
    public function init(): void {
        // Check requirements
        if (!$this->check_requirements()) {
            return;
        }
        
        // Load text domain
        load_plugin_textdomain('isidor-suite', false, dirname(ISIDOR_SUITE_BASENAME) . '/languages');
        
        // Load Core (always)
        $this->load_core();
        
        // Initialize Permissions System
        Isidor_App_Permissions::get_instance();
        Isidor_Permissions::get_instance();
        Isidor_Permissions_REST::init();
        Isidor_Permissions_Shortcodes::init();
        
        // Initialize Auto Setup
        Isidor_Auto_Setup::get_instance();
        
        // Initialize Parish Settings
        Isidor_Parish_Settings::get_instance();
        
        // Initialize App Shell (registriert Shortcodes + Frontend-Assets)
        // Muss immer laufen, damit Shortcodes registriert sind (auch bei AJAX)
        Isidor_App_Shell::get_instance();
        
        // Initialize Frontend User Manager
        Isidor_User_Manager::get_instance();
        
        // Initialize Backup System
        Isidor_Backup::get_instance();
        
        // Initialize GDPR Tools
        Isidor_GDPR::get_instance();
        
        // Initialize Impressum & Datenschutz
        Isidor_Impressum::get_instance();
        
        // Load optional modules
        if ($this->is_module_active('liturgus')) {
            $this->load_liturgus();
        }
        
        if ($this->is_module_active('cellerar')) {
            $this->load_cellerar();
        }
        
        if ($this->is_module_active('sakristan')) {
            $this->load_sakristan();
        }
        
        if ($this->is_module_active('agenda')) {
            $this->load_agenda();
        }
        
        if ($this->is_module_active('cantus')) {
            $this->load_cantus();
        }
        
        if ($this->is_module_active('tagesplan')) {
            $this->load_tagesplan();
        }
        
        if ($this->is_module_active('liturgia')) {
            $this->load_liturgia();
        }

        if ($this->is_module_active('pvc')) {
            $this->load_pvc();
        }
        
        if ($this->is_module_active('communicator')) {
            $this->load_communicator();
        }
        
        if ($this->is_module_active('matrikel')) {
            $this->load_matrikel();
        }

        if ($this->is_module_active('consilium')) {
            $this->load_consilium();
        }

        // Stipendien immer laden (Teil von Core)
        $this->load_stipendien();
        
        // Update version
        update_option('isidor_suite_version', ISIDOR_SUITE_VERSION);
    }
    
    /**
     * Check minimum requirements
     */
    private function check_requirements(): bool {
        $errors = [];
        
        if (version_compare(PHP_VERSION, ISIDOR_SUITE_MIN_PHP, '<')) {
            $errors[] = sprintf(
                __('Isidor Suite benötigt PHP %s oder höher. Aktuelle Version: %s', 'isidor-suite'),
                ISIDOR_SUITE_MIN_PHP,
                PHP_VERSION
            );
        }
        
        global $wp_version;
        if (version_compare($wp_version, ISIDOR_SUITE_MIN_WP, '<')) {
            $errors[] = sprintf(
                __('Isidor Suite benötigt WordPress %s oder höher. Aktuelle Version: %s', 'isidor-suite'),
                ISIDOR_SUITE_MIN_WP,
                $wp_version
            );
        }
        
        if (!empty($errors)) {
            add_action('admin_notices', function() use ($errors) {
                foreach ($errors as $error) {
                    echo '<div class="notice notice-error"><p>' . esc_html($error) . '</p></div>';
                }
            });
            return false;
        }
        
        return true;
    }
    
    /**
     * Load Core module
     */
    private function load_core(): void {
        require_once ISIDOR_CORE_PATH . 'class-core.php';
        Isidor_Core::get_instance();
    }
    
    /**
     * Load Liturgus module
     */
    private function load_liturgus(): void {
        require_once ISIDOR_LITURGUS_PATH . 'class-database.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-slots.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-assignments.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-dashboard.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-admin.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-reminders.php';
        require_once ISIDOR_LITURGUS_PATH . 'class-service-integration.php';
        
        new Liturgus_Slots();
        new Liturgus_Assignments();
        new Liturgus_Dashboard();
        new Liturgus_Reminders();
        Liturgus_Service_Integration::init();
        
        if (is_admin()) {
            new Liturgus_Admin();
        }
        
        // Dashboard URL helper
        $this->setup_liturgus_helpers();
    }
    
    /**
     * Setup Liturgus helper functions
     */
    private function setup_liturgus_helpers(): void {
        // Dashboard page detection
        add_action('save_post_page', function($post_id) {
            $content = get_post_field('post_content', $post_id);
            if (strpos($content, '[liturgus_dashboard') !== false) {
                delete_transient('liturgus_dashboard_url');
            }
        });
        
        // AJAX for creating dashboard page
        add_action('wp_ajax_liturgus_create_dashboard_page', [$this, 'liturgus_create_dashboard_page']);
        
        // Admin notice for missing dashboard page
        add_action('admin_notices', [$this, 'liturgus_dashboard_notice']);
    }
    
    /**
     * Load Cellerar module
     */
    private function load_cellerar(): void {
        require_once ISIDOR_CELLERAR_PATH . 'class-database.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-roles.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-audit.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-entries.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-expenses.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-files.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-statistics.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-export.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-mail.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-rest-api.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-shortcodes.php';
        require_once ISIDOR_CELLERAR_PATH . 'class-admin.php';
        
        Isidor_Cellerar_REST_API::init();
        Isidor_Cellerar_Shortcodes::init();
        
        if (is_admin()) {
            Isidor_Cellerar_Admin::init();
        }
        
        // Enqueue assets
        add_action('wp_enqueue_scripts', [$this, 'cellerar_enqueue_assets']);
    }
    
    /**
     * Load Sakristan module
     */
    private function load_sakristan(): void {
        require_once ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan.php';
        require_once ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan-admin.php';
        require_once ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan-shortcodes.php';
        require_once ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan-rest.php';
        
        new Isidor_Sakristan();
        new Isidor_Sakristan_Admin();
        new Isidor_Sakristan_Shortcodes();
        new Isidor_Sakristan_REST();
    }
    
    /**
     * Load Agenda module
     */
    private function load_agenda(): void {
        // Check if Core CPT exists
        add_action('init', function() {
            if (!post_type_exists('isidor_messe')) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-warning"><p><strong>Isidor Agenda:</strong> Das Core-Modul muss aktiv sein für die volle Funktionalität.</p></div>';
                });
                return;
            }
            
            require_once ISIDOR_AGENDA_PATH . 'class-db.php';
            require_once ISIDOR_AGENDA_PATH . 'class-plugin.php';
            require_once ISIDOR_AGENDA_PATH . 'class-events.php';
            require_once ISIDOR_AGENDA_PATH . 'class-series.php';
            require_once ISIDOR_AGENDA_PATH . 'class-rooms.php';
            require_once ISIDOR_AGENDA_PATH . 'class-slots.php';
            require_once ISIDOR_AGENDA_PATH . 'class-conflicts.php';
            require_once ISIDOR_AGENDA_PATH . 'class-approvals.php';
            require_once ISIDOR_AGENDA_PATH . 'class-meta.php';
            require_once ISIDOR_AGENDA_PATH . 'class-notifications.php';
            require_once ISIDOR_AGENDA_PATH . 'class-exports.php';
            require_once ISIDOR_AGENDA_PATH . 'class-shortcodes.php';
            require_once ISIDOR_AGENDA_PATH . 'class-admin.php';
            require_once ISIDOR_AGENDA_PATH . 'class-api.php';
            require_once ISIDOR_AGENDA_PATH . 'class-poster-tool.php';
            
            if (class_exists('Isidor_Agenda_Plugin')) {
                Isidor_Agenda_Plugin::get_instance();
            }
            
            if (class_exists('Isidor_Poster_Tool')) {
                Isidor_Poster_Tool::get_instance();
            }
        }, 20);
    }
    
    /**
     * Load Cantus module
     */
    private function load_cantus(): void {
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-db.php';
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-permissions.php';
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-batch.php';
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-frontend.php';
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-admin.php';
        require_once ISIDOR_CANTUS_PATH . 'class-cantus-api.php';
        
        if (is_admin()) {
            new Cantus_Admin();
        }
        new Cantus_Frontend();
        new Cantus_API();
    }
    
    /**
     * Load Liturgia module (Gottesdienst-Detailplanung)
     */
    private function load_liturgia(): void {
        require_once ISIDOR_LITURGIA_PATH . 'class-database.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-elements.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-templates.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-admin.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-api.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-integration.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-pdf.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-mailer.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-print.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-settings.php';
        require_once ISIDOR_LITURGIA_PATH . 'class-frontend.php';

        // Admin UI
        if (is_admin()) {
            \Isidor\Liturgia\Admin::get_instance();
        }

        // Frontend (Shortcode + AJAX)
        \Isidor\Liturgia\Frontend::init();

        // REST API
        \Isidor\Liturgia\API::init();

        // Integration (Cantus/Tagesplan Override-Filter)
        \Isidor\Liturgia\Integration::init();

        // PDF AJAX
        \Isidor\Liturgia\PDF::init();

        // E-Mail AJAX
        \Isidor\Liturgia\Mailer::init();

        // Settings
        \Isidor\Liturgia\Settings::init();
    }

    /**
     * Load Tagesplan module
     */
    private function load_tagesplan(): void {
        define('ISIDOR_TAGESPLAN_PATH', ISIDOR_SUITE_PATH . 'includes/tagesplan/');
        define('ISIDOR_TAGESPLAN_URL', ISIDOR_SUITE_URL . 'includes/tagesplan/');
        
        require_once ISIDOR_TAGESPLAN_PATH . 'class-tagesplan.php';
        require_once ISIDOR_TAGESPLAN_PATH . 'class-tagesplan-detail.php';
        
        Isidor_Tagesplan::get_instance();
        Isidor_Tagesplan_Detail::get_instance();
    }
    
    /**
     * Load Page Visibility Control module
     */
    private function load_pvc(): void {
        // Nicht laden wenn das eigenständige PVC-Plugin bereits aktiv ist
        if (class_exists('Page_Visibility_Control') || function_exists('pvc_init')) {
            return;
        }
        
        // Eigene Kopie laden – expliziter Pfad statt Konstante (diese könnte vom Standalone stammen)
        $pvc_file = ISIDOR_SUITE_PATH . 'includes/pvc/class-page-visibility-control.php';
        if (file_exists($pvc_file)) {
            require_once $pvc_file;
            if (class_exists('Page_Visibility_Control')) {
                Page_Visibility_Control::get_instance();
            }
        }
    }
    
    /**
     * Load Communicator module
     */
    private function load_communicator(): void {
        define('ISIDOR_COMM_PATH', ISIDOR_SUITE_PATH . 'includes/communicator/');
        
        require_once ISIDOR_COMM_PATH . 'class-communicator.php';
        require_once ISIDOR_COMM_PATH . 'class-communicator-frontend.php';
        
        Isidor_Communicator::get_instance();
        new Isidor_Communicator_Frontend();
    }
    
    /**
     * Load Matrikel module
     */
    private function load_matrikel(): void {
        define('ISIDOR_MATRIKEL_PATH', ISIDOR_SUITE_PATH . 'includes/matrikel/');
        
        require_once ISIDOR_MATRIKEL_PATH . 'class-matrikel.php';
        
        Isidor_Matrikel::get_instance();
    }
    
    /**
     * Load Stipendien module (always active with Core)
     */
    private function load_stipendien(): void {
        require_once ISIDOR_SUITE_PATH . 'includes/stipendien/class-stipendien.php';
        Isidor_Stipendien::get_instance();
    }

    /**
     * Load Consilium module (PGR/VVR-Sitzungsverwaltung)
     */
    private function load_consilium(): void {
        require_once ISIDOR_CONSILIUM_PATH . 'class-database.php';
        require_once ISIDOR_CONSILIUM_PATH . 'class-rest-api.php';
        require_once ISIDOR_CONSILIUM_PATH . 'class-mail.php';
        require_once ISIDOR_CONSILIUM_PATH . 'class-pdf.php';
        require_once ISIDOR_CONSILIUM_PATH . 'class-shortcodes.php';
        require_once ISIDOR_CONSILIUM_PATH . 'class-admin.php';

        Isidor_Consilium_REST_API::init();
        Isidor_Consilium_Shortcodes::init();

        if (is_admin()) {
            Isidor_Consilium_Admin::init();
        }

        // RSVP handler (runs early on init for token-based responses)
        add_action('init', ['Isidor_Consilium_Mail', 'handle_rsvp'], 5);

        // WP-Cron: Automatic reminders
        add_action('isidor_consilium_send_reminders', ['Isidor_Consilium_Mail', 'cron_send_reminders']);
        if (!wp_next_scheduled('isidor_consilium_send_reminders')) {
            wp_schedule_event(time(), 'daily', 'isidor_consilium_send_reminders');
        }

        add_action('wp_enqueue_scripts', [$this, 'consilium_enqueue_assets']);
    }

    /**
     * Consilium: Enqueue frontend assets
     */
    public function consilium_enqueue_assets(): void {
        global $post;
        if (!is_a($post, 'WP_Post')) {
            return;
        }

        $has_shortcode = has_shortcode($post->post_content, 'isidor_consilium_app')
                      || has_shortcode($post->post_content, 'isidor_consilium_vote')
                      || has_shortcode($post->post_content, 'isidor_consilium_live')
                      || has_shortcode($post->post_content, 'isidor_app');

        if (!$has_shortcode) {
            return;
        }

        wp_enqueue_style(
            'isidor-consilium',
            ISIDOR_SUITE_URL . 'assets/css/consilium-frontend.css',
            [],
            ISIDOR_CONSILIUM_VERSION
        );

        wp_enqueue_script(
            'isidor-consilium',
            ISIDOR_SUITE_URL . 'assets/js/consilium-frontend.js',
            ['jquery'],
            ISIDOR_CONSILIUM_VERSION,
            true
        );

        wp_localize_script('isidor-consilium', 'isidorConsilium', [
            'restUrl'   => rest_url('isidor/v1/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'pollInterval' => 3000,
            'autosaveInterval' => 10000,
            'currentUser' => [
                'id'        => get_current_user_id(),
                'canView'   => current_user_can('isidor_consilium_view'),
                'canManage' => current_user_can('isidor_consilium_manage'),
                'canVote'   => current_user_can('isidor_consilium_vote'),
                'canAdmin'  => current_user_can('isidor_consilium_admin'),
            ],
            'i18n' => [
                'loading'            => __('Wird geladen...', 'isidor-suite'),
                'error'              => __('Ein Fehler ist aufgetreten.', 'isidor-suite'),
                'confirmDelete'      => __('Wirklich löschen?', 'isidor-suite'),
                'voteSent'           => __('Stimme abgegeben.', 'isidor-suite'),
                'saved'              => __('Gespeichert.', 'isidor-suite'),
                'protocolDraftSaved' => __('Protokoll zwischengespeichert.', 'isidor-suite'),
                'protocolFinalized'  => __('Protokoll endgültig abgelegt und versendet.', 'isidor-suite'),
            ],
        ]);
    }

    /**
     * Add settings menu
     */
    public function add_settings_menu(): void {
        add_submenu_page(
            'isidor-os',
            __('Suite Einstellungen', 'isidor-suite'),
            __('⚙️ Suite Einstellungen', 'isidor-suite'),
            'manage_options',
            'isidor-suite-settings',
            [$this, 'render_settings_page']
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings(): void {
        register_setting('isidor_suite_settings', 'isidor_suite_modules', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_modules'],
        ]);
    }
    
    /**
     * Sanitize modules setting
     */
    public function sanitize_modules($input): array {
        $sanitized = [];
        $allowed = ['liturgus', 'cellerar', 'sakristan', 'agenda', 'cantus', 'tagesplan', 'liturgia', 'pvc', 'communicator', 'matrikel', 'consilium'];
        
        foreach ($allowed as $module) {
            $sanitized[$module] = isset($input[$module]) && $input[$module] === '1';
        }
        
        // Core always active
        $sanitized['core'] = true;
        
        return $sanitized;
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page(): void {
        ?>
        <div class="wrap">
            <h1><?php _e('Isidor Suite Einstellungen', 'isidor-suite'); ?></h1>
            
            <div style="background: linear-gradient(135deg, #1a365d 0%, #2d3748 100%); color: #fff; padding: 30px; border-radius: 12px; margin: 20px 0;">
                <h2 style="color: #fff; margin-top: 0;">🏛️ Isidor Suite v<?php echo ISIDOR_SUITE_VERSION; ?></h2>
                <p style="font-size: 1.1em; opacity: 0.9;">Modulares Pfarrverwaltungssystem für WordPress</p>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('isidor_suite_settings'); ?>
                
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><?php _e('Core (Messen & Rollen)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" checked disabled>
                                    <?php _e('Immer aktiv (Basis-Modul)', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('CPT für Messen, Rollen-System, Wochen-Vorlage, Generator', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Liturgus (Dienstplanung)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[liturgus]" value="1" <?php checked($this->is_module_active('liturgus')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Dienstplanung für Gottesdienste, Erinnerungen, Dashboard', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Cellerar (Finanzen)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[cellerar]" value="1" <?php checked($this->is_module_active('cellerar')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Einnahmen, Ausgaben, Statistiken, Export', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Sakristan (Sakristei)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[sakristan]" value="1" <?php checked($this->is_module_active('sakristan')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('ToDo-System, Notizen, Integration von Cantus & Liturgus', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Agenda (Termine & Räume)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[agenda]" value="1" <?php checked($this->is_module_active('agenda')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Terminplanung, Raumverwaltung, Serien, Poster-Generator', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Cantus (Liedplanung)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[cantus]" value="1" <?php checked($this->is_module_active('cantus')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Liedplanung für Gottesdienste, PDF-Export', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Tagesplan', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[tagesplan]" value="1" <?php checked($this->is_module_active('tagesplan')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Tagesordnungen für Gottesdienste erstellen und anzeigen', 'isidor-suite'); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e('Liturgia (Gottesdienst-Planung)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[liturgia]" value="1" <?php checked($this->is_module_active('liturgia')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Detailplanung besonderer Gottesdienste, Ablauf-Editor, PDF-Export, E-Mail-Versand', 'isidor-suite'); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e('Page Visibility Control', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[pvc]" value="1" <?php checked($this->is_module_active('pvc')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Seitensichtbarkeit nach Benutzerrollen steuern', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Communicator (Chat)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[communicator]" value="1" <?php checked($this->is_module_active('communicator')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Interner Pfarr-Messenger: Gruppen-Chats, Direktnachrichten', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Matrikel (Sakramente)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[matrikel]" value="1" <?php checked($this->is_module_active('matrikel')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('Taufen, Hochzeiten, Begräbnisse: Termine, Checklisten, Gebühren', 'isidor-suite'); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e('Consilium (Sitzungen)', 'isidor-suite'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="isidor_suite_modules[consilium]" value="1" <?php checked($this->is_module_active('consilium')); ?>>
                                    <?php _e('Aktiviert', 'isidor-suite'); ?>
                                </label>
                                <p class="description"><?php _e('PGR/VVR-Sitzungen: Tagesordnung, Protokoll, Abstimmungen, PDF-Versand', 'isidor-suite'); ?></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <?php submit_button(__('Module speichern', 'isidor-suite')); ?>
            </form>
            
            <div style="margin-top: 30px; padding: 20px; background: #f0f0f1; border-radius: 8px;">
                <h3><?php _e('Modul-Versionen', 'isidor-suite'); ?></h3>
                <ul style="list-style: disc; margin-left: 20px;">
                    <li>Core: <?php echo ISIDOR_CORE_VERSION; ?></li>
                    <li>Liturgus: <?php echo ISIDOR_LITURGUS_VERSION; ?></li>
                    <li>Cellerar: <?php echo ISIDOR_CELLERAR_VERSION; ?></li>
                    <li>Sakristan: <?php echo ISIDOR_SAKRISTAN_VERSION; ?></li>
                    <li>Agenda: <?php echo ISIDOR_AGENDA_VERSION; ?></li>
                    <li>Cantus: <?php echo ISIDOR_CANTUS_VERSION; ?></li>
                    <li>Liturgia: <?php echo ISIDOR_LITURGIA_VERSION; ?></li>
                    <li>Page Visibility Control: <?php echo PVC_VERSION; ?></li>
                    <li>Consilium: <?php echo ISIDOR_CONSILIUM_VERSION; ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    /**
     * Cellerar: Enqueue frontend assets
     */
    public function cellerar_enqueue_assets(): void {
        global $post;
        if (!is_a($post, 'WP_Post')) {
            return;
        }
        
        $has_shortcode = has_shortcode($post->post_content, 'isidor_cellerar_app') 
                      || has_shortcode($post->post_content, 'isidor_cellerar_my_submissions')
                      || has_shortcode($post->post_content, 'isidor_cellerar_submit_expense');
        
        if (!$has_shortcode) {
            return;
        }
        
        wp_enqueue_style(
            'isidor-cellerar',
            ISIDOR_SUITE_URL . 'assets/css/cellerar-frontend.css',
            [],
            ISIDOR_SUITE_VERSION
        );
        
        wp_enqueue_script(
            'isidor-cellerar',
            ISIDOR_SUITE_URL . 'assets/js/cellerar-frontend.js',
            ['jquery'],
            ISIDOR_SUITE_VERSION,
            true
        );
        
        wp_localize_script('isidor-cellerar', 'isidorCellerar', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('isidor/v1/'),
            'nonce' => wp_create_nonce('isidor_cellerar_nonce'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'messeExists' => post_type_exists('isidor_messe'),
            'i18n' => [
                'confirmDelete' => __('Möchten Sie diesen Eintrag wirklich löschen?', 'isidor-suite'),
                'confirmApprove' => __('Möchten Sie diese Ausgabe genehmigen?', 'isidor-suite'),
                'confirmReject' => __('Möchten Sie diese Ausgabe ablehnen?', 'isidor-suite'),
                'loading' => __('Wird geladen...', 'isidor-suite'),
                'error' => __('Ein Fehler ist aufgetreten.', 'isidor-suite'),
                'success' => __('Erfolgreich gespeichert.', 'isidor-suite'),
                'noData' => __('Keine Daten vorhanden.', 'isidor-suite'),
                'selectMesse' => __('Bitte wählen Sie eine Messe aus.', 'isidor-suite'),
                'invalidAmount' => __('Bitte geben Sie einen gültigen Betrag ein.', 'isidor-suite'),
                'uploadError' => __('Fehler beim Hochladen der Datei.', 'isidor-suite'),
                'fileTooLarge' => __('Die Datei ist zu groß. Maximum: 5 MB.', 'isidor-suite'),
                'invalidFileType' => __('Ungültiger Dateityp. Erlaubt: PDF, JPG, PNG.', 'isidor-suite'),
            ],
            'currentUser' => [
                'id' => get_current_user_id(),
                'canRead' => current_user_can('isidor_cellerar_read'),
                'canAddIncome' => current_user_can('isidor_cellerar_add_income'),
                'canAddExpense' => current_user_can('isidor_cellerar_add_expense'),
                'canApprove' => current_user_can('isidor_cellerar_approve_expense'),
                'canExport' => current_user_can('isidor_cellerar_export'),
                'canViewStats' => current_user_can('isidor_cellerar_view_stats'),
            ],
        ]);
    }
    
    /**
     * Liturgus: Create dashboard page via AJAX
     */
    public function liturgus_create_dashboard_page(): void {
        check_ajax_referer('liturgus_create_page', 'nonce');
        
        if (!current_user_can('publish_pages')) {
            wp_send_json_error(['message' => 'Keine Berechtigung']);
        }
        
        global $wpdb;
        $exists = $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE '%[liturgus_dashboard%' 
             LIMIT 1"
        );
        
        if ($exists) {
            wp_send_json_error(['message' => 'Dashboard-Seite existiert bereits', 'url' => get_permalink($exists)]);
        }
        
        $page_id = wp_insert_post([
            'post_title'   => 'Dienste',
            'post_name'    => 'dienste',
            'post_content' => '[liturgus_dashboard]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id()
        ]);
        
        if (is_wp_error($page_id)) {
            wp_send_json_error(['message' => $page_id->get_error_message()]);
        }
        
        delete_transient('liturgus_dashboard_url');
        
        wp_send_json_success([
            'message' => 'Dashboard-Seite erstellt!',
            'url' => get_permalink($page_id),
            'edit_url' => get_edit_post_link($page_id, 'raw')
        ]);
    }
    
    /**
     * Liturgus: Admin notice for missing dashboard page
     */
    public function liturgus_dashboard_notice(): void {
        if (!isset($_GET['page']) || strpos($_GET['page'], 'liturgus') === false) {
            return;
        }
        
        if (!current_user_can('publish_pages')) {
            return;
        }
        
        global $wpdb;
        $exists = $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE '%[liturgus_dashboard%' 
             LIMIT 1"
        );
        
        if ($exists) {
            return;
        }
        
        $nonce = wp_create_nonce('liturgus_create_page');
        ?>
        <div class="notice notice-warning" id="liturgus-dashboard-notice">
            <p>
                <strong>Liturgus:</strong> Es existiert noch keine Dashboard-Seite mit dem <code>[liturgus_dashboard]</code> Shortcode.
            </p>
            <p>
                <button type="button" class="button button-primary" id="liturgus-create-page-btn">
                    Dashboard-Seite jetzt erstellen
                </button>
                <span id="liturgus-create-status" style="margin-left: 10px;"></span>
            </p>
        </div>
        <script>
        jQuery(function($) {
            $('#liturgus-create-page-btn').on('click', function() {
                var $btn = $(this);
                var $status = $('#liturgus-create-status');
                
                $btn.prop('disabled', true).text('Wird erstellt...');
                
                $.post(ajaxurl, {
                    action: 'liturgus_create_dashboard_page',
                    nonce: '<?php echo $nonce; ?>'
                }, function(response) {
                    if (response.success) {
                        $status.html('<span style="color:green;">✓ ' + response.data.message + '</span> <a href="' + response.data.url + '" target="_blank">Seite anzeigen</a>');
                        $btn.hide();
                        setTimeout(function() {
                            $('#liturgus-dashboard-notice').fadeOut();
                        }, 3000);
                    } else {
                        $status.html('<span style="color:red;">✗ ' + response.data.message + '</span>');
                        $btn.prop('disabled', false).text('Dashboard-Seite jetzt erstellen');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    // ========================================================================
    // ACTIVATION / DEACTIVATION
    // ========================================================================
    
    /**
     * Plugin activation
     */
    public static function activate(): void {
        // Core activation
        require_once ISIDOR_CORE_PATH . 'class-core.php';
        Isidor_Core::activate();
        
        // App Permissions Table
        require_once ISIDOR_CORE_PATH . 'class-app-permissions.php';
        Isidor_App_Permissions::create_table();
        
        // Liturgus activation
        if (file_exists(ISIDOR_LITURGUS_PATH . 'class-database.php')) {
            require_once ISIDOR_LITURGUS_PATH . 'class-database.php';
            if (class_exists('Liturgus_Database')) {
                Liturgus_Database::activate();
            }
        }
        
        // Cellerar activation
        if (file_exists(ISIDOR_CELLERAR_PATH . 'class-database.php')) {
            require_once ISIDOR_CELLERAR_PATH . 'class-database.php';
            if (class_exists('Isidor_Cellerar_Database')) {
                Isidor_Cellerar_Database::create_tables();
            }
        }
        if (file_exists(ISIDOR_CELLERAR_PATH . 'class-roles.php')) {
            require_once ISIDOR_CELLERAR_PATH . 'class-roles.php';
            if (class_exists('Isidor_Cellerar_Roles')) {
                Isidor_Cellerar_Roles::add_capabilities();
            }
        }
        
        // Sakristan activation
        if (file_exists(ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan.php')) {
            require_once ISIDOR_SAKRISTAN_PATH . 'class-isidor-sakristan.php';
            if (class_exists('Isidor_Sakristan')) {
                Isidor_Sakristan::activate();
            }
        }
        
        // Agenda activation
        if (file_exists(ISIDOR_AGENDA_PATH . 'class-db.php')) {
            require_once ISIDOR_AGENDA_PATH . 'class-db.php';
            if (class_exists('Isidor_Agenda_DB')) {
                Isidor_Agenda_DB::activate();
            }
        }
        
        // Cantus activation
        if (file_exists(ISIDOR_CANTUS_PATH . 'class-cantus-db.php')) {
            require_once ISIDOR_CANTUS_PATH . 'class-cantus-db.php';
            if (class_exists('Cantus_DB')) {
                Cantus_DB::activate();
            }
        }

        // Liturgia activation
        if (file_exists(ISIDOR_LITURGIA_PATH . 'class-database.php')) {
            require_once ISIDOR_LITURGIA_PATH . 'class-database.php';
            if (class_exists('\Isidor\Liturgia\Database')) {
                \Isidor\Liturgia\Database::activate();
            }
        }

        // Consilium activation
        if (file_exists(ISIDOR_CONSILIUM_PATH . 'class-database.php')) {
            require_once ISIDOR_CONSILIUM_PATH . 'class-database.php';
            if (class_exists('Isidor_Consilium_Database')) {
                Isidor_Consilium_Database::create_tables();
            }
        }

        // Permissions v2 tables
        require_once ISIDOR_CORE_PATH . 'class-permissions.php';
        Isidor_Permissions::create_tables();

        // Liturgus per-messe slot config table
        if (file_exists(ISIDOR_LITURGUS_PATH . 'class-service-integration.php')) {
            require_once ISIDOR_LITURGUS_PATH . 'class-service-integration.php';
            Liturgus_Service_Integration::create_table();
        }

        // Set default modules
        if (!get_option('isidor_suite_modules')) {
            update_option('isidor_suite_modules', [
                'core'      => true,
                'liturgus'  => true,
                'cellerar'  => true,
                'sakristan' => true,
                'agenda'    => true,
                'cantus'    => true,
                'liturgia'  => true,
                'consilium' => true,
                'pvc'       => true,
            ]);
        } else {
            // Ensure new modules are added to existing installations
            $modules = get_option('isidor_suite_modules', []);
            $new_modules = ['liturgia' => true, 'consilium' => true];
            $updated = false;
            foreach ($new_modules as $key => $val) {
                if (!isset($modules[$key])) {
                    $modules[$key] = $val;
                    $updated = true;
                }
            }
            if ($updated) {
                update_option('isidor_suite_modules', $modules);
            }
        }

        // Reset setup flag so Auto Setup detects new pages (Liturgia, Consilium)
        delete_option('isidor_setup_completed');
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set version
        update_option('isidor_suite_version', ISIDOR_SUITE_VERSION);
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate(): void {
        // Core deactivation
        require_once ISIDOR_CORE_PATH . 'class-core.php';
        Isidor_Core::deactivate();
        
        // Liturgus deactivation
        if (file_exists(ISIDOR_LITURGUS_PATH . 'class-database.php')) {
            require_once ISIDOR_LITURGUS_PATH . 'class-database.php';
            if (class_exists('Liturgus_Database')) {
                Liturgus_Database::deactivate();
            }
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get Liturgus dashboard URL
 */
function liturgus_get_dashboard_url(): string {
    $cached_url = get_transient('liturgus_dashboard_url');
    if ($cached_url !== false) {
        return $cached_url;
    }
    
    global $wpdb;
    $page = $wpdb->get_row(
        "SELECT ID FROM {$wpdb->posts} 
         WHERE post_type = 'page' 
         AND post_status = 'publish' 
         AND post_content LIKE '%[liturgus_dashboard%' 
         ORDER BY ID ASC 
         LIMIT 1"
    );
    
    if ($page) {
        $url = get_permalink($page->ID);
        set_transient('liturgus_dashboard_url', $url, HOUR_IN_SECONDS);
        return $url;
    }
    
    $manual_page_id = get_option('liturgus_dashboard_page_id');
    if ($manual_page_id && get_post_status($manual_page_id) === 'publish') {
        $url = get_permalink($manual_page_id);
        set_transient('liturgus_dashboard_url', $url, HOUR_IN_SECONDS);
        return $url;
    }
    
    return home_url('/');
}

/**
 * Check if isidor_messe CPT exists
 */
function isidor_cellerar_check_messe_cpt(): bool {
    return post_type_exists('isidor_messe');
}

/**
 * Wrap a URL through the PWA App Link bridge.
 * Use this in emails so links open in the installed PWA.
 *
 * @param string $shortcut  Short key like 'dienste', 'termine', etc. Or full URL.
 * @return string           App-link bridge URL
 */
function isidor_app_link(string $shortcut): string {
    return home_url('/app-link/?to=' . urlencode($shortcut));
}

// ============================================================================
// BOOTSTRAP
// ============================================================================

// Register hooks
register_activation_hook(__FILE__, ['Isidor_Suite', 'activate']);
register_deactivation_hook(__FILE__, ['Isidor_Suite', 'deactivate']);

// Initialize
Isidor_Suite::get_instance();
