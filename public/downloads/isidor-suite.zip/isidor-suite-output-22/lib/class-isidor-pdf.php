<?php
/**
 * Isidor PDF Generator
 * Professioneller PDF-Generator mit TCPDF-Support und HTML-Fallback
 * 
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) exit;

class Isidor_PDF {
    
    private $pdf = null;
    private $engine = 'html'; // 'tcpdf', 'fpdf' oder 'html'
    
    // Seitenmaße (mm)
    private $page_width = 210;
    private $page_height = 297;
    private $margin_left = 15;
    private $margin_right = 15;
    private $margin_top = 15;
    private $margin_bottom = 15;
    private $content_width;
    
    // Aktuelle Position
    private $x;
    private $y;
    
    // Inhalt für HTML-Fallback
    private $html_content = '';
    private $title = 'Dokument';
    private $orientation = 'P';
    
    // Aktuelle Schrift
    private $font_family = 'Arial';
    private $font_style = '';
    private $font_size = 12;
    
    // Farben
    private $text_color = '#000000';
    private $fill_color = '#ffffff';
    private $draw_color = '#000000';
    
    /**
     * Constructor
     */
    public function __construct($orientation = 'P', $unit = 'mm', $format = 'A4') {
        $this->orientation = $orientation;
        
        // Seitenformat setzen
        if ($format === 'A4') {
            $this->page_width = 210;
            $this->page_height = 297;
        } elseif ($format === 'A3') {
            $this->page_width = 297;
            $this->page_height = 420;
        }
        
        // Bei Querformat tauschen
        if ($orientation === 'L') {
            $temp = $this->page_width;
            $this->page_width = $this->page_height;
            $this->page_height = $temp;
        }
        
        $this->content_width = $this->page_width - $this->margin_left - $this->margin_right;
        $this->x = $this->margin_left;
        $this->y = $this->margin_top;
        
        // Versuche TCPDF zu laden
        $tcpdf_paths = [
            ISIDOR_SUITE_PATH . 'lib/tcpdf/tcpdf.php',
            WP_CONTENT_DIR . '/plugins/tcpdf/tcpdf.php',
            ABSPATH . 'tcpdf/tcpdf.php',
        ];
        
        foreach ($tcpdf_paths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $this->pdf = new TCPDF($orientation, $unit, $format, true, 'UTF-8', false);
                $this->engine = 'tcpdf';
                $this->setupTCPDF();
                return;
            }
        }
        
        // Versuche FPDF zu laden
        $fpdf_paths = [
            ISIDOR_SUITE_PATH . 'lib/fpdf/fpdf.php',
            ISIDOR_SUITE_PATH . 'lib/fpdf.php',
        ];
        
        foreach ($fpdf_paths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $this->pdf = new FPDF($orientation, $unit, $format);
                $this->engine = 'fpdf';
                return;
            }
        }
        
        // HTML-Fallback
        $this->engine = 'html';
        $this->initHTML();
    }
    
    /**
     * TCPDF Setup
     */
    private function setupTCPDF(): void {
        $this->pdf->SetCreator('Isidor Suite');
        $this->pdf->SetAuthor(get_bloginfo('name'));
        $this->pdf->SetMargins($this->margin_left, $this->margin_top, $this->margin_right);
        $this->pdf->SetAutoPageBreak(true, $this->margin_bottom);
        $this->pdf->setHeaderFont(['dejavusans', '', 10]);
        $this->pdf->setFooterFont(['dejavusans', '', 8]);
        $this->pdf->SetFont('dejavusans', '', 10);
        
        // Header/Footer deaktivieren für sauberes Layout
        $this->pdf->setPrintHeader(false);
        $this->pdf->setPrintFooter(false);
    }
    
    /**
     * HTML-Fallback initialisieren
     */
    private function initHTML(): void {
        $this->html_content = '';
    }
    
    /**
     * Titel setzen
     */
    public function SetTitle(string $title): void {
        $this->title = $title;
        if ($this->engine === 'tcpdf') {
            $this->pdf->SetTitle($title);
        }
    }
    
    /**
     * Neue Seite
     */
    public function AddPage($orientation = '', $format = ''): void {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->AddPage($orientation ?: $this->orientation, $format);
        } else {
            if (!empty($this->html_content)) {
                $this->html_content .= '<div class="page-break"></div>';
            }
        }
        $this->x = $this->margin_left;
        $this->y = $this->margin_top;
    }
    
    /**
     * Schriftart setzen
     */
    public function SetFont(string $family, string $style = '', int $size = 0): void {
        $this->font_family = $family;
        $this->font_style = $style;
        if ($size > 0) $this->font_size = $size;
        
        if ($this->engine === 'tcpdf') {
            // TCPDF: Arial -> dejavusans
            $tcpdf_family = ($family === 'Arial' || $family === 'Helvetica') ? 'dejavusans' : $family;
            $this->pdf->SetFont($tcpdf_family, $style, $size ?: $this->font_size);
        } elseif ($this->engine === 'fpdf') {
            $this->pdf->SetFont($family, $style, $size ?: $this->font_size);
        }
    }
    
    /**
     * Zelle ausgeben
     */
    public function Cell($w, $h = 0, $txt = '', $border = 0, $ln = 0, $align = '', $fill = false): void {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->Cell($w, $h, $this->enc($txt), $border, $ln, $align, $fill);
        } else {
            $style = $this->getHTMLStyle();
            $border_style = $this->getBorderStyle($border);
            $align_style = $this->getAlignStyle($align);
            $bg_style = $fill ? "background-color:{$this->fill_color};" : '';
            
            $this->html_content .= sprintf(
                '<span style="display:inline-block;width:%smm;height:%smm;%s%s%s%s">%s</span>',
                $w, $h, $style, $border_style, $align_style, $bg_style, esc_html($txt)
            );
            
            if ($ln === 1 || $ln === 2) {
                $this->html_content .= '<br>';
                $this->x = $this->margin_left;
                $this->y += $h;
            } else {
                $this->x += $w;
            }
        }
    }
    
    /**
     * MultiCell ausgeben
     */
    public function MultiCell($w, $h, $txt, $border = 0, $align = 'J', $fill = false, $ln = 1): void {
        if ($this->engine === 'tcpdf') {
            $this->pdf->MultiCell($w, $h, $txt, $border, $align, $fill, $ln);
        } elseif ($this->engine === 'fpdf') {
            $this->pdf->MultiCell($w, $h, $this->enc($txt), $border, $align, $fill);
        } else {
            $style = $this->getHTMLStyle();
            $border_style = $this->getBorderStyle($border);
            
            $this->html_content .= sprintf(
                '<div style="width:%smm;%s%s">%s</div>',
                $w, $style, $border_style, nl2br(esc_html($txt))
            );
            
            $this->x = $this->margin_left;
        }
    }
    
    /**
     * HTML direkt schreiben (nur TCPDF)
     */
    public function writeHTML(string $html, bool $ln = true): void {
        if ($this->engine === 'tcpdf') {
            $this->pdf->writeHTML($html, $ln);
        } else {
            $this->html_content .= $html;
            if ($ln) $this->html_content .= '<br>';
        }
    }
    
    /**
     * Zeilenumbruch
     */
    public function Ln($h = null): void {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->Ln($h);
        } else {
            $this->html_content .= '<br>';
            $this->x = $this->margin_left;
            $this->y += $h ?: ($this->font_size * 0.4);
        }
    }
    
    /**
     * Position setzen
     */
    public function SetXY(float $x, float $y): void {
        $this->x = $x;
        $this->y = $y;
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetXY($x, $y);
        }
    }
    
    public function SetX(float $x): void {
        $this->x = $x;
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetX($x);
        }
    }
    
    public function SetY(float $y): void {
        $this->y = $y;
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetY($y);
        }
    }
    
    public function GetX(): float {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            return $this->pdf->GetX();
        }
        return $this->x;
    }
    
    public function GetY(): float {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            return $this->pdf->GetY();
        }
        return $this->y;
    }
    
    /**
     * Rechteck zeichnen
     */
    public function Rect(float $x, float $y, float $w, float $h, string $style = ''): void {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->Rect($x, $y, $w, $h, $style);
        }
    }
    
    /**
     * Linie zeichnen
     */
    public function Line(float $x1, float $y1, float $x2, float $y2): void {
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->Line($x1, $y1, $x2, $y2);
        } else {
            $this->html_content .= '<hr style="border:none;border-top:1px solid ' . $this->draw_color . ';">';
        }
    }
    
    /**
     * Farben setzen
     */
    public function SetTextColor(int $r, int $g = -1, int $b = -1): void {
        if ($g === -1) {
            $this->text_color = sprintf('#%02x%02x%02x', $r, $r, $r);
        } else {
            $this->text_color = sprintf('#%02x%02x%02x', $r, $g, $b);
        }
        
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetTextColor($r, $g === -1 ? $r : $g, $b === -1 ? $r : $b);
        }
    }
    
    public function SetFillColor(int $r, int $g = -1, int $b = -1): void {
        if ($g === -1) {
            $this->fill_color = sprintf('#%02x%02x%02x', $r, $r, $r);
        } else {
            $this->fill_color = sprintf('#%02x%02x%02x', $r, $g, $b);
        }
        
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetFillColor($r, $g === -1 ? $r : $g, $b === -1 ? $r : $b);
        }
    }
    
    public function SetDrawColor(int $r, int $g = -1, int $b = -1): void {
        if ($g === -1) {
            $this->draw_color = sprintf('#%02x%02x%02x', $r, $r, $r);
        } else {
            $this->draw_color = sprintf('#%02x%02x%02x', $r, $g, $b);
        }
        
        if ($this->engine === 'tcpdf' || $this->engine === 'fpdf') {
            $this->pdf->SetDrawColor($r, $g === -1 ? $r : $g, $b === -1 ? $r : $b);
        }
    }
    
    /**
     * Bild einfügen
     */
    public function Image(string $file, $x = '', $y = '', $w = 0, $h = 0): void {
        if ($this->engine === 'tcpdf') {
            $this->pdf->Image($file, $x, $y, $w, $h);
        } elseif ($this->engine === 'fpdf') {
            $this->pdf->Image($file, $x, $y, $w, $h);
        } else {
            $this->html_content .= sprintf(
                '<img src="%s" style="width:%smm;height:%smm;">',
                esc_url($file), $w, $h
            );
        }
    }
    
    /**
     * PDF ausgeben
     * 
     * @param string $dest I=Inline, D=Download, F=File, S=String
     * @param string $name Dateiname
     */
    /** UTF-8 -> Latin-1 for FPDF (TCPDF handles UTF-8 natively) */
    private function enc(string $t): string {
        if ($t === '' || $this->engine !== 'fpdf') return $t;
        if (function_exists('iconv')) {
            $c = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $t);
            if ($c !== false) return $c;
        }
        return mb_convert_encoding($t, 'ISO-8859-1', 'UTF-8');
    }

    public function Output(string $dest = 'I', string $name = 'document.pdf'): string {
        if ($this->engine === 'tcpdf') {
            return $this->pdf->Output($name, $dest);
        } elseif ($this->engine === 'fpdf') {
            return $this->pdf->Output($dest, $name);
        } else {
            return $this->outputHTML($dest, $name);
        }
    }
    
    /**
     * HTML-Ausgabe als Fallback
     */
    private function outputHTML(string $dest, string $name): string {
        $page_size = $this->orientation === 'L' ? 'A4 landscape' : 'A4';
        
        $html = '<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>' . esc_html($this->title) . '</title>
    <style>
        @page { 
            size: ' . $page_size . '; 
            margin: 15mm; 
        }
        @media print {
            body { margin: 0; padding: 0; }
            .page-break { page-break-after: always; }
            .no-print { display: none !important; }
        }
        * { box-sizing: border-box; }
        body { 
            font-family: Arial, Helvetica, sans-serif; 
            font-size: 12pt; 
            line-height: 1.4;
            color: #333;
            max-width: 210mm;
            margin: 0 auto;
            padding: 15mm;
        }
        table { 
            border-collapse: collapse; 
            width: 100%;
            margin-bottom: 10px;
        }
        td, th { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left;
        }
        th {
            background-color: #1a365d;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .header {
            background: linear-gradient(135deg, #1a365d 0%, #2d3748 100%);
            color: white;
            padding: 20px;
            margin: -15mm -15mm 20px -15mm;
            text-align: center;
        }
        .header h1 { margin: 0 0 5px 0; font-size: 24pt; }
        .header p { margin: 0; opacity: 0.8; }
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            font-size: 9pt;
            color: #666;
            text-align: center;
        }
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1a365d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .print-btn:hover { background: #2d3748; }
    </style>
</head>
<body>
    <button class="print-btn no-print" onclick="window.print()">🖨️ Drucken / Als PDF speichern</button>
    ' . $this->html_content . '
    <div class="footer">
        Erstellt mit Isidor Suite · ' . esc_html(get_bloginfo('name')) . ' · ' . date('d.m.Y H:i') . '
    </div>
</body>
</html>';
        
        switch ($dest) {
            case 'I': // Inline im Browser
            case 'D': // Download
                // Ausgabe-Buffer leeren
                while (ob_get_level()) {
                    ob_end_clean();
                }
                
                if ($dest === 'D') {
                    header('Content-Type: text/html; charset=utf-8');
                    header('Content-Disposition: attachment; filename="' . str_replace('.pdf', '.html', $name) . '"');
                } else {
                    header('Content-Type: text/html; charset=utf-8');
                }
                
                echo $html;
                exit;
                
            case 'S': // Als String zurückgeben
                return $html;
                
            case 'F': // In Datei speichern
                file_put_contents($name, $html);
                return $html;
        }
        
        return $html;
    }
    
    /**
     * Helper: HTML Style aus aktueller Schrift
     */
    private function getHTMLStyle(): string {
        $style = "font-family:{$this->font_family},sans-serif;";
        $style .= "font-size:{$this->font_size}pt;";
        $style .= "color:{$this->text_color};";
        
        if (strpos($this->font_style, 'B') !== false) {
            $style .= 'font-weight:bold;';
        }
        if (strpos($this->font_style, 'I') !== false) {
            $style .= 'font-style:italic;';
        }
        if (strpos($this->font_style, 'U') !== false) {
            $style .= 'text-decoration:underline;';
        }
        
        return $style;
    }
    
    /**
     * Helper: Border Style
     */
    private function getBorderStyle($border): string {
        if ($border === 0 || $border === '') return '';
        if ($border === 1) return 'border:1px solid #333;';
        
        $style = '';
        if (strpos((string)$border, 'L') !== false) $style .= 'border-left:1px solid #333;';
        if (strpos((string)$border, 'R') !== false) $style .= 'border-right:1px solid #333;';
        if (strpos((string)$border, 'T') !== false) $style .= 'border-top:1px solid #333;';
        if (strpos((string)$border, 'B') !== false) $style .= 'border-bottom:1px solid #333;';
        
        return $style;
    }
    
    /**
     * Helper: Alignment Style
     */
    private function getAlignStyle(string $align): string {
        switch ($align) {
            case 'C': return 'text-align:center;';
            case 'R': return 'text-align:right;';
            case 'J': return 'text-align:justify;';
            default: return 'text-align:left;';
        }
    }
    
    /**
     * Seitenbreite/-höhe
     */
    public function getPageWidth(): float {
        return $this->page_width;
    }
    
    public function getPageHeight(): float {
        return $this->page_height;
    }
    
    public function getContentWidth(): float {
        return $this->content_width;
    }
    
    /**
     * Engine-Typ abfragen
     */
    public function getEngine(): string {
        return $this->engine;
    }
    
    // =========================================================================
    // STATISCHE HELPER-METHODEN FÜR ISIDOR
    // =========================================================================
    
    /**
     * Standard-Header für Isidor-Dokumente
     */
    public function isidorHeader(string $title, string $subtitle = ''): void {
        if ($this->engine === 'html') {
            $this->html_content .= '<div class="header">';
            $this->html_content .= '<h1>⛪ ' . esc_html($title) . '</h1>';
            if ($subtitle) {
                $this->html_content .= '<p>' . esc_html($subtitle) . '</p>';
            }
            $this->html_content .= '</div>';
        } else {
            // PDF Header
            $this->SetFillColor(26, 54, 93); // #1a365d
            $this->Rect(0, 0, $this->page_width, 35, 'F');
            
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', 'B', 18);
            $this->SetXY($this->margin_left, 10);
            $this->Cell(0, 10, $title, 0, 1, 'C');
            
            if ($subtitle) {
                $this->SetFont('Arial', '', 11);
                $this->Cell(0, 6, $subtitle, 0, 1, 'C');
            }
            
            $this->SetTextColor(0, 0, 0);
            $this->SetY(45);
        }
    }
    
    /**
     * Tabelle aus Array erstellen
     */
    public function isidorTable(array $headers, array $data, array $widths = []): void {
        if ($this->engine === 'html') {
            $this->html_content .= '<table>';
            $this->html_content .= '<thead><tr>';
            foreach ($headers as $header) {
                $this->html_content .= '<th>' . esc_html($header) . '</th>';
            }
            $this->html_content .= '</tr></thead>';
            $this->html_content .= '<tbody>';
            foreach ($data as $row) {
                $this->html_content .= '<tr>';
                foreach ($row as $cell) {
                    $this->html_content .= '<td>' . esc_html($cell) . '</td>';
                }
                $this->html_content .= '</tr>';
            }
            $this->html_content .= '</tbody></table>';
        } else {
            // Spaltenbreiten berechnen
            if (empty($widths)) {
                $col_count = count($headers);
                $col_width = $this->content_width / $col_count;
                $widths = array_fill(0, $col_count, $col_width);
            }
            
            // Header
            $this->SetFillColor(26, 54, 93);
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', 'B', 10);
            
            foreach ($headers as $i => $header) {
                $this->Cell($widths[$i], 8, $header, 1, 0, 'C', true);
            }
            $this->Ln();
            
            // Daten
            $this->SetTextColor(0, 0, 0);
            $this->SetFont('Arial', '', 9);
            $fill = false;
            
            foreach ($data as $row) {
                if ($fill) {
                    $this->SetFillColor(249, 249, 249);
                } else {
                    $this->SetFillColor(255, 255, 255);
                }
                
                foreach ($row as $i => $cell) {
                    $this->Cell($widths[$i] ?? 30, 7, $cell, 1, 0, 'L', true);
                }
                $this->Ln();
                $fill = !$fill;
            }
        }
    }
    
    /**
     * Info-Box
     */
    public function isidorInfoBox(string $title, array $items): void {
        if ($this->engine === 'html') {
            $this->html_content .= '<div style="background:#f0f4f8;padding:15px;border-radius:8px;margin:15px 0;">';
            $this->html_content .= '<strong>' . esc_html($title) . '</strong><br>';
            foreach ($items as $key => $value) {
                $this->html_content .= esc_html($key) . ': <strong>' . esc_html($value) . '</strong><br>';
            }
            $this->html_content .= '</div>';
        } else {
            $this->SetFillColor(240, 244, 248);
            $this->Rect($this->x, $this->y, $this->content_width, 8 + (count($items) * 6), 'F');
            
            $this->SetFont('Arial', 'B', 10);
            $this->Cell($this->content_width, 7, $title, 0, 1);
            
            $this->SetFont('Arial', '', 9);
            foreach ($items as $key => $value) {
                $this->Cell(50, 5, $key . ':', 0, 0);
                $this->SetFont('Arial', 'B', 9);
                $this->Cell(0, 5, $value, 0, 1);
                $this->SetFont('Arial', '', 9);
            }
            
            $this->Ln(5);
        }
    }
}
