<?php if (!defined('ABSPATH')) exit; ?>

<h2>Kalender-Übersicht</h2>

<div style="margin-bottom: 20px;">
    <form method="get" action="">
        <input type="hidden" name="page" value="isidor-agenda">
        <input type="hidden" name="tab" value="calendar">
        
        <label>Monat: 
            <select name="month" onchange="this.form.submit()">
                <?php 
                $current_month = $_GET['month'] ?? date('Y-m');
                for ($i = 0; $i < 12; $i++) {
                    $date = date('Y-m', strtotime("first day of +$i month"));
                    $label = date('F Y', strtotime($date . '-01'));
                    $selected = $date === $current_month ? 'selected' : '';
                    echo "<option value='$date' $selected>$label</option>";
                }
                ?>
            </select>
        </label>
    </form>
</div>

<?php
$month = $_GET['month'] ?? date('Y-m');
$from = $month . '-01';
$to = date('Y-m-t', strtotime($from));

// Slots holen
$slots = Isidor_Agenda_Slots::get_for_period($from, $to);
$events = Isidor_Agenda_Events::get_for_period($from, $to);
$instances = Isidor_Agenda_Series::get_instances($from, $to);

// Nach Datum gruppieren
$by_date = [];

// Slots (Raumbuchungen)
foreach ($slots as $slot) {
    $date = $slot['date'];
    if (!isset($by_date[$date])) $by_date[$date] = [];
    $by_date[$date][] = [
        'type' => 'slot',
        'data' => $slot
    ];
}

// Events (Veranstaltungen)
foreach ($events as $event) {
    $date = $event['date'];
    if (!isset($by_date[$date])) $by_date[$date] = [];
    $by_date[$date][] = [
        'type' => 'event',
        'data' => $event
    ];
}

// Serien-Instanzen
foreach ($instances as $inst) {
    $date = $inst['date'];
    if (!isset($by_date[$date])) $by_date[$date] = [];
    $by_date[$date][] = [
        'type' => 'series',
        'data' => $inst
    ];
}

ksort($by_date);
?>

<div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px;">
    <!-- Wochentage -->
    <?php foreach (['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'] as $day): ?>
        <div style="font-weight: bold; text-align: center; padding: 10px; background: #f0f0f0;">
            <?php echo $day; ?>
        </div>
    <?php endforeach; ?>
    
    <!-- Tage -->
    <?php
    $start = new DateTime($from);
    $end = new DateTime($to);
    
    // Padding für ersten Tag
    $first_dow = $start->format('N'); // 1=Mo, 7=So
    for ($i = 1; $i < $first_dow; $i++) {
        echo '<div style="background: #fafafa;"></div>';
    }
    
    // Tage durchgehen
    $current = clone $start;
    while ($current <= $end) {
        $date = $current->format('Y-m-d');
        $day = $current->format('d');
        $events = $by_date[$date] ?? [];
        
        $is_today = $date === date('Y-m-d');
        $bg = $is_today ? '#fffbcc' : '#fff';
        
        echo '<div style="border: 1px solid #ddd; padding: 5px; min-height: 80px; background: ' . $bg . ';">';
        echo '<div style="font-weight: bold; margin-bottom: 5px;">' . $day . '</div>';
        
        foreach ($events as $event) {
            if ($event['type'] === 'slot') {
                // Raumbuchung
                $room = Isidor_Agenda_Rooms::get($event['data']['room_id']);
                $color = $event['data']['status'] === 'approved' ? '#90EE90' : '#FFE4B5';
                echo '<div style="font-size: 10px; background: ' . $color . '; padding: 2px; margin: 2px 0; border-radius: 3px;">';
                echo '📅 ' . substr($event['data']['start_time'], 0, 5) . ' ' . substr($room['name'] ?? '', 0, 12);
                echo '</div>';
            } elseif ($event['type'] === 'event') {
                // Veranstaltung
                $color = $event['data']['is_announcement_ready'] ? '#E6F3FF' : '#F5F5F5';
                $border = $event['data']['is_announcement_ready'] ? 'border-left: 3px solid #2271b1;' : '';
                $status_color = $event['data']['status'] === 'approved' ? '#28a745' : '#ffc107';
                echo '<div style="font-size: 10px; background: ' . $color . '; padding: 2px; margin: 2px 0; border-radius: 3px; ' . $border . '">';
                echo '<span style="color: ' . $status_color . ';">🎭</span> ' . substr($event['data']['start_time'], 0, 5) . ' ' . substr($event['data']['title'], 0, 12);
                if ($event['data']['is_announcement_ready']) {
                    echo ' <span style="font-size: 8px;">📢</span>';
                }
                echo '</div>';
            } else {
                // Serie
                $color = $event['data']['is_announcement_ready'] ? '#E6F3FF' : '#F0F0F0';
                echo '<div style="font-size: 10px; background: ' . $color . '; padding: 2px; margin: 2px 0; border-radius: 3px; border-left: 3px solid #0073aa;">';
                echo '🔁 ' . substr($event['data']['start_time'], 0, 5) . ' ' . substr($event['data']['series_title'], 0, 12);
                if ($event['data']['is_announcement_ready']) {
                    echo ' <span style="font-size: 8px;">📢</span>';
                }
                echo '</div>';
            }
        }
        
        echo '</div>';
        
        $current->modify('+1 day');
    }
    ?>
</div>

<div style="margin-top: 20px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd;">
    <strong>Legende:</strong><br><br>
    
    <strong>Raumbuchungen (intern):</strong><br>
    <span style="display: inline-block; width: 20px; height: 12px; background: #90EE90; margin-right: 5px;"></span> 📅 Genehmigt &nbsp;
    <span style="display: inline-block; width: 20px; height: 12px; background: #FFE4B5; margin-right: 5px;"></span> 📅 Ausstehend<br><br>
    
    <strong>Veranstaltungen (öffentlich):</strong><br>
    <span style="display: inline-block; width: 20px; height: 12px; background: #E6F3FF; margin-right: 5px; border-left: 3px solid #2271b1;"></span> 🎭 Mit Plakat 📢 &nbsp;
    <span style="display: inline-block; width: 20px; height: 12px; background: #F5F5F5; margin-right: 5px;"></span> 🎭 Ohne Plakat<br><br>
    
    <strong>Serien (wiederkehrend):</strong><br>
    <span style="display: inline-block; width: 20px; height: 12px; background: #E6F3FF; margin-right: 5px; border-left: 3px solid #0073aa;"></span> 🔁 Mit Plakat 📢 &nbsp;
    <span style="display: inline-block; width: 20px; height: 12px; background: #F0F0F0; margin-right: 5px; border-left: 3px solid #0073aa;"></span> 🔁 Ohne Plakat
</div>
