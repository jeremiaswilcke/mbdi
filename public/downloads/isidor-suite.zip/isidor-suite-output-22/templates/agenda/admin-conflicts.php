<?php if (!defined('ABSPATH')) exit; ?>

<h2>Konflikt-Management</h2>

<?php
$from = date('Y-m-d');
$to = date('Y-m-d', strtotime('+90 days'));

$conflicts = [];

// Prüfe jeden Tag
$current = new DateTime($from);
$end = new DateTime($to);

while ($current <= $end) {
    $date = $current->format('Y-m-d');
    $day_conflicts = Isidor_Agenda_Conflicts::detect($date);
    
    if (!empty($day_conflicts)) {
        $conflicts[$date] = $day_conflicts;
    }
    
    $current->modify('+1 day');
}
?>

<?php if (empty($conflicts)): ?>
    <div class="notice notice-success"><p>✓ Keine Konflikte gefunden!</p></div>
<?php else: ?>
    <div class="notice notice-warning"><p>⚠ <?php echo count($conflicts); ?> Tage mit Konflikten gefunden!</p></div>
    
    <?php foreach ($conflicts as $date => $day_conflicts): ?>
        <h3><?php echo date('D d.m.Y', strtotime($date)); ?></h3>
        
        <?php foreach ($day_conflicts as $conflict): 
            global $wpdb;
            $slot_a = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE id = %d",
                $conflict[0]
            ), ARRAY_A);
            
            $slot_b = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}isidor_agenda_slots WHERE id = %d",
                $conflict[1]
            ), ARRAY_A);
            
            $room = Isidor_Agenda_Rooms::get($slot_a['room_id']);
        ?>
            <div style="background: #fff3cd; padding: 15px; margin: 10px 0; border-left: 4px solid #ff6b6b;">
                <strong>Raum: <?php echo esc_html($room['name']); ?></strong><br>
                
                <div style="margin-top: 10px;">
                    Buchung 1: <?php echo substr($slot_a['start_time'], 0, 5) . ' - ' . substr($slot_a['end_time'], 0, 5); ?> 
                    (<?php echo get_userdata($slot_a['requested_by'])->display_name; ?>)
                    - Status: <?php echo $slot_a['status']; ?>
                </div>
                
                <div>
                    Buchung 2: <?php echo substr($slot_b['start_time'], 0, 5) . ' - ' . substr($slot_b['end_time'], 0, 5); ?> 
                    (<?php echo get_userdata($slot_b['requested_by'])->display_name; ?>)
                    - Status: <?php echo $slot_b['status']; ?>
                </div>
                
                <div style="margin-top: 10px;">
                    <button onclick="agendaRejectSlot(<?php echo $conflict[0]; ?>)" class="button">Buchung 1 ablehnen</button>
                    <button onclick="agendaRejectSlot(<?php echo $conflict[1]; ?>)" class="button">Buchung 2 ablehnen</button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endforeach; ?>
<?php endif; ?>
