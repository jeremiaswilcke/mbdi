<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap">
    <h1>Isidor Agenda</h1>
    <nav class="nav-tab-wrapper">
        <a href="?page=isidor-agenda&tab=calendar" class="nav-tab <?php echo $tab === 'calendar' ? 'nav-tab-active' : ''; ?>">Kalender</a>
        <a href="?page=isidor-agenda&tab=events" class="nav-tab <?php echo $tab === 'events' ? 'nav-tab-active' : ''; ?>">Veranstaltungen</a>
        <a href="?page=isidor-agenda&tab=series" class="nav-tab <?php echo $tab === 'series' ? 'nav-tab-active' : ''; ?>">Serien-Belegung</a>
        <a href="?page=isidor-agenda&tab=requests" class="nav-tab <?php echo $tab === 'requests' ? 'nav-tab-active' : ''; ?>">Anfragen</a>
        <a href="?page=isidor-agenda&tab=conflicts" class="nav-tab <?php echo $tab === 'conflicts' ? 'nav-tab-active' : ''; ?>">Konflikte</a>
        <a href="?page=isidor-agenda&tab=exports" class="nav-tab <?php echo $tab === 'exports' ? 'nav-tab-active' : ''; ?>">Exporte</a>
    </nav>
    <div class="agenda-tab-content">
        <?php
        $tpl_path = ISIDOR_SUITE_PATH . 'templates/agenda/';
        switch ($tab) {
            case 'calendar': include $tpl_path . 'admin-calendar.php'; break;
            case 'events': include $tpl_path . 'admin-events.php'; break;
            case 'series': include $tpl_path . 'admin-series.php'; break;
            case 'series_details': include $tpl_path . 'admin-series-details.php'; break;
            case 'requests': $requests = Isidor_Agenda_Slots::get_for_period(date('Y-m-d'), date('Y-m-d', strtotime('+90 days')), 'pending'); include $tpl_path . 'admin-requests.php'; break;
            case 'conflicts': include $tpl_path . 'admin-conflicts.php'; break;
            case 'exports': include $tpl_path . 'admin-exports.php'; break;
        }
        ?>
    </div>
</div>
