<?php if (!defined('ABSPATH')) exit; ?>

<h2>Veranstaltungen</h2>

<button onclick="agendaOpenEventForm()" class="button button-primary">Neue Veranstaltung</button>

<table class="widefat" style="margin-top: 20px;">
    <thead>
        <tr>
            <th>Titel</th>
            <th>Datum</th>
            <th>Zeit</th>
            <th>Raum</th>
            <th>Plakat</th>
            <th>Status</th>
            <th>Aktionen</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $events = Isidor_Agenda_Events::get_for_period(date('Y-m-d'), date('Y-m-d', strtotime('+90 days')));
        foreach ($events as $event): 
            $room = $event['room_id'] ? Isidor_Agenda_Rooms::get($event['room_id']) : null;
        ?>
            <tr>
                <td><strong><?php echo esc_html($event['title']); ?></strong></td>
                <td><?php echo date('d.m.Y', strtotime($event['date'])); ?></td>
                <td><?php echo substr($event['start_time'], 0, 5) . ' - ' . substr($event['end_time'], 0, 5); ?></td>
                <td><?php echo $room ? esc_html($room['name']) : '-'; ?></td>
                <td>
                    <button onclick="agendaToggleEventAnnouncement(<?php echo $event['id']; ?>, <?php echo $event['is_announcement_ready'] ? 0 : 1; ?>)" 
                            class="button <?php echo $event['is_announcement_ready'] ? 'button-primary' : ''; ?>">
                        <?php echo $event['is_announcement_ready'] ? '✓ JA' : '✗ NEIN'; ?>
                    </button>
                </td>
                <td><?php echo $event['status']; ?></td>
                <td>
                    <button onclick="agendaViewEvent(<?php echo $event['id']; ?>)" class="button">Details</button>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Event erstellen Modal -->
<div id="agenda-event-modal" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border: 1px solid #ccc; box-shadow: 0 5px 15px rgba(0,0,0,0.3); z-index: 9999; max-width: 600px; width: 90%;">
    <h2>Neue Veranstaltung</h2>
    
    <form id="agenda-event-form" onsubmit="agendaSubmitEvent(event)">
        <?php wp_nonce_field('agenda_nonce', 'agenda_nonce'); ?>
        
        <table class="form-table">
            <tr>
                <th><label for="event_title">Titel *</label></th>
                <td><input type="text" id="event_title" name="title" required style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="event_description">Beschreibung</label></th>
                <td><textarea id="event_description" name="description" rows="3" style="width: 100%;"></textarea></td>
            </tr>
            <tr>
                <th><label for="event_date">Datum *</label></th>
                <td><input type="date" id="event_date" name="date" required></td>
            </tr>
            <tr>
                <th><label for="event_start_time">Startzeit *</label></th>
                <td><input type="time" id="event_start_time" name="start_time" required></td>
            </tr>
            <tr>
                <th><label for="event_end_time">Endzeit *</label></th>
                <td><input type="time" id="event_end_time" name="end_time" required></td>
            </tr>
            <tr>
                <th><label for="event_room">Raum</label></th>
                <td>
                    <select id="event_room" name="room_id">
                        <option value="">Kein Raum</option>
                        <?php 
                        $rooms = Isidor_Agenda_Rooms::get_all();
                        foreach ($rooms as $room): ?>
                            <option value="<?php echo $room['id']; ?>"><?php echo esc_html($room['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">Raum wird automatisch gebucht</p>
                </td>
            </tr>
            <tr>
                <th><label for="event_meta1">Meta 1</label></th>
                <td><input type="text" id="event_meta1" name="meta1" style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="event_meta2">Meta 2</label></th>
                <td><input type="text" id="event_meta2" name="meta2" style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="event_speaker">Referent</label></th>
                <td><input type="text" id="event_speaker" name="speaker" style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="event_speaker_title">Referenten-Titel</label></th>
                <td><input type="text" id="event_speaker_title" name="speaker_title" style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="event_announcement">Plakat-Flag</label></th>
                <td>
                    <label>
                        <input type="checkbox" id="event_announcement" name="is_announcement_ready" value="1">
                        <strong>Ankündigungsfähig</strong> (erscheint auf Plakaten)
                    </label>
                </td>
            </tr>
        </table>
        
        <p>
            <button type="submit" class="button button-primary">Veranstaltung erstellen</button>
            <button type="button" onclick="agendaCloseEventForm()" class="button">Abbrechen</button>
        </p>
    </form>
</div>
<div id="agenda-event-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9998;" onclick="agendaCloseEventForm()"></div>
