<?php
/**
 * Admin Template: Exporte
 */
if (!defined('ABSPATH')) exit;
?>

<div class="agenda-exports">
    <h2>Exporte</h2>
    
    <div class="export-sections">
        
        <!-- PDF Export -->
        <div class="export-section" style="background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px;">
            <h3>📄 PDF Export</h3>
            <p>Exportiere Termine als PDF-Dokument.</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-top: 15px;">
                <input type="hidden" name="action" value="agenda_export_pdf">
                <?php wp_nonce_field('agenda_export', 'export_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="pdf_from_date">Von Datum</label>
                        </th>
                        <td>
                            <input type="date" id="pdf_from_date" name="from_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="pdf_to_date">Bis Datum</label>
                        </th>
                        <td>
                            <input type="date" id="pdf_to_date" name="to_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="pdf_type">Export-Typ</label>
                        </th>
                        <td>
                            <select id="pdf_type" name="export_type">
                                <option value="all">Alle Termine</option>
                                <option value="events">Nur Veranstaltungen</option>
                                <option value="series">Nur Serien</option>
                                <option value="slots">Nur Raumbuchungen</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-pdf" style="vertical-align: middle;"></span>
                        PDF generieren
                    </button>
                </p>
            </form>
        </div>
        
        <!-- CSV Export -->
        <div class="export-section" style="background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px;">
            <h3>📊 CSV Export</h3>
            <p>Exportiere Termine als CSV-Datei (für Excel, Google Sheets, etc.).</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-top: 15px;">
                <input type="hidden" name="action" value="agenda_export_csv">
                <?php wp_nonce_field('agenda_export', 'export_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="csv_from_date">Von Datum</label>
                        </th>
                        <td>
                            <input type="date" id="csv_from_date" name="from_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="csv_to_date">Bis Datum</label>
                        </th>
                        <td>
                            <input type="date" id="csv_to_date" name="to_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="csv_type">Export-Typ</label>
                        </th>
                        <td>
                            <select id="csv_type" name="export_type">
                                <option value="all">Alle Termine</option>
                                <option value="events">Nur Veranstaltungen</option>
                                <option value="series">Nur Serien</option>
                                <option value="slots">Nur Raumbuchungen</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="csv_delimiter">Trennzeichen</label>
                        </th>
                        <td>
                            <select id="csv_delimiter" name="delimiter">
                                <option value=",">Komma (,)</option>
                                <option value=";">Semikolon (;)</option>
                                <option value="\t">Tab</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-media-spreadsheet" style="vertical-align: middle;"></span>
                        CSV generieren
                    </button>
                </p>
            </form>
        </div>
        
        <!-- JSON Export -->
        <div class="export-section" style="background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px;">
            <h3>🔧 JSON Export</h3>
            <p>Exportiere Termine als JSON (für API-Integration, Backups, etc.).</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-top: 15px;">
                <input type="hidden" name="action" value="agenda_export_json">
                <?php wp_nonce_field('agenda_export', 'export_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="json_from_date">Von Datum</label>
                        </th>
                        <td>
                            <input type="date" id="json_from_date" name="from_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="json_to_date">Bis Datum</label>
                        </th>
                        <td>
                            <input type="date" id="json_to_date" name="to_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="json_type">Export-Typ</label>
                        </th>
                        <td>
                            <select id="json_type" name="export_type">
                                <option value="all">Alle Termine</option>
                                <option value="events">Nur Veranstaltungen</option>
                                <option value="series">Nur Serien</option>
                                <option value="slots">Nur Raumbuchungen</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="json_pretty">Formatierung</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" id="json_pretty" name="pretty" value="1" checked>
                                Lesbar formatiert (Pretty Print)
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-media-code" style="vertical-align: middle;"></span>
                        JSON generieren
                    </button>
                </p>
            </form>
        </div>
        
        <!-- iCal Export -->
        <div class="export-section" style="background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px;">
            <h3>📅 iCal/ICS Export</h3>
            <p>Exportiere Termine als iCal-Datei (für Google Calendar, Outlook, Apple Calendar, etc.).</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-top: 15px;">
                <input type="hidden" name="action" value="agenda_export_ical">
                <?php wp_nonce_field('agenda_export', 'export_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ical_from_date">Von Datum</label>
                        </th>
                        <td>
                            <input type="date" id="ical_from_date" name="from_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ical_to_date">Bis Datum</label>
                        </th>
                        <td>
                            <input type="date" id="ical_to_date" name="to_date" value="<?php echo date('Y-m-d', strtotime('+90 days')); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ical_type">Export-Typ</label>
                        </th>
                        <td>
                            <select id="ical_type" name="export_type">
                                <option value="all">Alle Termine</option>
                                <option value="events">Nur Veranstaltungen</option>
                                <option value="series">Nur Serien</option>
                            </select>
                            <p class="description">Raumbuchungen werden nicht in iCal exportiert</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-calendar-alt" style="vertical-align: middle;"></span>
                        iCal generieren
                    </button>
                </p>
            </form>
        </div>
        
    </div>
    
    <div class="export-info" style="background: #f0f0f1; padding: 15px; border-left: 4px solid #72aee6; margin-top: 20px;">
        <h4>ℹ️ Hinweise</h4>
        <ul>
            <li><strong>PDF:</strong> Für Ausdrucke und Übersichten</li>
            <li><strong>CSV:</strong> Für Tabellenkalkulation (Excel, Sheets)</li>
            <li><strong>JSON:</strong> Für API-Integration und technische Backups</li>
            <li><strong>iCal:</strong> Für Kalender-Apps (Google, Outlook, Apple)</li>
        </ul>
        <p><strong>Tipp:</strong> Regelmäßige JSON-Exports dienen als Backup!</p>
    </div>
</div>

<style>
.agenda-exports {
    padding: 20px 0;
}

.export-section h3 {
    margin-top: 0;
    font-size: 18px;
}

.export-section .dashicons {
    font-size: 16px;
}

.export-info h4 {
    margin-top: 0;
}

.export-info ul {
    margin-left: 20px;
}
</style>
