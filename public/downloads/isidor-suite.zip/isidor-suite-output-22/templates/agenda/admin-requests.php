<h2>Offene Anfragen</h2>

<?php 
// Alle Slots pending
$requests = Isidor_Agenda_Slots::get_for_period(date('Y-m-d'), date('Y-m-d', strtotime('+90 days')), 'pending');

if (empty($requests)): ?>
    <p>Keine offenen Anfragen.</p>
<?php else: ?>
    <table class="widefat">
        <thead>
            <tr>
                <th>Typ</th>
                <th>Titel/Zweck</th>
                <th>Datum</th>
                <th>Zeit</th>
                <th>Raum</th>
                <th>Angefragt von</th>
                <th>Kommentar</th>
                <th>Aktionen</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $req): 
                $room = Isidor_Agenda_Rooms::get($req['room_id']);
                $user = get_userdata($req['requested_by']);
                
                // Prüfe ob Event zu diesem Slot gehört
                global $wpdb;
                $event = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}isidor_agenda_events WHERE slot_id = %d",
                    $req['id']
                ), ARRAY_A);
                
                $is_event = !empty($event);
                $title = $is_event ? $event['title'] : $req['comment'];
                $type_label = $is_event ? '🎭 Veranstaltung' : '📅 Raumbuchung';
                $bg_color = $is_event ? 'background: #e6f3ff;' : '';
            ?>
                <tr style="<?php echo $bg_color; ?>">
                    <td><strong><?php echo $type_label; ?></strong></td>
                    <td>
                        <?php echo esc_html($title); ?>
                        <?php if ($is_event && $event['is_announcement_ready']): ?>
                            <span style="background: #ffc107; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-left: 5px;">📢 PLAKAT</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date('d.m.Y', strtotime($req['date'])); ?></td>
                    <td><?php echo substr($req['start_time'], 0, 5) . ' - ' . substr($req['end_time'], 0, 5); ?></td>
                    <td><?php echo esc_html($room['name'] ?? ''); ?></td>
                    <td><?php echo $user->display_name ?? ''; ?></td>
                    <td><?php echo esc_html($req['comment']); ?></td>
                    <td>
                        <button onclick="agendaApproveSlot(<?php echo $req['id']; ?>)" class="button button-primary">
                            <?php echo $is_event ? '✓ Event genehmigen' : '✓ Genehmigen'; ?>
                        </button>
                        <button onclick="agendaRejectSlot(<?php echo $req['id']; ?>)" class="button">Ablehnen</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<div style="margin-top: 20px; padding: 15px; background: #f9f9f9; border-left: 4px solid #2271b1;">
    <strong>ℹ️ Info:</strong><br>
    <span style="background: #e6f3ff; padding: 2px 6px;">🎭 Veranstaltungen</span> = Event mit Plakat-Flag möglich<br>
    <span style="padding: 2px 6px;">📅 Raumbuchungen</span> = Nur Raumreservierung (intern)<br>
    <span style="background: #ffc107; padding: 2px 6px;">📢 PLAKAT</span> = Erscheint auf Plakaten
</div>
