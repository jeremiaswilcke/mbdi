<?php
/**
 * Admin Template: Räume Verwaltung
 */
if (!defined('ABSPATH')) exit;
?>

<div class="wrap">
    <h1 class="wp-heading-inline">Räume</h1>
    
    <?php if (current_user_can('agenda_manage_rooms')): ?>
        <a href="#" class="page-title-action" id="add-new-room">Neuer Raum</a>
    <?php endif; ?>
    
    <hr class="wp-header-end">
    
    <?php if (isset($_GET['message'])): ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php 
                switch ($_GET['message']) {
                    case 'created':
                        echo 'Raum erfolgreich erstellt!';
                        break;
                    case 'updated':
                        echo 'Raum erfolgreich aktualisiert!';
                        break;
                    case 'deleted':
                        echo 'Raum erfolgreich gelöscht!';
                        break;
                }
                ?>
            </p>
        </div>
    <?php endif; ?>
    
    <?php if (empty($rooms)): ?>
        <div class="notice notice-info">
            <p>Noch keine Räume angelegt. Erstelle den ersten Raum mit dem Button oben.</p>
        </div>
    <?php else: ?>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 30%;">Raumname</th>
                    <th style="width: 25%;">Standort</th>
                    <th style="width: 10%;">Kapazität</th>
                    <th style="width: 15%;">Genehmigung</th>
                    <th style="width: 10%;">Status</th>
                    <th style="width: 10%;">Aktionen</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rooms as $room): ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html($room->name); ?></strong>
                            <?php if ($room->notes): ?>
                                <br><small class="description"><?php echo esc_html($room->notes); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($room->location ?: '—'); ?></td>
                        <td>
                            <?php 
                            if ($room->capacity) {
                                echo esc_html($room->capacity) . ' Personen';
                            } else {
                                echo '—';
                            }
                            ?>
                        </td>
                        <td>
                            <?php if ($room->requires_approval): ?>
                                <span class="dashicons dashicons-yes" style="color: #d63638;"></span> Erforderlich
                            <?php else: ?>
                                <span class="dashicons dashicons-no" style="color: #00a32a;"></span> Nicht erforderlich
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($room->active): ?>
                                <span style="color: #00a32a;">● Aktiv</span>
                            <?php else: ?>
                                <span style="color: #999;">○ Inaktiv</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (current_user_can('agenda_manage_rooms')): ?>
                                <a href="#" class="edit-room" data-room-id="<?php echo $room->id; ?>" title="Bearbeiten">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>
                                <a href="#" class="delete-room" data-room-id="<?php echo $room->id; ?>" title="Löschen" style="color: #d63638;">
                                    <span class="dashicons dashicons-trash"></span>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
    <?php endif; ?>
</div>

<!-- Modal: Neuer Raum / Raum bearbeiten -->
<div id="room-modal" style="display:none;">
    <div class="room-modal-overlay"></div>
    <div class="room-modal-content">
        <h2 id="room-modal-title">Neuer Raum</h2>
        
        <form id="room-form">
            <input type="hidden" id="room-id" name="room_id" value="">
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="room-name">Raumname *</label>
                    </th>
                    <td>
                        <input type="text" id="room-name" name="name" class="regular-text" required>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="room-location">Standort</label>
                    </th>
                    <td>
                        <input type="text" id="room-location" name="location" class="regular-text">
                        <p class="description">z.B. Erdgeschoss, 1. Stock, etc.</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="room-capacity">Kapazität</label>
                    </th>
                    <td>
                        <input type="number" id="room-capacity" name="capacity" min="0" step="1">
                        <p class="description">Maximale Personenanzahl</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="room-requires-approval">Genehmigung</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="room-requires-approval" name="requires_approval" value="1" checked>
                            Genehmigung durch Admin erforderlich
                        </label>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="room-notes">Notizen</label>
                    </th>
                    <td>
                        <textarea id="room-notes" name="notes" rows="3" class="large-text"></textarea>
                        <p class="description">Interne Hinweise zum Raum</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="room-active">Status</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="room-active" name="active" value="1" checked>
                            Raum ist aktiv und buchbar
                        </label>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary">Speichern</button>
                <button type="button" class="button" id="cancel-room-modal">Abbrechen</button>
            </p>
        </form>
    </div>
</div>

<style>
.room-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 100000;
}

.room-modal-content {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 30px;
    border-radius: 5px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.5);
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    z-index: 100001;
}

.room-modal-content h2 {
    margin-top: 0;
}
</style>

<script>
jQuery(document).ready(function($) {
    
    // Neuer Raum
    $('#add-new-room').on('click', function(e) {
        e.preventDefault();
        $('#room-modal-title').text('Neuer Raum');
        $('#room-form')[0].reset();
        $('#room-id').val('');
        $('#room-modal').show();
    });
    
    // Raum bearbeiten
    $('.edit-room').on('click', function(e) {
        e.preventDefault();
        var roomId = $(this).data('room-id');
        
        // Load room data via AJAX
        $.post(ajaxurl, {
            action: 'agenda_get_room',
            room_id: roomId,
            nonce: agendaData.nonce
        }, function(response) {
            if (response.success) {
                var room = response.data.room;
                
                // Populate form
                $('#room-modal-title').text('Raum bearbeiten');
                $('#room-id').val(room.id);
                $('#room-name').val(room.name);
                $('#room-location').val(room.location);
                $('#room-capacity').val(room.capacity);
                $('#room-requires-approval').prop('checked', room.requires_approval == 1);
                $('#room-notes').val(room.notes);
                $('#room-active').prop('checked', room.active == 1);
                
                $('#room-modal').show();
            } else {
                alert('Fehler beim Laden: ' + (response.data.message || 'Unbekannter Fehler'));
            }
        }).fail(function() {
            alert('Fehler beim Laden der Raumdaten. Bitte versuchen Sie es erneut.');
        });
    });
    
    // Raum löschen
    $('.delete-room').on('click', function(e) {
        e.preventDefault();
        if (!confirm('Raum wirklich löschen? Bestehende Buchungen bleiben erhalten.')) {
            return;
        }
        
        var roomId = $(this).data('room-id');
        
        // TODO: Delete via AJAX
        $.post(ajaxurl, {
            action: 'agenda_delete_room',
            room_id: roomId,
            nonce: agendaData.nonce
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Fehler beim Löschen: ' + response.data);
            }
        });
    });
    
    // Modal schließen
    $('#cancel-room-modal').on('click', function() {
        $('#room-modal').hide();
    });
    
    // Form Submit
    $('#room-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = $(this).serialize();
        
        $.post(ajaxurl, {
            action: 'agenda_save_room',
            ...Object.fromEntries(new URLSearchParams(formData)),
            nonce: agendaData.nonce
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Fehler beim Speichern: ' + response.data);
            }
        });
    });
    
});
</script>
