<?php 
if (!defined('ABSPATH')) exit;

$series_id = intval($_GET['series_id']);
$series = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}isidor_agenda_series WHERE id = %d",
    $series_id
), ARRAY_A);

if (!$series) {
    echo '<div class="notice error"><p>Serie nicht gefunden</p></div>';
    return;
}

$instances = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}isidor_agenda_series_instances WHERE series_id = %d ORDER BY date",
    $series_id
), ARRAY_A);
?>

<div class="wrap">
    <h1>Serie: <?php echo esc_html($series['title']); ?></h1>
    
    <p><a href="?page=isidor-agenda&tab=series">← Zurück zur Übersicht</a></p>
    
    <div class="card" style="max-width: 800px;">
        <h2>Details</h2>
        <table class="form-table">
            <tr>
                <th>Beschreibung:</th>
                <td><?php echo nl2br(esc_html($series['description'])); ?></td>
            </tr>
            <tr>
                <th>Muster:</th>
                <td><?php echo esc_html($series['recurrence_pattern']); ?></td>
            </tr>
            <tr>
                <th>Zeitraum:</th>
                <td><?php echo date('d.m.Y', strtotime($series['start_date'])) . ' - ' . ($series['end_date'] ? date('d.m.Y', strtotime($series['end_date'])) : 'unbegrenzt'); ?></td>
            </tr>
            <tr>
                <th>Zeit:</th>
                <td><?php echo substr($series['start_time'], 0, 5) . ' - ' . substr($series['end_time'], 0, 5); ?></td>
            </tr>
            <tr>
                <th>Plakat-Flag:</th>
                <td>
                    <button onclick="agendaToggleAnnouncement(<?php echo $series['id']; ?>, <?php echo $series['is_announcement_ready'] ? 0 : 1; ?>)" 
                            class="button <?php echo $series['is_announcement_ready'] ? 'button-primary' : ''; ?>">
                        <?php echo $series['is_announcement_ready'] ? '✓ Ankündigungsfähig' : '✗ Nicht ankündigungsfähig'; ?>
                    </button>
                </td>
            </tr>
        </table>
    </div>
    
    <h2 style="margin-top: 30px;">Termine (<?php echo count($instances); ?>)</h2>
    
    <table class="widefat">
        <thead>
            <tr>
                <th>Datum</th>
                <th>Zeit</th>
                <th>Status</th>
                <th>Grund</th>
                <th>Aktionen</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($instances as $inst): ?>
                <tr style="<?php echo $inst['is_cancelled'] ? 'background: #fdd; text-decoration: line-through;' : ''; ?>">
                    <td><?php echo date('D d.m.Y', strtotime($inst['date'])); ?></td>
                    <td><?php echo substr($inst['start_time'], 0, 5) . ' - ' . substr($inst['end_time'], 0, 5); ?></td>
                    <td><?php echo $inst['is_cancelled'] ? '✗ Abgesagt' : '✓ Aktiv'; ?></td>
                    <td><?php echo esc_html($inst['cancellation_reason']); ?></td>
                    <td>
                        <?php if ($inst['is_cancelled']): ?>
                            <button onclick="agendaToggleInstance(<?php echo $inst['id']; ?>, false)" class="button">Reaktivieren</button>
                        <?php else: ?>
                            <button onclick="agendaCancelInstance(<?php echo $inst['id']; ?>)" class="button">Absagen</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
