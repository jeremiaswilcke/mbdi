<?php if (!defined('ABSPATH')) exit; ?>

<h2>Serienveranstaltungen</h2>

<button onclick="agendaOpenSeriesForm()" class="button button-primary">Neue Serie</button>

<table class="widefat" style="margin-top: 20px;">
    <thead>
        <tr>
            <th>Titel</th>
            <th>Muster</th>
            <th>Start</th>
            <th>Ende</th>
            <th>Zeit</th>
            <th>Raum</th>
            <th>Plakat</th>
            <th>Termine</th>
            <th>Aktionen</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $series_list = Isidor_Agenda_Series::get_all();
        foreach ($series_list as $ser): 
            global $wpdb;
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}isidor_agenda_series_instances WHERE series_id = %d AND is_cancelled = 0",
                $ser['id']
            ));
            $room = $ser['room_id'] ? Isidor_Agenda_Rooms::get($ser['room_id']) : null;
        ?>
            <tr>
                <td><strong><?php echo esc_html($ser['title']); ?></strong></td>
                <td><?php echo esc_html($ser['recurrence_pattern']); ?></td>
                <td><?php echo date('d.m.Y', strtotime($ser['start_date'])); ?></td>
                <td><?php echo $ser['end_date'] ? date('d.m.Y', strtotime($ser['end_date'])) : '-'; ?></td>
                <td><?php echo substr($ser['start_time'], 0, 5) . ' - ' . substr($ser['end_time'], 0, 5); ?></td>
                <td><?php echo $room ? esc_html($room['name']) : '-'; ?></td>
                <td>
                    <button onclick="agendaToggleAnnouncement(<?php echo $ser['id']; ?>, <?php echo $ser['is_announcement_ready'] ? 0 : 1; ?>)" 
                            class="button <?php echo $ser['is_announcement_ready'] ? 'button-primary' : ''; ?>">
                        <?php echo $ser['is_announcement_ready'] ? '✓ JA' : '✗ NEIN'; ?>
                    </button>
                </td>
                <td><?php echo $count; ?> Termine</td>
                <td>
                    <a href="?page=isidor-agenda&tab=series_details&series_id=<?php echo $ser['id']; ?>" class="button">Verwalten</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Serie erstellen Modal -->
<div id="agenda-series-modal" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border: 1px solid #ccc; box-shadow: 0 5px 15px rgba(0,0,0,0.3); z-index: 9999; max-width: 600px; width: 90%;">
    <h2>Neue Serienveranstaltung</h2>
    
    <form id="agenda-series-form" onsubmit="agendaSubmitSeries(event)">
        <?php wp_nonce_field('agenda_nonce', 'agenda_nonce'); ?>
        
        <table class="form-table">
            <tr>
                <th><label for="series_title">Titel *</label></th>
                <td><input type="text" id="series_title" name="title" required style="width: 100%;"></td>
            </tr>
            <tr>
                <th><label for="series_description">Beschreibung</label></th>
                <td><textarea id="series_description" name="description" rows="3" style="width: 100%;"></textarea></td>
            </tr>
            <tr>
                <th><label for="series_pattern">Wiederholungsmuster *</label></th>
                <td>
                    <select id="series_pattern" name="recurrence_pattern" required>
                        <option value="weekly">Wöchentlich</option>
                        <option value="biweekly">Alle 2 Wochen</option>
                        <option value="monthly">Monatlich</option>
                        <option value="first_monday">Jeden 1. Montag im Monat</option>
                        <option value="last_friday">Jeden letzten Freitag im Monat</option>
                        <option value="daily">Täglich</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="series_start_date">Startdatum *</label></th>
                <td><input type="date" id="series_start_date" name="start_date" required></td>
            </tr>
            <tr>
                <th><label for="series_end_date">Enddatum</label></th>
                <td><input type="date" id="series_end_date" name="end_date"></td>
            </tr>
            <tr>
                <th><label for="series_start_time">Startzeit *</label></th>
                <td><input type="time" id="series_start_time" name="start_time" required></td>
            </tr>
            <tr>
                <th><label for="series_end_time">Endzeit *</label></th>
                <td><input type="time" id="series_end_time" name="end_time" required></td>
            </tr>
            <tr>
                <th><label for="series_room">Raum</label></th>
                <td>
                    <select id="series_room" name="room_id">
                        <option value="">Kein Raum</option>
                        <?php 
                        $rooms = Isidor_Agenda_Rooms::get_all();
                        foreach ($rooms as $room): ?>
                            <option value="<?php echo $room['id']; ?>"><?php echo esc_html($room['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="series_announcement">Plakat-Flag</label></th>
                <td>
                    <label>
                        <input type="checkbox" id="series_announcement" name="is_announcement_ready" value="1">
                        Ankündigungsfähig (erscheint auf Plakaten)
                    </label>
                </td>
            </tr>
        </table>
        
        <p>
            <button type="submit" class="button button-primary">Serie erstellen</button>
            <button type="button" onclick="agendaCloseSeriesForm()" class="button">Abbrechen</button>
        </p>
    </form>
</div>
<div id="agenda-series-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9998;" onclick="agendaCloseSeriesForm()"></div>
