<?php
/**
 * Shortcode Template: Meine Raumbuchungen
 * Verwendung: [isidor_agenda_my_requests]
 */
if (!defined('ABSPATH')) exit;

if (!is_user_logged_in()) {
    echo '<p>Bitte melden Sie sich an, um Ihre Anfragen zu sehen.</p>';
    return;
}
?>

<div class="isidor-agenda-my-requests">
    <h2>Meine Raumbuchungen</h2>
    
    <?php if (empty($requests)): ?>
        <div class="no-requests">
            <p>Sie haben noch keine Raumbuchungen.</p>
            <p><a href="#request-form" class="button">Raum jetzt anfragen</a></p>
        </div>
    <?php else: ?>
        
        <div class="requests-list">
            <?php foreach ($requests as $request): 
                $room = Isidor_Agenda_Rooms::get($request['room_id']);
                $status_class = $request['status'];
                $status_text = [
                    'pending' => 'Ausstehend',
                    'approved' => 'Genehmigt',
                    'rejected' => 'Abgelehnt',
                    'cancelled' => 'Storniert'
                ][$request['status']] ?? $request['status'];
                
                $status_icon = [
                    'pending' => '⏳',
                    'approved' => '✅',
                    'rejected' => '❌',
                    'cancelled' => '🚫'
                ][$request['status']] ?? '📋';
            ?>
                <div class="request-card status-<?php echo esc_attr($status_class); ?>">
                    <div class="request-header">
                        <div class="request-room">
                            <strong><?php echo esc_html($room['name'] ?? 'Unbekannter Raum'); ?></strong>
                            <?php if (!empty($room['location'])): ?>
                                <span class="request-location">
                                    (<?php echo esc_html($room['location']); ?>)
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="request-status status-<?php echo esc_attr($status_class); ?>">
                            <?php echo $status_icon; ?> <?php echo esc_html($status_text); ?>
                        </div>
                    </div>
                    
                    <div class="request-details">
                        <div class="request-detail">
                            <strong>Datum:</strong>
                            <?php echo date_i18n('d.m.Y', strtotime($request['date'])); ?>
                        </div>
                        
                        <div class="request-detail">
                            <strong>Zeit:</strong>
                            <?php echo substr($request['start_time'], 0, 5); ?> - 
                            <?php echo substr($request['end_time'], 0, 5); ?> Uhr
                        </div>
                        
                        <?php if (!empty($request['comment'])): ?>
                            <div class="request-detail">
                                <strong>Zweck:</strong>
                                <?php echo esc_html($request['comment']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="request-meta">
                            <small>
                                Angefragt am: <?php echo date_i18n('d.m.Y H:i', strtotime($request['created_at'])); ?>
                            </small>
                        </div>
                    </div>
                    
                    <?php if ($request['status'] === 'pending'): ?>
                        <div class="request-actions">
                            <button class="button button-small cancel-request" 
                                    data-request-id="<?php echo $request['id']; ?>">
                                Anfrage stornieren
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        
    <?php endif; ?>
</div>

<style>
.isidor-agenda-my-requests {
    padding: 20px 0;
}

.isidor-agenda-my-requests h2 {
    margin-bottom: 20px;
    color: #333;
}

.no-requests {
    text-align: center;
    padding: 40px;
    background: #f9f9f9;
    border-radius: 8px;
}

.no-requests p {
    margin: 10px 0;
}

.no-requests .button {
    margin-top: 15px;
    padding: 10px 20px;
    background: #2271b1;
    color: white;
    text-decoration: none;
    border-radius: 4px;
    display: inline-block;
}

.requests-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.request-card {
    background: white;
    border: 1px solid #ddd;
    border-left: 4px solid #999;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.request-card.status-pending {
    border-left-color: #ffc107;
}

.request-card.status-approved {
    border-left-color: #28a745;
}

.request-card.status-rejected {
    border-left-color: #dc3545;
}

.request-card.status-cancelled {
    border-left-color: #6c757d;
    opacity: 0.7;
}

.request-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #f0f0f0;
}

.request-room strong {
    font-size: 16px;
    color: #333;
}

.request-location {
    color: #666;
    font-size: 14px;
}

.request-status {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
}

.request-status.status-pending {
    background: #fff3cd;
    color: #856404;
}

.request-status.status-approved {
    background: #d4edda;
    color: #155724;
}

.request-status.status-rejected {
    background: #f8d7da;
    color: #721c24;
}

.request-status.status-cancelled {
    background: #e2e3e5;
    color: #383d41;
}

.request-details {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.request-detail {
    font-size: 14px;
    line-height: 1.6;
}

.request-detail strong {
    color: #333;
    margin-right: 5px;
}

.request-meta {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #f0f0f0;
}

.request-meta small {
    color: #999;
}

.request-actions {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.request-actions .button {
    padding: 8px 15px;
    font-size: 13px;
    border: 1px solid #ddd;
    background: white;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s;
}

.request-actions .button:hover {
    background: #f8f9fa;
    border-color: #999;
}

@media (max-width: 600px) {
    .request-header {
        flex-direction: column;
        gap: 10px;
    }
    
    .request-status {
        align-self: flex-start;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    $('.cancel-request').on('click', function() {
        if (!confirm('Möchten Sie diese Anfrage wirklich stornieren?')) {
            return;
        }
        
        const requestId = $(this).data('request-id');
        const button = $(this);
        
        button.prop('disabled', true).text('Wird storniert...');
        
        $.post(agendaData.ajaxUrl, {
            action: 'agenda_cancel_request',
            request_id: requestId,
            nonce: agendaData.nonce
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Fehler beim Stornieren: ' + (response.data || 'Unbekannter Fehler'));
                button.prop('disabled', false).text('Anfrage stornieren');
            }
        }).fail(function() {
            alert('Verbindungsfehler. Bitte versuchen Sie es erneut.');
            button.prop('disabled', false).text('Anfrage stornieren');
        });
    });
});
</script>
