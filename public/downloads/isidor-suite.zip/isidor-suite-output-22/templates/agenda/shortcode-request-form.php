<?php
/**
 * Shortcode Template: Raumbuchungs-Formular
 * Verwendung: [isidor_agenda_request_form]
 */
if (!defined('ABSPATH')) exit;

if (!is_user_logged_in()) {
    echo '<p>Bitte melden Sie sich an, um einen Raum anzufragen.</p>';
    return;
}

$rooms = Isidor_Agenda_Rooms::get_all();
$preselected_room = isset($_GET['room_id']) ? intval($_GET['room_id']) : 0;

// Veranstaltungstypen - exakt wie im Poster-Generator
$event_types = [
    'fest' => ['label' => '🎉 Fest', 'has_subtitle' => true, 'has_speaker' => false],
    'vortrag' => ['label' => '🎤 Vortrag', 'has_subtitle' => true, 'has_speaker' => true],
    'messe' => ['label' => '⛪ Hl. Messe', 'has_subtitle' => false, 'has_speaker' => false],
    'ausflug' => ['label' => '🚌 Ausflug', 'has_subtitle' => true, 'has_speaker' => false],
    'sonstiges' => ['label' => '📝 Sonstiges', 'has_subtitle' => true, 'has_speaker' => true, 'has_custom_type' => true],
];
?>

<div class="isidor-agenda-request-form" id="request-form">
    <h2>Raum anfragen</h2>
    
    <?php if (empty($rooms)): ?>
        <p>Aktuell sind keine Räume verfügbar.</p>
    <?php else: ?>
        
        <form method="post" class="agenda-form">
            <?php wp_nonce_field('agenda_request', 'agenda_nonce'); ?>
            <input type="hidden" name="agenda_request" value="1">
            
            <div class="form-group">
                <label for="room_id">Raum *</label>
                <select id="room_id" name="room_id" required>
                    <option value="">-- Raum wählen --</option>
                    <?php foreach ($rooms as $room): ?>
                        <option value="<?php echo $room->id; ?>" 
                                <?php selected($preselected_room, $room->id); ?>>
                            <?php echo esc_html($room->name); ?>
                            <?php if ($room->location): ?>
                                (<?php echo esc_html($room->location); ?>)
                            <?php endif; ?>
                            <?php if ($room->capacity): ?>
                                - max. <?php echo $room->capacity; ?> Personen
                            <?php endif; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="date">Datum *</label>
                <input type="date" id="date" name="date" 
                       min="<?php echo date('Y-m-d'); ?>" 
                       required>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="start_time">Von *</label>
                    <input type="time" id="start_time" name="start_time" required>
                </div>
                
                <div class="form-group">
                    <label for="end_time">Bis *</label>
                    <input type="time" id="end_time" name="end_time" required>
                </div>
            </div>
            
            <!-- Veranstaltung Checkbox -->
            <div class="form-group event-toggle">
                <label class="checkbox-label">
                    <input type="checkbox" id="is_event" name="is_event" value="1">
                    <span>🎪 Dies ist eine Veranstaltung (für Plakate)</span>
                </label>
                <small>Aktivieren für Feste, Vorträge oder andere Events</small>
            </div>
            
            <!-- Veranstaltungs-Details (versteckt bis Checkbox aktiviert) -->
            <div id="event-details" class="event-details" style="display:none;">
                <div class="event-details-header">
                    <h4>📋 Plakat-Felder</h4>
                    <p class="description">Diese Felder erscheinen auf dem Plakat</p>
                </div>
                
                <div class="form-group">
                    <label for="event_type">Art der Veranstaltung * <small>(Badge oben auf Plakat)</small></label>
                    <select id="event_type" name="event_type">
                        <?php foreach ($event_types as $key => $type): ?>
                            <option value="<?php echo $key; ?>" 
                                data-has-subtitle="<?php echo !empty($type['has_subtitle']) ? '1' : '0'; ?>"
                                data-has-speaker="<?php echo !empty($type['has_speaker']) ? '1' : '0'; ?>"
                                data-has-custom="<?php echo !empty($type['has_custom_type']) ? '1' : '0'; ?>">
                                <?php echo $type['label']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="event_title">Titel * <small>(Hauptzeile auf Plakat)</small></label>
                    <input type="text" id="event_title" name="event_title" 
                           placeholder="z.B. Pfarrfest Mariabrunn">
                </div>
                
                <div class="form-group" id="event-subtitle-group">
                    <label for="event_subtitle">Untertitel <small>(zweite Zeile, z.B. Thema)</small></label>
                    <input type="text" id="event_subtitle" name="event_subtitle" 
                           placeholder="z.B. Papst Leo - die ersten sechs Monate">
                </div>
                
                <div class="form-group" id="event-speaker-group">
                    <label for="event_speaker">Referent/in <small>(wird grün dargestellt)</small></label>
                    <input type="text" id="event_speaker" name="event_speaker" 
                           placeholder="Name des Referenten">
                </div>
                
                <div class="form-group" id="event-custom-type-group">
                    <label for="event_custom_type">Veranstaltungsart (Freitext) <small>(statt "Sonstiges")</small></label>
                    <input type="text" id="event_custom_type" name="event_custom_type" 
                           placeholder="z.B. Workshop, Konzert, Benefiz...">
                </div>
                
                <div class="form-group">
                    <label for="event_description">Beschreibung <small>(nur intern, nicht auf Plakat)</small></label>
                    <textarea id="event_description" name="event_description" rows="2"
                              placeholder="Kurze Beschreibung für interne Zwecke..."></textarea>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="event_public" name="event_public" value="1" checked>
                        <span>✅ Öffentlich — erscheint im Plakat-Generator</span>
                    </label>
                </div>
            </div>
            
            <div class="form-group">
                <label for="comment">Weitere Notizen</label>
                <textarea id="comment" name="comment" rows="3" 
                          placeholder="Sonstige Informationen..."></textarea>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="button button-primary">
                    Anfrage senden
                </button>
            </div>
            
            <p class="form-note">
                <small>
                    * Pflichtfelder<br>
                    Ihre Anfrage wird geprüft und Sie erhalten eine Benachrichtigung.
                </small>
            </p>
        </form>
        
    <?php endif; ?>
</div>

<style>
.isidor-agenda-request-form {
    max-width: 600px;
    margin: 20px auto;
    padding: 30px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.isidor-agenda-request-form h2 {
    margin-top: 0;
    color: #333;
    border-bottom: 2px solid var(--is-primary, #2271b1);
    padding-bottom: 10px;
}

.agenda-form {
    margin-top: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 5px;
    color: #333;
}

.form-group input[type="date"],
.form-group input[type="time"],
.form-group input[type="text"],
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    transition: border-color 0.15s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--is-primary, #2271b1);
}

.form-group textarea {
    resize: vertical;
    min-height: 80px;
}

.form-group small {
    display: block;
    margin-top: 5px;
    color: #666;
    font-size: 13px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

/* Event Toggle */
.event-toggle {
    background: #f8fafc;
    padding: 15px;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    font-weight: 600;
}

.checkbox-label input[type="checkbox"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
}

/* Event Details Box */
.event-details {
    background: linear-gradient(135deg, #eff6ff 0%, #f0fdf4 100%);
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
}

.event-details-header {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #bfdbfe;
}

.event-details-header h4 {
    margin: 0;
    color: #1e40af;
    font-size: 1rem;
}

.form-actions {
    margin-top: 25px;
}

.form-actions .button {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.2s;
}

.form-actions .button-primary {
    background: var(--is-primary, #2271b1);
    color: white;
}

.form-actions .button-primary:hover {
    background: var(--is-primary-hover, #135e96);
}

.form-note {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
    color: #666;
}

.notice {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 6px;
    border-left: 4px solid;
}

.notice.success {
    background: #d4edda;
    border-color: #28a745;
    color: #155724;
}

.notice.error {
    background: #f8d7da;
    border-color: #dc3545;
    color: #721c24;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.agenda-form');
    if (!form) return;
    
    const isEventCheckbox = document.getElementById('is_event');
    const eventDetails = document.getElementById('event-details');
    const eventType = document.getElementById('event_type');
    const speakerGroup = document.getElementById('event-speaker-group');
    const subtitleGroup = document.getElementById('event-subtitle-group');
    const customTypeGroup = document.getElementById('event-custom-type-group');
    const eventTitle = document.getElementById('event_title');
    
    // Toggle Event Details
    isEventCheckbox.addEventListener('change', function() {
        eventDetails.style.display = this.checked ? 'block' : 'none';
        eventTitle.required = this.checked;
        if (this.checked) {
            updateFieldVisibility();
        }
    });
    
    // Show/hide fields based on event type (using data attributes)
    function updateFieldVisibility() {
        const selected = eventType.options[eventType.selectedIndex];
        const hasSubtitle = selected.dataset.hasSubtitle === '1';
        const hasSpeaker = selected.dataset.hasSpeaker === '1';
        const hasCustom = selected.dataset.hasCustom === '1';
        
        subtitleGroup.style.display = hasSubtitle ? 'block' : 'none';
        speakerGroup.style.display = hasSpeaker ? 'block' : 'none';
        customTypeGroup.style.display = hasCustom ? 'block' : 'none';
    }
    
    eventType.addEventListener('change', updateFieldVisibility);
    
    // Initial state
    updateFieldVisibility();
    
    // Validate times
    form.addEventListener('submit', function(e) {
        const startTime = document.getElementById('start_time').value;
        const endTime = document.getElementById('end_time').value;
        
        if (startTime && endTime && startTime >= endTime) {
            e.preventDefault();
            alert('Die Endzeit muss nach der Startzeit liegen!');
        }
    });
});
</script>
