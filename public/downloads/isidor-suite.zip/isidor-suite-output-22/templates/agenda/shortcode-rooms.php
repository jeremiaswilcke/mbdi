<?php
/**
 * Shortcode Template: Räume-Übersicht
 * Verwendung: [isidor_agenda_rooms]
 */
if (!defined('ABSPATH')) exit;
?>

<div class="isidor-agenda-rooms">
    <h2>Verfügbare Räume</h2>
    
    <?php if (empty($rooms)): ?>
        <p>Aktuell sind keine Räume verfügbar.</p>
    <?php else: ?>
        
        <div class="rooms-grid">
            <?php foreach ($rooms as $room): ?>
                <div class="room-card">
                    <div class="room-header">
                        <h3><?php echo esc_html($room->name); ?></h3>
                        <?php if ($room->location): ?>
                            <span class="room-location">
                                📍 <?php echo esc_html($room->location); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="room-details">
                        <?php if ($room->capacity): ?>
                            <div class="room-detail">
                                <strong>Kapazität:</strong>
                                <?php echo esc_html($room->capacity); ?> Personen
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($room->notes): ?>
                            <div class="room-detail">
                                <strong>Hinweise:</strong>
                                <?php echo esc_html($room->notes); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($room->requires_approval): ?>
                            <div class="room-detail approval-required">
                                ⚠️ Genehmigung erforderlich
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (is_user_logged_in() && current_user_can('agenda_request_room')): ?>
                        <div class="room-actions">
                            <?php
                            // Use booking_url from shortcode attributes, or try to find the form page
                            $booking_url = !empty($atts['booking_url']) ? $atts['booking_url'] : '';
                            
                            if (empty($booking_url)) {
                                // Try to find page with request form shortcode
                                $args = [
                                    'post_type' => 'page',
                                    'posts_per_page' => 1,
                                    'post_status' => 'publish'
                                ];
                                $pages = get_posts($args);
                                
                                foreach ($pages as $page) {
                                    if (has_shortcode($page->post_content, 'isidor_agenda_request_form')) {
                                        $booking_url = get_permalink($page->ID);
                                        break;
                                    }
                                }
                            }
                            
                            if (empty($booking_url)) {
                                // Fallback: current page with anchor
                                $booking_url = get_permalink() . '#request-form';
                            }
                            
                            $button_url = add_query_arg(['room_id' => $room->id], $booking_url);
                            ?>
                            <a href="<?php echo esc_url($button_url); ?>" 
                               class="button button-primary">
                                Raum anfragen
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        
    <?php endif; ?>
</div>

<style>
.isidor-agenda-rooms {
    padding: 20px 0;
}

.rooms-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.room-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    background: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: transform 0.2s;
}

.room-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.room-header {
    border-bottom: 2px solid #f0f0f0;
    padding-bottom: 10px;
    margin-bottom: 15px;
}

.room-header h3 {
    margin: 0 0 5px 0;
    color: #333;
}

.room-location {
    font-size: 14px;
    color: #666;
}

.room-details {
    margin: 15px 0;
}

.room-detail {
    margin: 8px 0;
    font-size: 14px;
    line-height: 1.6;
}

.room-detail strong {
    color: #333;
}

.approval-required {
    background: #fff3cd;
    padding: 8px;
    border-radius: 4px;
    border-left: 3px solid #ffc107;
    margin-top: 10px;
}

.room-actions {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.room-actions .button {
    width: 100%;
    text-align: center;
    padding: 10px;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
    transition: background 0.2s;
}

.room-actions .button-primary {
    background: #2271b1;
    color: white;
    border: none;
}

.room-actions .button-primary:hover {
    background: #135e96;
}
</style>
