<?php
/**
 * Isidor App Shell – Eigenes Page Template
 * 
 * Dieses Template ersetzt das Theme-Template komplett auf Isidor-Seiten.
 * Kein Theme-Header, kein Theme-Footer, kein Theme-Sidebar.
 * Nur das Isidor App Shell Framework.
 *
 * @package IsidorSuite
 */

if (!defined('ABSPATH')) exit;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class('isidor-app'); ?>>
<?php wp_body_open(); ?>

<?php
// Der the_content Filter in class-app-shell.php wrappt den Content
// automatisch in das Shell-Markup (Header, Sidebar, Main, Bottom-Nav)
if (have_posts()) :
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
endif;
?>

<?php wp_footer(); ?>
</body>
</html>
