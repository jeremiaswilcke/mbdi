<?php
/**
 * Liturgia E-Mail Template
 *
 * HTML-E-Mail mit Kurzübersicht des Gottesdienstes.
 * Das PDF wird als Anhang mitgesendet.
 *
 * Verfügbare Variablen:
 *  $event, $elements, $type_label, $status_info, $date_str
 *
 * @package IsidorSuite\Liturgia
 */

if (!defined('ABSPATH')) exit;
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:'Segoe UI',-apple-system,Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:20px 0;">
    <tr>
        <td align="center">
            <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">

                <!-- Header -->
                <tr>
                    <td style="background:linear-gradient(135deg,#1e3a5f 0%,#2d4a7a 100%);padding:25px 30px;color:#ffffff;">
                        <h1 style="margin:0;font-size:22px;font-weight:700;">
                            <?php echo esc_html($event['event_title']); ?>
                        </h1>
                        <p style="margin:8px 0 0;font-size:14px;opacity:0.85;">
                            <?php echo esc_html($type_label); ?> | <?php echo $date_str; ?>
                        </p>
                    </td>
                </tr>

                <!-- Inhalt -->
                <tr>
                    <td style="padding:25px 30px;">

                        <!-- Info-Box -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;margin-bottom:20px;">
                            <tr>
                                <td style="padding:15px 20px;">
                                    <table width="100%" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="font-size:13px;color:#666;padding:3px 0;">
                                                <strong>Datum:</strong>
                                            </td>
                                            <td style="font-size:13px;color:#333;padding:3px 0;">
                                                <?php echo $date_str; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="font-size:13px;color:#666;padding:3px 0;">
                                                <strong>Typ:</strong>
                                            </td>
                                            <td style="font-size:13px;color:#333;padding:3px 0;">
                                                <?php echo esc_html($type_label); ?>
                                            </td>
                                        </tr>
                                        <?php if ($event['location_default']): ?>
                                        <tr>
                                            <td style="font-size:13px;color:#666;padding:3px 0;">
                                                <strong>Ort:</strong>
                                            </td>
                                            <td style="font-size:13px;color:#333;padding:3px 0;">
                                                <?php echo esc_html($event['location_default']); ?>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td style="font-size:13px;color:#666;padding:3px 0;">
                                                <strong>Status:</strong>
                                            </td>
                                            <td style="font-size:13px;padding:3px 0;">
                                                <span style="background:<?php echo esc_attr($status_info['bg']); ?>;color:<?php echo esc_attr($status_info['color']); ?>;padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600;">
                                                    <?php echo esc_html($status_info['label']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="font-size:13px;color:#666;padding:3px 0;">
                                                <strong>Elemente:</strong>
                                            </td>
                                            <td style="font-size:13px;color:#333;padding:3px 0;">
                                                <?php echo count($elements); ?> Ablauf-Elemente
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>

                        <!-- Ablauf-Kurzübersicht -->
                        <?php if (!empty($elements)): ?>
                        <h3 style="font-size:15px;color:#1e3a5f;margin:0 0 12px;">Ablauf (Kurzübersicht)</h3>
                        <table width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;">
                            <?php
                            $element_types_map = \Isidor\Liturgia\Database::get_element_types();
                            foreach ($elements as $el):
                                $el_label = $element_types_map[$el['element_type']] ?? $el['element_type'];
                            ?>
                            <tr>
                                <td style="padding:4px 0;border-bottom:1px solid #f0f0f0;width:30px;color:#999;font-weight:600;">
                                    <?php echo $el['sort_order']; ?>.
                                </td>
                                <td style="padding:4px 8px;border-bottom:1px solid #f0f0f0;">
                                    <?php echo esc_html($el['title']); ?>
                                    <?php if ($el['hymnal_number']): ?>
                                        <span style="background:#fef3c7;color:#92400e;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:600;">
                                            <?php echo esc_html($el['hymnal_number']); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:4px 0;border-bottom:1px solid #f0f0f0;color:#888;font-size:12px;text-align:right;">
                                    <?php
                                    if (!empty($el['persons'])) {
                                        $names = array_map(function ($p) { return $p['display_name']; }, $el['persons']);
                                        echo esc_html(implode(', ', $names));
                                    } elseif (!empty($el['responsible_person'])) {
                                        echo esc_html($el['responsible_person']);
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                        <?php endif; ?>

                        <!-- Hinweis -->
                        <p style="margin:20px 0 0;font-size:13px;color:#888;font-style:italic;">
                            Der vollständige Ablauf mit allen Details liegt als PDF bei.
                        </p>

                    </td>
                </tr>

                <!-- Footer -->
                <tr>
                    <td style="background:#f8f9fa;padding:15px 30px;border-top:1px solid #eee;">
                        <p style="margin:0;font-size:11px;color:#999;text-align:center;">
                            Diese E-Mail wurde automatisch von Liturgia / Isidor Suite versendet.
                        </p>
                    </td>
                </tr>

            </table>
        </td>
    </tr>
</table>

</body>
</html>
