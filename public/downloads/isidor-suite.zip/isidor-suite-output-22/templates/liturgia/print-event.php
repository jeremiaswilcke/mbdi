<?php
/**
 * Liturgia Print Template
 *
 * Browser-Druckansicht für einen Gottesdienst-Ablauf.
 * Wird direkt als HTML ausgegeben (kein WP-Admin Chrome).
 *
 * @package IsidorSuite\Liturgia
 */

use Isidor\Liturgia\Database;
use Isidor\Liturgia\Elements;
use Isidor\Liturgia\Settings;

if (!defined('ABSPATH')) exit;

// Variablen werden vom Aufrufer bereitgestellt:
// $event, $elements, $participants, $total_duration
// $event_types, $element_types, $roles, $statuses, $settings

$type_label = $event_types[$event['event_type']] ?? $event['event_type'];
$status_info = $statuses[$event['status']] ?? $statuses['entwurf'];
$date_str = date_i18n('l, j. F Y', strtotime($event['event_date']));
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liturgia: <?php echo esc_html($event['event_title']); ?> – <?php echo $date_str; ?></title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', -apple-system, Arial, sans-serif;
            font-size: 12pt;
            line-height: 1.5;
            color: #333;
            padding: 30px;
            max-width: 800px;
            margin: 0 auto;
        }

        .print-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #1e3a5f;
        }
        .print-header-logo img { max-height: 60px; }
        .print-title { font-size: 22pt; font-weight: 700; color: #1e3a5f; margin-bottom: 4px; }
        .print-meta { font-size: 11pt; color: #555; }
        .print-meta span { margin-right: 15px; }
        .print-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 10px;
            font-size: 10pt;
            font-weight: 600;
        }

        .print-notes {
            margin: 15px 0;
            padding: 12px;
            background: #f8f9fa;
            border-left: 3px solid #1e3a5f;
            font-size: 11pt;
        }
        .print-notes h3 { font-size: 12pt; margin-bottom: 6px; }

        .print-section-title {
            font-size: 14pt;
            font-weight: 700;
            margin: 20px 0 12px;
            color: #1e3a5f;
        }

        .print-element {
            margin-bottom: 14px;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
            page-break-inside: avoid;
        }
        .print-element:last-child { border-bottom: none; }

        .print-element-header {
            display: flex;
            align-items: baseline;
            gap: 8px;
            margin-bottom: 4px;
        }
        .print-element-num {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 22px;
            height: 22px;
            background: #1e3a5f;
            color: #fff;
            border-radius: 50%;
            font-size: 10pt;
            font-weight: 700;
            flex-shrink: 0;
        }
        .print-element-type {
            font-size: 9pt;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #888;
            font-weight: 600;
        }
        .print-element-title {
            font-weight: 700;
            font-size: 12pt;
        }
        .print-element-meta {
            font-size: 10pt;
            color: #666;
            margin-left: 30px;
        }
        .print-element-meta span { margin-right: 12px; }
        .print-element-desc {
            margin: 6px 0 0 30px;
            font-size: 11pt;
            color: #444;
        }
        .print-element-reading {
            margin: 6px 0 0 30px;
            padding: 8px 12px;
            background: #fafafa;
            border-left: 3px solid #d4a017;
            font-size: 11pt;
        }
        .print-element-reading strong { display: block; margin-bottom: 4px; }
        .print-hymnal {
            background: #fef3c7;
            color: #92400e;
            padding: 1px 6px;
            border-radius: 3px;
            font-weight: 600;
            font-size: 10pt;
        }

        .print-participants {
            margin-top: 25px;
            padding-top: 15px;
            border-top: 2px solid #1e3a5f;
        }
        .print-participants h3 { font-size: 13pt; margin-bottom: 10px; color: #1e3a5f; }
        .print-participants table { width: 100%; border-collapse: collapse; }
        .print-participants td { padding: 4px 8px; font-size: 11pt; border-bottom: 1px solid #eee; }
        .print-participants td:first-child { font-weight: 600; width: 150px; }

        .print-footer {
            margin-top: 30px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
            font-size: 9pt;
            color: #999;
            text-align: center;
        }

        @media print {
            body { padding: 0; font-size: 11pt; }
            .no-print { display: none !important; }
        }

        .no-print {
            position: fixed;
            top: 10px;
            right: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>

<div class="no-print">
    <button onclick="window.print()" style="padding:8px 20px;font-size:14px;cursor:pointer;background:#1e3a5f;color:#fff;border:none;border-radius:4px;">🖨️ Drucken</button>
    <button onclick="window.close()" style="padding:8px 20px;font-size:14px;cursor:pointer;background:#fff;color:#333;border:1px solid #ddd;border-radius:4px;margin-left:6px;">Schließen</button>
</div>

<!-- Header -->
<div class="print-header">
    <div>
        <?php
        $logo_id = $settings['logo_attachment_id'] ?? 0;
        if ($logo_id):
            $logo_url = wp_get_attachment_image_url($logo_id, 'medium');
            if ($logo_url):
        ?>
            <div class="print-header-logo">
                <img src="<?php echo esc_url($logo_url); ?>" alt="Logo">
            </div>
        <?php endif; endif; ?>

        <div class="print-title"><?php echo esc_html($event['event_title']); ?></div>
        <div class="print-meta">
            <span><?php echo esc_html($type_label); ?></span>
            <span><?php echo $date_str; ?></span>
            <?php if ($event['location_default']): ?>
                <span>📍 <?php echo esc_html($event['location_default']); ?></span>
            <?php endif; ?>
            <?php if ($total_duration > 0): ?>
                <span>⏱️ ca. <?php echo $total_duration; ?> Min.</span>
            <?php endif; ?>
        </div>
    </div>
    <div>
        <span class="print-badge" style="background:<?php echo esc_attr($status_info['bg']); ?>;color:<?php echo esc_attr($status_info['color']); ?>">
            <?php echo esc_html($status_info['label']); ?>
        </span>
    </div>
</div>

<!-- Anmerkungen -->
<?php if (!empty($event['notes'])): ?>
    <div class="print-notes">
        <h3>Anmerkungen</h3>
        <?php echo wp_kses_post($event['notes']); ?>
    </div>
<?php endif; ?>

<!-- Ablauf -->
<div class="print-section-title">Ablauf</div>

<?php foreach ($elements as $el):
    $el_type_label = $element_types[$el['element_type']] ?? $el['element_type'];
    $role_label = $roles[$el['responsible_role']] ?? $el['responsible_role'];
?>
    <div class="print-element">
        <div class="print-element-header">
            <span class="print-element-num"><?php echo $el['sort_order']; ?></span>
            <span class="print-element-type"><?php echo esc_html($el_type_label); ?></span>
            <span class="print-element-title"><?php echo esc_html($el['title']); ?></span>
            <?php if ($el['hymnal_number']): ?>
                <span class="print-hymnal"><?php echo esc_html($el['hymnal_number']); ?></span>
            <?php endif; ?>
        </div>
        <div class="print-element-meta">
            <?php if (!empty($el['persons'])): ?>
                <?php
                $person_names = array_map(function ($p) { return $p['display_name']; }, $el['persons']);
                ?>
                <span><strong><?php echo esc_html(implode(', ', $person_names)); ?></strong></span>
            <?php elseif ($el['responsible_person']): ?>
                <span><strong><?php echo esc_html($el['responsible_person']); ?></strong></span>
            <?php else: ?>
                <span><?php echo esc_html($role_label); ?></span>
            <?php endif; ?>
            <?php if ($el['location']): ?>
                <span>📍 <?php echo esc_html($el['location']); ?></span>
            <?php endif; ?>
            <?php if ($el['duration_minutes']): ?>
                <span>⏱️ <?php echo $el['duration_minutes']; ?> Min.</span>
            <?php endif; ?>
        </div>

        <?php if (!empty($el['description'])): ?>
            <div class="print-element-desc"><?php echo wp_kses_post($el['description']); ?></div>
        <?php endif; ?>

        <?php if (!empty($el['reading_reference']) || !empty($el['reading_text'])): ?>
            <div class="print-element-reading">
                <?php if ($el['reading_reference']): ?>
                    <strong><?php echo esc_html($el['reading_reference']); ?></strong>
                <?php endif; ?>
                <?php if ($el['reading_text']): ?>
                    <?php echo wp_kses_post($el['reading_text']); ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($el['media_notes'])): ?>
            <div class="print-element-desc" style="color:#888;font-size:10pt;">
                🎥 <?php echo wp_kses_post($el['media_notes']); ?>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; ?>

<!-- Beteiligte -->
<?php if (!empty($participants)): ?>
    <div class="print-participants">
        <h3>Beteiligte Personen</h3>
        <table>
            <?php foreach ($participants as $role => $persons): ?>
                <tr>
                    <td><?php echo esc_html($role); ?></td>
                    <td><?php
                        $names = array_map(function ($p) { return $p['display_name']; }, $persons);
                        echo esc_html(implode(', ', $names));
                    ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
<?php endif; ?>

<!-- Footer -->
<div class="print-footer">
    <?php if (!empty($settings['pdf_footer'])): ?>
        <?php echo esc_html($settings['pdf_footer']); ?> |
    <?php endif; ?>
    Erstellt am <?php echo date_i18n('d.m.Y H:i'); ?> mit Liturgia / Isidor Suite
</div>

</body>
</html>
