<?php
/**
 * Dashboard Template
 */
if (!defined('ABSPATH')) exit;

$user_id = get_current_user_id();
$today = date('Y-m-d');
$end = date('Y-m-d', strtotime('+3 weeks'));

// Meine Dienste
$my_assignments = Liturgus_Assignments::get_for_user($user_id, $today, $end);

// Freie Dienste MIT NAMEN (gefiltert nach User-Diensten)
$vacant = Liturgus_Assignments::get_vacant_with_assignments($today, $end, $user_id);

// Offene Tauschanfragen an mich
global $wpdb;
$pending_swaps = $wpdb->get_results($wpdb->prepare(
    "SELECT s.*, 
            a.messe_id, a.slot_key, a.position,
            m.post_title as messe_title,
            pm1.meta_value as messe_date,
            pm2.meta_value as messe_time,
            u.display_name as from_user_name
     FROM {$wpdb->prefix}liturgus_swaps s
     JOIN {$wpdb->prefix}liturgus_assignments a ON s.from_assignment_id = a.id
     JOIN {$wpdb->posts} m ON a.messe_id = m.ID
     JOIN {$wpdb->postmeta} pm1 ON m.ID = pm1.post_id AND pm1.meta_key = '_is_date'
     JOIN {$wpdb->postmeta} pm2 ON m.ID = pm2.post_id AND pm2.meta_key = '_is_time'
     JOIN {$wpdb->users} u ON s.from_user_id = u.ID
     WHERE s.to_user_id = %d AND s.status = 'pending'
     ORDER BY pm1.meta_value ASC",
    $user_id
), ARRAY_A);
?>

<div class="liturgus-dashboard">
    
    <?php if (!empty($pending_swaps)): ?>
    <!-- TAUSCHANFRAGEN -->
    <div class="liturgus-section liturgus-swap-alert">
        <h2 style="margin-top:0;">
            🔔 <?php echo count($pending_swaps); ?> Tauschanfrage<?php echo count($pending_swaps) > 1 ? 'n' : ''; ?> an dich
        </h2>
        
        <?php foreach ($pending_swaps as $swap): 
            $slot = Liturgus_Slots::get($swap['slot_key']);
        ?>
        <div class="liturgus-swap-card">
            <div class="liturgus-swap-card__info">
                <strong><?php echo esc_html($swap['from_user_name']); ?></strong>
                <span>
                    <?php echo esc_html($slot['label']); ?> am 
                    <strong><?php echo date_i18n('D, d.m.Y', strtotime($swap['messe_date'])); ?></strong> 
                    um <?php echo esc_html($swap['messe_time']); ?> Uhr
                    (<?php echo esc_html($swap['messe_title']); ?>)
                </span>
                <?php if ($swap['message']): ?>
                    <em>"<?php echo esc_html($swap['message']); ?>"</em>
                <?php endif; ?>
            </div>
            <div class="liturgus-swap-card__actions">
                <button onclick="liturgusAcceptSwap(<?php echo $swap['id']; ?>)" class="liturgus-btn">✓ Annehmen</button>
                <button onclick="liturgusRejectSwap(<?php echo $swap['id']; ?>)" class="liturgus-btn liturgus-btn-danger">✗ Ablehnen</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    
    <!-- Meine Dienste (OBEN) -->
    <div class="liturgus-section">
        <div class="liturgus-section-header">
            <h2>Meine Dienste</h2>
            <?php if (!empty($my_assignments)): ?>
                <a href="<?php echo add_query_arg(['liturgus_export' => 'ical']); ?>" class="liturgus-btn liturgus-btn-sm">📅 iCal Export</a>
            <?php endif; ?>
        </div>
        
        <?php if (empty($my_assignments)): ?>
            <p>Keine Dienste im gewählten Zeitraum.</p>
        <?php else: ?>
            <table class="liturgus-table">
                <thead>
                    <tr>
                        <th>Datum</th>
                        <th>Zeit</th>
                        <th>Messe</th>
                        <th>Dienst</th>
                        <th>Pos.</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($my_assignments as $a): 
                        $slot = Liturgus_Slots::get($a['slot_key']);
                    ?>
                        <tr>
                            <td data-label="Datum"><?php echo date('d.m.Y', strtotime($a['messe_date'])); ?></td>
                            <td data-label="Zeit"><?php echo $a['messe_time']; ?></td>
                            <td data-label="Messe"><?php echo esc_html($a['messe_title']); ?></td>
                            <td data-label="Dienst">
                                <?php echo esc_html($slot['label']); ?>
                                <?php if ($a['is_backup']): ?>
                                    <span class="liturgus-badge liturgus-badge-backup">Backup</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Pos."><?php echo $a['position']; ?></td>
                            <td data-label="">
                                <div class="liturgus-actions">
                                    <button onclick="liturgusOpenSwap(<?php echo $a['id']; ?>, '<?php echo esc_js($slot['label']); ?>', '<?php echo date('D d.m.Y', strtotime($a['messe_date'])); ?> <?php echo $a['messe_time']; ?>', '<?php echo esc_js($a['messe_title']); ?>')" class="liturgus-btn">↔️ Tauschen</button>
                                    <button onclick="liturgusCancel(<?php echo $a['id']; ?>)" class="liturgus-btn liturgus-btn-danger">Austragen</button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Freie Dienste (UNTEN) -->
    <div class="liturgus-section">
        <h2>Freie Dienste (nächste 3 Wochen)</h2>
        
        <?php if (empty($vacant)): ?>
            <p>Keine freien Dienste</p>
        <?php else: ?>
            <div class="liturgus-grid">
                <?php 
                $grouped = [];
                foreach ($vacant as $v) {
                    $grouped[$v['messe_id']]['info'] = [
                        'title' => $v['messe_title'],
                        'date' => $v['messe_date'],
                        'time' => $v['messe_time']
                    ];
                    $grouped[$v['messe_id']]['slots'][] = $v;
                }
                
                foreach ($grouped as $messe_id => $data): 
                ?>
                    <div class="liturgus-card">
                        <div class="liturgus-card-header">
                            <strong><?php echo date('D d.m', strtotime($data['info']['date'])); ?></strong>
                            <span><?php echo $data['info']['time']; ?></span>
                            <?php if (current_user_can('liturgus_manage') || current_user_can('manage_options')): ?>
                                <button type="button" class="liturgus-slot-config-btn" onclick="liturgusOpenSlotConfig(<?php echo $messe_id; ?>, '<?php echo esc_js($data['info']['title']); ?>')" title="Dienste konfigurieren"><span style="pointer-events:none;">&#9881;</span></button>
                            <?php endif; ?>
                        </div>
                        <div class="liturgus-card-body">
                            <?php foreach ($data['slots'] as $slot): 
                                // Skip slots with 0 positions AND 0 backups (effectively disabled)
                                if ($slot['total_main'] <= 0 && $slot['total_backup'] <= 0 && empty($slot['assigned_main']) && empty($slot['assigned_backup'])) continue;
                                $filled = count($slot['assigned_main']);
                                $total = $slot['total_main'];
                                $filled_bkp = count($slot['assigned_backup']);
                                $total_bkp = $slot['total_backup'];
                            ?>
                                <div class="liturgus-slot">
                                    <div class="liturgus-slot-info">
                                        <div style="display:flex;align-items:center;gap:6px;">
                                            <strong><?php echo esc_html($slot['slot_label']); ?></strong>
                                            <?php if (($slot['source'] ?? 'global') === 'messe'): ?>
                                                <small style="color:#16a34a;font-size:0.75em;" title="Angepasst für diese Messe">●</small>
                                            <?php endif; ?>
                                            <?php if ($total > 1 || ($slot['source'] ?? 'global') === 'messe'): ?>
                                                <small style="color:<?php echo $filled >= $total ? '#16a34a' : '#f59e0b'; ?>;font-size:0.8em;font-weight:500;"><?php echo $filled; ?>/<?php echo $total; ?></small>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if (!empty($slot['assigned_main'])): ?>
                                            <div class="liturgus-names">
                                                <?php foreach ($slot['assigned_main'] as $name): ?>
                                                    <span class="liturgus-name"><?php echo esc_html($name); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php // Show empty position placeholders
                                        if ($slot['vacant_main'] > 0): ?>
                                            <div class="liturgus-names">
                                                <?php for ($i = 0; $i < $slot['vacant_main']; $i++): ?>
                                                    <span class="liturgus-name" style="color:#d1d5db;border:1px dashed #d1d5db;background:transparent;">offen</span>
                                                <?php endfor; ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if (!empty($slot['assigned_backup'])): ?>
                                            <div class="liturgus-names liturgus-names-backup">
                                                <?php foreach ($slot['assigned_backup'] as $name): ?>
                                                    <span class="liturgus-name liturgus-name-backup">🔄 <?php echo esc_html($name); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="liturgus-actions">
                                        <?php if ($slot['vacant_main'] > 0): ?>
                                            <button onclick="liturgusSignup(<?php echo $messe_id; ?>, '<?php echo esc_js($slot['slot_key']); ?>', false)" class="liturgus-btn liturgus-btn-sm" title="<?php echo $slot['vacant_main']; ?> freie Position(en)">✓</button>
                                        <?php endif; ?>
                                        <?php if ($slot['vacant_backup'] > 0): ?>
                                            <button onclick="liturgusSignup(<?php echo $messe_id; ?>, '<?php echo esc_js($slot['slot_key']); ?>', true)" class="liturgus-btn liturgus-btn-sm liturgus-btn-backup" title="<?php echo $slot['vacant_backup']; ?> freie Backup-Position(en)">B</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
</div>

<!-- Tausch-Modal -->
<div id="liturgus-swap-modal" class="liturgus-modal" style="display:none;">
    <div class="liturgus-modal-content">
        <div class="liturgus-modal-header">
            <h3>Dienst tauschen</h3>
            <span class="liturgus-modal-close" onclick="liturgusCloseSwap()">&times;</span>
        </div>
        <div class="liturgus-modal-body">
            <div class="liturgus-hint" style="background:#f3f4f6;color:#374151;">
                <strong>Dein Dienst:</strong>
                <p id="liturgus-swap-my-service" style="margin:5px 0 0;"></p>
            </div>
            
            <label>
                <strong>Tauschen mit welchem Dienst?</strong>
                <select id="liturgus-swap-target" class="liturgus-input" style="font-size: 14px;">
                    <option value="">Dienst auswählen...</option>
                    <?php
                    // Alle Dienste anderer User im Zeitraum
                    global $wpdb;
                    $all_assignments = $wpdb->get_results($wpdb->prepare(
                        "SELECT a.id, a.slot_key, a.is_backup, a.user_id, 
                                p.post_title as messe_title, 
                                pm1.meta_value as messe_date, 
                                pm2.meta_value as messe_time,
                                u.display_name as user_name
                        FROM {$wpdb->prefix}liturgus_assignments a
                        JOIN {$wpdb->posts} p ON a.messe_id = p.ID
                        LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_is_date'
                        LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_is_time'
                        JOIN {$wpdb->users} u ON a.user_id = u.ID
                        WHERE a.status = 'assigned' 
                        AND a.user_id != %d
                        AND pm1.meta_value BETWEEN %s AND %s
                        ORDER BY pm1.meta_value, pm2.meta_value",
                        $user_id, $today, $end
                    ), ARRAY_A);
                    
                    foreach ($all_assignments as $assign) {
                        $slot = Liturgus_Slots::get($assign['slot_key']);
                        $date_str = date('D d.m.Y', strtotime($assign['messe_date']));
                        $backup_str = $assign['is_backup'] ? ' (Ersatz)' : '';
                        
                        echo '<option value="' . $assign['id'] . '">';
                        echo esc_html($assign['user_name']) . ': ';
                        echo esc_html($slot['label']) . $backup_str . ' | ';
                        echo $date_str . ' ' . esc_html($assign['messe_time']) . ' | ';
                        echo esc_html($assign['messe_title']);
                        echo '</option>';
                    }
                    ?>
                </select>
            </label>
            
            <div class="liturgus-hint">
                ℹ️ <strong>Hinweis:</strong> Beide Dienste werden getauscht. Du übernimmst deren Dienst, sie übernehmen deinen.
            </div>
            
            <label style="margin-top: 15px;">
                <strong>Nachricht (optional):</strong>
                <textarea id="liturgus-swap-message" class="liturgus-input" rows="3" placeholder="z.B. Ich kann an diesem Tag leider nicht..."></textarea>
            </label>
            
            <input type="hidden" id="liturgus-swap-my-assignment-id">
        </div>
        <div class="liturgus-modal-footer">
            <button onclick="liturgusCloseSwap()" class="liturgus-btn liturgus-btn-secondary">Abbrechen</button>
            <button onclick="liturgusSubmitSwap()" class="liturgus-btn">Tausch-Anfrage senden</button>
        </div>
    </div>

    <!-- SLOT CONFIG MODAL -->
    <?php if (current_user_can('liturgus_manage') || current_user_can('manage_options')): ?>
    <div id="liturgus-slot-config-overlay" class="liturgus-modal" style="display:none;position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;background:rgba(0,0,0,0.5)!important;z-index:999999!important;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
        <div class="liturgus-modal-content" style="max-width:500px;background:white;border-radius:14px;width:100%;max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,0.2);">
            <div class="liturgus-modal-header" style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                <h3 style="margin:0;font-size:1.1em;">&#9881; Dienste konfigurieren</h3>
                <button type="button" onclick="liturgusCloseSlotConfig()" style="background:none;border:none;font-size:1.5em;cursor:pointer;color:#9ca3af;padding:0 4px;">&times;</button>
            </div>
            <div class="liturgus-modal-body" style="padding:16px 20px;">
                <p style="color:#6b7280;font-size:0.9em;" id="liturgus-slot-config-title"></p>
                <div id="liturgus-slot-config-list"></div>
            </div>
            <div class="liturgus-modal-footer" style="padding:12px 20px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;">
                <button type="button" onclick="liturgusResetSlotConfig()" class="liturgus-btn liturgus-btn-secondary">↩️ Standard</button>
                <button type="button" onclick="liturgusSaveSlotConfig()" class="liturgus-btn">💾 Speichern</button>
            </div>
        </div>
    </div>
    <script>
    /* Move modal to body so it's not trapped in overflow:hidden containers */
    (function(){
        var el = document.getElementById('liturgus-slot-config-overlay');
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
    })();

    /* Inline fallback for slot config — in case liturgus.js doesn't define these */
    if (typeof liturgusOpenSlotConfig === 'undefined') {
        var _slotConfigMesseId = null;
        function liturgusOpenSlotConfig(messeId, messeTitle) {
            if (typeof liturgusData === 'undefined') { alert('JS-Fehler: liturgusData nicht geladen. Bitte Seite neu laden.'); return; }
            _slotConfigMesseId = messeId;
            var overlay = document.getElementById('liturgus-slot-config-overlay');
            // Ensure it's in body
            if (overlay.parentNode !== document.body) document.body.appendChild(overlay);
            document.getElementById('liturgus-slot-config-title').textContent = messeTitle;
            overlay.style.display = 'flex';
            var list = document.getElementById('liturgus-slot-config-list');
            list.innerHTML = '<p style="color:#9ca3af;text-align:center;">Lade…</p>';
            var fd = new FormData();
            fd.append('action', 'liturgus_get_messe_slots');
            fd.append('nonce', liturgusData.nonce);
            fd.append('messe_id', messeId);
            fetch(liturgusData.ajaxUrl, {method:'POST', body:fd})
                .then(function(r){return r.json();})
                .then(function(resp){
                    if(!resp.success){list.innerHTML='<p>Fehler: '+(resp.data&&resp.data.message?resp.data.message:'Unbekannt')+'</p>';return;}
                    var data=resp.data, global=data.global||[], messeOverrides={};
                    (data.messe||[]).forEach(function(m){messeOverrides[m.slot_key]=m;});
                    var h='';
                    global.forEach(function(g){
                        var mo=messeOverrides[g.slot_key];
                        var pos=mo?parseInt(mo.positions):parseInt(g.positions);
                        var bpos=mo?parseInt(mo.backup_positions):parseInt(g.backup_positions);
                        var disabled=mo?parseInt(mo.is_disabled):0;
                        var badge=mo?' <small style="color:#16a34a;">(angepasst)</small>':'';
                        h+='<div class="liturgus-slotcfg-row" data-key="'+g.slot_key+'" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f3f4f6;">';
                        h+='<label style="flex:0 0 auto;"><input type="checkbox" class="lsc-enable" '+(disabled?'':'checked')+' style="width:18px;height:18px;accent-color:#16a34a;"></label>';
                        h+='<div class="liturgus-slotcfg-label" style="flex:1;font-weight:500;'+(disabled?'opacity:0.35;text-decoration:line-through;':'')+'">'+g.label+badge+'</div>';
                        h+='<div style="display:flex;gap:8px;">';
                        h+='<label style="font-size:0.8em;color:#6b7280;display:flex;align-items:center;gap:4px;"><input type="number" class="lsc-pos" value="'+pos+'" min="0" max="20" style="width:55px;text-align:center;padding:4px;border:1px solid #d1d5db;border-radius:6px;"> Pos</label>';
                        h+='<label style="font-size:0.8em;color:#6b7280;display:flex;align-items:center;gap:4px;"><input type="number" class="lsc-bpos" value="'+bpos+'" min="0" max="10" style="width:55px;text-align:center;padding:4px;border:1px solid #d1d5db;border-radius:6px;"> Bkp</label>';
                        h+='</div></div>';
                    });
                    list.innerHTML=h;
                    list.querySelectorAll('.lsc-enable').forEach(function(cb){
                        cb.addEventListener('change',function(){
                            var lbl=this.closest('.liturgus-slotcfg-row').querySelector('.liturgus-slotcfg-label');
                            if(this.checked){lbl.style.opacity='1';lbl.style.textDecoration='none';}
                            else{lbl.style.opacity='0.35';lbl.style.textDecoration='line-through';}
                        });
                    });
                });
        }
        function liturgusSaveSlotConfig(){
            var rows=document.querySelectorAll('.liturgus-slotcfg-row'), slots=[];
            rows.forEach(function(row,i){
                slots.push({slot_key:row.dataset.key,positions:parseInt(row.querySelector('.lsc-pos').value)||0,backup_positions:parseInt(row.querySelector('.lsc-bpos').value)||0,is_disabled:row.querySelector('.lsc-enable').checked?0:1,sort_order:i});
            });
            var fd=new FormData();
            fd.append('action','liturgus_save_messe_slots');
            fd.append('nonce',liturgusData.nonce);
            fd.append('messe_id',_slotConfigMesseId);
            fd.append('slots',JSON.stringify(slots));
            fetch(liturgusData.ajaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(resp){
                if(resp.success){liturgusCloseSlotConfig();location.reload();}else{alert(resp.data&&resp.data.message||'Fehler');}
            });
        }
        function liturgusResetSlotConfig(){
            if(!confirm('Auf Standard zurücksetzen?'))return;
            var fd=new FormData();
            fd.append('action','liturgus_save_messe_slots');
            fd.append('nonce',liturgusData.nonce);
            fd.append('messe_id',_slotConfigMesseId);
            fd.append('reset','1');
            fetch(liturgusData.ajaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(resp){
                if(resp.success){liturgusCloseSlotConfig();location.reload();}
            });
        }
        function liturgusCloseSlotConfig(){
            var o=document.getElementById('liturgus-slot-config-overlay');
            if(o)o.style.display='none';
        }
    }
    </script>
    <?php endif; ?>
</div>
