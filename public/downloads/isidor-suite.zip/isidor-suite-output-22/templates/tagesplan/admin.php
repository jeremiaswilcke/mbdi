<?php
/**
 * Template: Tagesplan Admin-Seite
 */

if (!defined('ABSPATH')) exit;

$tagesplan = Isidor_Tagesplan::get_instance();
?>

<div class="wrap">
    <h1>📋 Tagesplan</h1>
    
    <!-- Datum-Auswahl -->
    <div class="isidor-card" style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin:20px 0;">
        <form method="get" style="display:flex; align-items:center; gap:15px;">
            <input type="hidden" name="page" value="isidor-tagesplan">
            
            <label for="date-select"><strong>Datum:</strong></label>
            <input type="date" 
                   name="date" 
                   id="date-select" 
                   value="<?php echo esc_attr($selected_date); ?>"
                   class="regular-text">
            
            <button type="submit" class="button button-primary">Anzeigen</button>
            
            <a href="<?php echo esc_url(add_query_arg('date', date('Y-m-d'))); ?>" class="button">Heute</a>
            <a href="<?php echo esc_url(add_query_arg('date', date('Y-m-d', strtotime('+1 day')))); ?>" class="button">Morgen</a>
            <a href="<?php echo esc_url(add_query_arg('date', date('Y-m-d', strtotime('next sunday')))); ?>" class="button">Nächster Sonntag</a>
        </form>
    </div>
    
    <!-- Messen für das Datum -->
    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
        
        <!-- Linke Spalte: Tagesplan -->
        <div>
            <?php if (empty($messen)): ?>
                <div class="isidor-card" style="background:#fff; padding:40px; border-radius:8px; text-align:center;">
                    <span style="font-size:4rem; opacity:0.3;">⛪</span>
                    <h2>Keine Messen für <?php echo esc_html(wp_date('l, j. F Y', strtotime($selected_date))); ?></h2>
                    <p>Es wurden keine Gottesdienste für dieses Datum gefunden.</p>
                    <a href="<?php echo admin_url('post-new.php?post_type=isidor_messe'); ?>" class="button button-primary">
                        + Neue Messe anlegen
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($messen as $index => $messe_id): ?>
                    <div class="isidor-card" style="background:#fff; padding:0; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1); margin-bottom:20px; overflow:hidden;">
                        
                        <!-- Messe-Header -->
                        <div style="background:linear-gradient(135deg, #1a365d 0%, #2d4a7c 100%); color:#fff; padding:15px 20px;">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <div>
                                    <strong style="font-size:1.5rem;">
                                        <?php echo esc_html(get_post_meta($messe_id, 'messe_time', true)); ?> Uhr
                                    </strong>
                                    <span style="margin-left:15px; opacity:0.8;">
                                        <?php echo esc_html(get_the_title($messe_id)); ?>
                                    </span>
                                </div>
                                <div style="display:flex; gap:8px;">
                                    <a href="<?php echo get_edit_post_link($messe_id); ?>" class="button button-small">Bearbeiten</a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tagesplan-Inhalt -->
                        <div style="padding:20px;">
                            <?php echo $tagesplan->render_tagesplan($messe_id); ?>
                        </div>
                        
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Rechte Spalte: Aktionen & Info -->
        <div>
            <!-- Export-Box -->
            <div class="isidor-card" style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                <h3 style="margin-top:0;">📤 Export</h3>
                
                <?php if (!empty($messen)): ?>
                    <p>Alle Messen für <?php echo esc_html(wp_date('d.m.Y', strtotime($selected_date))); ?>:</p>
                    
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        <?php foreach ($messen as $messe_id): ?>
                            <div style="padding:10px; background:#f7fafc; border-radius:6px;">
                                <strong><?php echo esc_html(get_post_meta($messe_id, 'messe_time', true)); ?> Uhr</strong>
                                <div style="margin-top:8px; display:flex; gap:6px; flex-wrap:wrap;">
                                    <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'pdf', 'messe_id' => $messe_id], home_url())); ?>" 
                                       class="button button-small" target="_blank">📄 PDF</a>
                                    <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'html', 'messe_id' => $messe_id], home_url())); ?>" 
                                       class="button button-small" target="_blank">🖨️ Drucken</a>
                                    <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'json', 'messe_id' => $messe_id], home_url())); ?>" 
                                       class="button button-small" target="_blank">📊 JSON</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p style="opacity:0.6;">Keine Messen zum Exportieren.</p>
                <?php endif; ?>
            </div>
            
            <!-- Display-Link -->
            <div class="isidor-card" style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px;">
                <h3 style="margin-top:0;">🖥️ Digital Display</h3>
                <p>Für Sakristei, Orgelempore oder Schaukasten:</p>
                
                <div style="background:#f0f4f8; padding:15px; border-radius:6px; margin:15px 0;">
                    <code style="word-break:break-all;">[isidor_tagesplan_display]</code>
                </div>
                
                <p style="font-size:0.9em; opacity:0.7;">
                    Dieser Shortcode zeigt eine automatisch aktualisierende Vollbild-Ansicht.
                    Ideal für Monitore im Pfarrzentrum.
                </p>
                
                <h4>Tastaturkürzel:</h4>
                <ul style="font-size:0.9em;">
                    <li><kbd>F</kbd> – Vollbild</li>
                    <li><kbd>R</kbd> – Aktualisieren</li>
                    <li><kbd>←</kbd> / <kbd>→</kbd> – Messen wechseln</li>
                </ul>
            </div>
            
            <!-- Template-Link -->
            <div class="isidor-card" style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top:0;">⚙️ Template anpassen</h3>
                <p>Passen Sie an, welche Informationen im Tagesplan angezeigt werden.</p>
                <a href="<?php echo admin_url('admin.php?page=isidor-tagesplan-template'); ?>" class="button">
                    Template bearbeiten →
                </a>
            </div>
            
            <!-- Shortcode-Referenz -->
            <div class="isidor-card" style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-top:20px;">
                <h3 style="margin-top:0;">📚 Shortcodes</h3>
                
                <table class="widefat" style="margin-top:10px;">
                    <tr>
                        <td><code>[isidor_tagesplan_heute]</code></td>
                        <td>Nächste Messe</td>
                    </tr>
                    <tr>
                        <td><code>[isidor_tagesplan messe_id="123"]</code></td>
                        <td>Bestimmte Messe</td>
                    </tr>
                    <tr>
                        <td><code>[isidor_tagesplan date="2026-02-01"]</code></td>
                        <td>Messen an Datum</td>
                    </tr>
                    <tr>
                        <td><code>[isidor_tagesplan_display]</code></td>
                        <td>Vollbild-Display</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.isidor-tagesplan {
    font-size: 14px;
}
.isidor-tagesplan .tagesplan-header {
    background: linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
    padding: 20px;
    border-radius: 8px;
    text-align: center;
    margin-bottom: 20px;
}
.isidor-tagesplan .tagesplan-parish {
    font-size: 1.3rem;
    margin: 0;
    color: #1a365d;
}
.isidor-tagesplan .tagesplan-date {
    margin: 5px 0 0;
    color: #4a5568;
}
.isidor-tagesplan .tagesplan-liturgical {
    font-style: italic;
    color: #718096;
    margin-top: 5px;
}
.isidor-tagesplan .tagesplan-section {
    margin-bottom: 20px;
}
.isidor-tagesplan .tagesplan-section h2 {
    font-size: 1rem;
    color: #1a365d;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 8px;
    margin: 0 0 15px;
}
.isidor-tagesplan .tagesplan-table {
    width: 100%;
    border-collapse: collapse;
}
.isidor-tagesplan .tagesplan-table th {
    text-align: left;
    padding: 6px 10px 6px 0;
    font-weight: 500;
    color: #718096;
    width: 120px;
    vertical-align: top;
}
.isidor-tagesplan .tagesplan-table td {
    padding: 6px 0;
}
.isidor-tagesplan .tagesplan-messe-info {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    background: #f7fafc;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
}
.isidor-tagesplan .tagesplan-time-box {
    background: linear-gradient(135deg, #1a365d 0%, #2d4a7c 100%);
    color: #fff;
    padding: 15px 20px;
    border-radius: 8px;
    text-align: center;
    flex-shrink: 0;
}
.isidor-tagesplan .tagesplan-time {
    font-size: 1.8rem;
    font-weight: 700;
    display: block;
}
.isidor-tagesplan .tagesplan-time-label {
    font-size: 0.85rem;
    opacity: 0.8;
}
.isidor-tagesplan .tagesplan-columns {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}
.isidor-tagesplan .lied-number {
    background: #e2e8f0;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 0.9em;
}
.isidor-tagesplan .tagesplan-actions {
    margin-top: 20px;
    padding-top: 15px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    gap: 10px;
}
.isidor-tagesplan .isidor-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.2s;
}
.isidor-tagesplan .isidor-btn-primary {
    background: #1a365d;
    color: #fff;
}
.isidor-tagesplan .isidor-btn-secondary {
    background: #e2e8f0;
    color: #1a365d;
}
.isidor-tagesplan .isidor-btn-ghost {
    background: transparent;
    color: #4a5568;
    border: 1px solid #e2e8f0;
}
kbd {
    background: #f1f1f1;
    border: 1px solid #ccc;
    border-radius: 3px;
    padding: 2px 6px;
    font-family: monospace;
}
</style>
