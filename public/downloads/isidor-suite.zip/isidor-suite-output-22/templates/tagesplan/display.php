<?php
/**
 * Template: Digitale Display-Ansicht
 * 
 * Für Monitore in Sakristei, Orgelempore, etc.
 * Auto-Refresh, Fullscreen-fähig
 * 
 * Variablen:
 * - $messen: Array mit Messe-IDs
 * - $date: Datum
 * - $atts: Shortcode-Attribute
 */

if (!defined('ABSPATH')) exit;

$tagesplan = Isidor_Tagesplan::get_instance();
$template = $tagesplan->get_template();
$parish_name = get_option('isidor_tagesplan_parish_name', get_bloginfo('name'));
$auto_refresh = $atts['auto_refresh'] !== 'false';
$fullscreen = $atts['fullscreen'] !== 'false';
?>

<div id="isidor-tagesplan-display" 
     class="isidor-tagesplan-display <?php echo $fullscreen ? 'fullscreen-ready' : ''; ?>"
     data-date="<?php echo esc_attr($date); ?>"
     data-auto-refresh="<?php echo $auto_refresh ? 'true' : 'false'; ?>">
    
    <!-- Header Bar -->
    <div class="display-header">
        <div class="display-header-left">
            <h1 class="display-parish"><?php echo esc_html($parish_name); ?></h1>
            <p class="display-date" id="display-current-date">
                <?php echo esc_html(wp_date('l, j. F Y')); ?>
            </p>
        </div>
        
        <div class="display-header-right">
            <span class="display-clock" id="display-clock">
                <?php echo esc_html(wp_date('H:i')); ?>
            </span>
            
            <div class="display-controls no-print">
                <button type="button" class="display-btn" id="btn-refresh" title="Aktualisieren">
                    🔄
                </button>
                <button type="button" class="display-btn" id="btn-fullscreen" title="Vollbild">
                    ⛶
                </button>
                <button type="button" class="display-btn" id="btn-prev-messe" title="Vorherige Messe">
                    ◀
                </button>
                <button type="button" class="display-btn" id="btn-next-messe" title="Nächste Messe">
                    ▶
                </button>
            </div>
        </div>
    </div>
    
    <!-- Status Bar -->
    <div class="display-status">
        <span class="status-indicator" id="status-indicator">●</span>
        <span class="status-text" id="status-text">Live</span>
        <span class="status-messe" id="status-messe">
            <?php if (count($messen) > 1): ?>
                Messe 1 von <?php echo count($messen); ?>
            <?php endif; ?>
        </span>
    </div>
    
    <!-- Main Content -->
    <div class="display-content" id="display-content">
        <?php if (empty($messen)): ?>
            <div class="display-no-messe">
                <div class="no-messe-icon">⛪</div>
                <h2>Keine Messe für heute</h2>
                <p>Es sind keine Gottesdienste für <?php echo esc_html(wp_date('l, j. F Y', strtotime($date))); ?> eingetragen.</p>
            </div>
        <?php else: ?>
            <?php 
            $first_messe_id = $messen[0];
            echo $tagesplan->render_tagesplan($first_messe_id);
            ?>
        <?php endif; ?>
    </div>
    
    <!-- Navigation Dots (bei mehreren Messen) -->
    <?php if (count($messen) > 1): ?>
    <div class="display-nav-dots" id="display-nav-dots">
        <?php foreach ($messen as $index => $mid): ?>
            <button type="button" 
                    class="nav-dot <?php echo $index === 0 ? 'active' : ''; ?>" 
                    data-messe-id="<?php echo esc_attr($mid); ?>"
                    data-index="<?php echo esc_attr($index); ?>">
            </button>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    
    <!-- Hidden Data -->
    <script type="application/json" id="messen-data">
        <?php echo wp_json_encode($messen); ?>
    </script>
</div>

<style>
/* Display-spezifische Styles */
.isidor-tagesplan-display {
    min-height: 100vh;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    color: #fff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    overflow: hidden;
}

.isidor-tagesplan-display.fullscreen-ready {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 99999;
}

/* Header */
.display-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 30px;
    background: rgba(0,0,0,0.3);
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.display-parish {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    color: #fff;
}

.display-date {
    font-size: 1.1rem;
    opacity: 0.8;
    margin: 5px 0 0;
}

.display-clock {
    font-size: 3rem;
    font-weight: 300;
    font-variant-numeric: tabular-nums;
    letter-spacing: 2px;
}

.display-controls {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.display-btn {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
    width: 44px;
    height: 44px;
    border-radius: 8px;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.2s;
}

.display-btn:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.05);
}

/* Status */
.display-status {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 30px;
    background: rgba(0,0,0,0.2);
    font-size: 0.9rem;
}

.status-indicator {
    color: #48bb78;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.status-indicator.loading {
    color: #ecc94b;
}

.status-indicator.error {
    color: #fc8181;
    animation: none;
}

.status-messe {
    margin-left: auto;
    opacity: 0.7;
}

/* Content */
.display-content {
    padding: 30px;
    max-height: calc(100vh - 200px);
    overflow-y: auto;
}

/* Override Tagesplan Styles für Display */
.isidor-tagesplan-display .isidor-tagesplan {
    background: transparent;
    color: #fff;
    max-width: 1200px;
    margin: 0 auto;
}

.isidor-tagesplan-display .tagesplan-header {
    background: linear-gradient(135deg, rgba(26, 54, 93, 0.8) 0%, rgba(45, 74, 124, 0.8) 100%);
    padding: 30px;
    border-radius: 16px;
    margin-bottom: 25px;
    text-align: center;
}

.isidor-tagesplan-display .tagesplan-parish {
    font-size: 2rem;
}

.isidor-tagesplan-display .tagesplan-date {
    font-size: 1.5rem;
    opacity: 0.9;
}

.isidor-tagesplan-display .tagesplan-liturgical {
    font-size: 1.2rem;
    font-style: italic;
    opacity: 0.8;
    margin-top: 10px;
}

.isidor-tagesplan-display .tagesplan-section {
    background: rgba(255,255,255,0.05);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
}

.isidor-tagesplan-display .tagesplan-section h2 {
    color: #90cdf4;
    font-size: 1.3rem;
    margin: 0 0 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.isidor-tagesplan-display .tagesplan-table {
    width: 100%;
}

.isidor-tagesplan-display .tagesplan-table th {
    text-align: left;
    padding: 8px 15px 8px 0;
    font-weight: 500;
    opacity: 0.7;
    width: 150px;
}

.isidor-tagesplan-display .tagesplan-table td {
    padding: 8px 0;
    font-size: 1.1rem;
}

.isidor-tagesplan-display .tagesplan-time-box {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    padding: 20px 30px;
    border-radius: 12px;
    display: inline-block;
    margin-right: 20px;
}

.isidor-tagesplan-display .tagesplan-time {
    font-size: 3rem;
    font-weight: 700;
    display: block;
}

.isidor-tagesplan-display .tagesplan-time-label {
    font-size: 1rem;
    opacity: 0.8;
}

.isidor-tagesplan-display .tagesplan-columns {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.isidor-tagesplan-display .lied-number {
    background: rgba(255,255,255,0.1);
    padding: 2px 8px;
    border-radius: 4px;
    margin-right: 10px;
    font-weight: 600;
}

.isidor-tagesplan-display .tagesplan-actions {
    display: none;
}

.isidor-tagesplan-display .tagesplan-footer {
    text-align: center;
    opacity: 0.5;
    font-size: 0.85rem;
    margin-top: 20px;
}

/* No Messe State */
.display-no-messe {
    text-align: center;
    padding: 80px 20px;
}

.no-messe-icon {
    font-size: 5rem;
    margin-bottom: 20px;
    opacity: 0.5;
}

.display-no-messe h2 {
    font-size: 2rem;
    margin-bottom: 10px;
}

.display-no-messe p {
    opacity: 0.7;
    font-size: 1.1rem;
}

/* Navigation Dots */
.display-nav-dots {
    display: flex;
    justify-content: center;
    gap: 10px;
    padding: 15px;
    background: rgba(0,0,0,0.2);
}

.nav-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(255,255,255,0.3);
    border: none;
    cursor: pointer;
    transition: all 0.2s;
}

.nav-dot:hover {
    background: rgba(255,255,255,0.5);
}

.nav-dot.active {
    background: #48bb78;
    transform: scale(1.2);
}

/* Responsive */
@media (max-width: 900px) {
    .isidor-tagesplan-display .tagesplan-columns {
        grid-template-columns: 1fr;
    }
    
    .display-clock {
        font-size: 2rem;
    }
    
    .display-parish {
        font-size: 1.4rem;
    }
}

/* Print */
@media print {
    .isidor-tagesplan-display {
        background: white;
        color: black;
    }
    
    .display-header,
    .display-status,
    .display-controls,
    .display-nav-dots,
    .no-print {
        display: none !important;
    }
    
    .display-content {
        padding: 0;
        max-height: none;
    }
}
</style>

<script>
(function() {
    const display = document.getElementById('isidor-tagesplan-display');
    const messenData = JSON.parse(document.getElementById('messen-data').textContent || '[]');
    const autoRefresh = display.dataset.autoRefresh === 'true';
    let currentIndex = 0;
    let refreshInterval;
    
    // Uhr aktualisieren
    function updateClock() {
        const clock = document.getElementById('display-clock');
        if (clock) {
            const now = new Date();
            clock.textContent = now.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
        }
    }
    
    // Tagesplan laden
    function loadTagesplan(messeId) {
        const content = document.getElementById('display-content');
        const indicator = document.getElementById('status-indicator');
        const statusText = document.getElementById('status-text');
        
        indicator.classList.add('loading');
        statusText.textContent = 'Lädt...';
        
        fetch(isidorTagesplan.ajaxurl + '?action=isidor_tagesplan_preview&messe_id=' + messeId, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'messe_id=' + messeId
        })
        .then(r => r.json())
        .then(response => {
            if (response.success) {
                content.innerHTML = response.data.html;
                indicator.classList.remove('loading', 'error');
                statusText.textContent = 'Live';
            } else {
                indicator.classList.remove('loading');
                indicator.classList.add('error');
                statusText.textContent = 'Fehler';
            }
        })
        .catch(() => {
            indicator.classList.remove('loading');
            indicator.classList.add('error');
            statusText.textContent = 'Offline';
        });
    }
    
    // Navigation
    function showMesse(index) {
        if (messenData.length === 0) return;
        
        currentIndex = (index + messenData.length) % messenData.length;
        loadTagesplan(messenData[currentIndex]);
        
        // Dots aktualisieren
        document.querySelectorAll('.nav-dot').forEach((dot, i) => {
            dot.classList.toggle('active', i === currentIndex);
        });
        
        // Status aktualisieren
        const statusMesse = document.getElementById('status-messe');
        if (statusMesse && messenData.length > 1) {
            statusMesse.textContent = 'Messe ' + (currentIndex + 1) + ' von ' + messenData.length;
        }
    }
    
    // Event Listeners
    document.getElementById('btn-refresh')?.addEventListener('click', () => {
        if (messenData.length > 0) {
            loadTagesplan(messenData[currentIndex]);
        }
    });
    
    document.getElementById('btn-fullscreen')?.addEventListener('click', () => {
        if (document.fullscreenElement) {
            document.exitFullscreen();
        } else {
            display.requestFullscreen();
        }
    });
    
    document.getElementById('btn-prev-messe')?.addEventListener('click', () => {
        showMesse(currentIndex - 1);
    });
    
    document.getElementById('btn-next-messe')?.addEventListener('click', () => {
        showMesse(currentIndex + 1);
    });
    
    document.querySelectorAll('.nav-dot').forEach(dot => {
        dot.addEventListener('click', () => {
            showMesse(parseInt(dot.dataset.index));
        });
    });
    
    // Tastatur-Navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') showMesse(currentIndex - 1);
        if (e.key === 'ArrowRight') showMesse(currentIndex + 1);
        if (e.key === 'f' || e.key === 'F') {
            document.getElementById('btn-fullscreen')?.click();
        }
        if (e.key === 'r' || e.key === 'R') {
            document.getElementById('btn-refresh')?.click();
        }
    });
    
    // Init
    setInterval(updateClock, 1000);
    updateClock();
    
    if (autoRefresh && typeof isidorTagesplan !== 'undefined') {
        refreshInterval = setInterval(() => {
            if (messenData.length > 0) {
                loadTagesplan(messenData[currentIndex]);
            }
        }, isidorTagesplan.refresh_interval || 60000);
    }
})();
</script>
