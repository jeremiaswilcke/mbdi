<?php
/**
 * Template: Tagesplan-Anzeige
 * 
 * Variablen:
 * - $data: Tagesplan-Daten
 * - $template: Template-Konfiguration
 * - $print_mode: Boolean für Druckansicht
 */

if (!defined('ABSPATH')) exit;

$design = $template['design'] ?? [];
$primary_color = $design['primary_color'] ?? '#1a365d';
$compact = $design['compact_mode'] ?? false;
?>

<div class="isidor-tagesplan <?php echo $print_mode ? 'print-mode' : ''; ?> <?php echo $compact ? 'compact' : ''; ?>" 
     style="--isidor-primary: <?php echo esc_attr($primary_color); ?>">
    
    <?php if ($template['header']['enabled']): ?>
    <header class="tagesplan-header">
        <?php if ($template['header']['show_logo'] && !empty($data['logo_url'])): ?>
            <img src="<?php echo esc_url($data['logo_url']); ?>" alt="" class="tagesplan-logo">
        <?php endif; ?>
        
        <div class="tagesplan-header-content">
            <?php if ($template['header']['show_parish_name']): ?>
                <h1 class="tagesplan-parish"><?php echo esc_html($data['parish_name']); ?></h1>
            <?php endif; ?>
            
            <?php if ($template['header']['show_date']): ?>
                <p class="tagesplan-date"><?php echo esc_html($data['messe']['date_formatted'] ?? ''); ?></p>
            <?php endif; ?>
            
            <?php if ($template['header']['show_liturgical_day'] && !empty($data['messe']['liturgical_day'])): ?>
                <p class="tagesplan-liturgical"><?php echo esc_html($data['messe']['liturgical_day']); ?></p>
            <?php endif; ?>
        </div>
    </header>
    <?php endif; ?>
    
    <?php if ($template['messe_info']['enabled']): ?>
    <section class="tagesplan-section tagesplan-messe-info">
        <div class="tagesplan-time-box">
            <span class="tagesplan-time"><?php echo esc_html($data['messe']['time']); ?></span>
            <span class="tagesplan-time-label">Uhr</span>
        </div>
        
        <div class="tagesplan-messe-details">
            <?php if ($template['messe_info']['show_celebrant'] && !empty($data['messe']['celebrant'])): ?>
                <p><strong>Zelebrant:</strong> <?php echo esc_html($data['messe']['celebrant']); ?></p>
            <?php endif; ?>
            
            <?php if ($template['messe_info']['show_intention'] && !empty($data['messe']['intention'])): ?>
                <p><strong>Intention:</strong> <?php echo esc_html($data['messe']['intention']); ?></p>
            <?php endif; ?>
            
            <?php if (!empty($data['messe']['location'])): ?>
                <p><strong>Ort:</strong> <?php echo esc_html($data['messe']['location']); ?></p>
            <?php endif; ?>
            
            <?php if ($template['messe_info']['show_notes'] && !empty($data['messe']['notes'])): ?>
                <p class="tagesplan-notes"><?php echo esc_html($data['messe']['notes']); ?></p>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>
    
    <div class="tagesplan-columns">
        <?php if ($template['dienste']['enabled'] && !empty($data['dienste'])): ?>
        <section class="tagesplan-section tagesplan-dienste">
            <h2><?php echo esc_html($template['dienste']['title']); ?></h2>
            
            <table class="tagesplan-table">
                <tbody>
                    <?php foreach ($template['dienste']['slots'] as $slot_key => $slot_config): ?>
                        <?php if ($slot_config['enabled'] && isset($data['dienste'][$slot_key])): ?>
                        <tr>
                            <th><?php echo esc_html($slot_config['label']); ?></th>
                            <td>
                                <?php echo esc_html($data['dienste'][$slot_key]['user_name']); ?>
                                <?php if (!empty($data['dienste'][$slot_key]['is_backup'])): ?>
                                    <span class="badge badge-backup">Vertretung</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <?php endif; ?>
        
        <?php if ($template['lieder']['enabled'] && !empty($data['lieder'])): ?>
        <section class="tagesplan-section tagesplan-lieder">
            <h2><?php echo esc_html($template['lieder']['title']); ?></h2>
            
            <table class="tagesplan-table tagesplan-lieder-table">
                <tbody>
                    <?php foreach ($template['lieder']['slots'] as $slot_key => $slot_config): ?>
                        <?php if ($slot_config['enabled'] && isset($data['lieder'][$slot_key])): 
                            $lied = $data['lieder'][$slot_key];
                        ?>
                        <tr>
                            <th><?php echo esc_html($slot_config['label']); ?></th>
                            <td>
                                <?php if (!empty($lied['number'])): ?>
                                    <span class="lied-number">
                                        <?php if ($template['lieder']['show_songbook']): ?>
                                            <?php echo esc_html($lied['songbook']); ?>
                                        <?php endif; ?>
                                        <?php echo esc_html($lied['number']); ?>
                                    </span>
                                    <?php if ($template['lieder']['show_strophes'] && !empty($lied['strophes'])): ?>
                                        <span class="lied-strophes">(Str. <?php echo esc_html($lied['strophes']); ?>)</span>
                                    <?php endif; ?>
                                    <?php if (!empty($lied['title'])): ?>
                                        <span class="lied-title lied-subtitle"><?php echo esc_html($lied['title']); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="lied-title"><?php echo esc_html($lied['title']); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <?php endif; ?>
    </div>
    
    <?php if ($template['lesungen']['enabled']): ?>
    <?php 
    $has_any_reading = !empty($data['lesungen']['lesung1']) 
                    || !empty($data['lesungen']['lesung2']) 
                    || !empty($data['lesungen']['antwortpsalm'])
                    || !empty($data['lesungen']['evangelium']);
    ?>
    <?php if ($has_any_reading): ?>
    <section class="tagesplan-section tagesplan-lesungen">
        <h2>
            <?php echo esc_html($template['lesungen']['title']); ?>
            <?php 
            // Liturgische Farbe als Badge
            $farbe_map = ['w' => ['⬜', 'Weiß'], 'r' => ['🟥', 'Rot'], 'v' => ['🟪', 'Violett'], 'g' => ['🟩', 'Grün']];
            $farbe = $data['lesungen']['lit_farbe'] ?? '';
            if ($farbe && isset($farbe_map[$farbe])): ?>
                <span class="tagesplan-lit-farbe" title="Liturgische Farbe: <?php echo esc_attr($farbe_map[$farbe][1]); ?>" 
                      style="font-size:0.7em; vertical-align:middle; margin-left:8px;">
                    <?php echo $farbe_map[$farbe][0]; ?> <?php echo esc_html($farbe_map[$farbe][1]); ?>
                </span>
            <?php endif; ?>
        </h2>
        
        <div class="tagesplan-lesungen-grid">
            <?php if ($template['lesungen']['show_lesung1'] && !empty($data['lesungen']['lesung1'])): ?>
            <div class="tagesplan-lesung">
                <strong>1. Lesung</strong>
                <span><?php echo esc_html($data['lesungen']['lesung1']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($data['lesungen']['antwortpsalm'])): ?>
            <div class="tagesplan-lesung">
                <strong>Antwortpsalm</strong>
                <span><?php echo esc_html($data['lesungen']['antwortpsalm']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if ($template['lesungen']['show_lesung2'] && !empty($data['lesungen']['lesung2'])): ?>
            <div class="tagesplan-lesung">
                <strong>2. Lesung</strong>
                <span><?php echo esc_html($data['lesungen']['lesung2']); ?></span>
            </div>
            <?php endif; ?>
            
            <?php if ($template['lesungen']['show_evangelium'] && !empty($data['lesungen']['evangelium'])): ?>
            <div class="tagesplan-lesung">
                <strong>Evangelium</strong>
                <span><?php echo esc_html($data['lesungen']['evangelium']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($data['lesungen']['schott_url'])): ?>
        <div class="tagesplan-schott-link" style="margin-top:10px; text-align:right;">
            <a href="<?php echo esc_url($data['lesungen']['schott_url']); ?>" target="_blank" rel="noopener"
               style="font-size:0.88em; color:var(--is-primary,#2563eb); text-decoration:none;">
                📕 Texte im Schott →
            </a>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php if ($template['hinweise']['enabled'] && !empty($data['hinweise'])): ?>
    <section class="tagesplan-section tagesplan-hinweise">
        <h2><?php echo esc_html($template['hinweise']['title']); ?></h2>
        <div class="tagesplan-hinweise-content">
            <?php echo wp_kses_post(nl2br($data['hinweise'])); ?>
        </div>
    </section>
    <?php endif; ?>
    
    <?php if ($template['footer']['enabled']): ?>
    <footer class="tagesplan-footer">
        <?php if ($template['footer']['show_generated_time']): ?>
            <span class="tagesplan-generated">
                Stand: <?php echo esc_html(wp_date('d.m.Y H:i')); ?>
            </span>
        <?php endif; ?>
        
        <?php if (!empty($template['footer']['custom_text'])): ?>
            <span class="tagesplan-custom-footer">
                <?php echo esc_html($template['footer']['custom_text']); ?>
            </span>
        <?php endif; ?>
    </footer>
    <?php endif; ?>
    
    <?php if (!$print_mode): ?>
    <div class="tagesplan-actions no-print">
        <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'pdf', 'messe_id' => $data['messe_id']], home_url())); ?>" 
           class="isidor-btn isidor-btn-primary" target="_blank">
            📄 PDF herunterladen
        </a>
        <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'html', 'messe_id' => $data['messe_id']], home_url())); ?>" 
           class="isidor-btn isidor-btn-secondary" target="_blank">
            🖨️ Drucken
        </a>
        <a href="<?php echo esc_url(add_query_arg(['isidor_tagesplan_export' => 'json', 'messe_id' => $data['messe_id']], home_url())); ?>" 
           class="isidor-btn isidor-btn-ghost" target="_blank">
            📊 JSON Export
        </a>
    </div>
    <?php endif; ?>
</div>
