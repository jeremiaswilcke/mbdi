<?php
/**
 * Template: Tagesplan Template-Editor
 * 
 * Variablen: $template, $parish_name, $logo_url
 */
if (!defined('ABSPATH')) exit;

$default_dienst_slots = [
    'celebrant' => 'Zelebrant', 'diakon' => 'Diakon',
    'lektor1' => 'Lektor 1', 'lektor2' => 'Lektor 2',
    'kommunion' => 'Kommunionhelfer', 'ministrant' => 'Ministranten',
    'mesner' => 'Mesner', 'orgel' => 'Orgel',
    'kantor' => 'Kantor', 'technik' => 'Technik',
];

$default_lieder_slots = [
    1 => 'Einzug', 2 => 'Kyrie', 3 => 'Gloria', 4 => 'Psalm',
    5 => 'Ruf vor dem Evangelium', 6 => 'Gabenbereitung',
    7 => 'Sanctus', 8 => 'Agnus Dei', 9 => 'Kommunion',
    10 => 'Danklied', 11 => 'Auszug',
];
?>

<div class="wrap">
    <h1>📋 Tagesplan – Template bearbeiten</h1>
    <p>Bestimmen Sie, welche Abschnitte und Felder im Tagesplan erscheinen.</p>
    
    <form method="post">
        <?php wp_nonce_field('isidor_tagesplan_template'); ?>
        
        <div style="display:grid; grid-template-columns:1fr 380px; gap:20px; margin-top:20px;">
            
            <!-- ============================================================ -->
            <!-- LINKE SPALTE: Alle Sektionen                                 -->
            <!-- ============================================================ -->
            <div>
                
                <!-- Grundeinstellungen -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">⛪ Grundeinstellungen</h2>
                    <table class="form-table">
                        <tr>
                            <th>Pfarreiname</th>
                            <td>
                                <strong><?php echo esc_html($parish_name); ?></strong>
                                <?php if ($logo_url): ?>
                                    <img src="<?php echo esc_url($logo_url); ?>" style="height:28px; vertical-align:middle; margin-left:12px; border-radius:4px;">
                                <?php endif; ?>
                                <p class="description">
                                    Diese Daten werden zentral verwaltet → 
                                    <a href="<?php echo admin_url('admin.php?page=isidor-parish'); ?>">⛪ Pfarrei-Einstellungen</a>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Header -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[header][enabled]" value="1" <?php checked($template['header']['enabled'] ?? true); ?>> Kopfbereich</label>
                    </h2>
                    <div class="tpl-options">
                        <?php foreach ([
                            'show_parish_name' => 'Pfarreiname anzeigen',
                            'show_date' => 'Datum anzeigen',
                            'show_liturgical_day' => 'Liturgischen Tag anzeigen',
                            'show_logo' => 'Logo anzeigen',
                        ] as $key => $label): ?>
                            <label class="tpl-check"><input type="checkbox" name="template[header][<?php echo $key; ?>]" value="1" <?php checked($template['header'][$key] ?? true); ?>> <?php echo $label; ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Messe-Info -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[messe_info][enabled]" value="1" <?php checked($template['messe_info']['enabled'] ?? true); ?>> Messe-Informationen</label>
                    </h2>
                    <div class="tpl-options">
                        <?php foreach ([
                            'show_time' => 'Uhrzeit',
                            'show_celebrant' => 'Zelebrant',
                            'show_intention' => 'Intention',
                            'show_notes' => 'Notizen',
                        ] as $key => $label): ?>
                            <label class="tpl-check"><input type="checkbox" name="template[messe_info][<?php echo $key; ?>]" value="1" <?php checked($template['messe_info'][$key] ?? true); ?>> <?php echo $label; ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Dienste -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[dienste][enabled]" value="1" <?php checked($template['dienste']['enabled'] ?? true); ?>> Dienste</label>
                    </h2>
                    
                    <div style="margin:12px 0;">
                        <label>Überschrift: </label>
                        <input type="text" name="template[dienste][title]" value="<?php echo esc_attr($template['dienste']['title'] ?? 'Dienste'); ?>" class="regular-text">
                    </div>
                    
                    <table class="widefat striped" style="margin-top:10px;">
                        <thead><tr><th style="width:40px">✓</th><th>Schlüssel</th><th>Anzeige-Label</th></tr></thead>
                        <tbody>
                            <?php foreach ($default_dienst_slots as $key => $fallback):
                                $slot = $template['dienste']['slots'][$key] ?? ['enabled' => true, 'label' => $fallback]; ?>
                                <tr>
                                    <td><input type="checkbox" name="template[dienste][slots][<?php echo $key; ?>][enabled]" value="1" <?php checked($slot['enabled'] ?? true); ?>></td>
                                    <td><code><?php echo $key; ?></code></td>
                                    <td><input type="text" name="template[dienste][slots][<?php echo $key; ?>][label]" value="<?php echo esc_attr($slot['label'] ?? $fallback); ?>" style="width:100%;"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Lieder -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[lieder][enabled]" value="1" <?php checked($template['lieder']['enabled'] ?? true); ?>> Lieder</label>
                    </h2>
                    
                    <div style="margin:12px 0;">
                        <label>Überschrift: </label>
                        <input type="text" name="template[lieder][title]" value="<?php echo esc_attr($template['lieder']['title'] ?? 'Lieder'); ?>" class="regular-text">
                    </div>
                    
                    <div class="tpl-options" style="margin-bottom:15px;">
                        <label class="tpl-check"><input type="checkbox" name="template[lieder][show_strophes]" value="1" <?php checked($template['lieder']['show_strophes'] ?? true); ?>> Strophen anzeigen</label>
                        <label class="tpl-check"><input type="checkbox" name="template[lieder][show_songbook]" value="1" <?php checked($template['lieder']['show_songbook'] ?? true); ?>> Liederbuch anzeigen (GL, EG …)</label>
                    </div>
                    
                    <table class="widefat striped">
                        <thead><tr><th style="width:40px">✓</th><th>Nr.</th><th>Anzeige-Label</th></tr></thead>
                        <tbody>
                            <?php foreach ($default_lieder_slots as $key => $fallback):
                                $slot = $template['lieder']['slots'][$key] ?? ['enabled' => true, 'label' => $fallback]; ?>
                                <tr>
                                    <td><input type="checkbox" name="template[lieder][slots][<?php echo $key; ?>][enabled]" value="1" <?php checked($slot['enabled'] ?? true); ?>></td>
                                    <td><?php echo $key; ?></td>
                                    <td><input type="text" name="template[lieder][slots][<?php echo $key; ?>][label]" value="<?php echo esc_attr($slot['label'] ?? $fallback); ?>" style="width:100%;"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Lesungen -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[lesungen][enabled]" value="1" <?php checked($template['lesungen']['enabled'] ?? true); ?>> Lesungen</label>
                    </h2>
                    <div style="margin:12px 0;">
                        <label>Überschrift: </label>
                        <input type="text" name="template[lesungen][title]" value="<?php echo esc_attr($template['lesungen']['title'] ?? 'Lesungen'); ?>" class="regular-text">
                    </div>
                    <div class="tpl-options">
                        <label class="tpl-check"><input type="checkbox" name="template[lesungen][show_lesung1]" value="1" <?php checked($template['lesungen']['show_lesung1'] ?? true); ?>> 1. Lesung</label>
                        <label class="tpl-check"><input type="checkbox" name="template[lesungen][show_lesung2]" value="1" <?php checked($template['lesungen']['show_lesung2'] ?? true); ?>> 2. Lesung</label>
                        <label class="tpl-check"><input type="checkbox" name="template[lesungen][show_evangelium]" value="1" <?php checked($template['lesungen']['show_evangelium'] ?? true); ?>> Evangelium</label>
                    </div>
                </div>
                
                <!-- Hinweise -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[hinweise][enabled]" value="1" <?php checked($template['hinweise']['enabled'] ?? true); ?>> Hinweise &amp; Ankündigungen</label>
                    </h2>
                    <div style="margin:12px 0;">
                        <label>Überschrift: </label>
                        <input type="text" name="template[hinweise][title]" value="<?php echo esc_attr($template['hinweise']['title'] ?? 'Hinweise & Ankündigungen'); ?>" class="regular-text">
                    </div>
                </div>
                
                <!-- Footer -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">
                        <label><input type="checkbox" name="template[footer][enabled]" value="1" <?php checked($template['footer']['enabled'] ?? true); ?>> Fußzeile</label>
                    </h2>
                    <div class="tpl-options">
                        <label class="tpl-check"><input type="checkbox" name="template[footer][show_generated_time]" value="1" <?php checked($template['footer']['show_generated_time'] ?? true); ?>> Erzeugungszeitpunkt anzeigen</label>
                    </div>
                    <div style="margin-top:12px;">
                        <label>Eigener Text: </label>
                        <input type="text" name="template[footer][custom_text]" value="<?php echo esc_attr($template['footer']['custom_text'] ?? ''); ?>" class="regular-text" placeholder="z.B. Ad maiorem Dei gloriam">
                    </div>
                </div>
                
                <!-- Design -->
                <div class="tpl-card">
                    <h2 class="tpl-heading">🎨 Design</h2>
                    <table class="form-table">
                        <tr>
                            <th>Primärfarbe</th>
                            <td><input type="color" name="template[design][primary_color]" value="<?php echo esc_attr($template['design']['primary_color'] ?? '#1a365d'); ?>"></td>
                        </tr>
                        <tr>
                            <th>Schriftgröße (Basis)</th>
                            <td>
                                <input type="number" name="template[design][font_size_base]" value="<?php echo intval($template['design']['font_size_base'] ?? 12); ?>" min="8" max="18" style="width:70px;"> pt
                            </td>
                        </tr>
                        <tr>
                            <th>Kompakt-Modus</th>
                            <td>
                                <label><input type="checkbox" name="template[design][compact_mode]" value="1" <?php checked($template['design']['compact_mode'] ?? false); ?>> Weniger Abstände für kleinere Ausdrucke</label>
                            </td>
                        </tr>
                    </table>
                </div>
                
            </div><!-- /linke Spalte -->
            
            <!-- ============================================================ -->
            <!-- RECHTE SPALTE: Speichern + Info                              -->
            <!-- ============================================================ -->
            <div>
                <!-- Speichern -->
                <div class="tpl-card" style="position:sticky; top:40px;">
                    <button type="submit" name="save_template" class="button button-primary button-hero" style="width:100%;">
                        💾 Template speichern
                    </button>
                    
                    <p style="margin-top:15px; text-align:center; font-size:0.9em; opacity:0.7;">
                        Änderungen wirken sich sofort auf alle Tagespläne aus.
                    </p>
                    
                    <hr style="margin:20px 0;">
                    
                    <h3 style="margin-top:0;">🔎 So funktioniert's</h3>
                    <ul style="font-size:0.92em; line-height:1.7;">
                        <li><strong>Sektionen</strong> – Aktivieren/deaktivieren Sie ganze Bereiche über die Hauptcheckbox.</li>
                        <li><strong>Felder</strong> – Innerhalb jeder Sektion können Sie einzelne Felder ein-/ausblenden.</li>
                        <li><strong>Labels</strong> – Passen Sie die Bezeichnungen an Ihre Pfarrei an.</li>
                        <li><strong>Reihenfolge</strong> – Ist fix (Header → Messe → Dienste → Lieder → Lesungen → Hinweise → Footer).</li>
                    </ul>
                    
                    <hr style="margin:20px 0;">
                    
                    <h3>📤 Export-URLs</h3>
                    <p style="font-size:0.88em;">Ersetzen Sie <code>{ID}</code> durch die Messe-ID:</p>
                    <div class="tpl-url-box">
                        <code>?isidor_tagesplan_export=pdf&amp;messe_id={ID}</code>
                    </div>
                    <div class="tpl-url-box">
                        <code>?isidor_tagesplan_export=json&amp;messe_id={ID}</code>
                    </div>
                    <div class="tpl-url-box">
                        <code>?isidor_tagesplan_export=html&amp;messe_id={ID}</code>
                    </div>
                    
                    <hr style="margin:20px 0;">
                    
                    <h3>📺 Display-Seite</h3>
                    <p style="font-size:0.88em;">Erstellen Sie eine Seite mit diesem Shortcode für den Monitor in der Sakristei oder an der Orgel:</p>
                    <div class="tpl-url-box">
                        <code>[isidor_tagesplan_display]</code>
                    </div>
                    <p style="font-size:0.85em; opacity:0.7;">
                        Aktualisiert sich automatisch. Vollbild per <kbd>F</kbd>-Taste.
                    </p>
                    
                    <hr style="margin:20px 0;">
                    
                    <a href="<?php echo admin_url('admin.php?page=isidor-tagesplan'); ?>" class="button" style="width:100%; text-align:center;">
                        ← Zurück zum Tagesplan
                    </a>
                </div>
            </div><!-- /rechte Spalte -->
            
        </div>
    </form>
</div>

<style>
.tpl-card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}
.tpl-heading {
    margin: 0 0 15px;
    font-size: 1.15em;
    padding-bottom: 10px;
    border-bottom: 2px solid #e2e8f0;
}
.tpl-options {
    margin-left: 24px;
}
.tpl-check {
    display: block;
    margin: 8px 0;
    cursor: pointer;
}
.tpl-url-box {
    background: #f0f4f8;
    padding: 8px 12px;
    border-radius: 4px;
    margin: 8px 0;
    word-break: break-all;
}
.tpl-url-box code {
    font-size: 0.85em;
}
kbd {
    background: #edf2f7;
    border: 1px solid #cbd5e0;
    border-radius: 3px;
    padding: 1px 5px;
    font-size: 0.9em;
}
</style>
